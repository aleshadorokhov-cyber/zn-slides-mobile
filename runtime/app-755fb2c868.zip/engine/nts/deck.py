# -*- coding: utf-8 -*-
"""
deck.py — РАБОТА С ПРЕЗЕНТАЦИЕЙ ЦЕЛИКОМ: шаблон, макеты, новые слайды, сохранение
===============================================================================

Класс Deck — «обёртка» над объектом Presentation из python-pptx. Он:
  1) открывает базовую презентацию (корпоративный шаблон с мастером, темой и
     встроенными шрифтами);
  2) оставляет в ней только первый (титульный) слайд — остальные удаляет;
  3) даёт удобный метод new_slide() — новый слайд нужного макета с заголовком,
     подзаголовком, подписью раздела в подвале и заметками докладчика;
  4) сохраняет результат.

Почему берётся готовая презентация, а не пустой шаблон: в ней уже есть правильный
титульный слайд, а главное — корпоративный мастер с фирменными фонами, логотипом,
подвалом и встроенными шрифтами. Наш код рисует только СОДЕРЖИМОЕ слайдов.
"""
from pptx import Presentation

from . import config as C


class Deck:
    def __init__(self, template=C.TEMPLATE, keep_first_slide=True, theme=None):
        """template — путь к базовой .pptx; keep_first_slide — оставить её титульный слайд;
        theme — свой шаблон пользователя (nts/theme.py): макеты берутся по его ролям, все слайды
        шаблона удаляются (титульный создаётся заново по его титульному макету)."""
        self.prs = Presentation(str(template))
        self.theme = theme
        if theme is not None:
            self.L_TITLE = theme.layout(self.prs, 'title')
            self.L_WHITE = self.L_DARK = theme.layout(self.prs, 'content')
            self.L_END = theme.layout(self.prs, 'end')
            self._drop_slides(keep=0)
            return
        layouts = self.prs.slide_masters[0].slide_layouts
        # Макеты, которые используются в презентации (номера — в config.py)
        self.L_TITLE = layouts[C.LAYOUT_TITLE]
        self.L_WHITE = layouts[C.LAYOUT_WHITE]
        self.L_DARK = layouts[C.LAYOUT_DARK]
        self.L_END = layouts[C.LAYOUT_END]
        self._drop_slides(keep=1 if keep_first_slide else 0)

    # ----------------------------------------------------------------------------------
    def _drop_slides(self, keep=1):
        """Удаляет из презентации все слайды, кроме первых keep.

        Слайд удаляется в два шага: убирается ссылка на его файл (drop_rel) и запись
        из списка слайдов (sldIdLst). Макеты и мастер при этом не трогаются.
        """
        sldIdLst = self.prs.slides._sldIdLst
        for sldId in list(sldIdLst)[keep:]:
            self.prs.part.drop_rel(sldId.rId)
            sldIdLst.remove(sldId)

    # ----------------------------------------------------------------------------------
    def new_slide(self, layout, title, subtitle=None, footer=None, notes=None):
        """Добавляет слайд по макету layout и заполняет стандартные заполнители.

        title    — заголовок слайда (заполнитель №0);
        subtitle — подзаголовок (заполнитель №2); если не задан — заполнитель удаляется,
                   чтобы на слайде не осталось надписи «Подзаголовок слайда»;
        footer   — короткая подпись раздела в подвале (заполнитель №10);
        notes    — текст заметок докладчика (виден в режиме докладчика и в «Заметках»).
        Возвращает созданный слайд.
        """
        sl = self.prs.slides.add_slide(layout)
        for ph in sl.placeholders:
            idx = ph.placeholder_format.idx
            if idx == C.PH_TITLE:
                ph.text_frame.text = title
            elif idx == C.PH_SUBTITLE:
                ph.text_frame.text = subtitle or ''
            elif idx == C.PH_FOOTER:
                ph.text_frame.text = footer or ''
        for ph in list(sl.placeholders):
            if ph.placeholder_format.idx == C.PH_SUBTITLE and not subtitle:
                ph._element.getparent().remove(ph._element)
        if notes:
            sl.notes_slide.notes_text_frame.text = notes
        return sl

    # ----------------------------------------------------------------------------------
    @staticmethod
    def ph_shape(sl, idx):
        """Возвращает заполнитель слайда с номером idx (или None)."""
        for ph in sl.placeholders:
            if ph.placeholder_format.idx == idx:
                return ph

    # ----------------------------------------------------------------------------------
    def save(self, path):
        """Сохраняет презентацию (папка создаётся при необходимости)."""
        path.parent.mkdir(parents=True, exist_ok=True)
        self.prs.save(str(path))
        return path
