# -*- coding: utf-8 -*-
"""
effects.py — ВИЗУАЛЬНЫЕ ЭФФЕКТЫ ФИГУР (тени, свечение, прозрачность, градиенты)
==============================================================================

python-pptx «из коробки» умеет только заливку и контур. Тени, свечение, прозрачность
и тонкие настройки геометрии он не поддерживает, поэтому здесь мы напрямую дописываем
XML-разметку DrawingML (формат, в котором PowerPoint хранит фигуры).

Как это устроено внутри файла .pptx (упрощённо):
    <p:sp>                      ← фигура
      <p:spPr>                  ← свойства фигуры
        <a:prstGeom prst="rect">  ← геометрия (тип фигуры + настройки avLst)
        <a:solidFill>…</a:solidFill>   ← заливка
        <a:ln>…</a:ln>                 ← контур
        <a:effectLst>                  ← СПИСОК ЭФФЕКТОВ (порядок важен!)
          <a:glow …/>                  ← 1) свечение
          <a:outerShdw …/>             ← 2) внешняя тень
        </a:effectLst>
      </p:spPr>
    </p:sp>

ВАЖНО: в <a:effectLst> PowerPoint требует строгий порядок: glow раньше outerShdw.
Если порядок нарушить, PowerPoint сочтёт файл повреждённым. Функции ниже это учитывают.

Единицы внутри XML:
  * расстояния — EMU (1 пт = 12 700 EMU; функция Pt() переводит пункты в EMU);
  * прозрачность (alpha) — в тысячных долях процента: 20 % → 20000;
  * углы — в 60 000-х долях градуса: 90° → 5 400 000.
"""
from lxml import etree
from pptx.oxml.ns import qn
from pptx.util import Pt

from .config import rgb


def no_shadow(shape):
    """Отключает тень темы у фигуры.

    Корпоративная тема задаёт фигурам тень «по умолчанию». Пустой <a:effectLst/>
    означает «эффектов нет» — так фигуры выглядят плоскими и чистыми.
    Вызывается автоматически в rect() и freeform().
    """
    spPr = shape._element.spPr
    if spPr.find(qn('a:effectLst')) is None:
        spPr.append(etree.SubElement(spPr, qn('a:effectLst')))


def shadow(shape, blur=12, dist=3, alpha=20, color='1F2A44', dir_=5400000):
    """Мягкая внешняя тень — «приподнимает» карточку над фоном.

    Параметры:
        blur  — размытие, пт (8–14 — мягкая «воздушная» тень; больше — расплывчатее);
        dist  — смещение тени от фигуры, пт (2–4 — едва заметный подъём);
        alpha — непрозрачность тени, % (14–25 — деликатно; 35 — для тёмного фона);
        color — цвет тени 'RRGGBB' (по умолчанию тёмно-синий, а не чёрный — мягче);
        dir_  — направление тени в 60000-х долях градуса (5400000 = 90° = вниз).

    Правило дизайна: тень одинакового «характера» на всём слайде, иначе карточки
    будут выглядеть как из разных презентаций.
    Возвращает ту же фигуру (удобно писать shadow(rect(...), ...)).
    """
    spPr = shape._element.spPr
    eff = spPr.find(qn('a:effectLst'))
    if eff is None:
        eff = etree.SubElement(spPr, qn('a:effectLst'))
    for c in list(eff):          # убираем прежние эффекты, чтобы не дублировать
        eff.remove(c)
    sh = etree.SubElement(eff, qn('a:outerShdw'))
    sh.set('blurRad', str(int(Pt(blur))))
    sh.set('dist', str(int(Pt(dist))))
    sh.set('dir', str(dir_))
    sh.set('algn', 't')               # тень «привязана» к верху фигуры
    sh.set('rotWithShape', '0')       # не поворачивать тень вместе с фигурой
    c = etree.SubElement(sh, qn('a:srgbClr'))
    c.set('val', color)
    etree.SubElement(c, qn('a:alpha')).set('val', str(alpha * 1000))
    return shape


def glow(shape, color='9AC854', rad=8, alpha=55):
    """Свечение вокруг фигуры — выделяет главный элемент слайда (центр мишени,
    плашку «Робот — мост через разрыв», ядро цикла).

    Параметры: color — цвет свечения, rad — радиус в пт, alpha — непрозрачность в %.
    Правило дизайна: свечение — максимум у 1–2 элементов на слайде, иначе пропадает акцент.
    Свечение вставляется ПЕРВЫМ в список эффектов (требование формата, см. выше),
    поэтому glow() можно вызывать и до, и после shadow().
    """
    spPr = shape._element.spPr
    eff = spPr.find(qn('a:effectLst'))
    if eff is None:
        eff = etree.SubElement(spPr, qn('a:effectLst'))
    g_ = etree.Element(qn('a:glow'))
    g_.set('rad', str(int(Pt(rad))))
    c = etree.SubElement(g_, qn('a:srgbClr'))
    c.set('val', color)
    etree.SubElement(c, qn('a:alpha')).set('val', str(alpha * 1000))
    eff.insert(0, g_)   # glow обязан стоять раньше outerShdw
    return shape


def alpha_fill(shape, hexcol, alpha):
    """Полупрозрачная заливка фигуры (alpha — непрозрачность в %, 0…100).

    В текущих слайдах не используется — оставлена для новых слайдов
    (например, полупрозрачная плашка поверх картинки).
    """
    shape.fill.solid()
    shape.fill.fore_color.rgb = rgb(hexcol)
    clr = shape._element.spPr.find(qn('a:solidFill')).find(qn('a:srgbClr'))
    etree.SubElement(clr, qn('a:alpha')).set('val', str(alpha * 1000))


def text_alpha(tb, alpha):
    """Делает ТЕКСТ полупрозрачным (alpha — непрозрачность в %).

    Используется для больших «фоновых» цифр 1…6 на плитках слайда «Выводы»:
    цифра 64 пт с непрозрачностью ~20 % — декоративный элемент, не спорящий с текстом.
    Работает для всех фрагментов текста, у которых задан цвет.
    """
    for r in tb._element.iter(qn('a:rPr')):
        sf = r.find(qn('a:solidFill'))
        if sf is not None:
            c = sf.find(qn('a:srgbClr'))
            if c is not None:
                etree.SubElement(c, qn('a:alpha')).set('val', str(alpha * 1000))


def grad(shape, c1, c2, angle=0):
    """Линейный градиент заливки из цвета c1 в цвет c2.

    angle — направление в градусах: 0 — слева направо, 90 — сверху вниз,
    45 — по диагонали. Правило дизайна: градиент только между «соседними» цветами
    палитры (NAVY→BLUE, DGREEN→GREEN) — так он выглядит объёмно, а не пёстро.
    """
    f = shape.fill
    f.gradient()
    f.gradient_angle = angle
    st = f.gradient_stops
    st[0].color.rgb = c1
    st[0].position = 0.0
    st[1].color.rgb = c2
    st[1].position = 1.0
    return shape


def set_av(shape, vals):
    """Задаёт «регуляторы» (adjust values) стандартной фигуры PowerPoint.

    У многих фигур есть жёлтые «ромбики»-регуляторы (скругление, угол дуги, глубина
    шеврона). В XML это <a:avLst><a:gd name="adj1" fmla="val 123"/></a:avLst>.
    vals — словарь {'adj1': число, 'adj2': число}.

    Пример — дуга (MSO_SHAPE.ARC): adj1 / adj2 — начальный и конечный угол
    в 60000-х долях градуса, отсчёт от направления «вправо» (3 часа) по часовой стрелке.
    Так на слайде 2 рисуется арка «моста» (верхняя полуокружность, 180°→0°).
    """
    av = shape._element.spPr.find(qn('a:prstGeom')).find(qn('a:avLst'))
    for g in list(av):
        av.remove(g)
    for k, v in vals.items():
        gd = etree.SubElement(av, qn('a:gd'))
        gd.set('name', k)
        gd.set('fmla', f'val {int(v)}')
