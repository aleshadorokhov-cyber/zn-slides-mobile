# -*- coding: utf-8 -*-
"""
planner_llm.py — ПЛАНИРОВЩИК С ЛОКАЛЬНОЙ МОДЕЛЬЮ ИИ
==================================================

Два уровня участия модели (options['ai_level']):

  'fast' (по умолчанию) — БЫСТРО. Модель получает КОРОТКУЮ выжимку (заголовки разделов,
      первые фразы, названия списков и таблиц) и отвечает только СТРУКТУРОЙ: какие слайды,
      в каком порядке, с какими макетами и заголовками и из какого раздела (S3) или
      таблицы (T1) брать содержимое. Тексты, числа и заметки докладчика подставляет код —
      теми же правилами, что и режим «По правилам». Ответ модели — 300–900 токенов,
      поэтому даже на процессоре план готов за минуты, а не за десятки минут.

  'full' — ПОЛНОСТЬЮ. Модель получает полную выжимку и сама пишет тексты элементов,
      подзаголовки и выводы (ответ 2–4 тыс. токенов; в 3–5 раз дольше). Числа для диаграмм,
      таблиц и KPI модель всё равно НЕ пишет — только ссылку на таблицу, данные подставляет
      код. Числа в плитках KPI проверяются по тексту документа: «придуманные» убираются.

Общее:
  * выжимка помечена метками S1…Sn (разделы) и T1…Tn (таблицы);
  * заметки докладчика берутся из текста раздела (модель их не пишет — это экономит
    до половины времени ответа);
  * ответ разбирается терпимо (JSON внутри текста, ```json```, <think>…);
  * при любой ошибке вызывающая функция (engine.analyze) строит план по правилам.
"""
import copy
import difflib
import json
import re

from .chart_types import TYPES as EXT_CHART
from .chart_types import prepare as chart_prepare
from .insights import choose_chart, kpi_from_table, make_insights
from .llm_client import Cancelled, LLMError, chat, estimate_tokens, extract_json  # noqa: F401
from .planner_rules import _notes, _table_slides, section_slides
from .spec import LAYOUTS, normalize
from .textutil import parse_number, shorten

# --------------------------------------------------------------------------------------
# Промпты
# --------------------------------------------------------------------------------------
_HEAD = """Ты — опытный автор деловых презентаций для научно-технического совета нефтегазовой компании.
Пиши по-русски, деловым стилем, без воды и без разметки Markdown. Используй ТОЛЬКО факты из документа."""

_LOGIC = """Логика доклада: зачем (актуальность, проблема) → цель и задачи → решение и как оно работает →
данные и результаты → эффект → выводы. Порядок слайдов может отличаться от порядка разделов документа.
На слайде — одна мысль. Заголовок слайда — до 60 символов и формулирует эту мысль.
Макет выбирай по содержимому: шаги → process или timeline; цель и задачи → target; числа с единицами → kpi;
было/стало или плюсы/минусы → compare; абзацы без списков → text; выводы → conclusions;
равноправные тезисы → cards; много коротких пунктов → list; таблица с числами → chart."""

SYSTEM_FAST = _HEAD + """
Твоя задача — по выжимке документа составить СТРУКТУРУ презентации в формате JSON.
Тексты слайдов писать НЕ нужно: содержимое каждого слайда приложение само возьмёт из указанного
раздела или таблицы документа.

ПРАВИЛА
1. Для каждого содержательного слайда укажи: layout (макет из каталога), title (заголовок),
   src — метка раздела ("S3") или таблицы ("T1"), откуда брать содержимое; subtitle — необязательно
   (одна фраза до 100 символов).
2. """ + _LOGIC + """
3. Один раздел — обычно один слайд; большой раздел можно показать двумя слайдами с разными макетами.
   Второстепенные разделы пропускай. Метки src — только из выжимки, не выдумывай.
4. Для chart можно указать chart_type: column | bar | line | area | pie | doughnut | stacked | radar
   (radar — профиль по 4–10 критериям одной шкалы; area — объём или накопленный итог во времени),
   а для особых данных: waterfall (было → изменения → стало), funnel_chart (этапы), pareto (причины по
   убыванию), scatter_trend (зависимость двух величин), histogram (распределение измерений), treemap (много долей).
5. Разделы и фрагменты со знаком ★ автор выделил как главные: обязательно покажи их на отдельных
   слайдах и не пропускай.
6. Служебные слайды без src: title (всегда первый), agenda (содержание — если разделов 4 и больше),
   section (разделитель с названием части — только в длинных докладах), end (всегда последний).

МАКЕТЫ (поле layout)
{catalog}

ФОРМАТ ОТВЕТА — только JSON-объект, без пояснений:
{{"slides": [
  {{"layout": "title"}},
  {{"layout": "agenda", "title": "Содержание"}},
  {{"layout": "cards", "title": "…", "src": "S2"}},
  {{"layout": "target", "title": "…", "src": "S3"}},
  {{"layout": "chart", "title": "…", "src": "T1", "chart_type": "column"}},
  {{"layout": "kpi", "title": "…", "src": "S6"}},
  {{"layout": "conclusions", "title": "Выводы", "src": "S9"}},
  {{"layout": "end"}}
]}}"""

SYSTEM_FULL = _HEAD + """
Твоя задача — по выжимке документа составить ПЛАН презентации в формате JSON.

ПРАВИЛА СОДЕРЖАНИЯ
1. """ + _LOGIC + """
2. Подзаголовок (subtitle) — одна фраза до 100 символов (можно пусто).
   Элемент (items): title — 2–4 слова, text — одно предложение до 120 символов.
   conclusion — необязательный вывод одной фразой внизу слайда (до 150 символов).
3. У каждого содержательного слайда укажи src — метку раздела ("S3") или таблицы ("T1"), по
   которому он сделан: по ней приложение добавит заметки докладчика. Заметки сам не пиши.
4. Числа в показателях (kpi) переписывай из документа точно, без пересчёта единиц.

Фрагменты со знаком ★ автор выделил как главные — обязательно включи их в план (в заголовок, тезис или вывод).

ДАННЫЕ ИЗ ТАБЛИЦ
5. Для диаграмм, таблиц и показателей из таблиц документа НЕ переписывай числа — укажи только
   "src": "T1". Для диаграммы можно указать chart_type: column | bar | line | area | pie | doughnut | stacked | radar,
   для особых данных — waterfall, funnel_chart, pareto, scatter_trend, histogram, treemap.
   Выводы по данным будут посчитаны автоматически.

МАКЕТЫ (поле layout)
{catalog}

ФОРМАТ ОТВЕТА — только JSON-объект, без пояснений:
{{"slides": [
  {{"layout": "title"}},
  {{"layout": "cards", "title": "…", "subtitle": "…", "src": "S2", "items": [{{"title": "…", "text": "…"}}], "conclusion": "…"}},
  {{"layout": "target", "title": "…", "src": "S3", "center": "текст цели", "items": [{{"title": "…", "text": "…"}}]}},
  {{"layout": "kpi", "title": "…", "src": "S5", "items": [{{"value": "<число из документа>", "unit": "<единица>", "title": "…"}}]}},
  {{"layout": "chart", "title": "…", "src": "T1", "chart_type": "column"}},
  {{"layout": "table", "title": "…", "src": "T2"}},
  {{"layout": "compare", "title": "…", "src": "S6", "left": {{"title": "Было", "items": ["…"]}}, "right": {{"title": "Стало", "items": ["…"]}}, "style": "before_after"}},
  {{"layout": "text", "title": "…", "src": "S7", "lead": "ключевой тезис", "paragraphs": ["…"]}},
  {{"layout": "conclusions", "title": "Выводы", "src": "S9", "items": [{{"title": "…", "text": "…"}}]}},
  {{"layout": "end"}}
]}}"""

SYSTEM_PROMPT = SYSTEM_FULL          # имя сохранено для совместимости (см. документацию)

MAX_TOKENS = {'fast': 1600, 'full': 4096}        # потолок длины ответа модели


def _catalog_text():
    lines = []
    for k, v in LAYOUTS.items():
        lim = f' (элементов: {v["min"]}–{v["max"]})' if v.get('min') else ''
        lines.append(f'- {k}: {v["desc"]}{lim}')
    return '\n'.join(lines)


# --------------------------------------------------------------------------------------
# Выжимки документа
# --------------------------------------------------------------------------------------
def _table_line(t, rows_n=0):
    nums = ', '.join(t.columns[j] for j in t.numeric_cols) or 'нет'
    s = (f'  Таблица {t.id}' + (f' «{t.title}»' if t.title else '') +
         f': столбцы: {" | ".join(t.columns)}; строк: {len(t.rows)}; числовые столбцы: {nums}')
    out = [s]
    for r in t.rows[:rows_n]:
        out.append('     ' + ' | '.join(shorten(c, 40) for c in r))
    if rows_n and len(t.rows) > rows_n:
        out.append('     …')
    return out


def digest(doc, max_chars=14000):
    """ПОЛНАЯ выжимка (режим «полностью»): абзацы, пункты списков, шапки и первые строки таблиц."""
    def build(par_lim, item_lim, rows_n):
        out = [f'НАЗВАНИЕ ДОКУМЕНТА: {doc.title}']
        if doc.subtitle:
            out.append(f'ПОДЗАГОЛОВОК: {doc.subtitle}')
        for i, s in enumerate(doc.walk(), 1):
            out.append(f'\n[S{i}] {"#" * s.level} {"★ " if s.mark else ""}{s.title}')
            for b in s.blocks:
                if b.kind == 'para':
                    if b.mark_text:
                        out.append('  ★ ' + shorten(b.mark_text, par_lim))
                    out.append(('  ★ ' if b.mark else '  ') + shorten(b.text, par_lim))
                elif b.kind == 'list':
                    out.append('  Список' + (' (нумерованный)' if b.ordered else '') + ':')
                    out.extend(('   ★ ' if it.mark else '   - ') + shorten(it.text, item_lim) for it in b.items[:15])
                elif b.kind == 'table':
                    out.extend(_table_line(doc.tables[b.table_id], rows_n))
        return '\n'.join(out)
    for par_lim, item_lim, rows_n in ((600, 220, 5), (350, 160, 4), (220, 120, 3), (140, 90, 2), (90, 60, 1)):
        txt = build(par_lim, item_lim, rows_n)
        if len(txt) <= max_chars:
            return txt
    return txt[:max_chars] + '\n…(документ сокращён)'


def digest_fast(doc, max_chars=7000):
    """КОРОТКАЯ выжимка (режим «быстро»): о каждом разделе — первая фраза, состав списков
    (несколько пунктов очень коротко) и шапки таблиц. Модели этого достаточно, чтобы выбрать
    структуру и макеты; тексты на слайды подставит код."""
    def build(par_lim, item_lim, items_n):
        out = [f'НАЗВАНИЕ ДОКУМЕНТА: {doc.title}']
        if doc.subtitle:
            out.append(f'ПОДЗАГОЛОВОК: {doc.subtitle}')
        for i, s in enumerate(doc.walk(), 1):
            out.append(f'[S{i}] {"#" * s.level} {"★ " if s.marked() else ""}{s.title}')
            paras = [b for b in s.blocks if b.kind == 'para']
            marked = [b.mark_text or b.text for b in paras if b.mark or b.mark_text]
            for m in marked[:2]:
                out.append(f'  ★ Выделено автором: {shorten(m, par_lim)}')
            if paras:
                first = shorten(paras[0].text, par_lim)
                more = f' (абзацев: {len(paras)})' if len(paras) > 1 else ''
                out.append(f'  Текст: {first}{more}')
            for b in s.blocks:
                if b.kind == 'list':
                    kind = 'нумерованный, ' if b.ordered else ''
                    items = '; '.join(shorten(it.text, item_lim) for it in b.items[:items_n])
                    if len(b.items) > items_n:
                        items += '; …'
                    out.append(f'  Список ({kind}{len(b.items)} пунктов): {items}')
                elif b.kind == 'table':
                    out.extend(_table_line(doc.tables[b.table_id], 0))
        return '\n'.join(out)
    for par_lim, item_lim, items_n in ((160, 50, 8), (120, 40, 6), (90, 30, 4), (60, 24, 3), (40, 18, 2)):
        txt = build(par_lim, item_lim, items_n)
        if len(txt) <= max_chars:
            return txt
    return txt[:max_chars] + '\n…(документ сокращён)'


# --------------------------------------------------------------------------------------
# Проверка чисел, которые написала модель (режим «полностью»)
# --------------------------------------------------------------------------------------
_NUM_GROUPED = re.compile(r'\d{1,3}(?:[  ]\d{3}(?!\d))+(?:[.,]\d+)?')
_NUM_PLAIN = re.compile(r'\d+(?:[.,]\d+)?')


def _numbers(text):
    """Все числа в тексте как множество (с разделителями разрядов и без)."""
    out = set()
    for rx in (_NUM_GROUPED, _NUM_PLAIN):
        for m in rx.finditer(text):
            v = parse_number(m.group(0))
            if v is not None:
                out.add(round(abs(v), 6))
    return out


def _doc_numbers(doc):
    parts = [doc.title or '', getattr(doc, 'subtitle', '') or '']
    for s in doc.walk():
        parts += [s.title or '', s.all_text(False)]
    for tb in doc.tables.values():
        parts += [tb.title or ''] + [str(c) for c in tb.columns] + [str(c) for r in tb.rows for c in r]
    return _numbers(' \n '.join(parts))


def _check_kpi(s, known, warnings):
    """Показатели, которые предложила модель: число должно встречаться в документе.
    Непроверенные значения убираются; если не осталось ни одного — слайд становится карточками."""
    items = [x for x in (s.get('items') if isinstance(s.get('items'), list) else []) if isinstance(x, dict)]
    good, bad = [], []
    for it in items:
        val = str(it.get('value') or '').strip()
        nums = _numbers(val)
        if not val or not nums or nums <= known:
            (good if val else bad).append(it)
        else:
            bad.append(it)
            shown = f'{val} {it.get("unit") or ""}'.strip()
            warnings.append(f'ИИ: число «{shown}» не найдено в документе — показатель убран.')
    if good:
        s['items'] = good
        return s
    s['layout'] = 'cards'
    s['items'] = [{'title': it.get('title') or '', 'text': it.get('text') or ''} for it in bad
                  if it.get('title') or it.get('text')]
    return s


def _check_labels(s, known, warnings):
    """Сроки этапов (годы, даты), которые написала модель, тоже должны быть в документе: иначе срок убирается."""
    for it in (s.get('items') if isinstance(s.get('items'), list) else []):
        if not isinstance(it, dict) or not it.get('label'):
            continue
        nums = _numbers(str(it['label']))
        if nums and not nums <= known:
            warnings.append(f'ИИ: срок «{it["label"]}» не найден в документе — убран.')
            it['label'] = ''
    return s


# --------------------------------------------------------------------------------------
# Содержимое слайда из документа (по ссылке src) и смена макета
# --------------------------------------------------------------------------------------
from .convert import _kind, convert_slide as _convert  # noqa: E402,F401


class _Picker:
    """Содержимое для слайдов по ссылкам S# / T#: разделы разбираются правилами (section_slides)
    один раз и кэшируются; слайды раздела выдаются по очереди, чтобы два слайда из одного
    раздела не повторяли друг друга."""

    def __init__(self, doc):
        self.doc = doc
        self.sections = list(doc.walk())
        self.cache = {}
        self.table_sec = {}
        for s in self.sections:
            for b in s.blocks:
                if b.kind == 'table':
                    self.table_sec[b.table_id] = s

    def section(self, ref):
        m = re.fullmatch(r'\s*[Ss]\s*(\d+)\s*', str(ref or ''))
        if m and 1 <= int(m.group(1)) <= len(self.sections):
            return self.sections[int(m.group(1)) - 1]
        return None

    def table(self, ref):
        m = re.fullmatch(r'\s*[Tt]\s*(\d+)\s*', str(ref or ''))
        return self.doc.tables.get(f'T{m.group(1)}') if m else None

    def by_title(self, title):
        """Раздел по похожему заголовку (если модель забыла src)."""
        if not title:
            return None
        names = [s.title for s in self.sections]
        best = difflib.get_close_matches(title, names, n=1, cutoff=0.6)
        return self.sections[names.index(best[0])] if best else None

    def _slides_of(self, sec):
        if id(sec) not in self.cache:
            label = shorten(sec.title, 40)
            lst = [copy.deepcopy(s) for s, _ in section_slides(self.doc, sec, label)]
            self.cache[id(sec)] = {'slides': lst, 'used': set()}
        return self.cache[id(sec)]

    def from_section(self, sec, want):
        """Слайд с содержимым раздела в макете want (или ближайшем возможном)."""
        c = self._slides_of(sec)
        cands = c['slides']
        if not cands:
            # раздел без списков/таблиц/абзацев (только заголовок) — пусто
            return None
        kind = _kind(want)
        order = ([i for i, s in enumerate(cands) if i not in c['used'] and s['layout'] == want] +
                 [i for i, s in enumerate(cands) if i not in c['used'] and _kind(s['layout']) == kind] +
                 [i for i in range(len(cands)) if i not in c['used']] +
                 [i for i, s in enumerate(cands) if s['layout'] == want] + [0])
        i = order[0]
        c['used'].add(i)
        sl = copy.deepcopy(cands[i])
        sl = _convert(sl, want)
        sl['notes'] = sl.get('notes') or _notes(sec)
        return _clean(sl)

    def from_table(self, t, want, title):
        sec = self.table_sec.get(t.id)
        label = shorten(sec.title, 40) if sec else ''
        lst = [s for s, _ in _table_slides(self.doc, t.id, sec.title if sec else title, label, False)]
        lst = [s for s in lst if not s.get('_dup')] or lst
        if not lst:
            return None
        pick = next((s for s in lst if s['layout'] == want), lst[0])
        sl = _convert(copy.deepcopy(pick), want)
        if sec and not sl.get('notes'):
            sl['notes'] = _notes(sec)
        return _clean(sl)


def _clean(sl):
    """Убирает служебные поля правил (начинаются с «_»)."""
    sl = {k: v for k, v in sl.items() if not k.startswith('_') or k in ('_cands', '_alt_label')}
    if isinstance(sl.get('items'), list):
        sl['items'] = [{k: v for k, v in it.items() if not k.startswith('_')} if isinstance(it, dict) else it
                       for it in sl['items']]
    return sl


def _has_content(s):
    return bool(s.get('items') or s.get('lead') or s.get('paragraphs') or s.get('left') or s.get('right')
                or s.get('columns') or (s.get('chart') or {}).get('series'))


def _ref(s):
    for k in ('src', 'data', 'table', 'data_ref', 'section_ref'):
        v = s.get(k)
        if isinstance(v, list):
            v = v[0] if v else None
        if v:
            return str(v).strip()
    return None


# --------------------------------------------------------------------------------------
# Разбор ответа модели
# --------------------------------------------------------------------------------------
def _resolve(raw, doc, warnings, level='fast'):
    """Ответ модели → список слайдов спецификации: подстановка содержимого по ссылкам S#/T#,
    данные диаграмм из таблиц, проверка чисел KPI, содержание и номера разделителей."""
    slides = raw.get('slides') if isinstance(raw, dict) else raw
    if not isinstance(slides, list):
        raise LLMError('в ответе нет списка slides')
    picker = _Picker(doc)
    known = _doc_numbers(doc) if level == 'full' else None
    out, sec_labels = [], []
    in_appendix = False
    for s in slides:
        if not isinstance(s, dict):
            continue
        lay = str(s.get('layout') or '').strip().lower()
        if lay not in LAYOUTS:
            # модель могла написать русское название макета
            by_name = {v['name'].lower(): k for k, v in LAYOUTS.items()}
            lay = by_name.get(lay)
            if not lay:
                continue
        title = str(s.get('title') or '').strip()
        subtitle = str(s.get('subtitle') or '').strip()
        if lay in ('title', 'end'):
            out.append({'layout': lay})
            continue
        if lay == 'section':
            out.append({'layout': 'section', 'title': title or 'Раздел', 'subtitle': subtitle})
            if re.search(r'(?i)дополнительн|приложени|резерв|backup|справочн', title):
                in_appendix = True                  # разделы приложения в «Содержание» не попадают
            continue
        if lay == 'agenda':
            items = [x if isinstance(x, str) else (x.get('text') or x.get('title') or '') for x in (s.get('items') or [])
                     if isinstance(x, (str, dict))]
            out.append({'layout': 'agenda', 'title': title or 'Содержание', 'items': [x for x in items if x],
                        '_auto_agenda': not any(items)})
            continue

        ref = _ref(s)
        t = picker.table(ref)
        sec = picker.section(ref) if not t else None
        model_content = level == 'full' and _has_content(s)
        new = None
        if t:
            if lay == 'chart':
                ch = choose_chart(t, title)
                if not ch:
                    warnings.append(f'ИИ: в таблице {t.id} нет данных для диаграммы «{title}» — показана таблицей.')
                    new = picker.from_table(t, 'table', title)
                else:
                    want = s.get('chart_type')
                    if want in ('column', 'bar', 'line', 'stacked', 'area') or (want in ('pie', 'doughnut') and len(ch['series']) == 1) \
                            or (want == 'radar' and 3 <= len(ch['categories']) <= 12 and len(ch['series']) <= 4):
                        ch['type'] = want
                    elif want in EXT_CHART and chart_prepare(want, ch['categories'], ch['series'])[0] == want:
                        ch['type'] = want                 # 1.7: каскадная, воронка, точечная и др. — если данные подходят
                    ch.pop('note', None)
                    new = {'layout': 'chart', 'chart': ch, 'insights': make_insights(ch)}
                    if ch.get('unit') and ch['unit'] != '%':
                        new['subtitle'] = f'Единицы: {ch["unit"]}'
                    sec_t = picker.table_sec.get(t.id)
                    if sec_t:
                        new['notes'] = _notes(sec_t)
                        new['section'] = shorten(sec_t.title, 40)
            elif lay == 'table':
                new = {'layout': 'table', 'columns': t.columns, 'rows': t.rows}
                sec_t = picker.table_sec.get(t.id)
                if sec_t:
                    new['notes'] = _notes(sec_t)
                    new['section'] = shorten(sec_t.title, 40)
            else:
                k = kpi_from_table(t) if lay == 'kpi' else None
                new = {'layout': 'kpi', 'items': k} if k else picker.from_table(t, lay, title)
            if new is None:
                warnings.append(f'ИИ: слайд «{title}» ({t.id}) — не удалось подготовить содержимое, пропущен.')
                continue
        elif model_content:
            new = {k: v for k, v in s.items() if k not in ('src', 'data', 'table', 'data_ref', 'chart_type', 'notes')}
            if lay in ('kpi', 'hero', 'gauge', 'bars', 'bubbles', 'funnel'):
                _check_kpi(new, known, warnings)
            if lay in ('timeline', 'roadmap', 'gantt', 'path'):
                _check_labels(new, known, warnings)
            if sec:
                new['notes'] = _notes(sec)
                new['section'] = shorten(sec.title, 40)
            elif lay == 'chart':
                warnings.append(f'ИИ: диаграмма «{title}» без ссылки на таблицу — слайд пропущен.')
                continue
        else:
            if not sec:
                sec = picker.by_title(title)
            if not sec:
                if lay in ('chart', 'table', 'kpi'):
                    warnings.append(f'ИИ: слайд «{title}» без ссылки на таблицу — пропущен.')
                else:
                    warnings.append(f'ИИ: слайд «{title}» не привязан к разделу документа — пропущен.')
                continue
            new = picker.from_section(sec, lay)
            if new is None:
                warnings.append(f'ИИ: раздел «{sec.title}» пуст — слайд «{title}» пропущен.')
                continue
        # заголовок и подзаголовок — от модели (её формулировки — смысл её участия)
        if title:
            new['title'] = title
        elif not new.get('title'):
            new['title'] = (sec.title if sec else (t.title if t else '')) or 'Слайд'
        if subtitle and level == 'full' or (subtitle and not new.get('subtitle')):
            new['subtitle'] = subtitle
        if s.get('conclusion') and isinstance(s['conclusion'], str):
            new['conclusion'] = s['conclusion']
        if not new.get('section'):
            new['section'] = shorten(sec.title, 40) if sec else shorten(new['title'], 40)
        if new.get('section') and new['section'] not in sec_labels and not in_appendix:
            sec_labels.append(new['section'])
        out.append(new)

    # «Содержание» без пунктов — из разделов, на которые опирается доклад; номера разделителей
    num = 0
    result = []
    for s in out:
        if s.get('_auto_agenda') is not None:
            auto = s.pop('_auto_agenda')
            if auto:
                s['items'] = [{'title': '', 'text': x} for x in sec_labels][:10]
            else:
                s['items'] = [{'title': '', 'text': x} for x in s['items']][:10]
            if len(s['items']) < 2:
                continue
        if s['layout'] == 'section':
            num += 1
            s['number'] = f'{num:02d}'
        result.append(s)
    return result


# --------------------------------------------------------------------------------------
# Основная функция
# --------------------------------------------------------------------------------------
def plan_llm(doc, opts, llm_cfg, progress=None):
    """Строит спецификацию с помощью локальной модели. Исключение — если не получилось.

    progress(event) — обратный вызов для индикатора в интерфейсе (см. llm_client.chat);
    дополнительно присылаются события {'phase': 'prompt', …} и {'phase': 'retry'}."""
    notify = progress or (lambda e: None)
    warnings = list(doc.warnings)
    target = int(opts.get('target_slides') or 0)
    level = 'full' if str(opts.get('ai_level') or '').lower() == 'full' else 'fast'
    max_chars = int((llm_cfg or {}).get('max_chars') or 14000)
    if level == 'fast':
        dg = digest_fast(doc, max(3000, max_chars // 2))
        system = SYSTEM_FAST.format(catalog=_catalog_text())
    else:
        dg = digest(doc, max_chars)
        system = SYSTEM_FULL.format(catalog=_catalog_text())
    want = (f'Ровно {target} слайдов, включая титульный и финальный.' if target else
            'Число слайдов выбери сам: обычно 8–15, включая титульный и финальный.')
    extra = []
    if opts.get('event'):
        extra.append(f'Мероприятие: {opts["event"]}.')
    if opts.get('focus'):
        extra.append(f'Акценты, которые просил автор: {opts["focus"]}.')
    if opts.get('remarks'):
        extra.append('Замечания и необходимые корректировки автора (обязательно учти их; числа по-прежнему '
                     f'только из документа): {shorten(str(opts["remarks"]), 1200)}')
    user = (f'{want}\n' + ('\n'.join(extra) + '\n' if extra else '') +
            'Ответь только JSON-объектом по формату из инструкции.\n\nВЫЖИМКА ДОКУМЕНТА:\n' + dg)
    notify({'phase': 'prompt', 'level': level, 'chars': len(system) + len(user),
            'tokens_est': estimate_tokens(system) + estimate_tokens(user)})

    def prog(e):
        if e.get('phase') == 'gen':
            e = dict(e, slides=e.get('text', '').count('"layout"'))
            e.pop('text', None)
        notify(e)

    text = chat(llm_cfg, system, user, progress=prog, max_tokens=MAX_TOKENS[level])
    try:
        raw = extract_json(text)
    except LLMError:
        # вторая попытка: просим исправить формат
        notify({'phase': 'retry'})
        text = chat(llm_cfg, system, user + '\n\nПредыдущий ответ был не JSON. Верни ТОЛЬКО корректный JSON-объект.',
                    progress=prog, max_tokens=MAX_TOKENS[level])
        raw = extract_json(text)
    slides = _resolve(raw, doc, warnings, level)
    if len([s for s in slides if s['layout'] not in ('title', 'end')]) == 0:
        raise LLMError('модель не предложила ни одного содержательного слайда')
    meta = {'title': opts.get('title') or doc.title or 'Презентация', 'subtitle': opts.get('subtitle') or doc.subtitle,
            'event': opts.get('event') or '', 'date': opts.get('date') or '',
            'animations': opts.get('animations', True)}
    from .planner_rules import finish_slides
    spec, w2 = normalize({'meta': meta, 'slides': slides})
    spec['slides'] = finish_slides(spec['slides'], opts)   # варианты на выбор, разнообразие соседей, типографика
    n = len(spec['slides'])
    if target and abs(n - target) > 1:
        warnings.append(f'ИИ предложила {n} слайдов вместо {target}. Поправьте план или пересоберите.')
    return spec, warnings + w2


def debug_prompt(doc, opts, llm_cfg=None):
    """Текст запроса к модели (для проверки и настройки промпта)."""
    level = 'full' if str((opts or {}).get('ai_level') or '').lower() == 'full' else 'fast'
    max_chars = int((llm_cfg or {}).get('max_chars') or 14000)
    if level == 'fast':
        return SYSTEM_FAST.format(catalog=_catalog_text()) + '\n\n----- USER -----\n' + digest_fast(doc, max(3000, max_chars // 2))
    return SYSTEM_FULL.format(catalog=_catalog_text()) + '\n\n----- USER -----\n' + digest(doc, max_chars)


if __name__ == '__main__':          # просмотр промпта: python -m engine.planner_llm [--full] файл.docx …
    import sys
    from .readers import read_files
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    d = read_files([(p, p) for p in args])
    print(debug_prompt(d, {'ai_level': 'full' if '--full' in sys.argv else 'fast'}))
    print(json.dumps(d.stats(), ensure_ascii=False))
