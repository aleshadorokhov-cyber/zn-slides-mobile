# -*- coding: utf-8 -*-
"""
library.py — БИБЛИОТЕКА МАТЕРИАЛОВ (1.7)
====================================

Постоянная библиотека материалов, из которых модель поиска берёт готовые фразы для слайдов: прежние доклады,
справки, отчёты, презентации — любые файлы, которые читает конструктор (Word, PDF, PowerPoint, Excel, CSV,
JSON, текст). Хранится в output/library/:
    files/<id><расширение>   — сам файл (для перечитывания следующими версиями);
    phrases/<id>.json        — готовые предложения из него (engine/phrases.pool_from_doc);
    views/<id>.json          — его текст по порядку, чтобы показать найденную фразу в документе (1.7.2, docview.py);
    decks/<id>.json          — для презентаций: устройство слайдов (образец для «Плана по образцу», byexample.py);
    index.json               — список: имя, дата, размер, число фраз, слайдов образца, ref — эталон.

Эталоны — лучшие презентации PowerPoint библиотеки, отмеченные автором (⭐): с ними команда «Сравнить с эталонами»
(engine/review.py) сравнивает текущую презентацию — число слайдов, объём текста, диаграммы и схемы, заголовки-выводы,
каркас (содержание, разделители, где выводы) и похожие слайды.

Фразы библиотеки на слайд сами не встают (кроме случая, когда автор нажал «Добавить»): они предлагаются у слайда
списком «🔎 Подходящие фразы» с пометкой «библиотека»; фразы с числами помечены ⚠ — числа на слайдах берутся
только из материалов доклада.

  items(), add(data, filename, ref) → запись, remove(id), set_ref(id, on) — эталон или нет, pool() — все фразы,
  decks() — презентации-образцы, etalons() — эталоны, outline(запись) — устройство слайдов одной презентации,
  warm(cfg) — в фоне подготовить фразы и слайды образцов к поиску по смыслу (векторы — в кэш), status(cfg).
"""
import hashlib
import json
import re
import shutil
import tempfile
import threading
import time
from pathlib import Path

from .nts import config as C

LIB_DIR = C.OUTPUT_DIR / 'library'
INDEX = LIB_DIR / 'index.json'
ID_RX = re.compile(r'[0-9a-f]{12}')
MAX_FILE = 100 * 1024 * 1024
_LOCK = threading.Lock()
_POOL = {'rev': None, 'pool': []}
_WARM = {'thread': None, 'done': 0, 'total': 0, 'error': '', 'model': ''}


class LibraryError(Exception):
    pass


def _load():
    try:
        d = json.loads(INDEX.read_text(encoding='utf-8'))
        return [e for e in d if isinstance(e, dict) and ID_RX.fullmatch(str(e.get('id') or ''))] if isinstance(d, list) else []
    except (OSError, ValueError):
        return []


def _save(items):
    LIB_DIR.mkdir(parents=True, exist_ok=True)
    tmp = INDEX.with_suffix('.tmp')
    tmp.write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding='utf-8')
    tmp.replace(INDEX)


def items():
    """Файлы библиотеки, новые первыми: [{'id', 'name', 'added', 'size', 'phrases', 'warnings', 'deck'}]
    (deck — у презентаций: сколько содержательных слайдов годится как образец)."""
    out = sorted(_load(), key=lambda e: str(e.get('added') or ''), reverse=True)
    for e in out:
        if 'deck' not in e and str(e.get('name') or '').lower().endswith('.pptx'):
            e['deck'] = sum(1 for x in outline(e) if x.get('role') in CONTENT_ROLES)
    return out


def add(data, filename, ref=False):
    """Байты файла → запись библиотеки. Тот же файл второй раз не добавляется (возвращается прежняя запись).
    Файл без текста или неподдерживаемого вида → LibraryError. ref — сразу эталон (только презентации PowerPoint)."""
    from .phrases import pool_from_doc
    from .readers import SUPPORTED, read_files
    name = Path(str(filename or '').replace('\\', '/')).name[:150] or 'файл'
    ext = Path(name).suffix.lower()
    if ext not in SUPPORTED:
        raise LibraryError('такие файлы конструктор не читает (подходят Word, PDF, PowerPoint, Excel, CSV, JSON, текст)')
    if ref and ext != '.pptx':
        raise LibraryError('эталоном может быть только презентация PowerPoint (.pptx)')
    if not data:
        raise LibraryError('файл пустой')
    if len(data) > MAX_FILE:
        raise LibraryError('файл больше 100 МБ')
    fid = hashlib.sha1(data).hexdigest()[:12]
    with _LOCK:
        old = next((e for e in _load() if e['id'] == fid), None)
    if old:
        if ref and not old.get('ref'):
            set_ref(fid, True)
            old = dict(old, ref=True)
        return dict(old, duplicate=True)
    tmp = Path(tempfile.mkdtemp(prefix='zn_lib_'))
    try:
        src = tmp / f'lib{ext}'
        src.write_bytes(data)
        doc = read_files([(str(src), name)])
        from .docview import view_from_doc
        view = view_from_doc(doc)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    pool = pool_from_doc(doc, lib=True)
    for p in pool:
        p['src'] = name
    (LIB_DIR / 'files').mkdir(parents=True, exist_ok=True)
    path = LIB_DIR / 'files' / f'{fid}{ext}'
    path.write_bytes(data)
    deck = _make_outline(fid, path, name) if ext == '.pptx' else []
    n_deck = sum(1 for r in deck if r.get('role') in CONTENT_ROLES)
    if not pool and n_deck < 2:
        try:
            path.unlink()
        except OSError:
            pass
        raise LibraryError('в файле не нашлось готовых предложений (только таблицы, рисунки или очень короткие строки)')
    (LIB_DIR / 'phrases').mkdir(parents=True, exist_ok=True)
    (LIB_DIR / 'phrases' / f'{fid}.json').write_text(json.dumps(pool, ensure_ascii=False), encoding='utf-8')
    (LIB_DIR / 'views').mkdir(parents=True, exist_ok=True)
    (LIB_DIR / 'views' / f'{fid}.json').write_text(json.dumps(view, ensure_ascii=False, separators=(',', ':')),
                                                    encoding='utf-8')
    entry = {'id': fid, 'name': name, 'added': time.strftime('%Y-%m-%dT%H:%M:%S'), 'size': len(data),
             'phrases': len(pool), 'warnings': [str(w) for w in doc.warnings[:3]]}
    if ext == '.pptx':
        entry['deck'] = n_deck
        if ref and n_deck >= 2:
            entry['ref'] = True
        elif ref:                                    # файл остаётся в библиотеке, но сравнивать с ним не с чем
            entry['warnings'] = ['не эталон: меньше двух содержательных слайдов'] + entry['warnings'][:2]
    with _LOCK:
        cur = [e for e in _load() if e['id'] != fid]
        _save(cur + [entry])
    return entry


def remove(fid):
    """Удаляет файл из библиотеки. True — удалён, False — такого нет."""
    if not ID_RX.fullmatch(str(fid or '')):
        return False
    with _LOCK:
        cur = _load()
        if not any(e['id'] == fid for e in cur):
            return False
        _save([e for e in cur if e['id'] != fid])
    for p in list((LIB_DIR / 'files').glob(f'{fid}.*')) + [LIB_DIR / 'phrases' / f'{fid}.json',
                                                         LIB_DIR / 'decks' / f'{fid}.json',
                                                         LIB_DIR / 'views' / f'{fid}.json']:
        try:
            p.unlink()
        except OSError:
            pass
    return True


def set_ref(fid, on):
    """Отметить презентацию библиотеки как эталон (on=True) или снять отметку. → запись или None (нет такой
    или это не презентация PowerPoint)."""
    if not ID_RX.fullmatch(str(fid or '')):
        return None
    with _LOCK:
        cur = _load()
        e = next((x for x in cur if x['id'] == fid), None)
        if not e or not str(e.get('name') or '').lower().endswith('.pptx'):
            return None
        if on:
            e['ref'] = True
        else:
            e.pop('ref', None)
        _save(cur)
    return e


def etalons():
    """Эталоны (⭐) с разобранными слайдами, старые первыми: [{'id', 'name', 'added', 'slides'}]."""
    refs = {e['id'] for e in _load() if e.get('ref')}
    return [d for d in decks() if d['id'] in refs]


def rev():
    try:
        st = INDEX.stat()
        return f'{st.st_mtime_ns}:{st.st_size}'
    except OSError:
        return ''


def pool():
    """Все фразы библиотеки (кэш в памяти до изменения библиотеки)."""
    r = rev()
    if _POOL['rev'] == r:
        return _POOL['pool']
    out = []
    for e in sorted(_load(), key=lambda e: str(e.get('added') or '')):
        try:
            d = json.loads((LIB_DIR / 'phrases' / f'{e["id"]}.json').read_text(encoding='utf-8'))
        except (OSError, ValueError):
            continue
        out += [dict(p, lib=True, src=e['name'], lid=e['id']) for p in d if isinstance(p, dict) and isinstance(p.get('t'), str)]
    _POOL.update(rev=r, pool=out)
    return out


CONTENT_ROLES = ('content', 'conclusions')
_DECKS = {'rev': None, 'decks': []}


def _make_outline(fid, path, name):
    """Устройство слайдов презентации (pptx_reader.outline_pptx) → decks/<id>.json. Ошибка — пустой образец."""
    from .readers.pptx_reader import OUTLINE_VERSION, outline_pptx
    try:
        slides = outline_pptx(path, name)
    except Exception:                                    # noqa: BLE001 — повреждённый файл не мешает библиотеке
        slides = []
    try:
        (LIB_DIR / 'decks').mkdir(parents=True, exist_ok=True)
        (LIB_DIR / 'decks' / f'{fid}.json').write_text(
            json.dumps({'v': OUTLINE_VERSION, 'slides': slides}, ensure_ascii=False), encoding='utf-8')
    except OSError:
        pass
    return slides


def outline(e):
    """Слайды презентации-образца из библиотеки: [{'n', 'role', 'kind', 'chart', 'items', 'title', 'text'}].
    Разбор хранится в decks/<id>.json; презентации, добавленные до 1.7 или разобранные старой версией, разбираются
    заново при первом обращении."""
    from .readers.pptx_reader import OUTLINE_VERSION
    fid = str(e.get('id') or '')
    if not ID_RX.fullmatch(fid) or not str(e.get('name') or '').lower().endswith('.pptx'):
        return []
    try:
        d = json.loads((LIB_DIR / 'decks' / f'{fid}.json').read_text(encoding='utf-8'))
        if d.get('v') == OUTLINE_VERSION and isinstance(d.get('slides'), list):
            return d['slides']
    except (OSError, ValueError, AttributeError):
        pass
    path = LIB_DIR / 'files' / f'{fid}.pptx'
    return _make_outline(fid, path, e['name']) if path.exists() else []


def decks():
    """Презентации библиотеки, пригодные как образец (хотя бы два содержательных слайда), старые первыми:
    [{'id', 'name', 'added', 'slides'}]. Кэш в памяти до изменения библиотеки."""
    r = rev()
    if _DECKS['rev'] == r:
        return _DECKS['decks']
    out = []
    for e in sorted(_load(), key=lambda e: str(e.get('added') or '')):
        sl = outline(e)
        if sum(1 for x in sl if x.get('role') in CONTENT_ROLES) >= 2:
            out.append({'id': e['id'], 'name': e['name'], 'added': e.get('added') or '', 'slides': sl})
    _DECKS.update(rev=r, decks=out)
    return out


def deck_texts():
    """Тексты содержательных слайдов образцов — для поиска похожих слайдов по смыслу."""
    return [x['text'] for d in decks() for x in d['slides'] if x.get('role') in CONTENT_ROLES and x.get('text')]


def status(cfg):
    """Сколько фраз библиотеки (и слайдов образцов) готово к поиску по смыслу:
    {'phrases', 'texts', 'ready', 'warming', 'error', 'decks', 'model'}."""
    from .llm_client import LLMError, side_cfg
    from .phrases import cached_vectors
    phr = [p['t'] for p in pool()]
    texts = list(dict.fromkeys(phr + deck_texts()))         # фразы и слайды образцов — к поиску по смыслу
    out = {'phrases': len(phr), 'texts': len(texts), 'ready': 0,
           'warming': bool(_WARM['thread'] and _WARM['thread'].is_alive()), 'error': _WARM['error'], 'decks': len(decks())}
    try:
        model = side_cfg(cfg, 'embed')['model']
    except LLMError as e:
        out['error'] = str(e)
        return out
    out['ready'] = len(cached_vectors(model, texts)) if texts else 0
    out['model'] = model
    return out


def warm(cfg):
    """В фоне считает векторы фраз библиотеки, которых ещё нет в кэше (если модель поиска на связи).
    Уже идёт — ничего не делает. Ошибка (модель не скачана, Ollama выключена) запоминается для status()."""
    from .llm_client import LLMError
    from .phrases import embed_texts
    t = _WARM['thread']
    if t and t.is_alive():
        return False

    def run():
        _WARM['error'] = ''
        try:
            texts = [p['t'] for p in pool()] + deck_texts()
            _WARM['total'] = len(texts)
            embed_texts(cfg, texts, lambda e: _WARM.update(done=e['done']))
        except LLMError as e:
            _WARM['error'] = str(e)
        except Exception as e:                               # noqa: BLE001 — фоновая подготовка не роняет сервер
            _WARM['error'] = f'{type(e).__name__}: {e}'
    th = threading.Thread(target=run, daemon=True, name='library-warm')
    _WARM['thread'] = th
    th.start()
    return True
