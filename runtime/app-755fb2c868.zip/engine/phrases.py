# -*- coding: utf-8 -*-
"""
phrases.py — ПОДХОДЯЩИЕ ФРАЗЫ: ПОИСК ПО СМЫСЛУ В МАТЕРИАЛАХ И БИБЛИОТЕКЕ (1.7)
==========================================================================

Режим «По правилам + поиск фраз». Модель поиска (эмбеддинги, например bge-m3 в Ollama) только сравнивает
готовые предложения из загруженных материалов и из библиотеки (engine/library.py) с темой слайда — сама она
ничего не пишет. Найденные предложения:
  * дополняют «тонкие» слайды: пункт без пояснения, слайд из нескольких слов (только из материалов доклада);
  * предлагаются у каждого слайда списком «🔎 Подходящие фразы» (и из библиотеки) — автор добавляет нужные сам.
Без модели поиска (Ollama выключена, модель не скачана) фразы подбираются по совпадению слов (BM25 по основам
слов) — с предупреждением.

  pool_from_doc(doc, lib=False)   — готовые фразы документа: [{'t', 'src', 'sec', 'lib', 'num'}]
  Searcher(pool, cfg)             — поиск в одном наборе фраз: prepare() считает векторы (кэш — файл
                                    output/search/vectors.sqlite), hits(query) → [(номер фразы, уверенность)]
  Finder(doc_pool, lib_pool, cfg) — материалы + библиотека: enrich(slides), attach_found(slides), search(query)
  save_pool(pool) → id; load_pool(id) — фразы доклада для окна слайда (output/cache/pools/)
"""
import hashlib
import json
import math
import operator
import re
import sqlite3
import statistics
import struct
import threading
import time

from .nts import config as C
from .textutil import clean, sentences, split_title_text

SEARCH_DIR = C.OUTPUT_DIR / 'search'
VECTOR_DB = SEARCH_DIR / 'vectors.sqlite'
KEEP_DAYS = 60                                       # векторы, не нужные столько дней, удаляются
POOL_DIR = C.OUTPUT_DIR / 'cache' / 'pools'
POOL_RX = re.compile(r'[0-9a-f]{16}')

MIN_LEN, MAX_LEN = 25, 320                 # длина фразы-кандидата, символов
MAX_POOL = 30000                           # фраз из одного набора (материалы доклада или библиотека)
META = ('title', 'end', 'section', 'agenda')
# макеты, у пунктов которых показывается пояснение (text) — его можно дополнить найденной фразой
FILL_TEXT = ('cards', 'list', 'process', 'timeline', 'cycle', 'target', 'conclusions', 'pyramid', 'stairs', 'matrix',
             'hub', 'honeycomb', 'layers', 'pillars', 'roadmap', 'gears', 'checklist', 'petals', 'path', 'converge',
             'puzzle', 'iceberg', 'well', 'field', 'value_chain')
WIDE = ('cards', 'list', 'process', 'timeline', 'conclusions', 'checklist', 'roadmap', 'path')   # просторные пункты
ADD_ITEMS = ('list', 'conclusions')        # «тонкий» слайд-список — найденные фразы новыми пунктами
THIN_WORDS = 15                            # меньше слов на слайде — слайд «тонкий»

dot = getattr(math, 'sumprod', None) or (lambda a, b: sum(map(operator.mul, a, b)))


# --------------------------------------------------------------------------------------
# Фразы документа
# --------------------------------------------------------------------------------------
_WORD = re.compile(r'[а-яёa-z0-9]+', re.I)


# речь докладчика, а не мысль для слайда: «Рассмотрим…», «Вначале обратимся…», «На слайде показано…»
_SPEECH = re.compile(r'(?i)^(рассмотрим|перейд[её]м|обратимся|вначале|сначала|далее|итак|давайте|теперь|как видно|'
                     r'как видите|как показано|на (этом |данном |следующем )?(слайде|рисунке|графике|схеме)|'
                     r'в (данной|этой|настоящей) (работе|презентации|главе)|спасибо|благодарю|вопросы)\b')
# слово подряд дважды («ЭЦН ЭЦН производительностью…») — склеенные подписи таблицы или схемы, а не фраза
_REPEAT = re.compile(r'(?i)\b(\w{2,})\s+\1\b')


def _ok_phrase(t):
    from .digest import junk
    if not MIN_LEN <= len(t) <= MAX_LEN or len(_WORD.findall(t)) < 4 or junk(t):
        return False
    if t.endswith((':', '?')) or re.match(r'(?i)^(рис\.|рисунок|таблица|табл\.|источник|примечание)\s*\d*', t):
        return False
    if not re.match(r'[А-ЯЁA-Z0-9«"(]', t) or re.match(r'(?i)^(а|и|но|или|да|же|ведь|то есть)\s', t):
        return False                                          # обрывок: начинается со строчной буквы или союза
    if t.count('(') != t.count(')') or t.count('«') != t.count('»') or _SPEECH.match(t) or _REPEAT.search(t):
        return False
    return len(re.findall(r'[а-яёa-z]', t, re.I)) >= 0.5 * len(t)


def _sentence_like(t):
    """Законченная мысль (для пояснения к пункту и для «тонкого» слайда): есть сказуемое, от пяти слов."""
    from .textutil import has_predicate
    return len(_WORD.findall(t)) >= 5 and has_predicate(t)


def pool_from_doc(doc, lib=False, limit=MAX_POOL):
    """Готовые предложения документа (абзацы — по предложениям, пункты списков — целиком или по предложениям).
    Каждое — {'t': текст, 'src': файл, 'sec': раздел верхнего уровня, 'lib': из библиотеки, 'num': есть число}."""
    out, seen = [], set()
    default_src = (doc.sources or [''])[0] if getattr(doc, 'sources', None) else ''

    def add(text, src, sec):
        t = clean(text).strip(' •·-–—;')
        if not _ok_phrase(t):
            return
        key = re.sub(r'\W+', ' ', t.lower()).strip()
        if key in seen:
            return
        seen.add(key)
        out.append({'t': t, 'src': src or default_src, 'sec': sec, 'lib': bool(lib), 'num': bool(re.search(r'\d', t))})

    def walk(sec, top):
        label = top or clean(sec.title)[:60]
        src = getattr(sec, 'source', '') or default_src
        for b in sec.blocks:
            if b.kind == 'para':
                for s in sentences(b.text):
                    add(s, src, label)
            elif b.kind == 'list':
                for it in b.items:
                    txt = clean(it.text)
                    if len(txt) <= MAX_LEN:
                        add(txt, src, label)
                    else:
                        for s in sentences(txt):
                            add(s, src, label)
            if len(out) >= limit:
                return
        for ch in sec.children:
            walk(ch, label)

    for s in doc.sections:
        walk(s, '')
        if len(out) >= limit:
            break
    return out[:limit]


# --------------------------------------------------------------------------------------
# Кэш векторов (половинная точность: 2 байта на число)
# --------------------------------------------------------------------------------------
_DB_LOCK = threading.Lock()


def _key(model, text):
    return hashlib.sha1((model + '\n' + text).encode('utf-8')).hexdigest()


def _connect():
    SEARCH_DIR.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(VECTOR_DB), timeout=30)
    con.execute('CREATE TABLE IF NOT EXISTS v (k TEXT PRIMARY KEY, d INTEGER, b BLOB)')
    return con


def _unit(v):
    n = math.sqrt(dot(v, v)) or 1.0
    return [x / n for x in v]


def cached_vectors(model, texts):
    """{текст: вектор} для тех текстов, чьи векторы уже посчитаны этой моделью."""
    keys = {}
    for t in texts:
        keys.setdefault(_key(model, t), t)
    out = {}
    if not keys or not VECTOR_DB.exists():
        return out
    ks = list(keys)
    try:
        with _DB_LOCK:
            con = _connect()
            try:
                day = int(time.time() // 86400)
                for i in range(0, len(ks), 500):
                    part = ks[i:i + 500]
                    marks = ",".join("?" * len(part))
                    rows = con.execute(f'SELECT k, b FROM v WHERE k IN ({marks})', part).fetchall()
                    for k, b in rows:
                        out[keys[k]] = list(struct.unpack(f'<{len(b) // 2}e', b))
                    con.execute(f'UPDATE v SET d = ? WHERE d < ? AND k IN ({marks})', [day, day] + part)  # нужен — не удалять
                con.commit()
            finally:
                con.close()
    except sqlite3.Error:                                    # испорченный кэш — посчитаем заново
        return {}
    return out


def store_vectors(model, pairs):
    """pairs — [(текст, вектор)]: векторы нормируются и сохраняются половинной точностью."""
    if not pairs:
        return
    day = int(time.time() // 86400)
    rows = [(_key(model, t), day, struct.pack(f'<{len(v)}e', *[max(-65000.0, min(65000.0, x)) for x in v]))
            for t, v in pairs]
    try:
        with _DB_LOCK:
            con = _connect()
            try:
                con.executemany('INSERT OR REPLACE INTO v (k, d, b) VALUES (?, ?, ?)', rows)
                con.commit()
            finally:
                con.close()
    except sqlite3.Error:
        pass


def prune_vectors(days=KEEP_DAYS):
    """Убирает из кэша векторы, которые не были нужны дольше days дней (кэш не растёт без конца).
    Возвращает число удалённых."""
    if not VECTOR_DB.exists():
        return 0
    try:
        with _DB_LOCK:
            con = _connect()
            try:
                n = con.execute('DELETE FROM v WHERE d < ?', (int(time.time() // 86400) - days,)).rowcount
                con.commit()
                if n:
                    con.execute('VACUUM')
            finally:
                con.close()
    except sqlite3.Error:
        return 0
    return n


def embed_texts(cfg, texts, progress=None):
    """Векторы для текстов: из кэша, недостающие — моделью поиска (порциями). → {текст: нормированный вектор}."""
    from .llm_client import embed, side_cfg
    model = side_cfg(cfg, 'embed')['model']
    texts = list(dict.fromkeys(texts))
    have = cached_vectors(model, texts)
    missing = [t for t in texts if t not in have]
    if missing:
        done0 = len(texts) - len(missing)

        def prog(e):
            if progress:
                progress({'phase': 'embed', 'done': done0 + e['done'], 'total': len(texts)})
        for i in range(0, len(missing), 256):                # сохраняем по ходу: отмена не теряет посчитанное
            part = missing[i:i + 256]
            vecs = [_unit(v) for v in embed(cfg, part, lambda e, i=i: prog({'done': i + e['done']}))]
            store_vectors(model, list(zip(part, vecs)))
            have.update(zip(part, vecs))
    return have


# --------------------------------------------------------------------------------------
# Поиск по словам (запасной): BM25 по основам слов
# --------------------------------------------------------------------------------------
STOP = set('''и в во не что он на я с со как а то все она так его но да ты к у же вы за бы по только ее мне было вот
от меня еще нет о из ему теперь когда даже ну вдруг ли если уже или ни быть был него до вас нибудь опять уж вам ведь
там потом себя ничего ей может они тут где есть надо ней для мы тебя их чем была сам чтоб без будто чего раз тоже себе
под будет ж тогда кто этот того потому этого какой совсем ним здесь этом один почти мой тем чтобы нее сейчас были куда
зачем всех никогда можно при наконец два об другой хоть после над больше тот через эти нас про всего них какая много
разве три эту моя впрочем хорошо свою этой перед иногда лучше чуть том нельзя такой им более всегда конечно всю между
это также которые который которая которых которой является являются году года годах год является также свой своих
своей the and for with that this from are was'''.split())


def stems(text):
    out = []
    for w in _WORD.findall(str(text or '').lower().replace('ё', 'е')):
        if len(w) < 3 or w in STOP or w.isdigit():
            continue
        out.append(w[:6] if len(w) > 7 else w[:5] if len(w) > 5 else w)
    return out


class _BM25:
    def __init__(self, texts, k1=1.4, b=0.6):
        self.docs = [stems(t) for t in texts]
        self.tf = []
        df = {}
        for d in self.docs:
            c = {}
            for w in d:
                c[w] = c.get(w, 0) + 1
            self.tf.append(c)
            for w in c:
                df[w] = df.get(w, 0) + 1
        n = max(1, len(self.docs))
        self.idf = {w: math.log(1 + (n - f + 0.5) / (f + 0.5)) for w, f in df.items()}
        self.avg = sum(len(d) for d in self.docs) / n or 1.0
        self.k1, self.b = k1, b
        self.post = {}
        for i, c in enumerate(self.tf):
            for w in c:
                self.post.setdefault(w, []).append(i)

    def scores(self, query):
        """{номер: (BM25, доля «веса» запроса, найденная во фразе, число совпавших основ)}."""
        q = list(dict.fromkeys(stems(query)))
        total = sum(self.idf.get(w, 0) for w in q) or 1.0
        acc = {}
        for w in q:
            idf = self.idf.get(w)
            if not idf:
                continue
            for i in self.post.get(w, ()):
                tf = self.tf[i][w]
                dl = len(self.docs[i])
                s = idf * tf * (self.k1 + 1) / (tf + self.k1 * (1 - self.b + self.b * dl / self.avg))
                a = acc.setdefault(i, [0.0, 0.0, 0])
                a[0] += s
                a[1] += idf / total
                a[2] += 1
        return acc, len(q)


# --------------------------------------------------------------------------------------
# Поиск в одном наборе фраз
# --------------------------------------------------------------------------------------
class Searcher:
    """Поиск в наборе фраз. После prepare() — по смыслу (векторы модели поиска), иначе — по словам.
    hits() возвращает [(номер фразы, уверенность 0…1)] — уверенность сравнима между наборами."""

    def __init__(self, pool, cfg=None):
        self.pool = pool or []
        self.cfg = cfg
        self.vecs = None
        self.reason = ''
        self._bm = None

    @property
    def semantic(self):
        return self.vecs is not None

    def prepare(self, progress=None, max_missing=None):
        """Векторы фраз: из кэша, недостающие — моделью поиска. True — поиск по смыслу; False — по словам
        (причина — в self.reason). max_missing — не считать, если недостающих больше (окно слайда: быстро)."""
        from .llm_client import Cancelled, LLMError, side_cfg
        if not self.pool:
            self.vecs = []
            return True
        if not self.cfg:
            self.reason = 'модель поиска не настроена'
            return False
        texts = [p['t'] for p in self.pool]
        try:
            model = side_cfg(self.cfg, 'embed')['model']
            if max_missing is not None:
                have = cached_vectors(model, texts)
                if len(set(texts) - set(have)) > max_missing:
                    self.reason = 'фразы ещё не подготовлены для поиска по смыслу'
                    return False
            have = embed_texts(self.cfg, texts, progress)
        except Cancelled:
            raise
        except LLMError as e:
            self.reason = str(e)
            return False
        self.vecs = [have[t] for t in texts]
        return True

    def hits(self, query, qvec=None, k=8, keep=None):
        """Лучшие фразы к запросу: [(номер, уверенность)]. keep(номер) → False — фраза пропускается."""
        if not self.pool:
            return []
        out = []
        if self.vecs is not None and qvec is not None:
            sc = [dot(qvec, v) for v in self.vecs]
            if len(sc) >= 8:
                mean, sd = statistics.fmean(sc), statistics.pstdev(sc) or 1e-6
            else:                                             # мало фраз — статистики нет: по абсолютной близости
                mean, sd = 0.3, 0.1
            order = sorted(range(len(sc)), key=sc.__getitem__, reverse=True)
            for i in order:
                if keep and not keep(i):
                    continue
                z = (sc[i] - mean) / sd
                conf = max(0.0, min(1.0, (z - 1.0) / 3.0)) if sc[i] >= 0.25 else 0.0
                if conf <= 0:
                    break
                out.append((i, round(conf, 3)))
                if len(out) >= k:
                    break
            return out
        if self._bm is None:
            self._bm = _BM25([p['t'] for p in self.pool])
        acc, nq = self._bm.scores(query)
        need = 1 if nq <= 2 else 2
        cand = sorted(((v[0], i, v[1], v[2]) for i, v in acc.items() if v[2] >= need), reverse=True)
        for _, i, cover, _m in cand:
            if keep and not keep(i):
                continue
            conf = max(0.0, min(1.0, (cover - 0.2) / 0.6))
            if conf <= 0:
                continue
            out.append((i, round(conf, 3)))
            if len(out) >= k:
                break
        return out


# --------------------------------------------------------------------------------------
# Материалы + библиотека
# --------------------------------------------------------------------------------------
def _norm(t):
    return re.sub(r'\W+', ' ', str(t or '').lower()).strip()


def slide_texts(s):
    """Все тексты слайда (для запроса и чтобы не предлагать то, что на слайде уже есть)."""
    out = [s.get('title') or '', s.get('subtitle') or '', s.get('lead') or '', s.get('center') or '',
           s.get('conclusion') or '']
    for it in s.get('items') or []:
        if isinstance(it, dict):
            out += [it.get('title') or '', it.get('text') or '']
        else:
            out.append(str(it))
    out += [str(p) for p in s.get('paragraphs') or []]
    for side in ('left', 'right'):
        if isinstance(s.get(side), dict):
            out.append(s[side].get('title') or '')
            out += [str(x) for x in s[side].get('items') or []]
    out += [str(x) for x in s.get('insights') or []]
    return [clean(t) for t in out if t and str(t).strip()]


def slide_query(s):
    t = slide_texts(s)
    return ' '.join(t)[:1500] if t else ''


def content_words(s):
    """Слов на слайде без заголовка: «тонкий» ли слайд."""
    texts = slide_texts(s)[1:]
    return sum(len(_WORD.findall(t)) for t in texts)


class Finder:
    """Поиск фраз в материалах доклада и в библиотеке. Модель поиска только сравнивает готовые предложения."""

    def __init__(self, doc_pool, lib_pool=None, cfg=None):
        self.doc = Searcher(doc_pool, cfg)
        self.lib = Searcher(lib_pool or [], cfg)
        self.cfg = cfg
        self.warnings = []
        self.qcache = {}

    @property
    def semantic(self):
        return self.doc.semantic

    def prepare(self, progress=None, max_missing=None, lib_max_missing=4000):
        """Векторы материалов и библиотеки. Модель недоступна — поиск по словам с предупреждением."""
        ok = self.doc.prepare(progress, max_missing)
        if ok and self.lib.pool:
            self.lib.prepare(progress, lib_max_missing if max_missing is None else min(max_missing, lib_max_missing))
            if not self.lib.semantic:
                self.warnings.append(f'Библиотека ещё готовится к поиску по смыслу ({len(self.lib.pool)} фраз): '
                                     'из неё фразы подобраны по совпадению слов.')
        if not ok:
            self.lib.vecs = None
            self.warnings.append(f'Модель поиска недоступна ({self.doc.reason}): фразы подобраны по совпадению слов.')
        return ok

    def qvecs(self, queries):
        """Векторы запросов (одной порцией); поиск по словам — None для каждого."""
        if not self.semantic:
            return [None] * len(queries)
        from .llm_client import Cancelled, LLMError
        need = [q for q in dict.fromkeys(queries) if q and q not in self.qcache]
        if need:
            try:
                self.qcache.update(embed_texts(self.cfg, need))
            except Cancelled:
                raise
            except LLMError as e:                            # модель пропала посреди работы — дальше по словам
                self.doc.vecs = self.lib.vecs = None
                self.warnings.append(f'Модель поиска перестала отвечать ({e}): фразы подобраны по совпадению слов.')
                return [None] * len(queries)
        return [self.qcache.get(q) for q in queries]

    def _hits(self, srch, query, qv, k, skip, max_len, numbers):
        def keep(i):
            p = srch.pool[i]
            return len(p['t']) <= max_len and (numbers or not p['num']) and _norm(p['t']) not in skip
        return [(srch.pool[i], c) for i, c in srch.hits(query, qv if srch.semantic else None, k, keep)]

    def search(self, query, k=8, exclude=(), qvec=None, lib=True, max_len=MAX_LEN, lib_numbers=True):
        """Фразы к запросу из материалов и библиотеки: [(фраза, уверенность)], лучшие первыми."""
        skip = {_norm(t) for t in exclude}
        qv = qvec if qvec is not None else self.qvecs([query])[0]
        out = self._hits(self.doc, query, qv, k, skip, max_len, True)
        if lib and self.lib.pool:
            out += self._hits(self.lib, query, qv, k, skip, max_len, lib_numbers)
        out.sort(key=lambda x: (-x[1], x[0]['lib']))
        res, seen = [], []
        from .planner_rules import same_text
        for p, c in out:
            if any(same_text(p['t'], q) for q in seen) or any(same_text(p['t'], e) for e in exclude if len(e) > 20):
                continue
            seen.append(p['t'])
            res.append((p, c))
            if len(res) >= k:
                break
        return res

    def enrich(self, slides, auto_conf=0.5):
        """Дополняет «тонкие» слайды готовыми предложениями из материалов доклада (не из библиотеки):
        пункт без пояснения получает подходящую фразу; слайд-список или текст, где мало слов, — 1–3 фразы.
        Одна фраза не встаёт на два слайда. Возвращает число вставок; у слайда — поле found_n."""
        jobs = []                                            # (слайд, что, номер пункта, запрос)
        for s in slides:
            lay = s.get('layout')
            if lay in META or s.get('_dup'):
                continue
            items = s.get('items') or []
            texts = [clean(it.get('text') or '') for it in items if isinstance(it, dict) and it.get('text')]
            params = sum(1 for t in texts if len(t) <= 20 and re.search(r'\d', t))
            if lay in FILL_TEXT and not (texts and params >= len(texts) / 2):   # таблица параметров — не трогаем
                for j, it in enumerate(items):
                    if isinstance(it, dict) and _wants_text(it, items[j + 1] if j + 1 < len(items) else None):
                        jobs.append((s, 'item', j, f'{it["title"]}. {s.get("title") or ""}'))
            if (lay in ADD_ITEMS or lay == 'text') and content_words(s) < THIN_WORDS:
                jobs.append((s, 'add', None, slide_query(s)))
        if not jobs:
            return 0
        used = set()
        for s in slides:
            used.update(_norm(t) for t in slide_texts(s))
        n = 0
        for (s, what, j, q), qv in zip(jobs, self.qvecs([q for *_, q in jobs])):
            here = slide_texts(s)
            if what == 'item':
                limit = 220 if s.get('layout') in WIDE else 150
                got = self._pick(q, qv, here, used, limit, auto_conf, 1, must=stems(s['items'][j]['title']))
                if got:
                    s['items'][j] = dict(s['items'][j], text=got[0])
            else:
                if s.get('layout') == 'text':
                    want = max(0, 2 - len(s.get('paragraphs') or [])) + (0 if s.get('lead') else 1)
                else:
                    want = max(0, min(3, 4 - len(s.get('items') or [])))
                got = self._pick(q, qv, here, used, 260 if s.get('layout') == 'text' else 220, auto_conf, want)
                for t in got:
                    if s.get('layout') == 'text':
                        if not s.get('lead') and len(t) <= 200:
                            s['lead'] = t
                        else:
                            s['paragraphs'] = list(s.get('paragraphs') or []) + [t]
                    else:
                        s['items'] = list(s.get('items') or []) + [{'title': '', 'text': t}]
            if got:
                s['found_n'] = s.get('found_n', 0) + len(got)
                n += len(got)
        return n

    def _pick(self, q, qv, here, used, max_len, conf, want, must=None):
        """До want законченных предложений к запросу. must — основы слов, хотя бы одна из которых должна быть
        во фразе (пояснение к пункту говорит о том же, о чём заголовок пункта)."""
        if want <= 0:
            return []
        out = []
        must = set(must or ())
        for p, c in self.search(q, k=want + 8, exclude=here, qvec=qv, lib=False, max_len=max_len):
            key = _norm(p['t'])
            if c < conf or key in used or not _sentence_like(p['t']):
                continue
            if must and not must & set(stems(p['t'])):
                continue
            used.add(key)
            out.append(p['t'])
            if len(out) >= want:
                break
        return out

    def attach_found(self, slides, k=8, floor=0.15):
        """«🔎 Подходящие фразы» у каждого слайда с содержанием: поле found — [{t, src, sec, lib, num, c}]."""
        todo = [s for s in slides if s.get('layout') not in META and slide_query(s)]
        for s, qv in zip(todo, self.qvecs([slide_query(s) for s in todo])):
            found = [dict(p, c=c) for p, c in self.search(slide_query(s), k=k, exclude=slide_texts(s), qvec=qv)
                     if c >= floor]
            if found:
                s['found'] = found
        return sum(1 for s in todo if s.get('found'))


def _wants_text(it, nxt):
    """Пункт с заголовком-тезисом без пояснения. Не дополняются: заголовок группы («Достоинства», за ним пункты без
    заголовков), параметр с единицами или числом («Длина – L, мм»), пункт с числом-значением."""
    title = clean(it.get('title') or '')
    if not title or len(clean(it.get('text') or '')) >= 20 or it.get('value'):
        return False
    if isinstance(nxt, dict) and not nxt.get('title') and nxt.get('text'):
        return False
    n = len(_WORD.findall(title))
    if n < 2 or n > 9 or re.search(r'\d|[,–—]\s*[a-zа-яё]{1,4}\.?$|:$', title, re.I):
        return False
    return True


def split_phrase(t):
    """Фраза → пункт {'title', 'text'} для карточек: «Заголовок: текст» → заголовок и текст, иначе только текст."""
    title, text = split_title_text(t)
    return {'title': title, 'text': text} if title and text else {'title': '', 'text': t}


# --------------------------------------------------------------------------------------
# Фразы доклада для окна слайда
# --------------------------------------------------------------------------------------
def save_pool(pool):
    """Фразы материалов доклада → output/cache/pools/<id>.json. Возвращает id (или '' при ошибке)."""
    if not pool:
        return ''
    data = json.dumps(pool, ensure_ascii=False, separators=(',', ':'))
    pid = hashlib.sha1(data.encode('utf-8')).hexdigest()[:16]
    try:
        POOL_DIR.mkdir(parents=True, exist_ok=True)
        p = POOL_DIR / f'{pid}.json'
        if not p.exists():
            tmp = p.with_suffix('.tmp')
            tmp.write_text(data, encoding='utf-8')
            tmp.replace(p)
        else:
            p.touch()
    except OSError:
        return ''
    return pid


def load_pool(pid):
    """Фразы доклада по id (нет файла — материалы удалены очисткой кэша через 7 дней) → список или None."""
    if not POOL_RX.fullmatch(str(pid or '')):
        return None
    try:
        d = json.loads((POOL_DIR / f'{pid}.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None
    return [p for p in d if isinstance(p, dict) and isinstance(p.get('t'), str)] if isinstance(d, list) else None
