# -*- coding: utf-8 -*-
"""
planner_rules.py — ПЛАНИРОВЩИК ПО ПРАВИЛАМ (без ИИ, полностью офлайн)
====================================================================

Превращает модель документа (model.Document) в спецификацию презентации (spec.py).
Логика «как опытный автор презентаций, но по правилам»:

  1. Титульный слайд: название документа (или заданное пользователем).
  2. Содержание — если разделов верхнего уровня ≥ 3.
  3. Каждый раздел → 1–N слайдов. Макет выбирается по СОДЕРЖИМОМУ и ЗАГОЛОВКУ раздела:
       • «Выводы/Заключение/Итоги»               → выводы (плитки)
       • «Цель и задачи» + список                 → мишень (цель в центре)
       • нумерованный список / «этапы, порядок»   → процесс (≤ 6) или таймлайн (7–8, или есть сроки)
       • «цикл»                                   → цикл
       • пункты с числами («— 85 млн руб.»)       → ключевые показатели (KPI)
       • два списка «было/стало», «плюсы/минусы»  → сравнение
       • прочие списки                            → карточки (≤ 6) или список (> 6)
       • подразделы без списков (2–6 шт.)          → карточки «подраздел = карточка»
       • только абзацы                            → «текст с тезисом»
       • таблица с числами                        → диаграмма + выводы по данным (+ таблица)
       • таблица «показатель — значение»          → KPI-плитки
       • текстовая таблица                        → таблица
     Короткий вводный абзац раздела → подзаголовок слайда.
     Абзац «Таким образом… / Вывод…» → баннер-вывод внизу слайда.
     Полный текст раздела → заметки докладчика.
  4. Разделители разделов — если разделов много (≥ 4) и слайдов больше 8.
  5. Итоговый слайд: раздел «Выводы» документа, а если его нет — «Ключевые тезисы».
  6. Подгонка под заданное число слайдов: у каждого слайда есть приоритет; при
     превышении удаляются наименее важные (дубли таблиц, разделители, содержание…).
"""
import math
import re

from .insights import LABEL_UNIT, choose_chart, kpi_from_table, kpi_scale_diverse, label_units, make_insights
from .condense import despeech, theses
from .digest import enumeration, junk, paragraph_points
from .digest import points as digest_points
from .smart import (CHECKED_SCHEMES, DATA_SCHEMES, intro_and_tail, item_from, points_slide, prose_slides,
                    scheme_for_items)
from .spec import LAYOUTS, normalize
from .textutil import (cap, find_number, first_sentence, parse_number, sentences, shorten, split_title_text,
                       typo)

RX = {
    'concl': re.compile(r'(?i)^\W*(\d+[.)]?\s*)?(выводы?|заключение|итоги|резюме|основные выводы|общие выводы|ключевые выводы|'
                        r'результаты работы|итоги работы|результаты проекта)\b'),
    'process': re.compile(r'(?i)этап|шаг|порядок|процесс|алгоритм|сценари|последовательн|дорожн|методик|'
                          r'план\w* работ|план\w* мероприят|реализац|внедрени|мероприят'),
    'goal': re.compile(r'(?i)\bцел[ьи]\b|цели и задач|цель и задач'),
    'cycle': re.compile(r'(?i)цикл|жизненн|круговорот'),
    'compare': re.compile(r'(?i)сравнен|было|стало|до и после|преимуществ|недостат|плюсы|минусы|против|\bvs\b|альтернатив'),
    'kpi': re.compile(r'(?i)показател|результат|эффект|kpi|цифр|достижени|итоги'),
    'intro': re.compile(r'(?i)^введение$|^основное$'),
    'side_left': re.compile(r'(?i)^(было|до|сейчас|текущ|плюсы|преимуществ|вариант а|как есть)'),
    'side_right': re.compile(r'(?i)^(стало|после|будет|целев|минусы|недостатк|вариант б|как будет)'),
    'date': re.compile(r'(?i)\b((19|20)\d\d|[IV]{1,3}\s?кв|[1-4]\s?кв|квартал|январ|феврал|март|апрел|ма[йя]\b|июн|июл|'
                       r'август|сентябр|октябр|ноябр|декабр|полугод)'),
    'final': re.compile(r'(?i)^(вывод|итак|таким образом|в результате|итого|в итоге)'),
}

PRIO = {'conclusions': 9, 'chart': 8, 'kpi': 8, 'target': 8, 'process': 8, 'timeline': 8, 'cycle': 8, 'image': 8,
        'cards': 7, 'compare': 7, 'list': 6, 'text': 5, 'table': 6, 'table_dup': 3, 'agenda': 4, 'section': 2}
MARK_BONUS = 3               # выделенные автором фрагменты — важнее


# --------------------------------------------------------------------------------------
# Вспомогательные функции
# --------------------------------------------------------------------------------------
def _items_from_lists(lists):
    """Пункты всех списков раздела; вложенные пункты присоединяются к родительскому.
    Выделенные автором пункты помечаются (_mark), «во-первых» и скобки вокруг пояснений убираются."""
    out = []
    for b in lists:
        for it in b.items:
            if it.level > 0 and out:
                out[-1]['text'] = (out[-1]['text'] + '; ' + it.text).strip('; ')
                continue
            d = item_from(it.text, it.bold)
            d['_mark'] = bool(it.mark)
            out.append(d)
    return out


def _kpi_item(raw):
    """«Экономия электроэнергии — 85 млн кВт·ч в год» → {value, unit, title}.
    Только короткие пункты, где число — главное (не «оценка 0–100» внутри длинной фразы)."""
    if len(raw) > 100:
        return None
    f = find_number(raw)
    if not f:
        return None
    num, unit, a, b = f
    if re.match(r'\s?[—–-]\s?\d', raw[b:b + 3]):           # диапазон «0–100» — не показатель
        return None
    val = abs(parse_number(num) or 0)
    if not unit and val < 10 and ',' not in num and '.' not in num:
        return None
    before = raw[:a].strip(' —–-:,')
    after_raw = raw[b:]
    after = after_raw.strip(' —–-:,')
    if raw[max(0, a - 1):a] == '(' or (before and len(after) > 30):
        return None                                   # число в скобках или в середине длинной фразы
    glue = '' if after_raw[:1] and not after_raw[:1].isspace() else ' '     # «кВт·ч» — без пробела
    if before:
        label = before
        unit = (unit + glue + after).strip() if len(after) <= 25 else unit
        extra = after if len(after) > 25 else ''
    else:
        label = after
        extra = ''
    if not label:
        return None
    return {'value': num, 'unit': unit.strip(), 'title': cap(shorten(label, 60)), 'text': shorten(extra, 120)}


def _subtitle_and_conclusion(paras):
    """Короткий первый абзац → подзаголовок; абзац «Таким образом…» → вывод-баннер."""
    sub, concl, rest = '', '', []
    for i, p in enumerate(paras):
        t = p.text
        if i == 0 and len(t) <= 150:
            sub = t.rstrip(':')
            continue
        if i == 0:
            fs = sentences(t)[0] if sentences(t) else ''
            if fs and len(fs) <= 140:
                sub = fs                          # длинный вводный абзац → его первое предложение
                rest.append(p)
                continue
        if RX['final'].match(t) and not concl:
            concl = re.sub(r'(?i)^(вывод[ы]?\s*[:.—–-]\s*)', '', t)
            continue
        rest.append(p)
    return sub, concl, rest


def _notes(sec):
    t = sec.all_text(with_children=True)
    return t[:4000]


def _text_slide(title, paras, sec_label, notes):
    """Только абзацы → пересказ: главная мысль раздела крупно и по тезису из каждого абзаца."""
    paras = [p for p in paras if not junk(p.text)]
    if not paras:
        return None
    return points_slide({'title': title, 'section': sec_label, 'notes': notes}, digest_points(paras))


def _pairs_as_cards(paras):
    """Абзацы с жирным началом или «Заголовок: текст» → карточки (короткое первое предложение
    заголовком не считается: «Уважаемые коллеги!» — не заголовок)."""
    items = []
    for p in paras:
        t, x = split_title_text(p.text, p.bold)
        explicit = bool(p.bold) or bool(re.match(r'^.{2,70}?(?::|\s[—–-]\s)', p.text))
        if not t or not explicit or t.endswith(('!', '?')):
            return None
        items.append({'title': t, 'text': x})
    return items if 2 <= len(items) <= 6 else None


# --------------------------------------------------------------------------------------
# Таблицы
# --------------------------------------------------------------------------------------
MAX_TABLE_ROWS = 40          # больше строк текстовой таблицы на слайды не выводится


def _cost(s):
    """Сколько слайдов на самом деле займёт слайд плана (длинные таблицы и списки делятся)."""
    lay = s.get('layout')
    if lay == 'table':
        return max(1, math.ceil(len(s.get('rows') or []) / 12))
    info = LAYOUTS.get(lay) or {}
    if info.get('kind') == 'items' and info.get('max'):
        return max(1, math.ceil(len(s.get('items') or []) / info['max']))
    return 1


_UNIT_HDR = re.compile(r'(?i)^\s*(ед\.?\s*(изм\.?|измерения)?|единиц\w*( измерения)?)\s*$')
_KEY_ROW = re.compile(r'(?i)npv|чдд|irr|вндд?|окупаемост|капитальн|капвложени|инвестици|добыч|прирост|индекс доходност|'
                      r'выручк|ebitda|прибыл|запас|кин\b|себестоимост|эффект')


def _unit_col(t):
    """Столбец «Ед. изм.» (по заголовку или по коротким значениям-единицам) или None."""
    for j, c in enumerate(t.columns):
        if j != t.label_col and _UNIT_HDR.match(str(c)):
            return j
    return None


def _mixed_unit_slides(t, title, sec_label, tid):
    """Таблица «Показатель | Значение | Ед. изм.» с разными единицами: диаграмма по ней бессмысленна
    (тонны рядом с процентами и годами). Вместо неё — главные показатели плитками и вся таблица."""
    uc = _unit_col(t)
    if uc is None:
        return _label_unit_slides(t, title, sec_label, tid)
    vcols = [j for j in t.numeric_cols if j != uc and j != t.label_col]
    if not vcols:
        return None
    j = vcols[0]
    units = {str(r[uc]).strip().lower() for r in t.rows if str(r[uc]).strip()}
    if len(units) < 3:
        return None
    lab = t.label_col
    rows = [r for r in t.rows if parse_number(r[j]) is not None and not re.match(r'(?i)\s*в\s+т\.?\s*ч', str(r[lab]))]
    key = sorted(rows, key=lambda r: (0 if _KEY_ROW.search(str(r[lab])) else 1, t.rows.index(r)))[:6]
    key.sort(key=t.rows.index)
    items = [{'value': str(r[j]).strip(), 'unit': str(r[uc]).strip(), 'title': shorten(str(r[lab]), 60), 'text': ''}
             for r in key]
    out = [({'layout': 'kpi', 'title': title, 'items': items, 'section': sec_label, '_table': tid}, PRIO['kpi'])]
    cols = [c for k, c in enumerate(t.columns) if k not in t.id_cols]
    rws = [[c for k, c in enumerate(r) if k not in t.id_cols] for r in t.rows]
    out.append(({'layout': 'table', 'title': shorten(title, 66) + ' — все показатели', 'columns': cols,
                 'rows': rws[:MAX_TABLE_ROWS], 'section': sec_label, '_table': tid, '_dup': len(rws) <= len(items)},
                PRIO['table']))
    return out


_CHG_HDR = re.compile(r'(?i)изменени|отклонени|темп|динамик|прирост,?\s*%|\+/-|±|Δ')


def _label_unit_slides(t, title, sec_label, tid):
    """«Выручка, млрд руб. | 2024 | 2025 | Изменение, %» — строки в разных единицах: плитки по главным
    строкам (значение последнего периода, в пояснении — прошлый период и изменение) и вся таблица."""
    if len(label_units(t)) < 2:
        return None
    lab = t.label_col
    chg = next((j for j, c in enumerate(t.columns) if j != lab and _CHG_HDR.search(str(c))), None)
    vcols = [j for j in range(len(t.columns)) if j not in (lab, chg) and j not in t.id_cols
             and sum(parse_number(r[j]) is not None for r in t.rows if j < len(r)) >= len(t.rows) * 0.6]
    if not vcols:
        return None
    yr = lambda j: max([int(y) for y in re.findall(r'(?:19|20)\d\d', str(t.columns[j]))] or [0])
    j = max(vcols, key=lambda c: (yr(c), c))                       # последний период
    prev = [c for c in vcols if c != j and yr(c) < yr(j)]
    pj = max(prev, key=yr) if prev else None
    rows = [r for r in t.rows if parse_number(r[j]) is not None and not re.match(r'(?i)\s*в\s+т\.?\s*ч', str(r[lab]))]
    key = sorted(rows, key=lambda r: (0 if _KEY_ROW.search(str(r[lab])) else 1, t.rows.index(r)))[:6]
    key.sort(key=t.rows.index)
    items = []
    for r in key:
        m = LABEL_UNIT.search(str(r[lab]))
        name, unit = (str(r[lab])[:m.start()].strip(), m.group(1).strip()) if m else (str(r[lab]).strip(), '')
        bits = []
        if pj is not None and parse_number(r[pj]) is not None:
            bits.append(f'{t.columns[pj]}: {str(r[pj]).strip()}')
        if chg is not None and str(r[chg]).strip() not in ('', '—', '-'):
            cv = str(r[chg]).strip()
            cu = '' if re.search(r'%|п\.\s?п', cv) or not re.search(r'%', str(t.columns[chg])) else ' %'
            bits.append(f'изменение {cv}{cu}')
        items.append({'value': str(r[j]).strip(), 'unit': unit, 'title': shorten(name, 60),
                      'text': ('; '.join(bits).rstrip('.') + '.') if bits else ''})
    stitle = f'{title}: {t.columns[j]}' if yr(j) and str(t.columns[j]) not in title else title
    out = [({'layout': 'kpi', 'title': shorten(stitle, 88), 'items': items, 'section': sec_label, '_table': tid},
            PRIO['kpi'])]
    cols = [c for k, c in enumerate(t.columns) if k not in t.id_cols]
    rws = [[c for k, c in enumerate(r) if k not in t.id_cols] for r in t.rows]
    out.append(({'layout': 'table', 'title': shorten(title, 66) + ' — все показатели', 'columns': cols,
                 'rows': rws[:MAX_TABLE_ROWS], 'section': sec_label, '_table': tid, '_dup': len(rws) <= len(items)},
                PRIO['table']))
    return out


def _table_slides(doc, tid, sec_title, sec_label, many):
    t = doc.tables[tid]
    title = shorten(t.title or sec_title, 80)
    if many and not t.title:
        title = f'{sec_title}: {t.columns[t.label_col]}' if t.columns else sec_title
    out = []
    mixed = _mixed_unit_slides(t, title, sec_label, tid)
    if mixed:
        return mixed
    kpis = kpi_from_table(t)
    if kpis and (kpi_scale_diverse(t) or RX['kpi'].search(title + ' ' + sec_title)):
        out.append(({'layout': 'kpi', 'title': title, 'items': kpis, 'section': sec_label}, PRIO['kpi']))
        return out
    chart = choose_chart(t, sec_title)
    rows = [r for i, r in enumerate(t.rows)]
    if chart:
        ins = make_insights(chart)
        unit = chart.get('unit')
        sub = f'Единицы: {unit}' if unit and unit != '%' else ''
        chart.pop('note', None)
        out.append(({'layout': 'chart', 'title': title, 'subtitle': sub, 'chart': chart, 'insights': ins,
                     'section': sec_label, '_table': tid}, PRIO['chart']))
        if len(t.columns) <= 7 and len(rows) <= 14:
            out.append(({'layout': 'table', 'title': shorten(title, 70) + ' — данные', 'columns': t.columns, 'rows': rows,
                         'section': sec_label, '_table': tid, '_dup': True}, PRIO['table_dup']))
    else:
        sch = _text_table_scheme(t, title, sec_title, sec_label)
        if sch:
            out.append(sch)
        else:
            cols = [c for j, c in enumerate(t.columns) if j not in t.id_cols]
            rws = [[c for j, c in enumerate(r) if j not in t.id_cols] for r in rows]
            sl = {'layout': 'table', 'title': title, 'columns': cols, 'rows': rws[:MAX_TABLE_ROWS],
                  'section': sec_label, '_table': tid}
            if len(rws) > MAX_TABLE_ROWS:          # длинный реестр на слайдах не читается
                sl['subtitle'] = f'Первые {MAX_TABLE_ROWS} строк из {len(rws)} — полностью в исходном файле'
                sl['notes'] = f'Таблица сокращена: показаны {MAX_TABLE_ROWS} строк из {len(rws)}.'
            out.append((sl, PRIO['table']))
    return out


SIDES_RX = re.compile(r'(?i)^(было|до|вручную|сейчас|текущ|как есть|плюс|преимущ)')
SIDES_RX2 = re.compile(r'(?i)^(стало|после|с роботом|автоматическ|будет|целев|как будет|минус|недостат)')


def _text_table_scheme(t, title, sec_title, sec_label):
    """Небольшая текстовая таблица → наглядная схема вместо таблицы:
       • «Этап | Вручную | С роботом» (было/стало)     → сравнение;
       • «Этап | Шаг | Описание» с группами в 1-м столбце → таймлайн / процесс;
       • «Название | Описание» (2 столбца, ≤ 8 строк)   → карточки или список."""
    cols = [j for j in range(len(t.columns)) if j not in t.id_cols]
    rows = [r for r in t.rows if any(str(r[j]).strip() for j in cols)]
    if not rows or len(rows) > 8:
        return None
    hdr = [str(t.columns[j]).strip() for j in cols]
    cell = lambda r, j: str(r[cols[j]]).strip()
    # сравнение
    if len(cols) == 3 and SIDES_RX.search(hdr[1]) and SIDES_RX2.search(hdr[2]):
        left = [f'{cell(r, 0)}: {cell(r, 1)}' if cell(r, 0) else cell(r, 1) for r in rows]
        right = [cell(r, 2) for r in rows]
        style = 'pros_cons' if re.search(r'(?i)плюс|преимущ', hdr[1]) else 'before_after'
        return ({'layout': 'compare', 'title': title, 'left': {'title': hdr[1], 'items': left},
                 'right': {'title': hdr[2], 'items': right}, 'style': style, 'section': sec_label}, PRIO['compare'])
    # этапы с группами
    if len(cols) == 3:
        groups = [cell(r, 0) for r in rows]
        grouped = len(set(g for g in groups if g)) < len(rows)
        if grouped or RX['process'].search(sec_title + ' ' + title):
            items = [{'label': cell(r, 0), 'title': re.sub(r'^\d+[.)]\s*', '', cell(r, 1)), 'text': cell(r, 2)} for r in rows]
            lay = 'timeline' if len(rows) >= 3 else 'process'
            return ({'layout': lay, 'title': title, 'items': items, 'section': sec_label}, PRIO['timeline'])
    # «название — описание»
    if len(cols) == 2:
        items = [{'title': shorten(cell(r, 0), 60), 'text': cell(r, 1)} for r in rows]
        lay = 'cards' if len(rows) <= 6 else 'list'
        return ({'layout': lay, 'title': title, 'items': items, 'section': sec_label}, PRIO[lay])
    return None


# --------------------------------------------------------------------------------------
# Раздел → слайды
# --------------------------------------------------------------------------------------
_NUM_PREFIX = re.compile(r'^\d{1,2}(?:\.\d{1,2})*\.?\s+(?=[А-ЯЁA-Z«])')     # «3.1 Суть технологии»


def section_slides(doc, sec, sec_label):
    """Возвращает список (слайд, приоритет) для раздела и его подразделов."""
    out = []
    paras = [b for b in sec.blocks if b.kind == 'para']
    lists = [b for b in sec.blocks if b.kind == 'list']
    tables = [b for b in sec.blocks if b.kind == 'table']
    images = [b for b in sec.blocks if b.kind == 'image']
    title = shorten(_NUM_PREFIX.sub('', sec.title), 80)
    notes = _notes(sec)
    sub, concl, rest_paras = _subtitle_and_conclusion(paras) if lists or tables else ('', '', paras)
    if lists:
        # подзаголовок — из абзаца ДО списка (вводные «…следующие задачи:» и вопросы пропускаются),
        # вывод — из абзаца ПОСЛЕ списка
        first_l = sec.blocks.index(lists[0])
        last_l = sec.blocks.index(lists[-1])
        before = [b for b in sec.blocks[:first_l] if b.kind == 'para']
        after = [b for b in sec.blocks[last_l + 1:] if b.kind == 'para']
        sub2, concl2 = intro_and_tail(before, after)
        if not RX['goal'].search(sec.title):
            sub = sub2 if (sub2 or not sub or sub.endswith('?') or sub.endswith(':')) else sub
        concl = concl or concl2
        rest_paras = [p for p in rest_paras if p not in before and p not in after]
    marked_paras = [b for b in paras if b.mark or b.mark_text]
    if marked_paras:                     # выделенный автором абзац — в подзаголовок (если короткий) или вывод
        mp = marked_paras[0]
        mt = mp.mark_text or mp.text
        if len(mt) <= 140 and not lists:
            sub = mt
        elif not concl or (mp.mark_text and mp.mark_text.lower() in concl.lower()):
            # в вывод — именно выделенная часть, без вводных слов абзаца («Главный результат: …»)
            mt = cap(mt.strip())
            concl = shorten(mt if mt[-1:] in '.!?…' else mt + '.', 190)

    # ---- «Выводы / Заключение» -----------------------------------------------------------
    if RX['concl'].search(sec.title):
        items = _items_from_lists(lists)
        if not items:                    # выводы абзацами: главные мысли и перечни («три вопроса: о …, о …»)
            for p in paras:
                if junk(p.text):
                    continue
                e = enumeration(p.text)
                if e:
                    head = [t for t in paragraph_points(p.text, 2, 240) if not any(t[:30] in i_ for i_ in e[1])
                            and not same_text(t, e[0])][:1]
                    items += [{'title': '', 'text': t} for t in head]
                    items += [item_from(t) for t in e[1]]
                else:
                    items += [{'title': '', 'text': t} for t in paragraph_points(p.text, 3, 240, joint=False)]
        if items:
            lay = 'conclusions' if len(items) <= 6 else 'list'
            out.append(({'layout': lay, 'title': title, 'items': items, 'section': sec_label,
                         'notes': notes, '_role': 'conclusions'}, PRIO['conclusions']))
            return out

    # ---- Списки ------------------------------------------------------------------------------
    if lists:
        # сравнение: два списка, у каждого перед ним — подпись «Было:»/«Стало:» и т. п.
        if len(lists) == 2 and (RX['compare'].search(sec.title) or _side_labels(sec)):
            lab = _side_labels(sec) or ('Было', 'Стало')
            it1 = [i.text for i in lists[0].items]
            it2 = [i.text for i in lists[1].items]
            style = 'pros_cons' if re.search(r'(?i)плюс|преимущ|минус|недостат', ' '.join(lab) + sec.title) else 'before_after'
            out.append(({'layout': 'compare', 'title': title, 'subtitle': sub, 'section': sec_label,
                         'left': {'title': lab[0], 'items': it1}, 'right': {'title': lab[1], 'items': it2},
                         'style': style, 'conclusion': concl, 'notes': notes}, PRIO['compare']))
        else:
            items = _items_from_lists(lists)
            n = len(items)
            ordered = any(b.ordered for b in lists)
            has_dates = sum(bool(RX['date'].search(i['_raw'])) for i in items) >= max(2, n * 0.6)
            kpis = [_kpi_item(i['_raw']) for i in items]
            n_kpi = sum(k is not None for k in kpis)
            goal_para = next((p.text for p in paras if re.search(r'(?i)\bцел(ь|и|ью)\b', p.text)), '')
            base = {'title': title, 'subtitle': sub, 'section': sec_label, 'conclusion': concl, 'notes': notes}

            scheme, special = _pick_scheme(sec.title, n, has_dates, base, items, sub or sec.title)
            if special:
                out.append((special, PRIO['cards'] + 1))
            elif RX['goal'].search(sec.title) and goal_para and 3 <= n <= 6:
                center = re.sub(r'(?i)^цел[ьи]\s*(\w+\s*)?[—–:-]\s*', '', goal_para)
                center = re.sub(r'(?i)^(целью|цель)\s+(проекта|работы|программы|исследования)?\s*(является|—|-|:)\s*',
                                '', center)
                center = cap(shorten(center, 160))
                out.append((dict(base, layout='target', subtitle='', center=center, items=items), PRIO['target']))
            elif RX['cycle'].search(sec.title) and 3 <= n <= 6:
                out.append((dict(base, layout='cycle', center=shorten(sec.title, 60), items=items), PRIO['cycle']))
            elif (ordered or RX['process'].search(sec.title)) and n >= 2 and not (n_kpi >= max(2, n * 0.6)):
                if has_dates or n > 6:
                    for it in items:
                        m = RX['date'].search(it['_raw'])
                        if m and has_dates:
                            it['label'] = _date_label(it['_raw'])
                    lay = 'timeline' if n <= 8 else 'list'
                else:
                    lay = 'process'
                out.append((dict(base, layout=lay, items=items), PRIO.get(lay, 6)))
            elif n_kpi >= max(2, n * 0.6) and n <= 6:
                ks = [k for k in kpis if k]
                out.append((dict(base, layout='kpi', items=ks), PRIO['kpi']))
            elif scheme and scheme != 'cycle' and scheme not in DATA_SCHEMES:
                extra = {}
                if scheme in ('hub', 'pillars', 'tree', 'venn', 'petals', 'mindmap', 'converge', 'fishbone'):
                    extra['center'] = shorten(sub or sec.title, 120)
                if scheme == 'path':
                    for it in items:
                        it['label'] = _date_label(it['_raw'])
                if scheme == 'roadmap':
                    for it in items:
                        it['label'] = _date_label(it['_raw'])
                out.append((dict(base, layout=scheme, items=items, **extra), PRIO['cards'] + 1))
            elif n <= 6:
                out.append((dict(base, layout='cards', items=items), PRIO['cards']))
            else:
                out.append((dict(base, layout='list', items=items), PRIO['list']))
        # абзацы, которые не вошли в подзаголовок, — отдельным текстовым слайдом, если их много
        long_paras = [p for p in rest_paras if len(p.text) > 200]
        if len(long_paras) >= 2:
            ts = _text_slide(title + ': пояснения', long_paras, sec_label, notes)
            if ts:
                out.append((ts, PRIO['text'] - 1))

    # ---- Таблицы -----------------------------------------------------------------------------
    explain = []
    if tables and not lists:                 # развёрнутые абзацы рядом с таблицей — отдельным слайдом перед ней
        explain = [p for p in paras if len(p.text) > 200 and not junk(p.text) and p.text != concl]
        if explain:
            ts = _text_slide(title, explain, sec_label, notes)
            if ts:
                out.append((ts, PRIO['text']))
            else:
                explain = []
    for b in tables:
        for sl, pr in _table_slides(doc, b.table_id, sec.title, sec_label, len(tables) > 1):
            if not sl.get('notes'):
                sl['notes'] = notes
            if sub and not sl.get('subtitle') and not lists and len(tables) == 1 and not explain:
                sl['subtitle'] = despeech(sub) or sub
            if concl and sl['layout'] == 'chart' and not sl.get('conclusion'):
                sl['conclusion'] = concl
            out.append((sl, pr))

    # ---- Только абзацы (и рисунки): схема вместо «простыни» текста -----------------------------
    if not lists and not tables and (images or (paras and (sec.marker or not _pairs_as_cards(paras)))):
        got = prose_slides(doc, sec, title, sec_label, notes, PRIO)
        if got:
            out.extend(got)
            paras = []                                  # обработано
    if not lists and not tables and paras:
        cards = _pairs_as_cards(paras)
        if cards:
            out.append(({'layout': 'cards', 'title': title, 'items': cards, 'section': sec_label,
                         'notes': notes}, PRIO['cards']))
        elif not sec.children or sum(len(p.text) for p in paras) > 250:
            ts = _text_slide(title, paras, sec_label, notes)
            if ts:
                out.append((ts, PRIO['text']))

    # ---- Подразделы ------------------------------------------------------------------------------
    kids = sec.children
    simple = kids and all(not any(b.kind in ('list', 'table', 'image') for b in k.blocks) and not k.children
                          and not k.marker for k in kids)
    kid_len = [sum(len(b.text) for b in k.blocks if b.kind == 'para') for k in kids] if kids else []
    long_kids = bool(kid_len) and sum(kid_len) / len(kid_len) > 600     # подразделы «на страницу» — каждому свой слайд
    if simple and 2 <= len(kids) <= 6 and not long_kids:
        items = []
        for k in kids:
            kp = [b for b in k.blocks if b.kind == 'para' and not junk(b.text)]
            whole = ' '.join(b.text for b in kp)
            if len(whole) <= 300:
                txt = whole                       # короткий подраздел — целиком
            else:
                pts = [t for _, t, _ in digest_points(kp, per_par=2 if len(kp) == 1 else 1, max_chars=200)]
                txt = ' '.join(pts) if pts else ' '.join(theses(whole, 2))
            items.append({'title': shorten(_NUM_PREFIX.sub('', k.title), 60),
                          'text': shorten(txt, 300)})
        out.append(({'layout': 'cards', 'title': title, 'items': items, 'section': sec_label,
                     'subtitle': sub if not lists and not tables else '', 'notes': notes}, PRIO['cards']))
    else:
        for k in kids:
            out.extend(section_slides(doc, k, sec_label))
    return out


def _side_labels(sec):
    """Подписи перед двумя списками («Было:» / «Стало:»), если они есть."""
    labels, prev = [], None
    for b in sec.blocks:
        if b.kind == 'list' and prev is not None and prev.kind == 'para' and len(prev.text) <= 60:
            labels.append(prev.text.rstrip(':'))
        prev = b
    if len(labels) == 2 and RX['side_left'].search(labels[0]) and RX['side_right'].search(labels[1]):
        return labels[0], labels[1]
    return None


def _pick_scheme(title, n, has_dates, base, items, center):
    """Схема по смыслу заголовка, для которой в пунктах хватает данных. Возвращает (схема, готовый
    слайд для схем с особыми данными — SWOT, риски, план-график, чек-лист — или None)."""
    from .layouts.extra import date_span
    from .layouts.mapslide import map_ok
    from .variety import _ok
    if map_ok(items):                                        # пункты — страны: карта
        return 'map', dict(base, layout='map', items=[dict(it) for it in items])
    skip = ()
    while True:
        k = scheme_for_items(title, n, has_dates, skip)
        if k not in CHECKED_SCHEMES:
            return k, None
        its = [dict(it) for it in items]
        if k == 'gantt':
            for it in its:
                it['label'] = date_span(it['_raw'])
        s = dict(base, layout=k, items=its)
        if k in ('fishbone', 'petals', 'mindmap'):
            s['center'] = shorten(center, 120)
        if _ok(s, k):
            return k, (s if k in DATA_SCHEMES else None)
        skip += (k,)


def _date_label(text):
    m = re.search(r'(?i)((?:[IV]{1,3}|[1-4])\s?кв\.?\s?(?:(?:19|20)\d\d)?|(?:19|20)\d\d(?:\s?[—–-]\s?(?:19|20)\d\d)?|'
                  r'(?:январ|феврал|март|апрел|ма[йя]|июн|июл|август|сентябр|октябр|ноябр|декабр)\w*\s?(?:(?:19|20)\d\d)?)', text)
    return m.group(1).strip() if m else ''


# --------------------------------------------------------------------------------------
# Главная функция
# --------------------------------------------------------------------------------------
def plan_rules(doc, opts=None):
    """doc — model.Document; opts — настройки из интерфейса. Возвращает (spec, warnings)."""
    opts = opts or {}
    warnings = list(doc.warnings)
    target = int(opts.get('target_slides') or 0)

    sections = list(doc.sections)
    meta = {
        'title': opts.get('title') or doc.title or 'Презентация',
        'subtitle': opts.get('subtitle') or doc.subtitle or '',
        'event': opts.get('event') or '',
        'date': opts.get('date') or '',
        'animations': opts.get('animations', True),
    }
    # Короткое «Введение» из одного абзаца → подзаголовок титульного слайда
    if sections and RX['intro'].match(sections[0].title) and not sections[0].children:
        b = sections[0].blocks
        if len(b) == 1 and b[0].kind == 'para' and len(b[0].text) <= 170 and not meta['subtitle']:
            meta['subtitle'] = b[0].text
            sections = sections[1:]

    # ---- слайды по разделам ----------------------------------------------------------------
    script = any(s.marker for s in doc.walk())    # документ-сценарий «Слайд 1, Слайд 2…»
    short_doc = shorten(meta['title'], 40)
    groups = []                      # [(раздел, [(слайд, приоритет)])]
    appendix = set()                 # разделы-обёртки слайдов сценария («Дополнительные материалы»)
    for sec in sections:
        label = short_doc if sec.marker else shorten(sec.title, 40)
        sl = section_slides(doc, sec, label)
        if sec.marked():             # раздел с пометками автора — важнее и не выпадает при подгонке
            sl = [(dict(s, _mark=True), p + MARK_BONUS) for s, p in sl]
        if not sec.marker and sec.children and any(k.marker for k in sec.children):
            appendix.add(id(sec))
        if sl:
            groups.append((sec, sl))

    groups = _drop_repeated_numbers(groups, warnings)
    has_concl = any(s.get('_role') == 'conclusions' for _, g in groups for s, _ in g)
    content_secs = [sec for sec, _ in groups if not RX['concl'].search(sec.title) and not RX['intro'].match(sec.title)]

    # ---- «Ключевые тезисы», если в документе нет выводов -------------------------------------
    auto_concl = None
    if not has_concl and not script and opts.get('conclusions', True) and len(content_secs) >= 3:
        items = []
        for sec, g in groups:
            if RX['intro'].match(sec.title):
                continue
            first = next((s for s, _ in g), None)
            txt = ''
            if first:
                if first.get('lead'):
                    txt = first['lead']
                elif first.get('items'):
                    it = first['items'][0]
                    txt = it.get('text') or it.get('title') or ''
                    if first['layout'] == 'kpi':
                        txt = f'{it.get("title")}: {it.get("value")} {it.get("unit", "")}'
                elif first.get('insights'):
                    txt = first['insights'][0]
            if txt:
                items.append({'title': shorten(sec.title, 50), 'text': first_sentence(txt, 160)})
        if len(items) >= 2:
            auto_concl = ({'layout': 'conclusions', 'title': 'Ключевые тезисы', 'items': items[:6],
                           'section': 'Итоги', '_role': 'conclusions'}, PRIO['conclusions'] - 1)

    # ---- сборка с содержанием и разделителями -------------------------------------------------
    n_content = sum(len(g) for _, g in groups)
    want_agenda = opts.get('agenda', 'auto')
    want_sections = opts.get('sections', 'auto')
    main_secs = [s for s in content_secs if id(s) not in appendix]
    agenda_ok = (want_agenda is True) or (want_agenda == 'auto' and len(main_secs) >= (7 if script else 3))
    sections_ok = (want_sections is True) or (want_sections == 'auto' and len(content_secs) >= 5 and n_content >= 14
                                              and not script)

    seq = []                         # [(слайд, приоритет)]
    if agenda_ok:
        items = [{'title': '', 'text': shorten(s.title, 70)} for s in main_secs][:10]
        seq.append(({'layout': 'agenda', 'title': 'Содержание', 'items': items}, PRIO['agenda']))
    num = 0
    tail = []                                       # выводы — всегда в конце доклада
    for gi, (sec, g) in enumerate(groups):
        is_main = sec in content_secs
        g = [(s, p + 2 if is_main and sec is content_secs[0] and p < PRIO['conclusions'] and not s.get('_dup') else p)
             for s, p in g]
        real = [x for x in g if not x[0].get('_dup')]
        if (sections_ok and is_main and len(real) >= 2) or (id(sec) in appendix and real):
            num += 1
            seq.append(({'layout': 'section', 'title': sec.title, 'subtitle': '', 'number': f'{num:02d}'},
                        PRIO['section']))
        for x in g:
            # выводы — в конец доклада; в документе-сценарии порядок задал автор
            (tail if x[0].get('_role') == 'conclusions' and not script else seq).append(x)
    seq.extend(tail)
    if auto_concl:
        seq.append(auto_concl)

    # ---- подгонка под заданное число слайдов --------------------------------------------------
    if not opts.get('data_tables'):                # таблицы-дубли к диаграммам — только по галочке
        seq = [x for x in seq if not x[0].get('_dup')]
    total = lambda: sum(_cost(s) for s, _ in seq)  # с учётом слайдов-продолжений
    if target:
        budget = max(1, target - 2)                # минус титул и финал
        if total() > budget:
            # 1) убираем разделители, 2) дубли таблиц, 3) по возрастанию приоритета (с конца)
            for kill in ('section', 'table_dup', 'agenda'):
                if total() <= budget:
                    break
                if kill == 'section':
                    seq = [x for x in seq if x[0]['layout'] != 'section']
                elif kill == 'agenda':
                    seq = [x for x in seq if x[0]['layout'] != 'agenda']
                else:
                    while total() > budget and any(s.get('_dup') for s, _ in seq):
                        idx = max(i for i, (s, _) in enumerate(seq) if s.get('_dup'))
                        seq.pop(idx)
            while total() > budget and len(seq) > 1:
                # выделенные автором слайды удаляются в последнюю очередь
                pool = [i for i, (s, _) in enumerate(seq) if not s.get('_mark')] or list(range(len(seq)))
                low = min(seq[i][1] for i in pool)
                idx = max(i for i in pool if seq[i][1] == low)
                seq.pop(idx)
            warnings.append(f'Материала больше, чем на {target} слайдов: менее важные слайды пропущены.')
        elif total() < budget:
            warnings.append(f'В документе материала примерно на {total() + 2} слайдов — '
                            f'меньше заданных {target}. Добавьте файлы или уменьшите число слайдов.')

    ag = next((x for x, _ in seq if x.get('layout') == 'agenda'), None)
    if ag:                                         # в содержании — только разделы, у которых остались слайды (1.7)
        key = lambda t: re.sub(r'\W+', ' ', str(t or '')).lower().strip()
        have = [key(x.get('section') or x.get('title')) for x, _ in seq if x.get('layout') not in ('agenda', 'section')]
        have = [h for h in have if h]
        ag['items'] = [it for it in ag['items']
                       if any(h.startswith(key(it['text'])[:20]) or key(it['text']).startswith(h[:20]) for h in have)]
        if len(ag['items']) < 2:
            seq = [x for x in seq if x[0] is not ag]
    if opts.get('_finder'):                        # режим «поиск фраз»: «тонкие» слайды — готовыми фразами (1.7)
        opts['_finder'].enrich([s for s, _ in seq])
    slides = [{'layout': 'title'}] + [s for s, _ in seq] + [{'layout': 'end'}]
    slides = finish_slides(slides, opts)
    spec, w2 = normalize({'meta': meta, 'slides': slides})
    return spec, warnings + w2


NUMERIC_LAYOUTS = ('kpi', 'bars', 'gauge', 'bubbles', 'funnel')


def _numbers(s):
    """Множество чисел слайда показателей (None — если это не слайд показателей или чисел меньше трёх)."""
    if s.get('layout') not in NUMERIC_LAYOUTS:
        return None
    vals = set()
    for it in s.get('items') or []:
        if isinstance(it, dict):
            v = parse_number(str(it.get('value') or '').replace('до ', ''))
            if v is not None:
                vals.add(round(v, 6))
    return vals if len(vals) >= 3 else None


def _drop_repeated_numbers(groups, warnings):
    """Слайд показателей, повторяющий числа более раннего (те же цифры в Word и в Excel), пропускается.
    Выделенные автором слайды не удаляются."""
    seen = []
    out = []
    for sec, g in groups:
        kept = []
        for s, p in g:
            nums = _numbers(s)
            if nums:
                prev = next((t for ns, t in seen if len(nums & ns) >= 0.75 * len(nums)), None)
                if prev is not None and not s.get('_mark'):
                    warnings.append(f'Слайд «{s.get("title") or sec.title}» повторяет показатели слайда «{prev}» — '
                                    'пропущен.')
                    continue
                seen.append((nums, s.get('title') or sec.title))
            kept.append((s, p))
        if kept:
            out.append((sec, kept))
    return out


def _words(t):
    return re.findall(r'[0-9a-zа-яё]+', (t or '').lower())


def same_text(a, b):
    """Одна и та же мысль: один текст содержит другой или почти все слова совпадают."""
    wa, wb = _words(a), _words(b)
    if not wa or not wb:
        return False
    sa, sb = ' '.join(wa), ' '.join(wb)
    if sa in sb or sb in sa:
        return True
    A, B = set(wa), set(wb)
    return min(len(A), len(B)) >= 5 and len(A & B) / min(len(A), len(B)) >= 0.8


_CONCL_LABEL = re.compile(r'(?i)^((главн|основн|ключев|общ)\w*\s+)?(вывод|итог|результат)\w*\s*[:—–-]\s*(?=\w)')


def _dedupe_captions(s):
    """Подзаголовок и вывод-баннер не повторяют друг друга (остаётся вывод); тезис текста — не повторяется в выводе.
    Метка «Главный результат:» в начале вывода убирается — у баннера уже есть подпись «Вывод»."""
    if isinstance(s.get('conclusion'), str) and _CONCL_LABEL.match(s['conclusion']):
        s['conclusion'] = cap(_CONCL_LABEL.sub('', s['conclusion']))
    if s.get('subtitle') and s.get('conclusion') and same_text(s['subtitle'], s['conclusion']):
        s['subtitle'] = ''
    if s.get('lead') and s.get('conclusion') and same_text(s['lead'], s['conclusion']):
        s['conclusion'] = ''


def finish_slides(slides, opts=None):
    """Общая доводка плана (и для правил, и для ИИ): варианты на выбор для каждого слайда,
    разнообразие соседних слайдов, очистка служебных полей, типографика."""
    from .alternatives import attach_alts
    from .convert import convert_slide
    from .variety import diversify
    opts = opts or {}
    for i, s in enumerate(slides):                # читаемость: длинная цепочка шагов — нумерованными плашками
        items = s.get('items') or []
        if s.get('layout') in ('process', 'cards') and len(items) >= 5 and \
                sum(len(it.get('text') or '') for it in items if isinstance(it, dict)) / len(items) > 70:
            s2 = convert_slide(dict(s), 'list')
            if s2.get('layout') == 'list':
                s2['variant'] = 'tiles'
                slides[i] = s2
    if opts.get('alternatives', True):
        attach_alts(slides)                      # 3–4 варианта оформления на выбор
    if opts.get('variety', True):
        slides = diversify(slides)               # соседние слайды — в разных схемах
    for s in slides:
        _dedupe_captions(s)
        for a in s.get('alts') or []:
            _dedupe_captions(a)
        for k in [k for k in s if k.startswith('_')]:
            s.pop(k)
        if isinstance(s.get('items'), list):
            s['items'] = [{k: v for k, v in it.items() if not k.startswith('_')} if isinstance(it, dict) else it
                          for it in s['items']]
        _typo_slide(s)
        for a in s.get('alts') or []:
            _typo_slide(a)
    return slides


def _typo_slide(s):
    """Неразрывные пробелы (типографика) во всех текстах слайда."""
    for k in ('title', 'subtitle', 'lead', 'conclusion', 'center'):
        if isinstance(s.get(k), str) and s[k]:
            s[k] = typo(s[k])
    for k in ('paragraphs', 'insights'):
        if isinstance(s.get(k), list):
            s[k] = [typo(x) if isinstance(x, str) else x for x in s[k]]
    for it in s.get('items') if isinstance(s.get('items'), list) else []:
        if not isinstance(it, dict):
            continue
        for k in ('title', 'text'):
            if isinstance(it.get(k), str) and it[k]:
                it[k] = typo(it[k])
    for side in ('left', 'right'):
        if isinstance(s.get(side), dict) and isinstance(s[side].get('items'), list):
            s[side]['items'] = [typo(x) if isinstance(x, str) else x for x in s[side]['items']]
