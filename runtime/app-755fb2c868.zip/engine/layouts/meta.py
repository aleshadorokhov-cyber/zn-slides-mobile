# -*- coding: utf-8 -*-
"""
meta.py — СЛУЖЕБНЫЕ СЛАЙДЫ: титульный, раздел, содержание, финальный
===================================================================
"""
import copy

from lxml import etree
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR
from pptx.oxml.ns import qn
from pptx.util import Pt

from ..nts import config as C
from ..nts.effects import shadow, text_alpha
from ..nts.shapes import group, rect, shape_text, text
from ..textfit import clip, fit_size_many
from .base import GREEN, LGREEN, NAVY, WHITE, common_size, content_slide, pair
from .tplframe import frame_slide


# --------------------------------------------------------------------------------------
# Титульный слайд — правится первый слайд базовой презентации
# --------------------------------------------------------------------------------------
def render_title(ctx, s):
    meta = ctx.meta
    title = s.get('title') or meta.get('title') or ''
    lines = [x for x in (s.get('subtitle') or meta.get('subtitle'), meta.get('event'), meta.get('author')) if x]
    if ctx.tpl is not None:                       # свой шаблон — титул по его титульному макету
        return frame_slide(ctx, 'title', title, lines + [meta.get('date') or ''], s.get('notes'))
    sl = ctx.d.prs.slides[0]
    for sh in sl.shapes:
        if not sh.is_placeholder:
            continue
        idx = sh.placeholder_format.idx
        if idx == C.PH_TITLE:
            # заголовок: блок 6,38 × 2,47″, прижат к низу; кегль 40 → 24 пт
            size = fit_size_many([title], 6.3, 2.4, 40, 24, 'mj')
            sh.text_frame.paragraphs[0].runs[0].text = clip(title, 6.3, 2.4, size, 'mj')
            for r in sh.text_frame.paragraphs[0].runs[1:]:
                r.text = ''
            for r in sh.text_frame.paragraphs[0].runs:
                r.font.size = Pt(size)
        elif idx == C.PH_TITLE_SUB:
            tf = sh.text_frame
            paras = tf.paragraphs
            # шаблон: 1-й абзац — крупный зелёный, 2-й — мелкий; лишние строки копируют 2-й абзац
            proto_big, proto_small = paras[0]._p, paras[1]._p if len(paras) > 1 else paras[0]._p
            for p in list(paras):
                p._p.getparent().remove(p._p)
            body = tf._txBody
            for i, line in enumerate(lines or ['']):
                pe = copy.deepcopy(proto_big if i == 0 else proto_small)
                runs = pe.findall(qn('a:r'))
                for extra in runs[1:]:
                    pe.remove(extra)
                if runs:
                    runs[0].find(qn('a:t')).text = line
                body.append(pe)
            # подгонка: первая строка до 3 строк текста
            if lines:
                size = fit_size_many([lines[0]], 6.3, 0.95, 21, 14, 'mn', max_lines=3)
                for r in tf.paragraphs[0].runs:
                    r.font.size = Pt(size)
    # дата в овале: поле «Дата» (обновляется само) или заданная пользователем дата
    if meta.get('date'):
        for sh in sl.shapes:
            if sh.has_text_frame:
                fld = sh.text_frame._txBody.find('.//' + qn('a:fld'))
                if fld is not None and (fld.get('type') or '').startswith('datetime'):
                    r = etree.SubElement(fld.getparent(), qn('a:r'))
                    rpr = fld.find(qn('a:rPr'))
                    if rpr is not None:
                        r.append(copy.deepcopy(rpr))
                    etree.SubElement(r, qn('a:t')).text = meta['date']
                    fld.addprevious(r)
                    fld.getparent().remove(fld)
    if s.get('notes'):
        sl.notes_slide.notes_text_frame.text = s['notes']
    for sh in sl.placeholders:
        if sh.placeholder_format.idx == C.PH_TITLE:
            ctx.anim(sl, sh, 'rise', 0, 700)
        elif sh.placeholder_format.idx == C.PH_TITLE_SUB:
            ctx.anim(sl, sh, 'fade', 400, 700)
    return sl


# --------------------------------------------------------------------------------------
# Раздел — тёмный слайд-разделитель шаблона
# --------------------------------------------------------------------------------------
def render_section(ctx, s):
    d = ctx.d
    if ctx.tpl is not None:
        num = str(s.get('number') or '').strip()
        title = s.get('title') or ''
        return frame_slide(ctx, 'section', f'{num}. {title}' if num and title else title or num,
                           [s.get('subtitle') or ''], s.get('notes'))
    sl = d.prs.slides.add_slide(d.prs.slide_masters[0].slide_layouts[C.LAYOUT_SECTION])
    title = s.get('title') or ''
    for ph in list(sl.placeholders):
        idx = ph.placeholder_format.idx
        if idx == C.PH_TITLE:
            size = fit_size_many([title], 11.3, 1.35, 44, 26, 'mj', max_lines=2)
            ph.text_frame.text = clip(title, 11.3, 1.35, size, 'mj', 2)
            for r in ph.text_frame.paragraphs[0].runs:
                r.font.size = Pt(size)
            ctx.anim(sl, ph, 'rise', 200, 700)
        elif idx == C.PH_SUBTITLE:
            if s.get('subtitle'):
                ph.text_frame.text = s['subtitle']
            else:
                ph._element.getparent().remove(ph._element)
    if s.get('number'):
        num = text(sl, C.L, 2.55, 4.0, 1.6, s['number'], size=96, color=LGREEN, font='b')
        text_alpha(num, 70)
        ctx.anim(sl, num, 'zoom', 0, 600)
    if s.get('notes'):
        sl.notes_slide.notes_text_frame.text = s['notes']
    return sl


# --------------------------------------------------------------------------------------
# Содержание — нумерованные пункты в 1–2 колонки
# --------------------------------------------------------------------------------------
def render_agenda(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = [it.get('title') or it.get('text') or '' for it in s['items']]
    n = len(items)
    cols = 1 if n <= 5 else 2
    per = -(-n // cols)
    gap_x = 0.5
    cw = (C.CW - (cols - 1) * gap_x) / cols
    avail = bottom - top - 0.1
    rh = min(0.95, avail / per)
    d_ = min(0.62, rh * 0.72)
    tw = cw - d_ - 0.3
    size = common_size(items, tw, rh - 0.08, 22, 13, 'mj', max_lines=2)
    y0 = top + 0.1 + (avail - rh * per) / 2
    for i, t in enumerate(items):
        c, r = divmod(i, per)
        x = C.L + c * (cw + gap_x)
        y = y0 + r * rh
        g = group(sl)
        c1, c2 = pair(i, n)
        circ = rect(g, x, y + (rh - d_) / 2, d_, d_, fill=c1, shape=MSO_SHAPE.OVAL)
        shadow(circ, 6, 2, 20)
        shape_text(circ, f'{i + 1:02d}', size=max(11, d_ * 26), color=WHITE, font='b', margins=(0, 0, 0, 0))
        text(g, x + d_ + 0.25, y, tw, rh, clip(t, tw, rh - 0.08, size, 'mj', 2), size=size, color=NAVY, font='mj',
             anchor=MSO_ANCHOR.MIDDLE)
        # тонкая разделительная линия под пунктом
        rect(g, x + d_ + 0.25, y + rh - 0.02, tw, 0.012, fill=C.LGRAY)
        ctx.anim(sl, g, 'rise', 100 + i * 120, 400)
    return sl


# --------------------------------------------------------------------------------------
# Финальный слайд
# --------------------------------------------------------------------------------------
def render_end(ctx, s):
    d = ctx.d
    if ctx.tpl is not None:
        lines = [s.get('subtitle') or ctx.meta.get('title'), ctx.meta.get('event')]
        return frame_slide(ctx, 'end', s.get('title') or 'Спасибо за внимание!', lines,
                           s.get('notes') or 'Благодарю за внимание. Готов ответить на вопросы.')
    sl = d.prs.slides.add_slide(d.L_END)
    for ph in sl.placeholders:
        if ph.placeholder_format.idx == C.PH_TITLE:
            ph.text_frame.text = s.get('title') or 'Спасибо за внимание!'
            ctx.anim(sl, ph, 'rise', 0, 700)
    lines = [x for x in (s.get('subtitle') or ctx.meta.get('title'), ctx.meta.get('event')) if x]
    if lines:
        size = fit_size_many(['\n'.join(lines)], 5.4, 1.3, 16, 11, 'mj')
        tb = text(sl, C.L, 3.95, 5.4, 1.3, [clip(x, 5.4, 0.6, size, 'mj', 2) for x in lines], size=size,
                  color=GREEN, font='mj', space_after=4)
        ctx.anim(sl, tb, 'fade', 500, 700)
    sl.notes_slide.notes_text_frame.text = s.get('notes') or 'Благодарю за внимание. Готов ответить на вопросы.'
    return sl
