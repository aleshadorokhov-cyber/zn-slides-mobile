# -*- coding: utf-8 -*-
"""
app.py — ВЕБ-ПРИЛОЖЕНИЕ «КОНСТРУКТОР ПРЕЗЕНТАЦИЙ» (Flask)
========================================================

Запуск на своём компьютере:      python app.py                → http://127.0.0.1:8050
Запуск на сервере для коллег:    python app.py --server       → http://<имя-сервера>:8050
                                 (порт: --port 8080; адрес: --host 0.0.0.0)

Страница (web/templates/index.html + web/static/app.js) общается с сервером через API:

    GET  /                      — страница приложения
    GET  /api/status            — версия, доступность LibreOffice (предпросмотр), настройки ИИ
    GET  /api/layouts           — каталог макетов (для выпадающих списков)
    GET  /api/icons             — список иконок
    POST /api/analyze           — файлы + настройки → задание анализа {"job": id} (при ?wait=1 — сразу план)
    POST /api/sample            — то же на встроенных примерах (папка samples/)
    GET  /api/job/<id>          — ход задания (фаза, токены, слайды); по готовности — план
    POST /api/job/<id>/cancel   — отменить задание (модель прекращает генерацию)
    POST /api/report            — файлы + настройки → задание «справка в Word» {"job": id} (при ?wait=1 — сразу .docx)
    POST /api/report/sample     — то же на встроенных примерах (папка samples/)
    GET  /api/report/<id>/file  — скачать готовую справку («Справка_<тема>.docx»)
    POST /api/build             — спецификация → файл .pptx (скачивание)
    POST /api/preview           — спецификация → PDF для просмотра в браузере (LibreOffice или PowerPoint)
    POST /api/own, GET /api/own[/<id>], DELETE /api/own/<id> — свои слайды из файла PowerPoint (1.7)
    POST /api/versions[/build]  — версии под аудиторию: для правления, рабочая, внешняя (1.7)
    GET|POST /api/dictionary    — словарь Компании (+ /import из Excel/CSV, /export в CSV) (1.7)
    POST /api/text/check|fix    — словарь, правописание и типографика текста слайдов (1.7)
    POST /api/deckcheck         — проверка готового файла: текст за рамкой и краем, наложения, мелкий шрифт (1.7)
    POST /api/render_slides     — картинки слайдов: миниатюры плана и вариантов, просмотр слайда крупно
    POST /api/chart_data        — данные для диаграммы из файла (Excel, CSV, JSON, таблицы Word, PDF, PowerPoint)
    POST /api/chart_insights    — выводы по данным диаграммы (из её чисел)
    GET  /api/ping              — «страница открыта» (запуск ярлыком: сервер выключается, когда вкладок нет)
    POST /api/shutdown          — выключить конструктор (только с этого компьютера)
    POST /api/shortcut          — ярлык на рабочем столе и в меню «Пуск» (Windows)
                                  (LibreOffice или PowerPoint на Windows + pypdfium2)
    GET  /api/settings          — настройки модели ИИ (ключи скрыты) и таблица сервисов: локальные и облачные
    POST /api/settings          — сохранить настройки (файл settings.json)
    POST /api/llm/test          — проверить связь с сервером модели, получить список моделей
    POST /api/llm/ping          — пробный запрос к модели: загрузка, скорость, видеокарта или процессор
    POST /api/llm/draw_test     — пробный рисунок модели ИИ (проверка, что модель умеет рисовать)
    GET  /api/ai/find           — «Найти ИИ»: модели на этом компьютере (?lan=1 — в сети, ?host= — на устройстве) (1.7)
    POST /api/ai/start, /api/ai/pull — запустить Ollama / LM Studio, скачать модель в Ollama (1.7)
    GET/POST /api/autopilot, POST /api/autopilot/run|open, GET /api/autopilot/file — автопилот: «Входящие» → «Готово» (1.7)
    POST /api/illustrate        — иллюстрация к слайду: её рисует модель ИИ (код SVG → фигуры PowerPoint)
    GET  /api/pictures          — библиотека картинок: разделы, рисунки, страны для карт
    GET  /api/pictures/<id>.svg — рисунок библиотеки или карта страны (map_VNM)
    POST /api/pictures/suggest  — картинки, подходящие к слайду (или ко всей презентации: slides)
    POST /api/pictures/distribute — раскладка выбранных картинок по слайдам (по смыслу или по порядку)
    POST /api/picture           — вариант слайда с картинкой или с 2–3 картинками (библиотека, карта, своя)
    POST /api/upload_image      — загрузить свою картинку (PNG, JPEG, GIF, BMP, WEBP, TIFF, SVG)
    GET  /api/uploads           — список своих картинок (с другого компьютера — только переданные names)
    GET  /api/upload/<имя>      — своя картинка (для миниатюр в плане)
    DELETE /api/upload/<имя>    — удалить свою картинку из output/uploads
    GET  /api/templates         — шаблоны оформления: корпоративный и загруженные свои (.pptx/.potx)
    POST /api/templates         — загрузить свои шаблоны (несколько файлов сразу)
    PATCH /api/templates/<id>   — переименовать, выбрать макеты для ролей, основной и акцентный цвет
    DELETE /api/templates/<id>  — удалить свой шаблон (корпоративный не удаляется)
    GET  /api/templates/<id>/preview/<n>.jpg — образец слайда в этом шаблоне (1 — титул, 2 — слайд
                                  с содержанием, 3 — раздел, 4 — финал; нужен LibreOffice или PowerPoint)
    POST /api/revise            — замечание к слайду → исправленный слайд (модель ИИ или правила)
    POST /api/revise_plan       — общие замечания ко всему плану (выполняются правилами)
    POST /api/verify            — сверка чисел слайдов с материалами доклада (1.7)
    POST /api/review            — «Проверить»: замечания рецензента (what=review) или сравнение с эталонами
                                  (what=etalons); фоновое задание, ход — /api/job/<id> (1.7)
    GET/POST /api/library       — библиотека материалов: список, добавить файл (ref=1 — сразу эталон ⭐)
    PATCH /api/library/<id>     — отметить эталоном или снять отметку ({"ref": true|false})
    POST /api/upload_image (lib=1) — свои фотографии сразу в библиотеку фото; PATCH /api/upload/<имя>
                                  {"lib", "cat", "author"} — в библиотеке или нет, раздел, автор (1.7)
    DELETE /api/library/<id>    — убрать файл из библиотеки

Загруженные файлы обрабатываются во временной папке и сразу удаляются. На диске остаются
settings.json и кэш картинок output/cache (рисунки из Word для слайдов «Рисунок»):
файлы кэша старше CACHE_DAYS дней удаляются при запуске и перед каждым анализом.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse
import uuid
from pathlib import Path

from flask import Flask, abort, jsonify, render_template, request, send_file

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import engine  # noqa: E402
from engine.llm_client import DEFAULTS as LLM_DEFAULTS  # noqa: E402
from engine.llm_client import Cancelled, LLMError, list_models, ping_model  # noqa: E402
from engine.llm_client import (GIGACHAT_SCOPES, GROUPS, LOCKED_MSG, MASK, PROVIDER, CloudRefused,  # noqa: E402
                               cloud_locked, cloud_refusal, describe, is_cloud, provider_table)
from engine import deckcheck as _deckcheck  # noqa: E402
from engine.nts import config as C  # noqa: E402

VERSION = '1.7.2'
CACHE_DIR = ROOT / 'output' / 'cache'
CACHE_DAYS = 7                   # сколько дней хранить рисунки из загруженных документов
SETTINGS_FILE = ROOT / 'settings.json'

app = Flask(__name__, template_folder=str(ROOT / 'web' / 'templates'), static_folder=str(ROOT / 'web' / 'static'))
app.config['MAX_CONTENT_LENGTH'] = 60 * 1024 * 1024          # не больше 60 МБ за один раз
app.json.ensure_ascii = False


# --------------------------------------------------------------------------------------
# Настройки
# --------------------------------------------------------------------------------------
# Ключи верхнего уровня settings.json, которые задаёт только администратор (в интерфейсе не меняются):
#   "allow_cloud": false          — облачные модели запрещены (то же — переменная окружения ZN_NO_CLOUD=1);
#   "internal_domains": ["…"]     — домены серверов Компании: модель по такому адресу считается локальной;
#   "allow_lan_scan": false       — «Найти ИИ» не ищет в сети (только этот компьютер и адрес, вписанный вручную).
ADMIN_KEYS = ('allow_cloud', 'internal_domains', 'allow_lan_scan')
# автопилот (1.7): включён ли, папка «Входящие» ('' — output/Входящие), как строить план
AUTO_DEFAULTS = {'on': False, 'folder': '', 'mode': 'rules'}


def load_settings():
    """Настройки из settings.json поверх значений по умолчанию. В s['llm'] добавляются служебные поля
    allow_cloud и internal_domains (из ключей администратора) — по ним llm_client запрещает облачные
    модели; в файл они обратно не пишутся. Ключи API — по сервисам (api_keys), api_key — ключ выбранного."""
    s = {'llm': dict(LLM_DEFAULTS, api_keys={}),
         'defaults': {'event': '', 'target_slides': 0, 'mode': 'rules'}, 'admin': {},
         'autopilot': dict(AUTO_DEFAULTS)}
    if SETTINGS_FILE.exists():
        try:
            saved = json.loads(SETTINGS_FILE.read_text(encoding='utf-8-sig'))   # -sig: файл мог сохранить Блокнот
            s['llm'].update({k: v for k, v in (saved.get('llm') or {}).items() if k in LLM_DEFAULTS})
            s['defaults'].update(saved.get('defaults') or {})
            s['admin'] = {k: saved[k] for k in ADMIN_KEYS if k in saved}
            s['autopilot'].update({k: v for k, v in (saved.get('autopilot') or {}).items() if k in AUTO_DEFAULTS})
        except (OSError, ValueError, AttributeError):
            pass
    llm = s['llm']
    keys = llm.get('api_keys') if isinstance(llm.get('api_keys'), dict) else {}
    keys = {str(k): str(v) for k, v in keys.items() if v}
    if not keys and llm.get('api_key'):              # settings.json прежних версий: один ключ
        keys = {str(llm.get('provider')): str(llm['api_key'])}
    llm.update(api_keys=keys, api_key=keys.get(llm.get('provider'), ''))
    llm['allow_cloud'] = s['admin'].get('allow_cloud', True) is not False
    llm['internal_domains'] = s['admin'].get('internal_domains') or []
    return s


def save_settings(s):
    """settings.json: ключи администратора — как были в файле; служебные поля llm не пишутся."""
    out = {**(s.get('admin') or {}), 'llm': {k: v for k, v in s['llm'].items() if k in LLM_DEFAULTS},
           'defaults': s['defaults'], 'autopilot': {k: v for k, v in (s.get('autopilot') or {}).items() if k in AUTO_DEFAULTS}}
    SETTINGS_FILE.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')


def runtime_llm(llm, over=None):
    """Настройки модели для запроса: сохранённые (llm) и, если есть, поля окна настроек, ещё не сохранённые
    (over). В результате — ключ только выбранного сервиса, без ключей остальных; «••••» — ключ не меняли."""
    cfg = {**llm, **(over or {})}
    if 'api_key' not in (over or {}) or cfg.get('api_key') == MASK:
        cfg['api_key'] = (llm.get('api_keys') or {}).get(cfg.get('provider'), '')
    cfg.pop('api_keys', None)
    return cfg


def llm_settings():
    """Сохранённые настройки модели для запроса (см. runtime_llm)."""
    return runtime_llm(load_settings()['llm'])


def find_soffice():
    for c in ('soffice', 'libreoffice', r'C:\Program Files\LibreOffice\program\soffice.exe',
              r'C:\Program Files (x86)\LibreOffice\program\soffice.exe',
              '/Applications/LibreOffice.app/Contents/MacOS/soffice'):
        p = shutil.which(c) or (c if Path(c).exists() else None)
        if p:
            return p
    return None


SOFFICE = find_soffice()


def find_powerpoint():
    """Установлен ли PowerPoint (только Windows): он тоже умеет сохранять презентацию в PDF."""
    if os.name != 'nt' or os.environ.get('ZN_NO_POWERPOINT'):
        return False
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, r'PowerPoint.Application\CLSID'):
            return bool(shutil.which('powershell') or shutil.which('powershell.exe'))
    except OSError:
        return False


POWERPOINT = find_powerpoint()
_PPT_PS = r"""$ErrorActionPreference = 'Stop'
$app = New-Object -ComObject PowerPoint.Application
try {
  $p = $app.Presentations.Open($env:ZN_PPTX, $true, $false, $false)
  try { $p.SaveAs($env:ZN_PDF, 32) } finally { $p.Close() }
} finally {
  if ($app.Presentations.Count -eq 0) { $app.Quit() }
  [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($app)
}"""
PPT_LOCK = threading.Lock()          # PowerPoint — одно приложение на компьютер: запросы по очереди


def preview_engine():
    return 'libreoffice' if SOFFICE else ('powerpoint' if POWERPOINT else '')


def pptx_to_pdf(path, timeout):
    """Презентация → PDF рядом с ней: LibreOffice (отдельный профиль, не мешает открытому LibreOffice)
    или, если его нет, PowerPoint на Windows. Возвращает путь к PDF."""
    path = Path(path)
    pdf = path.with_suffix('.pdf')
    if SOFFICE:
        prof = path.parent / 'lo_profile'
        run_with_timeout([SOFFICE, f'-env:UserInstallation={prof.as_uri()}', '--headless', '--convert-to', 'pdf',
                          '--outdir', str(path.parent), str(path)], timeout)
    elif POWERPOINT:
        env = dict(os.environ, ZN_PPTX=str(path.resolve()), ZN_PDF=str(pdf.resolve()))
        with PPT_LOCK:
            kw = {'stdout': subprocess.PIPE, 'stderr': subprocess.PIPE, 'env': env, 'timeout': timeout,
                  'creationflags': getattr(subprocess, 'CREATE_NO_WINDOW', 0)}
            r = subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
                                '-Command', _PPT_PS], **kw)
        if r.returncode:
            raise subprocess.CalledProcessError(r.returncode, 'PowerPoint', r.stdout, r.stderr)
    else:
        raise OSError('нет программы для просмотра')
    if not pdf.exists():
        raise OSError('PDF не создан')
    return pdf


def safe_name(title):
    """Имя файла из названия презентации (без запрещённых в Windows символов)."""
    name = re.sub(r'[\\/:*?"<>|«»\n\r\t]+', ' ', title or 'Презентация').strip()
    name = re.sub(r'\s+', '_', name)[:80].strip('._') or 'Презентация'
    return name


def parse_options(raw):
    """Параметры из формы → словарь с проверенными типами (неверные значения — по умолчанию)."""
    try:
        o = json.loads(raw or '{}')
    except ValueError:
        o = {}
    if not isinstance(o, dict):
        o = {}
    out = {}
    for k in ('title', 'subtitle', 'event', 'date', 'focus'):
        v = o.get(k)
        out[k] = str(v).strip()[:300] if v not in (None, '') else ''
    try:
        out['target_slides'] = max(0, min(60, int(o.get('target_slides') or 0)))
    except (TypeError, ValueError):
        out['target_slides'] = 0
    out['mode'] = o.get('mode') if o.get('mode') in ('ai', 'search') else 'rules'
    out['ai_level'] = 'full' if o.get('ai_level') == 'full' else 'fast'
    out['marks'] = o.get('marks') if o.get('marks') in ('priority', 'only', 'ignore') else 'priority'
    try:
        out['illustrations'] = max(0, min(30, int(o['illustrations']))) if o.get('illustrations') not in (None, '') else None
    except (TypeError, ValueError):
        out['illustrations'] = None
    out['remarks'] = str(o.get('remarks') or '').strip()[:3000]       # замечания автора ко всей презентации
    for k, default in (('conclusions', True), ('data_tables', False), ('animations', True), ('pictures', True)):
        out[k] = bool(o.get(k, default))
    ex = str(o.get('example') or 'auto')                              # план по образцу (1.7): авто, выкл., id образца
    out['example'] = ex if ex in ('auto', 'off') or re.fullmatch(r'[0-9a-f]{12}', ex) else 'auto'
    for k in ('agenda', 'sections'):
        v = o.get(k)
        if v in ('auto', None, ''):
            out[k] = 'auto'
        else:
            out[k] = (v == 'yes') if isinstance(v, str) else bool(v)
    return out


def is_local_request():
    """Запрос пришёл с этого же компьютера (настройки ИИ меняются только так)."""
    return (request.remote_addr or '') in ('127.0.0.1', '::1', '::ffff:127.0.0.1')


def from_own_page():
    """Запрос отправлен страницей самого конструктора, а не чужим сайтом, открытым в том же браузере
    (браузер подписывает такие запросы заголовком Origin)."""
    origin = request.headers.get('Origin')
    return not origin or origin.split('://', 1)[-1] == request.host


def run_with_timeout(cmd, timeout):
    """Запуск внешней программы; по истечении времени процесс завершается вместе с дочерними
    (LibreOffice порождает soffice.bin, который иначе остался бы висеть)."""
    kw = {'stdout': subprocess.PIPE, 'stderr': subprocess.PIPE}
    if os.name == 'nt':
        kw['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        kw['start_new_session'] = True
    proc = subprocess.Popen(cmd, **kw)
    try:
        out, err = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        if os.name == 'nt':
            subprocess.run(['taskkill', '/F', '/T', '/PID', str(proc.pid)], capture_output=True)
        else:
            import signal
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except OSError:
                proc.kill()
        proc.communicate()
        raise
    if proc.returncode:
        raise subprocess.CalledProcessError(proc.returncode, cmd, out, err)
    return out


# --------------------------------------------------------------------------------------
# Страница и справочники
# --------------------------------------------------------------------------------------
@app.get('/')
def index():
    return render_template('index.html', version=VERSION)


# --------------------------------------------------------------------------------------
# Запуск ярлыком (start.pyw): сервер без окна, сам выключается, когда вкладка закрыта
# --------------------------------------------------------------------------------------
LAUNCHER = {'on': False, 'idle_min': 0, 'last': time.time()}
HERE_ONLY = 'Это можно сделать только на том компьютере, где запущен конструктор.'


@app.before_request
def _touch():
    LAUNCHER['last'] = time.time()


def _idle_due(now=None):
    """Пора ли выключаться: нет запросов дольше idle_min минут и нечем заняться. Пока идёт анализ или справка
    и пока включён автопилот (он работает без вкладки), сервер не выключается."""
    busy = any(j.state == 'running' for j in list(JOBS.values()))
    auto = AUTO['thread'] is not None and AUTO['thread'].is_alive()
    return not busy and not auto and (now or time.time()) - LAUNCHER['last'] > LAUNCHER['idle_min'] * 60


def _idle_watchdog():
    """Сервер, запущенный ярлыком, выключается через idle_min минут без запросов (страница, пока открыта,
    отмечается раз в минуту — /api/ping)."""
    while True:
        time.sleep(30)
        if _idle_due():
            os._exit(0)


@app.get('/api/ping')
def ping():
    return jsonify({'ok': True})


@app.post('/api/shutdown')
def shutdown():
    """Выключить конструктор (кнопка «⏻» при запуске ярлыком). Только с этого компьютера."""
    if not (is_local_request() and from_own_page()):
        return jsonify({'error': HERE_ONLY}), 403
    threading.Timer(0.4, lambda: os._exit(0)).start()
    return jsonify({'ok': True})


@app.post('/api/shortcut')
def shortcut():
    """Ярлык «Конструктор презентаций» на рабочем столе и в меню «Пуск» (Windows, только с этого компьютера)."""
    if not (is_local_request() and from_own_page()):
        return jsonify({'error': HERE_ONLY}), 403
    if os.name != 'nt':
        return jsonify({'error': 'Ярлык создаётся только в Windows. На Linux и macOS запускайте run_mac_linux.sh.'}), 400
    sys.path.insert(0, str(ROOT / 'tools'))
    try:
        import make_shortcut
        made = make_shortcut.create()
    except Exception as e:                       # noqa: BLE001
        app.logger.exception('shortcut')
        return jsonify({'error': f'Не удалось создать ярлык: {e}'}), 500
    return jsonify({'ok': True, 'paths': [str(p) for p in made]})


@app.get('/api/status')
def status():
    s = load_settings()
    try:
        import pypdfium2  # noqa: F401
        thumbs = bool(SOFFICE or POWERPOINT)
    except ImportError:
        thumbs = False
    d = describe(s['llm'])
    return jsonify({'app': 'zn_slides', 'version': VERSION, 'libreoffice': bool(SOFFICE), 'thumbs': thumbs,
                    'launcher': LAUNCHER['on'], 'windows': os.name == 'nt',
                    'preview': preview_engine(),
                    'can_configure': is_local_request(), 'llm': {
        'provider': s['llm']['provider'], 'base_url': s['llm']['base_url'], 'model': s['llm']['model'],
        'illustrations': s['llm'].get('illustrations', 2),
        'embed_model': s['llm'].get('embed_model') or '', 'vision_model': s['llm'].get('vision_model') or '',
        'cloud': d['llm_cloud'], 'provider_name': d['llm_provider_name'],      # облачная: данные уходят наружу
        'cloud_consent': bool(s['llm'].get('cloud_consent'))},
        'cloud_allowed': not cloud_locked(s['llm']),
        'defaults': s['defaults'], 'formats': sorted(engine.SUPPORTED)})


@app.get('/api/layouts')
def layouts():
    return jsonify(engine.catalog())


@app.get('/api/chart_types')
def chart_types():
    from engine.spec import chart_catalog
    return jsonify(chart_catalog())


@app.get('/api/icons')
def icons():
    """Иконки для выбора: [{id, ru, cat}] — каталог (русские названия, разделы) и иконки без описания."""
    from engine.textutil import icon_catalog
    names = {p.stem.rsplit('_', 1)[0] for p in C.ICON_DIR.glob('*_w.png')}
    out = [{'id': e['id'], 'ru': e.get('ru') or e['id'][2:], 'cat': e.get('cat') or 'Прочее', 'words': e.get('words') or []}
           for e in icon_catalog() if e['id'] in names]
    seen = {e['id'] for e in out}
    out += [{'id': n, 'ru': n[2:], 'cat': 'Прочее', 'words': []} for n in sorted(names - seen)]
    return jsonify(out)


@app.get('/api/icon/<name>.png')
def icon_png(name):
    p = C.ICON_DIR / f'{name}_n.png'
    if not re.fullmatch(r'Tb\w+', name) or not p.exists():
        abort(404)
    return send_file(p, mimetype='image/png', max_age=86400)


# --------------------------------------------------------------------------------------
# Анализ — фоновые задания с индикатором хода
# --------------------------------------------------------------------------------------
# Анализ с локальной ИИ может длиться минуты, поэтому он выполняется в отдельном потоке,
# а браузер раз в секунду спрашивает /api/job/<id>: фазу, число токенов, слайдов — и может
# отменить задание. Задания живут в памяти процесса и удаляются через 15 минут.
JOBS = {}
JOBS_LOCK = threading.Lock()
JOB_TTL = 15 * 60


class Job:
    def __init__(self, files, opts, tmp=None):
        self.id = uuid.uuid4().hex[:12]
        self.files, self.opts, self.tmp = files, opts, tmp
        self.state = 'running'                   # running | done | error | cancelled
        self.progress = {'phase': 'start'}
        self.result, self.error, self.status = None, None, 200
        self.cancel = False
        self.t0 = time.time()
        self.finished = None

    def on_progress(self, e):
        if self.cancel:
            raise Cancelled('отменено пользователем')
        e = dict(e)
        e['elapsed'] = round(time.time() - self.t0, 1)
        self.progress = e

    def run(self):
        try:
            s = load_settings()
            # режим «поиск фраз» берёт из настроек только адрес и имя модели поиска (она на этом компьютере)
            llm = runtime_llm(s['llm']) if self.opts.get('mode') in ('ai', 'search') else None
            if not llm and self.opts.get('example') != 'off' and s['llm'].get('embed_model'):
                # план по образцу и в режиме «по правилам» сравнивает слайды моделью поиска (она на этом компьютере)
                self.opts = dict(self.opts, _embed=runtime_llm(s['llm']))
            spec, warnings, info = engine.analyze(self.files, self.opts, llm, progress=self.on_progress)
            # иллюстрации рисует та же модель ИИ — если план построен ею (модель на связи)
            n_auto = int(self.opts.get('illustrations') if self.opts.get('illustrations') is not None
                         else s['llm'].get('illustrations') or 0)
            if spec is not None and llm and info.get('mode_used') == 'ai' and n_auto > 0:
                from engine.illustrate import auto_illustrate
                warnings += auto_illustrate(spec, llm, n_auto, self.on_progress)
            info['seconds'] = round(time.time() - self.t0, 1)
            if spec is None:
                self.error, self.status = ('; '.join(warnings) or 'Не удалось прочитать файлы.'), 400
                self.state = 'error'
            else:
                self.result = {'spec': spec, 'warnings': warnings, 'info': info}
                self.state = 'done'
        except Cancelled:
            self.state = 'cancelled'
            self.error, self.status = 'Анализ отменён.', 499
        except Exception as e:                   # не должно случаться, но ответ всегда — понятный JSON
            app.logger.exception('analyze failed')
            self.error, self.status = f'Не удалось разобрать файлы: {type(e).__name__}: {e}', 500
            self.state = 'error'
        finally:
            self.finished = time.time()
            if self.tmp:
                shutil.rmtree(self.tmp, ignore_errors=True)

    def view(self):
        out = {'job': self.id, 'state': self.state, 'progress': self.progress,
               'elapsed': round((self.finished or time.time()) - self.t0, 1)}
        if self.state == 'done':
            out['result'] = self.result
        elif self.state in ('error', 'cancelled'):
            out['error'] = self.error
        return out


_VEC_PRUNED = [0.0]


def clean_cache(days=None):
    """Удаляет из output/cache файлы старше CACHE_DAYS дней (рисунки из загруженных документов,
    иллюстрации), раз в день — давно не нужные векторы модели поиска. Возвращает число удалённых файлов."""
    limit = time.time() - (CACHE_DAYS if days is None else days) * 86400
    n = 0
    if time.time() - _VEC_PRUNED[0] > 86400:
        _VEC_PRUNED[0] = time.time()
        from engine.phrases import prune_vectors
        threading.Thread(target=prune_vectors, daemon=True).start()
    if not CACHE_DIR.exists():
        return 0
    for p in CACHE_DIR.rglob('*'):
        try:
            if p.is_file() and p.stat().st_mtime < limit:
                p.unlink()
                n += 1
        except OSError:                                   # файл занят — удалим в следующий раз
            pass
    return n


def _ai_refusal(opts):
    """Режим ИИ с облачной моделью без согласия или при запрете администратора → текст отказа (иначе None)."""
    return cloud_refusal(llm_settings()) if opts.get('mode') == 'ai' else None


def _start_job(files, opts, tmp=None):
    refusal = _ai_refusal(opts)
    if refusal:                                  # документы во внешний сервис не отправляются
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
        return jsonify({'error': refusal}), 403
    clean_cache()
    with JOBS_LOCK:
        now = time.time()
        for k in [k for k, j in JOBS.items() if j.finished and now - j.finished > JOB_TTL]:
            JOBS.pop(k, None)
        job = Job(files, opts, tmp)
        JOBS[job.id] = job
    if request.args.get('wait') == '1':          # для скриптов: дождаться результата в том же запросе
        job.run()
        if job.state == 'done':
            return jsonify(job.result)
        return jsonify({'error': job.error}), job.status
    threading.Thread(target=job.run, daemon=True).start()
    return jsonify({'job': job.id, 'state': job.state}), 202


@app.post('/api/analyze')
def analyze():
    files = request.files.getlist('files')
    if not files:
        return jsonify({'error': 'Загрузите хотя бы один файл Word или Excel.'}), 400
    opts = parse_options(request.form.get('options'))
    try:
        tmp = Path(tempfile.mkdtemp(prefix='zn_slides_'))
    except OSError as e:
        return jsonify({'error': f'Нет места для временных файлов: {e}'}), 500
    try:
        paths = []
        for i, f in enumerate(files):
            name = Path(f.filename or f'file{i}').name
            dst = tmp / f'{i:02d}{Path(name).suffix.lower()}'
            f.save(dst)
            paths.append((str(dst), name))
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify({'error': f'Не удалось сохранить файлы: {e}'}), 500
    return _start_job(paths, opts, tmp)


@app.post('/api/sample')
def sample():
    opts = parse_options(request.form.get('options') or (request.get_data(as_text=True) or '{}'))
    smp = ROOT / 'samples'
    files = [(str(p), p.name) for p in sorted(smp.glob('*')) if p.suffix.lower() in engine.SUPPORTED]
    if not files:
        return jsonify({'error': 'Папка samples пуста. Выполните: python tools/make_samples.py'}), 400
    return _start_job(files, opts)


@app.get('/api/job/<jid>')
def job_status(jid):
    job = JOBS.get(jid)
    if not job:
        return jsonify({'error': 'Задание не найдено (возможно, сервер перезапускался).'}), 404
    return jsonify(job.view())


@app.post('/api/job/<jid>/cancel')
def job_cancel(jid):
    job = JOBS.get(jid)
    if not job:
        return jsonify({'error': 'Задание не найдено.'}), 404
    job.cancel = True
    return jsonify({'ok': True, 'state': job.state})


# --------------------------------------------------------------------------------------
# Справка в Word (.docx) — фоновое задание, как анализ: ход и отмена — через /api/job/<id>
# и /api/job/<id>/cancel; готовый файл хранится в памяти задания (до JOB_TTL после окончания).
# --------------------------------------------------------------------------------------
DOCX_MIME = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'


def _report_options(raw):
    """Настройки справки: те же, что у анализа (title, date, mode, ai_level, focus, marks), плюс
    author (исполнитель — в подвале), phone (его телефон), about («о …» — заголовок к тексту),
    pages (листов справки: 1–30; 0, пусто или неверное значение — без ограничения)."""
    opts = parse_options(raw)
    try:
        o = json.loads(raw or '{}')
    except ValueError:
        o = {}
    if not isinstance(o, dict):
        o = {}
    for k in ('author', 'phone', 'about'):
        v = o.get(k)
        opts[k] = str(v).strip()[:200] if v not in (None, '') else ''
    try:
        opts['pages'] = max(0, min(30, int(float(o.get('pages') or 0))))
    except (TypeError, ValueError, OverflowError):
        opts['pages'] = 0
    return opts


class ReportJob(Job):
    """Задание «справка»: результат — файл .docx (байты в памяти задания) и сведения для интерфейса."""

    def __init__(self, files, opts, tmp=None):
        super().__init__(files, opts, tmp)
        self.data, self.filename = None, None

    def run(self):
        from engine.report import make_report
        out_dir = None
        try:
            llm = llm_settings() if self.opts.get('mode') == 'ai' else None
            out_dir = Path(tempfile.mkdtemp(prefix='zn_report_'))
            path, warnings, info = make_report(self.files, out_dir / 'report.docx', self.opts, llm,
                                               progress=self.on_progress)
            info['seconds'] = round(time.time() - self.t0, 1)
            if llm:                              # какая модель писала справку и облачная ли она
                info.update({k: v for k, v in describe(llm).items() if k not in info})
            if path is None:
                self.error, self.status = ('; '.join(warnings) or 'Не удалось прочитать файлы.'), 400
                self.state = 'error'
            else:
                self.data = Path(path).read_bytes()
                self.filename = 'Справка_' + safe_name(info.get('title') or 'Справка') + '.docx'
                self.result = {'file': f'/api/report/{self.id}/file', 'filename': self.filename,
                               'size': len(self.data), 'warnings': warnings, 'info': info}
                self.state = 'done'
        except Cancelled:
            self.state = 'cancelled'
            self.error, self.status = 'Подготовка справки отменена.', 499
        except Exception as e:                   # ответ всегда — понятный JSON
            app.logger.exception('report failed')
            self.error, self.status = f'Не удалось подготовить справку: {type(e).__name__}: {e}', 500
            self.state = 'error'
        finally:
            self.finished = time.time()
            if out_dir:
                shutil.rmtree(out_dir, ignore_errors=True)
            if self.tmp:
                shutil.rmtree(self.tmp, ignore_errors=True)


def _send_report(job):
    from io import BytesIO
    resp = send_file(BytesIO(job.data), as_attachment=True, download_name=job.filename, mimetype=DOCX_MIME)
    resp.headers['X-Warnings'] = json.dumps(job.result.get('warnings') or [], ensure_ascii=True)
    resp.headers['X-Report-Mode'] = str((job.result.get('info') or {}).get('mode_used') or '')
    return resp


def _start_report(files, opts, tmp=None):
    refusal = _ai_refusal(opts)
    if refusal:                                  # документы во внешний сервис не отправляются
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
        return jsonify({'error': refusal}), 403
    clean_cache()
    with JOBS_LOCK:
        now = time.time()
        for k in [k for k, j in JOBS.items() if j.finished and now - j.finished > JOB_TTL]:
            JOBS.pop(k, None)
        job = ReportJob(files, opts, tmp)
        JOBS[job.id] = job
    if request.args.get('wait') == '1':          # для скриптов и проверок: сразу файл .docx
        job.run()
        if job.state == 'done':
            return _send_report(job)
        return jsonify({'error': job.error}), job.status
    threading.Thread(target=job.run, daemon=True).start()
    return jsonify({'job': job.id, 'state': job.state}), 202


@app.post('/api/report')
def report():
    """Справка в Word: multipart files + options (JSON, как у /api/analyze, плюс author, phone, about, pages)."""
    files = request.files.getlist('files')
    if not files:
        return jsonify({'error': 'Загрузите хотя бы один файл Word или Excel.'}), 400
    opts = _report_options(request.form.get('options'))
    try:
        tmp = Path(tempfile.mkdtemp(prefix='zn_report_in_'))
    except OSError as e:
        return jsonify({'error': f'Нет места для временных файлов: {e}'}), 500
    try:
        paths = []
        for i, f in enumerate(files):
            name = Path(f.filename or f'file{i}').name
            dst = tmp / f'{i:02d}{Path(name).suffix.lower()}'
            f.save(dst)
            paths.append((str(dst), name))
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify({'error': f'Не удалось сохранить файлы: {e}'}), 500
    return _start_report(paths, opts, tmp)


@app.post('/api/report/sample')
def report_sample():
    opts = _report_options(request.form.get('options') or (request.get_data(as_text=True) or '{}'))
    smp = ROOT / 'samples'
    files = [(str(p), p.name) for p in sorted(smp.glob('*')) if p.suffix.lower() in engine.SUPPORTED]
    if not files:
        return jsonify({'error': 'Папка samples пуста. Выполните: python tools/make_samples.py'}), 400
    return _start_report(files, opts)


@app.get('/api/report/<jid>/file')
def report_file(jid):
    job = JOBS.get(jid)
    if not isinstance(job, ReportJob):
        return jsonify({'error': 'Справка не найдена (прошло больше 15 минут или сервер перезапускался).'}), 404
    if job.state != 'done' or job.data is None:
        return jsonify({'error': job.error or 'Справка ещё готовится.', 'state': job.state}), 409
    return _send_report(job)


# --------------------------------------------------------------------------------------
# Сборка и предпросмотр
# --------------------------------------------------------------------------------------
class BuildError(Exception):
    pass


def _spec_from_request():
    """План из тела запроса; неверный план → BuildError с понятным текстом."""
    body = request.get_json(silent=True)
    spec = body.get('spec') if isinstance(body, dict) else None
    if not isinstance(spec, dict) or not isinstance(spec.get('slides'), list) or not spec['slides']:
        raise BuildError('План презентации пуст или повреждён.')
    if not isinstance(spec.get('meta'), dict):
        spec['meta'] = {}
    return spec


def _build_tmp(spec):
    """Собирает .pptx во временной папке → (папка, путь, предупреждения, число слайдов)."""
    tmp = Path(tempfile.mkdtemp(prefix='zn_build_'))
    try:
        out = tmp / (safe_name(str(spec['meta'].get('title') or '')) + '.pptx')
        path, warnings, n = engine.build(spec, out)
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        app.logger.exception('build failed')
        raise BuildError(f'Не удалось собрать презентацию: {type(e).__name__}: {e}')
    return tmp, path, warnings, n


@app.errorhandler(BuildError)
def build_error(e):
    return jsonify({'error': str(e)}), 400


@app.post('/api/build')
def build():
    tmp, path, warnings, n = _build_tmp(_spec_from_request())
    try:
        data = path.read_bytes()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    from io import BytesIO
    resp = send_file(BytesIO(data), as_attachment=True, download_name=path.name,
                     mimetype='application/vnd.openxmlformats-officedocument.presentationml.presentation')
    resp.headers['X-Slides'] = str(n)
    resp.headers['X-Warnings'] = json.dumps(warnings, ensure_ascii=True)
    return resp


def _versions_request():
    """{spec, kinds, words, n} → версии плана (engine/versions)."""
    from engine import versions as V
    body = request.get_json(silent=True) or {}
    spec = _spec_from_request()
    kinds = [k for k in (body.get('kinds') or list(V.KINDS)) if k in V.KINDS]
    if not kinds:
        raise BuildError('Выберите хотя бы одну версию.')
    words = body.get('words') or []
    if isinstance(words, str):
        words = re.split(r'[,;\n]+', words)
    words = [str(w).strip()[:80] for w in words if str(w).strip()][:50]
    try:
        n = max(3, min(15, int(body.get('n') or V.BOARD_N)))
    except (TypeError, ValueError):
        n = V.BOARD_N
    return spec, V.make(spec, kinds, words, n)


@app.post('/api/versions')
def versions_plan():
    """Версии под аудиторию (1.7): для правления, рабочая, внешняя → планы и «что изменено» (без сборки)."""
    _, vs = _versions_request()
    return jsonify({'versions': vs})


@app.post('/api/versions/build')
def versions_build():
    """Собрать выбранные версии → .zip: презентации и «Что изменено.txt»."""
    import io
    import zipfile
    spec, vs = _versions_request()
    base = safe_name(str(spec['meta'].get('title') or ''))
    buf, report = io.BytesIO(), []
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        for v in vs:
            tmp, path, warnings, n = _build_tmp(v['spec'])
            try:
                name = f'{base} — {v["name"]}.pptx'
                z.write(path, name)
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
            report += [f'{name} · слайдов: {n}'] + [f'  • {x}' for x in v['notes']] + [f'  • {w}' for w in warnings] + ['']
        z.writestr('Что изменено.txt', '\ufeff' + '\r\n'.join(report))
    from flask import Response
    resp = Response(buf.getvalue(), mimetype='application/zip')
    resp.headers['Content-Disposition'] = f"attachment; filename*=UTF-8''{urllib.parse.quote(base + ' — версии.zip')}"
    return resp


def _check_pdf(path):
    """PDF готового файла для проверки автопилота (вместе с картинками слайдов — не больше двух за раз)."""
    with THUMB_SLOTS:
        return pptx_to_pdf(path, 240)


_deckcheck.TO_PDF = _check_pdf if preview_engine() else None


@app.post('/api/deckcheck')
def deckcheck_plan():
    """Проверка готового файла (1.7): {"spec"} → замечания как у рецензента + картинки слайдов с обведёнными местами
    (если есть LibreOffice или PowerPoint; без них — проверка только по файлу)."""
    from engine import deckcheck as DC
    spec = _spec_from_request()
    eng = preview_engine()
    if eng and not THUMB_SLOTS.acquire(timeout=120):
        return jsonify({'error': 'Конструктор занят картинками слайдов — попробуйте через минуту.'}), 503
    tmp = Path(tempfile.mkdtemp(prefix='zn_check_'))
    try:
        r = DC.check_spec(spec, tmp, to_pdf=(lambda p: pptx_to_pdf(p, 240)) if eng else None)
    except Exception as e:                                   # noqa: BLE001
        app.logger.exception('deckcheck failed')
        return jsonify({'error': f'Не удалось проверить файл: {type(e).__name__}: {e}'}), 500
    finally:
        if eng:
            THUMB_SLOTS.release()
        shutil.rmtree(tmp, ignore_errors=True)
    r['engine'] = eng
    return jsonify(r)


# --------------------------------------------------------------------------------------
# Корпоративный словарь, правописание и типографика (1.7)
# --------------------------------------------------------------------------------------
@app.get('/api/dictionary')
def dictionary_get():
    from engine import dictionary as D
    d = D.load()
    return jsonify({'entries': d['entries'], 'auto': d['auto'], 'builtin': D.builtin(), 'cats': list(D.CATS)})


@app.post('/api/dictionary')
def dictionary_save():
    """{"entries": [{"right", "wrong", "cat"}], "auto"} → сохранённый словарь."""
    from engine import dictionary as D
    if not from_own_page():
        return jsonify({'error': 'Менять словарь можно только со страницы конструктора.'}), 403
    body = request.get_json(silent=True) or {}
    if not isinstance(body, dict) or not isinstance(body.get('entries'), list):
        return jsonify({'error': 'Нет записей словаря.'}), 400
    d = D.save({'entries': body['entries'], 'auto': body.get('auto', True)})
    return jsonify({'entries': d['entries'], 'auto': d['auto']})


@app.post('/api/dictionary/import')
def dictionary_import():
    """Файл Excel, CSV или TXT → записи добавляются к словарю (совпадающие — дополняются)."""
    from engine import dictionary as D
    if not from_own_page():
        return jsonify({'error': 'Пополнять словарь можно только со страницы конструктора.'}), 403
    f = request.files.get('file')
    if not f:
        return jsonify({'error': 'Файл не получен.'}), 400
    name = f.filename or 'словарь.csv'
    if Path(name).suffix.lower() not in ('.xlsx', '.xlsm', '.csv', '.txt'):
        return jsonify({'error': 'Нужен файл Excel (.xlsx), CSV или TXT.'}), 400
    data = f.read(5 * 1024 * 1024 + 1)
    if len(data) > 5 * 1024 * 1024:
        return jsonify({'error': 'Файл словаря больше 5 МБ.'}), 400
    try:
        new = D.parse_file(data, name)
    except Exception as e:                                   # noqa: BLE001 — испорченный файл не роняет сервер
        return jsonify({'error': f'«{name}» не прочитан: {type(e).__name__}: {e}'}), 400
    if not new:
        return jsonify({'error': f'В «{name}» не найдено записей: первый столбец — как правильно, второй — как ещё пишут.'}), 400
    old = D.load()
    known = {e['right'].lower() for e in old['entries']}
    d = D.save({'entries': D.merge(old['entries'], new), 'auto': old['auto']})
    return jsonify({'entries': d['entries'], 'auto': d['auto'], 'added': sum(1 for e in new if e['right'].lower() not in known),
                    'updated': sum(1 for e in new if e['right'].lower() in known)})


@app.get('/api/dictionary/export')
def dictionary_export():
    from flask import Response
    from engine import dictionary as D
    resp = Response(D.to_csv(D.load()['entries']).encode('utf-8'), mimetype='text/csv')
    resp.headers['Content-Disposition'] = f"attachment; filename*=UTF-8''{urllib.parse.quote('Словарь Компании.csv')}"
    return resp


@app.post('/api/text/check')
def text_check():
    """{"spec"} → {"findings": [...], "counts": {...}, "auto"}: что исправят словарь, правописание и типографика."""
    from engine import dictionary as D
    spec = _spec_from_request()
    d = D.load()
    r = D.check(spec, d['entries'])
    r['findings'] = r['findings'][:600]
    return jsonify(dict(r, auto=d['auto'], entries=len(d['entries'])))


@app.post('/api/text/fix')
def text_fix():
    """{"spec", "where": [[номер слайда, путь], …] | null} → {"changes": [{"i", "path", "old", "text"}], "fixed"}
    (исключения «оставить как есть» — meta.text_skip плана)."""
    from engine import dictionary as D
    body = request.get_json(silent=True) or {}
    spec = _spec_from_request()
    where = body.get('where')
    if where is not None:
        try:
            where = [(int(w[0]), [p if isinstance(p, int) else str(p) for p in w[1]]) for w in where][:2000]
        except (TypeError, ValueError, IndexError):
            return jsonify({'error': 'Неверное место правки.'}), 400
    changes = []
    _, n = D.apply(spec, D.load()['entries'], where=where, out=changes)
    return jsonify({'changes': changes, 'fixed': n})


@app.post('/api/verify')
def verify_numbers():
    """Сверка чисел слайдов с материалами доклада (1.7): {"spec"} → {"slides": [...], "counts": {...}} или {"error"}."""
    from engine.factcheck import verify
    body = request.get_json(silent=True) or {}
    spec = body.get('spec') if isinstance(body, dict) else None
    if not isinstance(spec, dict) or not isinstance(spec.get('slides'), list):
        return jsonify({'error': 'Нет плана презентации.'}), 400
    r = verify(spec)
    return jsonify(r), (200 if 'error' not in r else 409)


class ReviewJob(Job):
    """Задание «Проверить»: рецензент или сравнение с эталонами (модель ИИ может думать минуту-другую)."""

    def __init__(self, spec, what, llm, cfg):
        super().__init__([], {})
        self.spec, self.what, self.llm, self.cfg = spec, what, llm, cfg

    def run(self):
        from engine.review import compare, review
        try:
            fn = compare if self.what == 'etalons' else review
            r = fn(self.spec, self.llm, self.cfg, progress=self.on_progress)
            if self.llm and r.get('mode') == 'ai':
                r['model'] = describe(self.llm)
            self.result, self.state = r, 'done'
        except Cancelled:
            self.state = 'cancelled'
            self.error, self.status = 'Проверка отменена.', 499
        except Exception as e:                   # ответ всегда — понятный JSON
            app.logger.exception('review failed')
            self.error, self.status = f'Проверка не удалась: {type(e).__name__}: {e}', 500
            self.state = 'error'
        finally:
            self.finished = time.time()


@app.post('/api/review')
def review_plan():
    """{"spec", "what": "review" | "etalons", "use_ai"} → 202 {"job"} (готовый результат — в /api/job/<id>)."""
    body = request.get_json(silent=True) or {}
    spec = body.get('spec') if isinstance(body, dict) else None
    if not isinstance(spec, dict) or not isinstance(spec.get('slides'), list) or not spec['slides']:
        return jsonify({'error': 'Нет плана презентации.'}), 400
    what = 'etalons' if body.get('what') == 'etalons' else 'review'
    cfg = llm_settings()
    llm = cfg if body.get('use_ai') and cfg.get('model') else None
    refusal = cloud_refusal(llm) if llm else None
    if refusal:                                  # план во внешний сервис не отправляется
        return jsonify({'error': refusal}), 403
    with JOBS_LOCK:
        now = time.time()
        for k in [k for k, j in JOBS.items() if j.finished and now - j.finished > JOB_TTL]:
            JOBS.pop(k, None)
        job = ReviewJob(spec, what, llm, cfg)
        JOBS[job.id] = job
    if request.args.get('wait') == '1':          # для скриптов и проверок
        job.run()
        return (jsonify(job.result), 200) if job.state == 'done' else (jsonify({'error': job.error}), job.status)
    threading.Thread(target=job.run, daemon=True).start()
    return jsonify({'job': job.id, 'state': job.state}), 202


@app.post('/api/preview')
def preview():
    if not preview_engine():
        return jsonify({'error': 'Для предпросмотра нужен LibreOffice (бесплатно) или PowerPoint. Можно просто скачать .pptx.'}), 501
    who = 'LibreOffice' if SOFFICE else 'PowerPoint'
    if not THUMB_SLOTS.acquire(timeout=120):
        return jsonify({'error': f'{who} занят картинками слайдов — попробуйте через минуту или просто скачайте .pptx.',
                        'busy': True}), 503
    tmp = None
    try:
        tmp, path, warnings, n = _build_tmp(_spec_from_request())
        data = pptx_to_pdf(path, 240).read_bytes()
    except subprocess.TimeoutExpired:
        return jsonify({'error': f'{who} не успел построить PDF за 4 минуты. Скачайте .pptx.'}), 504
    except (subprocess.SubprocessError, OSError) as e:
        return jsonify({'error': f'{who} не смог построить PDF: {e}'}), 500
    finally:
        THUMB_SLOTS.release()
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
    from io import BytesIO
    return send_file(BytesIO(data), mimetype='application/pdf', download_name='preview.pdf')


# --------------------------------------------------------------------------------------
# Миниатюры вариантов слайда
# --------------------------------------------------------------------------------------
THUMB_CACHE = {}                 # ключ (хэш слайда) → PNG data URL
THUMB_LOCK = threading.Lock()
# Картинки слайдов строятся не больше чем по две сразу: каждая — LibreOffice или PowerPoint, до минуты и
# дольше. Без предела фоновые миниатюры (и их повторы после обновления страницы) занимали все потоки
# сервера — страница переставала отвечать. Фоновый запрос при занятых местах сразу получает 503 «busy»
# и повторяется позже, запрос пользователя (слайд крупно, окно диаграммы) ждёт место до минуты.
THUMB_SLOTS = threading.BoundedSemaphore(2)


def _rasterize(pdf_path, pages, width_px=560):
    """Страницы PDF → PNG data URL (нужен пакет pypdfium2; без него — None)."""
    try:
        import pypdfium2 as pdfium
    except ImportError:
        return None
    import base64
    from io import BytesIO
    pdf = pdfium.PdfDocument(str(pdf_path))
    out = {}
    try:
        for p in pages:
            if p is None or p >= len(pdf):
                continue
            page = pdf[p]
            scale = width_px / page.get_width()
            img = page.render(scale=scale).to_pil().convert('RGB')
            buf = BytesIO()
            img.save(buf, 'JPEG', quality=85 if width_px <= 800 else 90, optimize=True)   # втрое легче PNG
            out[p] = 'data:image/jpeg;base64,' + base64.b64encode(buf.getvalue()).decode()
    finally:
        pdf.close()
    return out


@app.post('/api/render_slides')
def render_slides():
    """Картинки слайдов: {"slides": [...], "meta": {...}, "width": 560, "pages": false} →
    {"images": [dataURL | null, …]} (первая страница каждого слайда), при "pages": true ещё
    {"pages": [[dataURL, …], …]} — все страницы слайда (длинная таблица занимает несколько).
    "number" (для одного слайда) — его номер в презентации, чтобы в колонтитуле стоял он, а не 1.
    "background": true — фоновый запрос (миниатюры плана и вариантов): при занятых местах (THUMB_SLOTS)
    сразу 503 {"busy": true}, без ожидания.
    Миниатюры плана и вариантов — width 300–560, просмотр слайда крупно — до 1920."""
    import hashlib
    body = request.get_json(silent=True)
    slides = body.get('slides') if isinstance(body, dict) else None
    if not isinstance(slides, list) or not slides or len(slides) > 12:
        return jsonify({'error': 'Нужен список из 1–12 слайдов.'}), 400
    try:
        width = max(160, min(1920, int(body.get('width') or 560)))
    except (TypeError, ValueError):
        width = 560
    all_pages = bool(body.get('pages'))
    try:                                         # номер слайда в презентации — для просмотра одного слайда крупно
        number = max(1, min(300, int(body.get('number') or 1))) if len(slides) == 1 else 1
    except (TypeError, ValueError):
        number = 1
    if not preview_engine():
        return jsonify({'error': 'Для просмотра слайдов нужен LibreOffice или PowerPoint.',
                        'images': [None] * len(slides)}), 501
    meta = body.get('meta') if isinstance(body.get('meta'), dict) else {}
    slides = [{k: v for k, v in s.items() if k not in ('alts', 'remarks')} if isinstance(s, dict) else s for s in slides]
    tpl_rev = engine.templates.revision(meta.get('template'))     # свой шаблон и его настройки
    keys = [hashlib.sha1(json.dumps([s, meta.get('title'), width, number, tpl_rev], ensure_ascii=False, sort_keys=True,
                                    default=str).encode()).hexdigest() for s in slides]
    with THUMB_LOCK:
        cached = [THUMB_CACHE.get(k) for k in keys]          # каждая запись — список страниц слайда
    todo = [i for i, c in enumerate(cached) if c is None]
    err = None
    if todo:
        got = THUMB_SLOTS.acquire(blocking=False) if body.get('background') else THUMB_SLOTS.acquire(timeout=60)
        if not got:
            return jsonify({'error': 'Конструктор занят: картинки слайдов построятся чуть позже.', 'busy': True,
                            'images': [(c[0] if c else None) for c in cached]}), 503
        tmp = None
        try:
            tmp = Path(tempfile.mkdtemp(prefix='zn_thumbs_'))
            path, starts = engine.build_preview_deck([slides[i] for i in todo], tmp / 'thumbs.pptx', meta, number=number,
                                                     pad_hidden=preview_engine() == 'libreoffice')
            pdf = pptx_to_pdf(path, 180)
            total = _page_count(pdf)
            known = [st for st in starts if st is not None] + [total]
            spans = []
            for st in starts:                                   # страницы слайда: от его начала до начала следующего
                if st is None:
                    spans.append([])
                    continue
                nxt = min(k for k in known if k > st)
                spans.append(list(range(st, min(nxt, st + 6))))
            imgs = _rasterize(pdf, sorted({p for sp in spans for p in sp}), width)
            if imgs is None:
                return jsonify({'error': 'Для просмотра слайдов установите пакет pypdfium2 (pip install pypdfium2).',
                                'images': [None] * len(slides)}), 501
            with THUMB_LOCK:
                for i, sp in zip(todo, spans):
                    pages = [imgs.get(p) for p in sp if imgs.get(p)]
                    cached[i] = pages
                    if pages:
                        THUMB_CACHE[keys[i]] = pages
                if len(THUMB_CACHE) > 400:
                    for k in list(THUMB_CACHE)[:200]:
                        THUMB_CACHE.pop(k, None)
        except subprocess.TimeoutExpired:
            err = ('Не успели построить картинки слайдов.', 504)
        except Exception as e:                   # noqa: BLE001
            app.logger.exception('thumbs failed')
            err = (f'Не удалось построить картинки слайдов: {e}', 500)
        finally:
            THUMB_SLOTS.release()
            if tmp:
                shutil.rmtree(tmp, ignore_errors=True)
    out = {'images': [(c[0] if c else None) for c in cached]}
    if all_pages:
        out['pages'] = [c or [] for c in cached]
    if err:
        out['error'] = err[0]
        return jsonify(out), err[1]
    return jsonify(out)


CHART_DATA_EXT = {'.xlsx', '.xlsm', '.csv', '.txt', '.docx', '.pdf', '.md', '.json', '.pptx'}


@app.post('/api/chart_data')
def chart_data():
    """Данные для диаграммы из файла (Excel, CSV, JSON, таблицы Word и PDF, таблицы и диаграммы PowerPoint):
    {"tables": [{"name", "categories",
    "series", "type", "unit", "hint"}, …]} — по одной записи на таблицу с числами. Файл не сохраняется."""
    f = request.files.get('file')
    if not f or not f.filename:
        return jsonify({'error': 'Выберите файл с данными: Excel (.xlsx), CSV, JSON, Word, PDF или PowerPoint '
                                 'с таблицей.'}), 400
    name = Path(f.filename).name
    ext = Path(name).suffix.lower()
    if ext not in CHART_DATA_EXT:
        return jsonify({'error': f'Файл «{name}» не подходит. Нужен Excel (.xlsx, .xlsm), CSV, JSON или Word/PDF/'
                                 f'PowerPoint (.pptx) с таблицей (старые .xls, .doc и .ppt пересохраните в новом '
                                 f'формате).'}), 400
    tmp = Path(tempfile.mkdtemp(prefix='zn_chart_'))
    try:
        dst = tmp / f'data{ext}'
        f.save(dst)
        doc = engine.read_files([(str(dst), name)])
        from engine.insights import table_grid
        tables = []
        for k, t in enumerate(doc.tables.values(), 1):
            try:
                g = table_grid(t)
            except Exception:                    # noqa: BLE001 — одна кривая таблица не мешает остальным
                app.logger.exception('table_grid')
                g = None
            if g and g['categories'] and any(v is not None for s in g['series'] for v in s['values']):
                g['name'] = g['name'] or f'Таблица {k}'
                tables.append(g)
    except Exception as e:                       # noqa: BLE001
        app.logger.exception('chart_data')
        return jsonify({'error': f'Не удалось прочитать «{name}»: {e}'}), 400
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    if not tables:
        return jsonify({'error': f'В «{name}» не нашлось таблицы с числами. Нужна таблица: первая строка — названия '
                                 f'рядов, первый столбец — подписи (годы, объекты), в остальных — числа.'}), 400
    return jsonify({'tables': tables[:30], 'file': name})


@app.post('/api/chart_insights')
def chart_insights():
    """Выводы по данным диаграммы (рост, максимум, доли — только из её чисел): {"chart": {…}} → {"insights": […]}."""
    body = request.get_json(silent=True) or {}
    sp, _ = engine.normalize({'meta': {}, 'slides': [{'layout': 'chart', 'title': 'x', 'chart': body.get('chart')}]},
                             add_title_end=False)
    sl = next((x for x in sp['slides'] if x.get('layout') == 'chart'), None)
    if not sl:
        return jsonify({'insights': [], 'error': 'Для выводов нужны числа в таблице данных.'})
    from engine.insights import make_insights
    try:
        ins = make_insights(sl['chart'])
    except Exception:                            # noqa: BLE001
        app.logger.exception('chart_insights')
        ins = []
    return jsonify({'insights': ins})


def _page_count(pdf_path):
    try:
        import pypdfium2 as pdfium
    except ImportError:
        return 0
    pdf = pdfium.PdfDocument(str(pdf_path))
    try:
        return len(pdf)
    finally:
        pdf.close()


# --------------------------------------------------------------------------------------
# Настройки модели ИИ (локальной или облачной)
# --------------------------------------------------------------------------------------
def _mask_proxy(p):
    """Пароль в адресе прокси (http://логин:пароль@прокси:порт) не показывается."""
    return re.sub(r'(?i)^([a-z]+://[^:/@]+:)[^@]+@', lambda m: m.group(1) + MASK + '@', str(p or ''))


@app.get('/api/settings')
def get_settings():
    s = load_settings()
    llm = {k: v for k, v in s['llm'].items() if k in LLM_DEFAULTS}
    llm['api_key'] = MASK if llm.get('api_key') else ''
    llm['api_keys'] = {p: MASK for p, k in (llm.get('api_keys') or {}).items() if k}   # у каких сервисов есть ключ
    llm['proxy'] = _mask_proxy(llm.get('proxy'))
    return jsonify({'llm': llm, 'defaults': s['defaults'], 'cloud_allowed': not cloud_locked(s['llm']),
                    'cloud': is_cloud(s['llm']), 'providers': provider_table(), 'groups': GROUPS,
                    'internal_domains': s['llm'].get('internal_domains') or []})


LOCAL_ONLY = ('Настройки ИИ меняются только на самом сервере: откройте приложение там по адресу '
              'http://127.0.0.1:8050 или поправьте файл settings.json.')

# поле → (тип, минимум, максимум, подпись для сообщения об ошибке)
NUM_FIELDS = {'temperature': (float, 0, 2, 'Температура'), 'num_ctx': (int, 1024, 262144, 'Контекст'),
              'timeout': (int, 10, 7200, 'Ожидание'), 'max_chars': (int, 2000, 400000, 'Объём выжимки'),
              'illustrations': (int, 0, 30, 'Иллюстраций при анализе')}


def _clean_llm(llm):
    """Проверка полей настроек ИИ. Ошибка → ValueError с понятным текстом."""
    if not isinstance(llm, dict):
        raise ValueError('Неверный формат настроек.')
    out = {k: v for k, v in llm.items() if k in LLM_DEFAULTS and k != 'api_keys'}
    for k, (typ, lo, hi, label) in NUM_FIELDS.items():
        if k in out and out[k] in ('', None):
            out.pop(k)                           # пустое поле — значение не меняется
        if k in out:
            try:
                v = typ(float(str(out[k]).replace(',', '.')))
            except (TypeError, ValueError):
                raise ValueError(f'Поле «{label}» должно быть числом.')
            if not lo <= v <= hi:
                raise ValueError(f'Поле «{label}»: допустимо от {lo} до {hi}.')
            out[k] = v
    if 'provider' in out and out['provider'] not in PROVIDER:
        raise ValueError('Неизвестный тип сервера.')
    if 'base_url' in out:
        out['base_url'] = str(out['base_url']).strip()
        if not re.match(r'(?i)^https?://[^\s/]+', out['base_url']):
            raise ValueError('Адрес сервера должен начинаться с http:// или https://')
    for k in ('model', 'api_key', 'proxy', 'ca_file', 'folder_id', 'auth_url', 'embed_model', 'vision_model'):
        if k in out:
            out[k] = str(out[k] or '').strip()
    for k, label in (('embed_url', 'модели поиска'), ('vision_url', 'модели для названий картинок')):
        if k in out:
            out[k] = str(out[k] or '').strip().rstrip('/') or LLM_DEFAULTS[k]
            if not re.match(r'(?i)^https?://[^\s/]+', out[k]):
                raise ValueError(f'Адрес {label} должен начинаться с http:// или https://')
    for k in ('json_mode', 'use_proxy', 'cloud_consent'):
        if k in out:
            out[k] = bool(out[k])
    px = out.get('proxy') or ''
    if px and px.lower() not in ('нет', 'none', 'direct', 'no', 'off', '-', 'напрямую') and \
            not re.match(r'(?i)^https?://[^\s/]+', px):            # SOCKS стандартная библиотека не умеет
        raise ValueError('Прокси: пусто — системный, «нет» — напрямую или адрес вида http://прокси:порт')
    if out.get('ca_file') and not Path(out['ca_file'].strip('"')).is_file():
        raise ValueError(f'Файл сертификатов не найден: {out["ca_file"]}')
    if out.get('auth_url') and not re.match(r'(?i)^https?://[^\s/]+', out['auth_url']):
        raise ValueError('Адрес выдачи токена должен начинаться с http:// или https://')
    if out.get('folder_id') and not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', out['folder_id']):
        raise ValueError('Идентификатор каталога Yandex Cloud: латинские буквы и цифры (например, b1g…).')
    if 'yandex_auth' in out and out['yandex_auth'] not in ('api_key', 'bearer'):
        raise ValueError('Вид ключа YandexGPT: api_key или bearer.')
    if 'gigachat_scope' in out and out['gigachat_scope'] not in GIGACHAT_SCOPES:
        raise ValueError('Область доступа GigaChat: ' + ', '.join(GIGACHAT_SCOPES))
    return out


def _form_llm(body):
    """Поля окна настроек (ещё не сохранённые) поверх сохранённых → настройки для пробного запроса.
    Неверное поле → ValueError."""
    raw = (body or {}).get('llm') if isinstance(body, dict) else None
    raw = dict(raw) if isinstance(raw, dict) else {}
    if MASK in str(raw.get('proxy') or ''):
        raw.pop('proxy')                         # пароль прокси не меняли
    return runtime_llm(load_settings()['llm'], _clean_llm(raw))


@app.post('/api/settings')
def set_settings():
    if not is_local_request():
        return jsonify({'error': LOCAL_ONLY}), 403
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return jsonify({'error': 'Неверный формат настроек.'}), 400
    s = load_settings()
    llm = dict(body.get('llm') or {}) if isinstance(body.get('llm'), dict) else {}
    key = llm.pop('api_key', None)
    if MASK in str(llm.get('proxy') or ''):
        llm.pop('proxy')                         # пароль прокси не меняли
    try:
        llm = _clean_llm(llm)
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    prov = llm.get('provider', s['llm'].get('provider'))
    if is_cloud({**s['llm'], **llm}) and cloud_locked(s['llm']):
        return jsonify({'error': LOCKED_MSG}), 403
    if prov != s['llm'].get('provider') and 'cloud_consent' not in llm:
        llm['cloud_consent'] = False             # согласие дают конкретному сервису: сменили сервис — подтвердить заново
    keys = dict(s['llm'].get('api_keys') or {})  # ключ — свой у каждого сервиса: при смене сервиса не теряется
    if key is not None and key != MASK:          # «••••» — ключ не меняли
        key = str(key).strip()
        if key:
            keys[prov] = key
        else:
            keys.pop(prov, None)
    s['llm'].update(llm)
    s['llm'].update(api_keys=keys, api_key=keys.get(prov, ''))
    if isinstance(body.get('defaults'), dict):
        s['defaults'].update({k: v for k, v in body['defaults'].items() if k in s['defaults']})
    save_settings(s)
    return jsonify({'ok': True})


@app.post('/api/llm/test')
def llm_test():
    """Связь с сервером модели и список моделей (документы не отправляются — согласие не нужно,
    запрет администратора действует). Сервис без списка моделей → рекомендуемые модели."""
    if not is_local_request():
        return jsonify({'ok': False, 'error': LOCAL_ONLY}), 403
    try:
        cfg = _form_llm(request.get_json(silent=True))
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    cloud = is_cloud(cfg)
    try:
        models = list_models(cfg)
    except LLMError as e:
        p = PROVIDER.get(cfg.get('provider')) or {}
        if p.get('cloud') and p.get('models') and e.status in (404, 405) and not isinstance(e, CloudRefused):
            return jsonify({'ok': True, 'models': p['models'], 'has_model': cfg.get('model') in p['models'],
                            'suggested': True, 'cloud': cloud})
        return jsonify({'ok': False, 'error': str(e), 'cloud': cloud})
    return jsonify({'ok': True, 'models': models, 'has_model': cfg.get('model') in models, 'cloud': cloud})


@app.post('/api/illustrate')
def illustrate():
    """Иллюстрация к слайду: {"slide": {...}} → {"alt": вариант слайда}. Рисует модель ИИ из настроек."""
    body = request.get_json(silent=True)
    s = body.get('slide') if isinstance(body, dict) else None
    if not isinstance(s, dict):
        return jsonify({'error': 'Нет слайда.'}), 400
    from engine.illustrate import illustrated_slide, model_drawing
    from engine.svgdraw import SvgError
    llm = llm_settings()
    refusal = cloud_refusal(llm)
    if refusal:
        return jsonify({'error': refusal}), 403
    try:
        svg = model_drawing(s, llm)
    except (LLMError, SvgError) as e:
        return jsonify({'error': f'Модель не нарисовала иллюстрацию: {e}'}), 502
    return jsonify({'alt': illustrated_slide(s, svg)})


# --------------------------------------------------------------------------------------
# Картинки: библиотека, карты стран, свои картинки
# --------------------------------------------------------------------------------------
@app.get('/api/pictures')
def pictures_list():
    from engine import pictures as P
    cat = P.catalog()
    cats = ([P.MY_CAT] if any(e['cat'] == P.MY_CAT for e in cat) else []) + \
        [c for c in P.CATEGORIES if any(e['cat'] == c for e in cat)] + ['Карты стран']
    return jsonify({'categories': cats, 'my_cat': P.MY_CAT, 'photo_cats': [c for c in P.CATEGORIES if c not in ('Элементы оформления', 'Карты')],
                    'items': [dict({'id': e['id'], 'name': e['name'], 'cat': e['cat'], 'photo': bool(e.get('photo')),
                                    'credit': e.get('credit') or '',
                                    'source': (e.get('source') or {}).get('set', '') or (e.get('source') or {}).get('site', '')},
                                   **({'mine': True, 'upload': e['upload'], 'author': e['source'].get('author', '')} if e.get('mine') else {}))
                              for e in cat],
                    'countries': P.countries_list()})


@app.get('/api/photo/<pid>')
def photo_file(pid):
    """Встроенная фотография (?w=360 — уменьшенная копия для окна выбора)."""
    from engine import pictures as P
    p = P.photo_path(pid)
    if not p:
        abort(404)
    w = request.args.get('w', type=int)
    if w:
        try:
            p = P.thumb(p, max(120, min(w, 800)))
        except OSError:
            pass
    return send_file(p, max_age=86400)


@app.get('/api/pictures/<pid>.svg')
def picture_svg(pid):
    from engine import pictures as P
    try:
        svg = P.svg(pid)
    except P.PictureError:
        abort(404)
    resp = app.response_class(svg, mimetype='image/svg+xml')
    resp.headers['Cache-Control'] = 'max-age=86400'
    return resp


def _pictures_cfg():
    """Настройки модели поиска для подбора картинок по смыслу — если она задана (иначе None: по словам)."""
    cfg = llm_settings()
    return cfg if str(cfg.get('embed_model') or '').strip() else None


@app.post('/api/pictures/suggest')
def pictures_suggest():
    from engine import pictures as P
    body = request.get_json(silent=True) or {}
    deck = body.get('slides') if isinstance(body, dict) else None
    cfg = _pictures_cfg()
    if isinstance(deck, list):                               # ко всей презентации (окно «Картинки к слайдам»)
        return jsonify({'items': P.deck_suggest([x if isinstance(x, dict) else {} for x in deck[:200]], cfg=cfg),
                        'semantic': bool(cfg and P.sem_searcher(cfg))})
    s = body.get('slide') if isinstance(body, dict) else None
    q = str(body.get('query') or '')[:200] if isinstance(body, dict) else ''
    if not isinstance(s, dict) and not q:
        return jsonify({'error': 'Нет слайда.'}), 400
    sem = P.sem_hits([s or {}], cfg, 12, queries=[q] if q else None)[0] if cfg else []
    sug = P.smart_suggest(s or {}, 12, query=q or None, sem=sem)
    out = [{'id': e['id'], 'name': e['name'], 'cat': e['cat'], 'by': 'model' if how == 'смысл' else 'words'}
           for e, _, how in sug]
    if isinstance(s, dict):                                  # страны, названные на слайде, — картой
        from engine.geo import find_countries
        from engine.illustrate import slide_subject
        for cid in find_countries(slide_subject(s))[:3]:
            e = P.get(f'map_{cid}')
            if e:
                out.append({'id': e['id'], 'name': e['name'], 'cat': 'Карты стран'})
    return jsonify({'items': out})


def _clean_image(im):
    """Ссылка на картинку из запроса → {'picture'|'upload'|'svg', 'caption'}; ошибка → (сообщение, код)."""
    from engine import pictures as P
    clean = {}
    if not isinstance(im, dict):
        return None, ('Нет картинки.', 400)
    if im.get('picture'):
        clean['picture'] = str(im['picture'])[:40]
    elif im.get('upload'):
        clean['upload'] = str(im['upload'])[:40]
    elif isinstance(im.get('svg'), str):
        from engine.svgdraw import SvgError, sanitize
        try:
            clean['svg'] = sanitize(im['svg'])
        except SvgError as e:
            return None, (f'Рисунок не подходит: {e}', 400)
        if im.get('ai'):
            clean['ai'] = True
    if not clean or not P.resolve(clean):
        return None, ('Картинка не найдена (возможно, файл удалён из папки output/uploads).', 404)
    clean['caption'] = str(im.get('caption') or '')[:120]
    if not clean.get('svg'):                                 # эффект фото (1.7)
        from engine.photofx import clean as fx_clean
        clean.update(fx_clean(im))
    if clean.get('upload') and im.get('live3d') is True:      # 3D-модель — вращаемой в PowerPoint 365 (1.7, проба)
        clean['live3d'] = True
    return clean, None


@app.post('/api/picture')
def picture_alt():
    """{"slide", "image": {"picture"|"upload"|"svg"} или "images": [до трёх], "full": bool}
    → {"alt": вариант слайда с картинкой (картинками)}."""
    from engine import pictures as P
    body = request.get_json(silent=True) or {}
    s = body.get('slide') if isinstance(body, dict) else None
    raw = body.get('images') if isinstance(body, dict) and isinstance(body.get('images'), list) else \
        [body.get('image')] if isinstance(body, dict) and isinstance(body.get('image'), dict) else None
    if not isinstance(s, dict) or not raw:
        return jsonify({'error': 'Нет слайда или картинки.'}), 400
    ims = []
    for im in raw[:P.MAX_PER_SLIDE]:
        clean, err = _clean_image(im)
        if err:
            return jsonify({'error': err[0]}), err[1]
        ims.append(clean)
    label = str(body.get('label') or '')[:60] or P.labels_of(ims)
    return jsonify({'alt': P.picture_alt(s, ims if len(ims) > 1 else ims[0], full=bool(body.get('full')), label=label)})


@app.post('/api/pictures/distribute')
def pictures_distribute():
    """{"slides": [слайды плана — исходные тезисы], "images": [{"picture"|"upload"}], "busy": [номера слайдов, которые
    не трогать], "load": {номер: картинок уже стоит}, "mode": "auto"|"order"}
    → {"places": [{"slide": номер|null, "score", "why"}]}."""
    from engine import pictures as P
    body = request.get_json(silent=True) or {}
    slides = body.get('slides') if isinstance(body, dict) else None
    images = body.get('images') if isinstance(body, dict) else None
    if not isinstance(slides, list) or not isinstance(images, list):
        return jsonify({'error': 'Нет слайдов или картинок.'}), 400
    ims = []
    for im in images[:300]:
        im = im if isinstance(im, dict) else {}
        ims.append({'picture': str(im['picture'])[:40]} if im.get('picture') else
                   {'upload': str(im['upload'])[:40]} if im.get('upload') else {})
    busy = [b for b in (body.get('busy') or []) if isinstance(b, int)]
    load = body.get('load') if isinstance(body.get('load'), dict) else {}
    load = {k: v for k, v in load.items() if isinstance(v, int)}
    names = {e['upload']: e for e in P.list_uploads([im['upload'] for im in ims if im.get('upload')])}
    places = P.distribute([x if isinstance(x, dict) else {} for x in slides[:300]], ims,
                          mode='order' if body.get('mode') == 'order' else 'auto', busy=busy, load=load, names=names)
    return jsonify({'places': places})


def _big_request(mb):
    """Этому запросу можно больше обычных 60 МБ (архив снимков, файл библиотеки). Flask 3.0 — не умеет, пропуск."""
    try:
        request.max_content_length = mb * 1024 * 1024
    except (AttributeError, TypeError):
        pass


ZIP_MAX_FILES = 500
ZIP_MAX_TOTAL = 1024 * 1024 * 1024


def _upload_zip(data, zname):
    """Архив .zip со снимками → [{'image', 'name', 'title'}], [ошибки]. Папки архива подсказывают названия."""
    import io
    import zipfile
    from engine import pictures as P
    done, errs = [], []
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        return [], [f'{zname}: архив повреждён']
    exts = P.RASTER | {'.svg'}
    members = [m for m in zf.infolist() if not m.is_dir() and Path(m.filename).suffix.lower() in exts
               and not m.filename.startswith('__MACOSX/') and not Path(m.filename).name.startswith('._')]
    if not members:
        return [], [f'{zname}: в архиве нет картинок']
    if len(members) > ZIP_MAX_FILES:
        errs.append(f'{zname}: картинок больше {ZIP_MAX_FILES} — загружены первые {ZIP_MAX_FILES}')
        members = members[:ZIP_MAX_FILES]
    total = 0
    for m in members:
        name = m.filename.replace('\\', '/')
        if m.flag_bits & 0x800 == 0:                         # имена без пометки UTF-8 — как пишет Проводник Windows
            try:
                name = m.filename.encode('cp437').decode('cp866')
            except (UnicodeEncodeError, UnicodeDecodeError):
                pass
        total += m.file_size
        if m.file_size > P.MAX_UPLOAD or total > ZIP_MAX_TOTAL:
            errs.append(f'{Path(name).name}: файл слишком большой')
            continue
        try:
            with zf.open(m) as fh:
                blob = fh.read(P.MAX_UPLOAD + 1)
            im = P.save_upload(blob, Path(name).name, folder=str(Path(name).parent))
        except P.PictureError as e:
            errs.append(f'{Path(name).name}: {e}')
            continue
        except (OSError, zipfile.BadZipFile, RuntimeError) as e:  # RuntimeError — архив с паролем
            errs.append(f'{Path(name).name}: не прочитан ({e})')
            continue
        done.append({'image': im, 'name': Path(name).name, 'title': P.upload_title(im['upload'])})
    return done, errs


# --------------------------------------------------------------------------------------
# Свои слайды из файла PowerPoint (engine/ownslides.py)
# --------------------------------------------------------------------------------------
@app.post('/api/own')
def own_upload():
    """Файл PowerPoint со своими слайдами → список его слайдов {'id', 'name', 'n', 'wide', 'slides': [...]}."""
    from engine import ownslides as O
    if not from_own_page():
        return jsonify({'error': 'Загружать слайды можно только со страницы конструктора.'}), 403
    f = request.files.get('file')
    if not f or not f.filename:
        return jsonify({'error': 'Нет файла.'}), 400
    if Path(f.filename).suffix.lower() not in ('.pptx', '.potx', '.ppsx', '.ppt'):
        return jsonify({'error': 'Нужен файл PowerPoint (.pptx).'}), 400
    try:
        return jsonify(O.save(f.read(), f.filename))
    except O.OwnError as e:
        return jsonify({'error': str(e)}), 400


@app.get('/api/own')
def own_list():
    from engine import ownslides as O
    return jsonify({'items': O.listing() if is_local_request() else []})


@app.get('/api/own/<fid>')
def own_info(fid):
    from engine import ownslides as O
    try:
        return jsonify(O.inspect(fid))
    except O.OwnError as e:
        return jsonify({'error': str(e)}), 404


@app.delete('/api/own/<fid>')
def own_delete(fid):
    from engine import ownslides as O
    if not from_own_page():
        return jsonify({'error': 'Удалять можно только со страницы конструктора.'}), 403
    return jsonify({'ok': O.delete(fid)})


@app.post('/api/upload_image')
def upload_image():
    """Своя картинка или архив .zip со снимками (до 500). Название по содержанию — из описания внутри файла,
    имени файла или папки архива; без них — пусто (назовёт модель или автор)."""
    from engine import pictures as P
    _big_request(400)
    f = request.files.get('file')
    if not f:
        return jsonify({'error': 'Файл не получен.'}), 400
    data = f.read()
    lib = request.form.get('lib') == '1'                    # сразу в библиотеку фотографий (1.7)
    if lib and not from_own_page():
        return jsonify({'error': 'Пополнять библиотеку можно только со страницы конструктора.'}), 403
    if (f.filename or '').lower().endswith('.zip'):
        done, errs = _upload_zip(data, f.filename)
        if not done:
            return jsonify({'error': 'Картинки не загружены: ' + '; '.join(errs[:3])}), 400
        if lib:
            for d in done:
                if P.set_library(d['image'].get('upload'), True):
                    d['photo_id'] = P.MY_PREFIX + d['image']['upload'][:20]
        return jsonify({'images': done, 'errors': errs})
    folder = str(request.form.get('folder') or '')[:200]
    from engine import model3d as M3
    if M3.is_model(f.filename):                              # 3D-модель (1.7): на слайд — вид с ракурса
        try:
            im = M3.save(data, f.filename or '', str(request.form.get('view') or 'iso'), folder=folder)
        except M3.Model3DError as e:
            return jsonify({'error': f'3D-модель не загружена: {e}'}), 400
        return jsonify({'image': im, 'url': f'/api/upload/{im["upload"]}', 'name': f.filename or '',
                        'title': P.upload_title(im['upload'])})
    try:
        im = P.save_upload(data, f.filename or '', folder=folder)
    except P.PictureError as e:
        return jsonify({'error': f'Картинка не загружена: {e}'}), 400
    url = f'/api/upload/{im["upload"]}' if im.get('upload') else None
    out = {'image': im, 'url': url, 'name': f.filename or '', 'title': P.upload_title(im['upload'])}
    if lib:
        if not P.set_library(im['upload'], True):
            return jsonify({'error': f'«{f.filename}»: векторный рисунок (SVG) — не фотография, он остался в «Моих картинках».'}), 400
        out['photo_id'] = P.MY_PREFIX + im['upload'][:20]
    return jsonify(out)


@app.patch('/api/upload/<name>')
def upload_rename(name):
    """Своя картинка — правка автором: {"title": "…"} — название; {"lib": true|false, "cat", "author"} — в библиотеке
    фотографий или нет, раздел и автор снимка (1.7)."""
    from engine import pictures as P
    if not from_own_page():
        return jsonify({'error': 'Менять картинки можно только со страницы конструктора.'}), 403
    body = request.get_json(silent=True) or {}
    if not isinstance(body, dict) or not P.upload_path(name):
        return jsonify({'error': 'Такой картинки нет (возможно, удалена).'}), 404
    if 'title' in body and not P.set_title(name, str(body.get('title') or ''), 'user'):
        return jsonify({'error': 'Название не сохранено.'}), 500
    if any(k in body for k in ('lib', 'cat', 'author')):
        on = bool(body['lib']) if 'lib' in body else bool((P._load_index().get(name) or {}).get('lib'))
        if not P.set_library(name, on, body.get('cat'), body.get('author')):
            return jsonify({'error': 'Векторный рисунок (SVG) — не фотография: в библиотеку фото он не добавляется.'}), 400
    e = P._load_index().get(name) or {}
    return jsonify({'ok': True, 'title': P.upload_title(name), 'lib': bool(e.get('lib')), 'cat': e.get('cat') or '',
                    'author': e.get('author') or '', 'photo_id': P.MY_PREFIX + name[:20] if e.get('lib') else ''})


@app.post('/api/upload/<name>/view')
def upload_view(name):
    """Вид 3D-модели с другого ракурса: {"view": "front"} → новая своя картинка (прежняя остаётся)."""
    from engine import model3d as M3
    from engine import pictures as P
    if not from_own_page():
        return jsonify({'error': 'Менять ракурс можно только со страницы конструктора.'}), 403
    view = str((request.get_json(silent=True) or {}).get('view') or 'iso')
    if view not in M3.VIEWS:
        return jsonify({'error': 'Неизвестный ракурс.'}), 400
    try:
        im = M3.rerender(name, view)
    except M3.Model3DError as e:
        return jsonify({'error': str(e)}), 404
    return jsonify({'image': im, 'url': f'/api/upload/{im["upload"]}', 'title': P.upload_title(im['upload']),
                    'view_name': M3.VIEWS[view][0]})


@app.post('/api/upload/<name>/autoname')
def upload_autoname(name):
    """Название своей картинки по содержанию — локальной моделью, которая распознаёт изображения."""
    from engine import pictures as P
    if not from_own_page():
        return jsonify({'error': 'Называть картинки можно только со страницы конструктора.'}), 403
    try:
        r = P.autoname(name, llm_settings())
    except P.PictureError as e:
        return jsonify({'error': str(e)}), 404
    except LLMError as e:
        return jsonify({'error': f'Модель не назвала картинку: {e}'}), 502
    return jsonify(r)


@app.get('/api/uploads')
def uploads_list():
    """Свои картинки. На этом компьютере — все из output/uploads; с другого компьютера — только те, чьи
    имена переданы (?names=a.png,b.jpg: браузер помнит свои загрузки), чтобы не показывать чужие."""
    from engine import pictures as P
    names = [n for n in str(request.args.get('names') or '').split(',') if n][:500]
    items = P.list_uploads() if is_local_request() else P.list_uploads(names)
    from engine import model3d as M3
    for e in items:                                          # вид 3D-модели: можно взять другой ракурс
        info = M3.model_info(e['upload'])
        if info and info.get('glb'):
            e['model3d'] = info.get('view') if isinstance(info.get('view'), str) else 'iso'
    return jsonify({'items': [dict(e, url=f'/api/upload/{e["upload"]}') for e in items],
                    'views': [[k, v[0]] for k, v in M3.VIEWS.items()]})


@app.get('/api/upload/<name>')
def upload_file(name):
    from engine import pictures as P
    p = P.upload_path(name)
    if not p:
        abort(404)
    w = request.args.get('w', type=int)
    if w:                                                    # уменьшенная копия для окна выбора
        try:
            p = P.thumb(p, max(120, min(w, 800)))
        except OSError:
            pass
    resp = send_file(p, max_age=86400)
    if p.suffix == '.svg':                                   # открытый отдельно SVG не выполняет ничего
        resp.headers['Content-Security-Policy'] = "default-src 'none'; style-src 'unsafe-inline'"
    return resp


@app.delete('/api/upload/<name>')
def upload_delete(name):
    """Удаляет свою картинку из output/uploads (только со страницы конструктора)."""
    from engine import pictures as P
    if not from_own_page():
        return jsonify({'error': 'Удалять картинки можно только со страницы конструктора.'}), 403
    if not P.delete_upload(name):
        return jsonify({'error': 'Такой картинки нет (возможно, уже удалена).'}), 404
    return jsonify({'ok': True})


# --------------------------------------------------------------------------------------
# Эффекты фотографий (1.7, engine/photofx.py)
# --------------------------------------------------------------------------------------
DOCIMG_RX = re.compile(r'[0-9a-f]{16}\.(png|jpe?g|gif|bmp|webp|tiff?)')


def _doc_image(path):
    """Рисунок из материалов (output/cache/<sha1>.<расширение>) — только оттуда; иначе None."""
    name = Path(str(path or '').replace('\\', '/')).name
    if not DOCIMG_RX.fullmatch(name):
        return None
    p = C.OUTPUT_DIR / 'cache' / name
    return p if p.is_file() else None


@app.get('/api/docimage/<name>')
def doc_image(name):
    """Рисунок из материалов доклада — для миниатюр в плане (только кэш output/cache)."""
    from engine import pictures as P
    p = _doc_image(name)
    if not p:
        abort(404)
    w = request.args.get('w', type=int)
    if w:
        try:
            p = P.thumb(p, max(120, min(w, 800)))
        except OSError:
            pass
    return send_file(p, max_age=86400)


@app.get('/api/photofx')
def photofx_list():
    from engine import photofx as F
    return jsonify({'effects': [{'id': k, 'name': v[0], 'hint': v[1]} for k, v in F.EFFECTS.items()],
                    'tones': [{'id': k, 'name': v[0], 'hint': v[1]} for k, v in F.TONES.items()]})


@app.post('/api/photofx/suggest')
def photofx_suggest():
    """{"slide": слайд плана, "index": номер картинки, "model": true|false} → {"effect", "tone", "why", "by"
    ('model' — предложила модель, которая видит изображения; 'rules' — по снимку), "note"?}.
    Векторный рисунок → {"effect": null}."""
    from engine import photofx as F
    if not from_own_page():
        return jsonify({'error': 'Подбирать эффекты можно только со страницы конструктора.'}), 403
    body = request.get_json(silent=True) or {}
    s = body.get('slide') if isinstance(body, dict) else None
    i = body.get('index') if isinstance(body, dict) else None
    if not isinstance(s, dict) or not isinstance(i, int) or not isinstance(s.get('images'), list):
        return jsonify({'error': 'Нет слайда или картинки.'}), 400
    ims = []
    for im in s['images'][:3]:
        im = im if isinstance(im, dict) else {}
        if im.get('path'):
            p = _doc_image(im['path'])
            ims.append({'path': str(p), 'caption': str(im.get('caption') or '')[:120]} if p else {})
        else:
            clean, err = _clean_image(im)
            ims.append(clean if not err else {})
    items = [it for it in (s.get('items') or []) if isinstance(it, dict)][:8]
    slide = {'title': str(s.get('title') or '')[:150], 'images': ims, 'items': items,
             'illustration': bool(s.get('illustration'))}
    cfg = llm_settings()
    use_model = body.get('model') is not False and bool(str(cfg.get('vision_model') or '').strip())
    r = F.suggest(slide, i, cfg, use_model)
    if r is None:
        return jsonify({'effect': None})
    return jsonify(r)


# --------------------------------------------------------------------------------------
# Свои шаблоны оформления (engine/templates.py)
# --------------------------------------------------------------------------------------
TPL_PREVIEW_LOCK = threading.Lock()
TPL_PREVIEW_BUSY = {}            # id шаблона → замок построения образцов
TPL_SAMPLE = [
    {'layout': 'title'},
    {'layout': 'cards', 'title': 'Пример слайда с содержанием', 'subtitle': 'Так будут выглядеть слайды презентации',
     'items': [{'title': 'Мониторинг', 'text': 'Робот ежедневно проверяет источники и находит новые данные', 'icon': 'TbRadar'},
               {'title': 'Анализ', 'text': 'Ключевые показатели сводятся в единую таблицу', 'icon': 'TbChartBar'},
               {'title': 'Результат', 'text': 'Решения принимаются быстрее и на полных данных', 'icon': 'TbTarget'}],
     'conclusion': 'Цвета, шрифты и поля взяты из шаблона'},
    {'layout': 'section', 'title': 'Раздел презентации', 'number': '01'},
    {'layout': 'end'}]


def template_previews(tid):
    """Образцы слайдов в шаблоне: 4 картинки JPEG в папке шаблона (строятся один раз на версию настроек)."""
    import hashlib
    T = engine.templates
    if not T.get(tid):
        raise KeyError(tid)
    tag = hashlib.sha1(f'{T.revision(tid)}|{VERSION}'.encode()).hexdigest()[:10]
    d = T.TPL_DIR / (tid if tid != T.BUILTIN else '_builtin')
    files = [d / f'preview_{tag}_{i}.jpg' for i in range(1, 5)]
    if all(f.exists() for f in files):
        return files
    with TPL_PREVIEW_LOCK:
        lock = TPL_PREVIEW_BUSY.setdefault(tid, threading.Lock())
    with lock:
        if all(f.exists() for f in files):
            return files
        tmp = Path(tempfile.mkdtemp(prefix='zn_tpl_'))
        try:
            spec = {'meta': {'title': 'Название презентации', 'subtitle': 'Подзаголовок презентации',
                             'event': 'Мероприятие · дата', 'template': tid, 'animations': False}, 'slides': TPL_SAMPLE}
            path, _, _ = engine.build(spec, tmp / 'sample.pptx')
            pdf = pptx_to_pdf(path, 180)
            import pypdfium2 as pdfium
            d.mkdir(parents=True, exist_ok=True)
            doc = pdfium.PdfDocument(str(pdf))
            try:
                for i, f in enumerate(files):
                    if i >= len(doc):
                        break
                    page = doc[i]
                    img = page.render(scale=520 / page.get_width()).to_pil().convert('RGB')
                    part = f.with_suffix(f'.{threading.get_ident()}.tmp')
                    img.save(part, 'JPEG', quality=85, optimize=True)
                    part.replace(f)
            finally:
                doc.close()
            for old in d.glob('preview_*.jpg'):
                if old not in files:
                    old.unlink(missing_ok=True)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    return files


@app.get('/api/templates')
def templates_list():
    T = engine.templates
    return jsonify({'templates': T.list_templates(), 'roles': T.ROLE_NAMES, 'builtin': T.BUILTIN,
                    'previews': bool(preview_engine())})


@app.post('/api/templates')
def templates_upload():
    """Свои шаблоны PowerPoint (.pptx, .potx) — один или несколько файлов в поле files."""
    T = engine.templates
    if not from_own_page():
        return jsonify({'error': 'Загружать шаблоны можно только со страницы конструктора.'}), 403
    files = request.files.getlist('files') or request.files.getlist('file')
    if not files:
        return jsonify({'error': 'Файл шаблона не получен.'}), 400
    added, errors = [], []
    for f in files[:10]:
        name = f.filename or 'шаблон.pptx'
        if Path(name).suffix.lower() not in ('.pptx', '.potx', '.ppsx'):
            errors.append(f'{name}: нужен файл PowerPoint .pptx или .potx.')
            continue
        try:
            added.append(T.add_template(f.read(), name))
        except T.TemplateError as e:
            errors.append(f'{name}: {e}')
        except Exception as e:                       # noqa: BLE001
            app.logger.exception('template upload failed')
            errors.append(f'{name}: не удалось разобрать шаблон ({type(e).__name__}).')
    return jsonify({'added': added, 'errors': errors}), (200 if added or not errors else 400)


@app.patch('/api/templates/<tid>')
def templates_update(tid):
    T = engine.templates
    if not from_own_page():
        return jsonify({'error': 'Менять шаблоны можно только со страницы конструктора.'}), 403
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return jsonify({'error': 'Нет изменений.'}), 400
    try:
        return jsonify({'template': T.update(tid, body)})
    except T.TemplateError as e:
        return jsonify({'error': str(e)}), 404


@app.delete('/api/templates/<tid>')
def templates_delete(tid):
    T = engine.templates
    if not from_own_page():
        return jsonify({'error': 'Удалять шаблоны можно только со страницы конструктора.'}), 403
    if tid == T.BUILTIN:
        return jsonify({'error': 'Корпоративный шаблон удалить нельзя.'}), 400
    if not T.delete(tid):
        return jsonify({'error': 'Такого шаблона нет (возможно, уже удалён).'}), 404
    return jsonify({'ok': True})


@app.get('/api/templates/<tid>/preview/<int:n>.jpg')
def templates_preview(tid, n):
    if not 1 <= n <= 4:
        abort(404)
    if not preview_engine():
        return jsonify({'error': 'Для образцов слайдов нужен LibreOffice или PowerPoint.'}), 501
    try:
        files = template_previews(tid)
    except KeyError:
        abort(404)
    except subprocess.TimeoutExpired:
        return jsonify({'error': 'Не успели построить образец слайда.'}), 504
    except Exception as e:                           # noqa: BLE001
        app.logger.exception('template preview failed')
        return jsonify({'error': f'Не удалось построить образец: {e}'}), 500
    f = files[n - 1]
    if not f.exists():
        abort(404)
    return send_file(f, mimetype='image/jpeg', max_age=3600)


# --------------------------------------------------------------------------------------
# Замечания и правки
# --------------------------------------------------------------------------------------
@app.post('/api/revise')
def revise():
    """{"slide", "remark", "use_ai", "spec"} → {"slide", "done", "warnings", "mode"}."""
    body = request.get_json(silent=True) or {}
    s = body.get('slide') if isinstance(body, dict) else None
    remark = str(body.get('remark') or '').strip()[:2000] if isinstance(body, dict) else ''
    if not isinstance(s, dict) or not remark:
        return jsonify({'error': 'Нет слайда или текста замечания.'}), 400
    from engine.revise import revise_slide
    llm = llm_settings() if body.get('use_ai') else None
    refusal = cloud_refusal(llm) if llm else None
    if refusal:
        return jsonify({'error': refusal}), 403
    spec = body.get('spec') if isinstance(body.get('spec'), dict) else None
    try:
        new, done, warnings, mode = revise_slide(s, remark, llm=llm, spec=spec)
    except Cancelled:
        return jsonify({'error': 'Отменено.'}), 499
    return jsonify({'slide': new, 'done': done, 'warnings': warnings, 'mode': mode,
                    'cloud': bool(llm and mode == 'ai' and is_cloud(llm))})


@app.post('/api/revise_plan')
def revise_plan():
    """{"spec", "remarks"} → {"spec", "done"}: общие замечания ко всему плану (правилами)."""
    body = request.get_json(silent=True) or {}
    spec = body.get('spec') if isinstance(body, dict) else None
    text = str(body.get('remarks') or '').strip()[:3000] if isinstance(body, dict) else ''
    if not isinstance(spec, dict) or not text:
        return jsonify({'error': 'Нет плана или текста замечаний.'}), 400
    from engine.revise import apply_general
    spec, done = apply_general(spec, text)
    return jsonify({'spec': spec, 'done': done})


@app.post('/api/llm/draw_test')
def llm_draw_test():
    """Пробный рисунок модели ИИ: проверка, что выбранная модель умеет рисовать (и за сколько)."""
    if not is_local_request():
        return jsonify({'ok': False, 'error': LOCAL_ONLY}), 403
    try:
        cfg = _form_llm(request.get_json(silent=True))
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    from engine.illustrate import model_drawing
    from engine.svgdraw import SvgError, data_url
    t0 = time.time()
    try:
        svg = model_drawing({'title': 'Добыча нефти: скважина, насос и рост добычи',
                             'items': [{'title': 'Скважина и станок-качалка'}, {'title': 'Трубопровод'},
                                       {'title': 'График роста'}]}, cfg)
    except (LLMError, SvgError) as e:
        return jsonify({'ok': False, 'error': str(e)})
    from engine.illustrate import _count
    return jsonify({'ok': True, 'image': data_url(svg), 'seconds': round(time.time() - t0, 1), 'shapes': _count(svg)})


# --------------------------------------------------------------------------------------
# Библиотека материалов, поиск подходящих фраз и образцы для «Плана по образцу» (1.7)
# --------------------------------------------------------------------------------------
FINDERS = {}                     # (фразы доклада, библиотека, модель поиска) → (Finder, время)
FINDERS_LOCK = threading.Lock()
WARMED = set()                   # фразы докладов, которые уже готовятся к поиску по смыслу в фоне


@app.get('/api/library')
def library_list():
    from engine import library as L
    cfg = llm_settings()
    st = L.status(cfg)
    if st['texts'] and st['ready'] < st['texts'] and not st['warming'] and not st['error']:
        L.warm(cfg)                                          # подготовить к поиску по смыслу, пока окно открыто
        st['warming'] = True
    return jsonify({'items': L.items(), 'status': st})


@app.post('/api/library')
def library_add():
    from engine import library as L
    if not from_own_page():
        return jsonify({'error': 'Пополнять библиотеку можно только со страницы конструктора.'}), 403
    _big_request(110)
    f = request.files.get('file')
    if not f:
        return jsonify({'error': 'Файл не получен.'}), 400
    try:
        entry = L.add(f.read(), f.filename or '', ref=request.form.get('ref') == '1')
    except L.LibraryError as e:
        return jsonify({'error': f'«{f.filename}» не добавлен: {e}'}), 400
    except Exception as e:                                   # noqa: BLE001 — испорченный файл не роняет сервер
        app.logger.exception('library add failed')
        return jsonify({'error': f'«{f.filename}» не прочитан: {type(e).__name__}: {e}'}), 400
    L.warm(llm_settings())
    return jsonify({'item': entry})


@app.patch('/api/library/<fid>')
def library_patch(fid):
    """{"ref": true | false} — отметить презентацию эталоном (⭐) или снять отметку."""
    from engine import library as L
    if not from_own_page():
        return jsonify({'error': 'Менять библиотеку можно только со страницы конструктора.'}), 403
    body = request.get_json(silent=True) or {}
    e = L.set_ref(fid, bool(body.get('ref'))) if isinstance(body, dict) and 'ref' in body else None
    if not e:
        return jsonify({'error': 'Эталоном может быть только презентация PowerPoint из библиотеки.'}), 400
    return jsonify({'item': e})


@app.delete('/api/library/<fid>')
def library_delete(fid):
    from engine import library as L
    if not from_own_page():
        return jsonify({'error': 'Удалять из библиотеки можно только со страницы конструктора.'}), 403
    if not L.remove(fid):
        return jsonify({'error': 'Такого файла в библиотеке нет (возможно, уже удалён).'}), 404
    return jsonify({'ok': True})


def _finder(pid, cfg):
    """Поиск фраз для окна слайда: фразы доклада + библиотека. Кэш в памяти; недосчитанный поиск — по словам,
    а векторы тем временем считаются в фоне (следующий запрос — уже по смыслу)."""
    from engine import library as L
    from engine import phrases as PH
    key = (pid, L.rev(), cfg.get('embed_url'), cfg.get('embed_model'))
    now = time.time()
    with FINDERS_LOCK:
        hit = FINDERS.get(key)
        if hit and (hit[0].semantic and (hit[0].lib.semantic or not hit[0].lib.pool) or now - hit[1] < 30):
            return hit[0]
    pool = PH.load_pool(pid) or []
    f = PH.Finder(pool, L.pool(), cfg)
    f.prepare(max_missing=1500)
    if not f.semantic and 'не подготовлены' in f.doc.reason and pid not in WARMED:
        WARMED.add(pid)
        threading.Thread(target=lambda: _quiet(PH.embed_texts, cfg, [x['t'] for x in pool]), daemon=True).start()
    if f.semantic and f.lib.pool and not f.lib.semantic:
        L.warm(cfg)
    with FINDERS_LOCK:
        FINDERS[key] = (f, now)
        for k in sorted(FINDERS, key=lambda k: FINDERS[k][1])[:-4]:
            FINDERS.pop(k, None)
    return f


def _quiet(fn, *a):
    try:
        fn(*a)
    except Exception:                                        # noqa: BLE001 — фоновая подготовка: ошибка не важна
        pass


@app.post('/api/phrases')
def phrases_search():
    """{"pool": id фраз доклада (meta.pool), "query": свои слова или "slide": слайд, "k": сколько}
    → {"items": [{"t", "src", "sec", "lib", "num", "c"}], "semantic": по смыслу ли, "note": пояснение}."""
    from engine import phrases as PH
    body = request.get_json(silent=True) or {}
    s = body.get('slide') if isinstance(body.get('slide'), dict) else None
    q = str(body.get('query') or '').strip()[:500] or (PH.slide_query(s) if s else '')
    if not q:
        return jsonify({'error': 'Напишите, что найти, — или откройте слайд с текстом.'}), 400
    try:
        k = max(1, min(30, int(body.get('k') or 12)))
    except (TypeError, ValueError):
        k = 12
    pid = str(body.get('pool') or '')
    f = _finder(pid, llm_settings())
    exclude = (PH.slide_texts(s) if s else []) + [str(x) for x in (body.get('exclude') or [])[:200]]
    res = f.search(q, k=k, exclude=exclude)
    note = ''
    if not f.semantic:
        note = 'Поиск по совпадению слов: ' + (f.doc.reason or 'модель поиска недоступна') + '.'
    elif f.lib.pool and not f.lib.semantic:
        note = 'Библиотека ещё готовится к поиску по смыслу: из неё — по совпадению слов.'
    if pid and PH.load_pool(pid) is None:
        note = ('Фразы материалов этого плана уже удалены очисткой кэша (через 7 дней) — поиск идёт только '
                'по библиотеке. Постройте план заново, чтобы искать и в материалах. ' + note).strip()
    return jsonify({'items': [dict(p, c=c) for p, c in res], 'semantic': f.semantic, 'note': note})


VIEW_GONE = ('Текст документа этого плана уже удалён очисткой кэша (через 7 дней) или план открыт на другом '
             'компьютере. Постройте план заново из материалов — и фразу можно будет показать в документе.')


def _doc_target(body):
    """Снимок документа и путь к оригиналу: из материалов плана (view) или из библиотеки (lib). → (снимок, оригинал
    по номеру файла или None, ошибка)."""
    from engine import docview as DV
    lid = str(body.get('lib') or '')
    if lid:
        view, path = DV.library_view(lid)
        if not view:
            return None, None, 'Этого файла уже нет в «📚 Библиотеке материалов».'
        ok = path.suffix.lower() in DV.ORIG_EXT
        return view, (lambda i: path if ok else None), ''
    view = DV.load_view(str(body.get('view') or ''))
    if not view:
        return None, None, VIEW_GONE
    return view, (lambda i: DV.original_path(view['files'][i].get('orig'))), ''


def _doc_phrases(raw):
    """Фразы для выделения: первая — нажатая, дальше — остальные найденные (не больше 30)."""
    return [x[:1500] for x in (raw or [])[:30] if isinstance(x, str) and x.strip()]


@app.post('/api/docview')
def docview():
    """Документ, из которого взята фраза, с её местом (1.7.2). {"view": id снимка (meta.view) или "lib": id файла
    библиотеки, "src": источник фразы, "phrases": [нажатая фраза, остальные найденные], "file": номер файла (по желанию)}
    → {"name", "ext", "files", "file", "blocks", "start", "total", "hits", "orig", "page", "note"}."""
    from engine import docview as DV
    body = request.get_json(silent=True) or {}
    view, orig, err = _doc_target(body)
    if err:
        return jsonify({'error': err}), 404
    phrases = _doc_phrases(body.get('phrases'))
    files = view['files']
    if not files:
        return jsonify({'error': 'В документе нет текста.'}), 404
    try:
        fi = int(body['file'])
        if not 0 <= fi < len(files):
            raise ValueError
    except (KeyError, TypeError, ValueError):
        fi = DV.pick_file(view, str(body.get('src') or ''), phrases)
    f = files[fi]
    hits = DV.locate(f['blocks'], phrases)
    start, blocks, hits = DV.window(f['blocks'], hits)
    path = orig(fi)
    page = 0
    if path is not None and path.suffix.lower() == '.pdf' and phrases:
        try:
            page = DV.pdf_page(path, phrases[0])
        except Exception:                                  # noqa: BLE001 — нет страницы: откроется с начала
            page = 0
    note = ''
    if phrases and not any(h[3] == 0 for h in hits):
        note = 'Дословно эта фраза в тексте не нашлась (её могли сократить или собрать из двух строк) — показан документ целиком.'
    return jsonify({'name': f['name'], 'ext': f.get('ext') or '', 'files': [x['name'] for x in files], 'file': fi,
                    'blocks': blocks, 'start': start, 'total': len(f['blocks']), 'hits': hits,
                    'orig': path is not None, 'page': page, 'note': note})


@app.get('/api/docview/original')
def docview_original():
    """Оригинал документа (Word или PDF) с выделенными фразами: ?view=…|lib=…&file=номер&p=фраза&p=… (1.7.2)."""
    from io import BytesIO
    from engine import docview as DV
    body = {'view': request.args.get('view'), 'lib': request.args.get('lib')}
    view, orig, err = _doc_target(body)
    text = lambda m, code: (m, code, {'Content-Type': 'text/plain; charset=utf-8'})     # noqa: E731
    if err:
        return text(err, 404)
    try:
        fi = max(0, min(len(view['files']) - 1, int(request.args.get('file') or 0)))
    except ValueError:
        fi = 0
    path = orig(fi) if view['files'] else None
    if path is None:
        return text('Оригинал этого документа не сохранён: выделение в оригинале есть только у файлов Word и PDF.', 404)
    phrases = _doc_phrases(request.args.getlist('p'))
    stem = Path(view['files'][fi]['name']).stem[:80] or 'документ'
    try:
        if path.suffix.lower() == '.docx':
            data, _ = DV.docx_highlight(path, phrases)
            return send_file(BytesIO(data), as_attachment=True, download_name=f'{stem} — найдено.docx', mimetype=DOCX_MIME)
        data, _, _ = DV.pdf_highlight(path, phrases)
        return send_file(BytesIO(data), mimetype='application/pdf', download_name=f'{stem} — найдено.pdf')
    except Exception as e:                                 # noqa: BLE001 — повреждённый файл
        return text(f'Не удалось открыть оригинал: {e}', 500)


@app.post('/api/llm/embed_test')
def llm_embed_test():
    """Проверка модели поиска: связь, размер вектора, скорость (тексты документов не отправляются)."""
    from engine.llm_client import embed, side_cfg
    from engine.phrases import dot
    if not is_local_request():
        return jsonify({'ok': False, 'error': LOCAL_ONLY}), 403
    try:
        cfg = _form_llm(request.get_json(silent=True))
        model = side_cfg(cfg, 'embed')['model']
        t0 = time.time()
        a, b, c = embed(cfg, ['Бурение скважин на шельфе', 'Строительство морских скважин', 'Годовой бюджет на обучение'])
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    except LLMError as e:
        return jsonify({'ok': False, 'error': str(e)})
    n = lambda v: [x / ((sum(y * y for y in v) ** 0.5) or 1) for x in v]           # noqa: E731
    a, b, c = n(a), n(b), n(c)
    return jsonify({'ok': True, 'model': model, 'dims': len(a), 'seconds': round(time.time() - t0, 2),
                    'near': round(dot(a, b), 3), 'far': round(dot(a, c), 3)})


@app.post('/api/llm/vision_test')
def llm_vision_test():
    """Проверка модели, которая называет картинки: название встроенного снимка (или рисунка-образца)."""
    from engine import pictures as P
    from engine.llm_client import side_cfg, vision_name
    if not is_local_request():
        return jsonify({'ok': False, 'error': LOCAL_ONLY}), 403
    try:
        cfg = _form_llm(request.get_json(silent=True))
        model = side_cfg(cfg, 'vision')['model']
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    except LLMError as e:
        return jsonify({'ok': False, 'error': str(e)})
    ph = next((e for e in P.catalog() if e.get('photo')), None)
    src = Path(ph['path']) if ph else C.ASSETS / 'deco' / 'banner_goal.png'
    try:
        t0 = time.time()
        r = vision_name(cfg, P.vision_jpeg(src))
    except LLMError as e:
        return jsonify({'ok': False, 'error': str(e)})
    return jsonify({'ok': True, 'model': model, 'name': r['name'], 'tags': r['tags'], 'seconds': round(time.time() - t0, 1),
                    'sample': ph['name'] if ph else 'фирменная волна (рисунок оформления)',
                    'url': f'/api/photo/{ph["id"]}?w=360' if ph else ''})


@app.post('/api/llm/ping')
def llm_ping():
    """Пробный запрос к модели (загрузка, скорость, видеокарта/процессор). Облачная модель — только
    с согласием (галочка в окне настроек учитывается и до сохранения)."""
    if not is_local_request():
        return jsonify({'ok': False, 'error': LOCAL_ONLY}), 403
    try:
        cfg = _form_llm(request.get_json(silent=True))
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    try:
        return jsonify(ping_model(cfg))
    except LLMError as e:
        return jsonify({'ok': False, 'error': str(e)})


# --------------------------------------------------------------------------------------
# «🔎 Найти ИИ» (1.7): программы с моделями на этом компьютере, телефоне, других компьютерах сети
# --------------------------------------------------------------------------------------
def _current_ai(llm, found):
    """Работает ли модель из настроек: сервер отвечает, модель на нём есть. Облачная — не проверяется."""
    from engine import discover as D
    cur = {'provider': llm.get('provider'), 'base_url': llm.get('base_url'), 'model': llm.get('model'),
           'cloud': is_cloud(llm), 'reachable': None, 'has_model': None, 'name': ''}
    if cur['cloud'] or llm.get('provider') not in ('ollama', 'openai'):
        return cur
    try:
        u = urllib.parse.urlsplit(str(llm.get('base_url') or ''))
        host, port = (u.hostname or '').lower(), u.port or (443 if u.scheme == 'https' else 80)
    except ValueError:
        return dict(cur, reachable=False)
    local = host in ('localhost', '127.0.0.1', '::1')
    hit = next((f for f in found if f['port'] == port and (f['host'] == host or (local and f['host'] == D.LOCAL))), None)
    if hit is not None:
        names, name = [m['name'] for m in hit['models']], f"{hit['name']} · {hit['where']}"
        for f in found:
            f['current'] = f['id'] == hit['id']
    else:                                                # сервер на своём порту или в сети Компании — спросить, как при работе
        if not D.port_open(host, port, 1.5):
            return dict(cur, reachable=False)
        try:
            names = list_models(llm)
        except LLMError as e:
            return dict(cur, reachable=False, error=str(e))
        name = f"{PROVIDER[llm['provider']]['short']} · {D.THIS_PC if local else host}"
    model = str(llm.get('model') or '')
    has = model in names or (llm.get('provider') == 'ollama' and ':' not in model and model + ':latest' in names)
    return dict(cur, reachable=True, has_model=has, name=name, id=hit['id'] if hit else '')


@app.get('/api/ai/find')
def ai_find():
    """Поиск локальных моделей ИИ: этот компьютер; ?lan=1 — сеть /24 (телефон, другие компьютеры);
    ?host=адрес — одно устройство. Документы не отправляются: у серверов запрашивается только список моделей."""
    if not is_local_request():
        return jsonify({'error': LOCAL_ONLY}), 403
    from engine import discover as D
    s = load_settings()
    try:
        res = D.find(lan=request.args.get('lan') == '1', host=(request.args.get('host') or '').strip() or None,
                     allow_lan=s['admin'].get('allow_lan_scan', True) is not False)
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    res['current'] = _current_ai(llm_settings(), res['found'])
    return jsonify(res)


@app.post('/api/ai/start')
def ai_start():
    """Запустить сервер Ollama или LM Studio на этом компьютере (программа уже установлена)."""
    if not (is_local_request() and from_own_page()):
        return jsonify({'error': LOCAL_ONLY}), 403
    from engine import discover as D
    kind = str((request.get_json(silent=True) or {}).get('kind') or '')
    ok, msg = D.start(kind)
    return jsonify({'ok': ok, 'message': msg})


@app.route('/api/ai/pull', methods=['GET', 'POST'])
def ai_pull():
    """Скачать модель в Ollama (POST {base_url, model}) и ход скачивания (GET ?base_url=&model=).
    Адрес — только этот компьютер или частная сеть; модель скачивает сама Ollama."""
    if not (is_local_request() and from_own_page()):
        return jsonify({'error': LOCAL_ONLY}), 403
    from engine import discover as D
    body = request.get_json(silent=True) if request.method == 'POST' else request.args
    base, model = str((body or {}).get('base_url') or '').rstrip('/'), str((body or {}).get('model') or '').strip()
    u = urllib.parse.urlsplit(base)
    host = (u.hostname or '').lower()
    if u.scheme != 'http' or not (host == 'localhost' or D.is_private(host)) or not re.fullmatch(r'[\w.:/-]{1,100}', model) \
            or D.RX_CLOUD.search(model):
        return jsonify({'error': 'Скачать можно модель без «cloud» в имени и только в Ollama на этом компьютере или в вашей сети.'}), 400
    if request.method == 'GET':
        return jsonify(D.pull_state(base, model))
    return jsonify(D.pull(base, model))


# --------------------------------------------------------------------------------------
# Автопилот (1.7): папка «Входящие» → готовые проверенные презентации в «Готово»
# --------------------------------------------------------------------------------------
AUTO = {'thread': None, 'wake': threading.Event()}
AUTO_PERIOD = 15                                     # секунд между проверками папки


def _auto_folder(a=None):
    from engine.autopilot import folder_of
    return folder_of((a or load_settings()['autopilot']).get('folder'))


def _auto_analyze(mode):
    """План для автопилота — как у кнопки «Анализировать»: тот же режим и модели из настроек. Облачная модель
    без согласия (или под запретом) не вызывается: план строится по правилам, причина — в отчёте."""
    s = load_settings()
    opts = parse_options(json.dumps({'mode': mode}))
    llm, notes = None, []
    if opts['mode'] in ('ai', 'search'):
        llm = runtime_llm(s['llm'])
        refusal = cloud_refusal(llm) if opts['mode'] == 'ai' else None
        if refusal:
            opts['mode'], llm, notes = 'rules', None, [refusal + ' План построен по правилам.']
    if not llm and opts.get('example') != 'off' and s['llm'].get('embed_model'):
        opts['_embed'] = runtime_llm(s['llm'])

    def run(files):
        spec, warnings, info = engine.analyze(files, opts, llm)
        return spec, notes + warnings, info
    return run


def _auto_loop():
    from engine import autopilot as AP
    while True:
        a = load_settings()['autopilot']
        if not a.get('on'):
            break
        try:
            AP.process(_auto_folder(a), _auto_analyze(a.get('mode') or 'rules'), a.get('mode') or 'rules')
        except Exception as e:                       # noqa: BLE001 — фоновая проверка не падает
            AP.STATUS['error'] = f'{type(e).__name__}: {e}'
            app.logger.exception('autopilot failed')
        AUTO['wake'].wait(AUTO_PERIOD)
        AUTO['wake'].clear()
    AUTO['thread'] = None


def _auto_start():
    t = AUTO['thread']
    if t is not None and t.is_alive():
        AUTO['wake'].set()
        return
    AUTO['thread'] = threading.Thread(target=_auto_loop, daemon=True, name='autopilot')
    AUTO['thread'].start()


@app.get('/api/autopilot')
def autopilot_state():
    """Настройки автопилота и что лежит во «Входящих»: готово, в очереди, ошибка."""
    if not is_local_request():
        return jsonify({'error': LOCAL_ONLY}), 403
    from engine import autopilot as AP
    a = load_settings()['autopilot']
    folder = _auto_folder(a)
    return jsonify({**a, 'path': str(folder), 'default': str(AP.default_folder()), 'exists': folder.is_dir(),
                    'running': AP.STATUS['running'], 'current': AP.STATUS['current'], 'last': AP.STATUS['last'],
                    'error': AP.STATUS['error'], 'items': AP.listing(folder) if folder.is_dir() else []})


@app.post('/api/autopilot')
def autopilot_set():
    """{on, folder, mode} — включить или выключить, папка «Входящие», как строить план."""
    if not (is_local_request() and from_own_page()):
        return jsonify({'error': LOCAL_ONLY}), 403
    from engine import autopilot as AP
    body = request.get_json(silent=True) or {}
    s = load_settings()
    a = s['autopilot']
    if 'folder' in body:
        f = str(body.get('folder') or '').strip().strip('"')
        if f:
            p = AP.folder_of(f)
            if not p.is_absolute():
                return jsonify({'error': 'Укажите полный путь к папке, например C:\\Users\\Имя\\Documents\\Входящие.'}), 400
            try:
                AP.ensure(p)
            except OSError as e:
                return jsonify({'error': f'Папку не удалось открыть или создать: {e}'}), 400
        a['folder'] = f
    if body.get('mode') in AP.MODE_NAMES:
        a['mode'] = body['mode']
    if 'on' in body:
        a['on'] = bool(body['on'])
    save_settings(s)
    if a['on']:
        try:
            AP.ensure(_auto_folder(a))
        except OSError as e:
            return jsonify({'error': f'Папка «{_auto_folder(a)}» недоступна: {e}'}), 400
        _auto_start()
    return autopilot_state()


@app.post('/api/autopilot/run')
def autopilot_run():
    """«Обработать сейчас»: проход по «Входящим», не дожидаясь очередной проверки."""
    if not (is_local_request() and from_own_page()):
        return jsonify({'error': LOCAL_ONLY}), 403
    from engine import autopilot as AP
    a = load_settings()['autopilot']
    if a.get('on'):
        _auto_start()
    else:
        mode = a.get('mode') or 'rules'
        threading.Thread(target=AP.process, args=(_auto_folder(a), _auto_analyze(mode), mode), daemon=True).start()
    return jsonify({'ok': True})


@app.post('/api/autopilot/open')
def autopilot_open():
    """Открыть папку «Входящие» (или «Готово») в проводнике."""
    if not (is_local_request() and from_own_page()):
        return jsonify({'error': LOCAL_ONLY}), 403
    from engine import autopilot as AP
    try:
        p = AP.ensure(_auto_folder())
    except OSError as e:
        return jsonify({'ok': False, 'error': f'Папка недоступна: {e}'}), 400
    if (request.get_json(silent=True) or {}).get('done'):
        p = p / AP.DONE
    try:
        if os.name == 'nt':
            os.startfile(str(p))                         # noqa: S606 — своя папка, путь из настроек
        elif sys.platform == 'darwin':
            subprocess.Popen(['open', str(p)])
        elif shutil.which('xdg-open'):
            subprocess.Popen(['xdg-open', str(p)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            return jsonify({'ok': False, 'error': f'Откройте папку вручную: {p}'})
    except OSError as e:
        return jsonify({'ok': False, 'error': f'Не удалось открыть папку {p}: {e}'})
    return jsonify({'ok': True, 'path': str(p)})


@app.get('/api/autopilot/file')
def autopilot_file():
    """Готовый файл автопилота: ?key=…&kind=pptx | report | plan."""
    if not is_local_request():
        return jsonify({'error': LOCAL_ONLY}), 403
    from engine import autopilot as AP
    kind = request.args.get('kind') or ''
    p = AP.file_of(_auto_folder(), request.args.get('key') or '', kind)
    if p is None:
        return jsonify({'error': 'Файл не найден: возможно, его удалили из папки «Готово».'}), 404
    if kind == 'pptx':
        return send_file(p, as_attachment=True, download_name=p.name,
                         mimetype='application/vnd.openxmlformats-officedocument.presentationml.presentation')
    return send_file(p, mimetype='application/json' if kind == 'plan' else 'text/plain; charset=utf-8')


@app.errorhandler(413)
def too_big(_):
    return jsonify({'error': 'Файлы слишком большие (больше 60 МБ за раз).'}), 413


# --------------------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description='Конструктор презентаций (веб-приложение)')
    ap.add_argument('--server', action='store_true', help='доступ для коллег по сети (адрес 0.0.0.0)')
    ap.add_argument('--host', default=None, help='адрес (по умолчанию 127.0.0.1 — только этот компьютер)')
    ap.add_argument('--port', type=int, default=8050)
    ap.add_argument('--no-browser', action='store_true', help='не открывать браузер автоматически')
    ap.add_argument('--idle-exit', type=int, default=0, metavar='МИН',
                    help='выключиться через МИН минут без обращений (запуск ярлыком: start.pyw)')
    a = ap.parse_args()
    if a.idle_exit > 0:
        LAUNCHER.update(on=True, idle_min=a.idle_exit, last=time.time())
        threading.Thread(target=_idle_watchdog, daemon=True).start()
    clean_cache()
    from engine.nts.compact import compact_template
    threading.Thread(target=compact_template, daemon=True).start()    # облегчённый шаблон — заранее, в фоне
    host = a.host or ('0.0.0.0' if a.server else '127.0.0.1')
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    url = f'http://{"127.0.0.1" if host in ("0.0.0.0", "127.0.0.1") else host}:{a.port}'
    print(f'Конструктор презентаций {VERSION}')
    print(f'Откройте в браузере: {url}')
    if host == '0.0.0.0':
        import socket
        print(f'Коллегам в сети:      http://{socket.gethostname()}:{a.port}')
    if LAUNCHER['on']:
        print(f'Выключится сам через {LAUNCHER["idle_min"]} мин после закрытия последней вкладки (если не включён автопилот) '
              'или кнопкой выключения в шапке страницы')
    else:
        print('Остановить: Ctrl+C')
    if load_settings()['autopilot'].get('on'):
        _auto_start()
        print(f'Автопилот: папка «{_auto_folder()}»')
    if not a.no_browser and host in ('127.0.0.1', '0.0.0.0'):
        import webbrowser
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    try:
        from waitress import serve                    # промышленный сервер (если установлен)
        serve(app, host=host, port=a.port, threads=16, max_request_body_size=app.config['MAX_CONTENT_LENGTH'])
    except ImportError:
        app.run(host=host, port=a.port, threaded=True, debug=False)


if __name__ == '__main__':
    main()
