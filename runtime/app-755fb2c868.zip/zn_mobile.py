# -*- coding: utf-8 -*-
"""
zn_mobile.py — КОНСТРУКТОР В БРАУЗЕРЕ ТЕЛЕФОНА (Pyodide)
=======================================================

Тот же движок и то же веб-приложение (app.py), что в Windows-версии, но без сервера: Python работает
внутри страницы (Pyodide в фоновом потоке браузера — Web Worker), а запросы интерфейса к /api/…
передаются сюда напрямую, функцией handle(), через тестовый клиент Flask.

Что отличается от Windows и почему:
  * потоков нет — фоновые задания (анализ, справка) запускаются сразу после ответа на запрос,
    ход работы передаётся странице сообщениями (notify), а не опросом /api/job;
  * LibreOffice и PowerPoint на телефоне нет — картинки слайдов рисует сама страница из облегчённой
    презентации (/api/m/preview_deck), а не из PDF;
  * сеть — только через браузер: запросы к модели ИИ идут синхронным XMLHttpRequest (в Web Worker
    это разрешено); сервер модели должен разрешать запросы со страниц (CORS);
  * папка output — в хранилище браузера (IndexedDB), её сохраняет worker.js после каждого изменения.
"""
import io
import json
import os
import sys
import threading
import time

ROOT = '/app'
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# --------------------------------------------------------------------------------------
# Потоки: start() откладывает задание до конца текущего запроса (run_pending)
# --------------------------------------------------------------------------------------
PENDING = []


def _start(self):
    if isinstance(self, threading.Timer):      # таймеры (выключение сервера) на телефоне не нужны
        return
    PENDING.append(self)


threading.Thread.start = _start

NOTIFY = None                                    # функция страницы: notify(json_строка)


def set_notify(fn):
    global NOTIFY
    NOTIFY = fn


def _post(kind, **data):
    if NOTIFY is not None:
        try:
            NOTIFY(json.dumps(dict(data, kind=kind), ensure_ascii=False, default=str))
        except Exception:                        # noqa: BLE001 — страница закрыта, сообщение не важно
            pass


def run_pending():
    """Выполняет отложенные задания по очереди. Возвращает их число."""
    n = 0
    while PENDING:
        t = PENDING.pop(0)
        n += 1
        job = getattr(getattr(t, '_target', None), '__self__', None)     # Thread.run() удаляет _target
        try:
            t.run()
        finally:
            if job is not None and hasattr(job, 'view'):
                _post('jobdone', job=job.id, view=job.view())
    return n


# --------------------------------------------------------------------------------------
# Сеть: запросы к модели ИИ — синхронный XMLHttpRequest
# --------------------------------------------------------------------------------------
class _XhrResponse(io.BytesIO):
    def __init__(self, data, status, headers, url):
        super().__init__(data)
        self.status = self.code = status
        self.headers = headers
        self.url = url

    def getcode(self):
        return self.status

    def info(self):
        return self.headers

    def __iter__(self):                          # построчно, как ответ urllib (потоковые ответы)
        return iter(self.getvalue().splitlines(True))


def _xhr_open(cfg, req, timeout):
    import email.message
    import urllib.error
    from engine import llm_client as L
    from js import Uint8Array, XMLHttpRequest
    from pyodide.ffi import to_js

    url = req.full_url
    if L._host(url) == 'browser.local':          # встроенная модель: считает сама страница (WebGPU)
        return _local_llm(cfg, req, url)
    xhr = XMLHttpRequest.new()
    xhr.open(req.get_method(), url, False)
    try:
        xhr.timeout = int(max(5, float(timeout or 60)) * 1000)
    except Exception:                            # noqa: BLE001 — старые браузеры: без предела
        pass
    xhr.responseType = 'arraybuffer'
    for k, v in req.header_items():
        if k.lower() in ('content-length', 'host', 'connection', 'user-agent', 'accept-encoding'):
            continue
        try:
            xhr.setRequestHeader(k, v)
        except Exception:                        # noqa: BLE001
            pass
    if 'api.anthropic.com' in url:               # Anthropic разрешает запросы со страниц только так
        xhr.setRequestHeader('anthropic-dangerous-direct-browser-access', 'true')
    body = req.data
    try:
        if body is None:
            xhr.send()
        else:
            xhr.send(to_js(bytes(body)))
    except Exception as e:                       # noqa: BLE001
        msg = str(e)
        if 'timeout' in msg.lower() or 'TimeoutError' in msg:
            raise L._timeout_error(cfg)
        raise L.LLMError(_blocked(url))
    status = int(xhr.status or 0)
    if status == 0:
        raise L.LLMError(_blocked(url))
    data = bytes(Uint8Array.new(xhr.response).to_py()) if xhr.response else b''
    hdrs = email.message.Message()
    for line in str(xhr.getAllResponseHeaders() or '').split('\r\n'):
        if ':' in line:
            k, v = line.split(':', 1)
            hdrs[k.strip()] = v.strip()
    if status >= 400:
        raise L._http_error(cfg, urllib.error.HTTPError(url, status, str(xhr.statusText or ''), hdrs,
                                                        io.BytesIO(data)))
    return _XhrResponse(data, status, hdrs, url)


def _local_llm(cfg, req, url):
    import email.message
    import urllib.error
    from engine import llm_client as L
    import js
    from pyodide.ffi import to_js
    hdrs_in = json.dumps({k: v for k, v in req.header_items()})
    body = to_js(bytes(req.data)) if req.data is not None else None
    r = js.znLLM(req.get_method(), url, hdrs_in, body)
    status = int(r.status or 0)
    if status == 0:
        raise L.LLMError(str(getattr(r, 'error', '') or 'встроенная модель недоступна'))
    data = bytes(r.body.to_py())
    hdrs = email.message.Message()
    hdrs['Content-Type'] = str(r.ctype)
    if status >= 400:
        raise L._http_error(cfg, urllib.error.HTTPError(url, status, 'error', hdrs, io.BytesIO(data)))
    return _XhrResponse(data, status, hdrs, url)


def _blocked(url):
    from engine import llm_client as L
    host = L._host(url)
    return (f'нет связи с {host}: сервер недоступен с телефона или не разрешает запросы со страниц браузера '
            f'(CORS). Для Ollama на компьютере в сети: запустите её с переменными OLLAMA_HOST=0.0.0.0 и '
            f'OLLAMA_ORIGINS=*, а страницу конструктора откройте по http (не https). Облачные сервисы, которые '
            f'не принимают запросы из браузера, подключайте через шлюз Компании.')


# --------------------------------------------------------------------------------------
# Запуск приложения
# --------------------------------------------------------------------------------------
os.chdir(ROOT)
os.environ.setdefault('ZN_NO_POWERPOINT', '1')
import app as A  # noqa: E402
import engine  # noqa: E402
from engine import llm_client as _L  # noqa: E402
from engine.nts import compact as _compact  # noqa: E402
from engine.nts import config as _C  # noqa: E402

A.SETTINGS_FILE = A.ROOT / 'output' / 'settings.json'        # настройки — в хранилище браузера
_L.DEFAULTS['model'] = ''                        # модель ИИ на телефоне не выбрана, пока её не подключат
# вспомогательные модели (1.7: поиск по смыслу и названия картинок) по умолчанию смотрят на localhost:11434 —
# на телефоне там ничего нет: пусто, пока их не подключат в «Модель ИИ»
for _k in ('embed_model', 'vision_model'):
    if _k in _L.DEFAULTS:
        _L.DEFAULTS[_k] = ''
A.SOFFICE, A.POWERPOINT = None, False
_L._open = _xhr_open
# встроенная модель ИИ (в самом телефоне, WebGPU) — ещё один «локальный сервер» в списке
if 'browser' not in _L.PROVIDER:
    _bp = _L._p('browser', 'Встроенная модель (в самом телефоне)', 'Встроенная', 'local', 'http://browser.local/v1',
                'Qwen3-1.7B-q4f16_1-MLC', ['Qwen3-1.7B-q4f16_1-MLC', 'Qwen3-4B-q4f16_1-MLC', 'Qwen3-0.6B-q4f16_1-MLC'],
                'работает на видеочипе телефона, без интернета', auth='none')
    _L.PROVIDERS.append(_bp)
    _L.PROVIDER['browser'] = _bp

# шаблон в сборке для телефона уже облегчён (картинки уменьшены заранее, tools/build_web.py)
_orig_compact = _compact.compact_template


def _compact_template(path=_C.TEMPLATE):
    from pathlib import Path
    if Path(path) == Path(_C.TEMPLATE):
        return Path(path)
    return _orig_compact(path)


_compact.compact_template = _compact_template
import engine.render as _R  # noqa: E402
_R.compact_template = _compact_template
try:
    import engine.templates as _T  # noqa: E402,F401
except Exception:                                # noqa: BLE001
    pass

# ход работы заданий — сразу на страницу
_orig_progress = A.Job.on_progress


def _on_progress(self, e):
    _orig_progress(self, e)
    _post('progress', job=self.id, view=self.view())


A.Job.on_progress = _on_progress

# статус: что умеет телефонная версия
_orig_status = A.app.view_functions['status']


def _status():
    r = _orig_status()
    d = r.get_json()
    d.update(mobile=True, thumbs=True, preview='browser', can_configure=True, launcher=False, windows=False)
    return A.jsonify(d)


A.app.view_functions['status'] = _status
A.is_local_request = lambda: True                # настройки ИИ — свои у каждого телефона

# Что на телефоне не работает (1.7): автопилот следит за папкой компьютера в бесконечном цикле, «Найти ИИ»
# перебирает адреса сети и запускает программы — в браузере это невозможно, а движок бы завис.
def _not_on_phone(*a, **k):
    return A.jsonify({'error': 'На телефоне это недоступно: работает только в Windows-версии.'}), 501


for _rule in list(A.app.url_map.iter_rules()):
    if str(_rule.rule).startswith(('/api/autopilot', '/api/ai/')):
        A.app.view_functions[_rule.endpoint] = _not_on_phone


# --------------------------------------------------------------------------------------
# Дополнительные запросы телефонной версии
# --------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------
# Облегчённые картинки для просмотра слайдов на телефоне
# --------------------------------------------------------------------------------------
PREVIEW_W = 1280                                 # наибольшая сторона картинки в просмотре (в .pptx — исходная)
_LIGHT = {}


def _light_dirs():
    from pathlib import Path
    return Path(ROOT) / 'preview_media', Path(ROOT) / 'output' / '.preview_media'


def light_image(data):
    """PNG/JPEG больше PREVIEW_W точек → уменьшенная копия того же формата; иначе None.
    Фон шаблона 3840×2160 в памяти телефона — 33 МБ, уменьшенный — 3,7 МБ."""
    from PIL import Image
    try:
        im = Image.open(io.BytesIO(data))
        if max(im.size) <= PREVIEW_W or im.format not in ('PNG', 'JPEG'):
            return None
        fmt, k = im.format, PREVIEW_W / max(im.size)
        im = im.resize((max(1, round(im.width * k)), max(1, round(im.height * k))), Image.BILINEAR)
        out = io.BytesIO()
        if fmt == 'PNG':
            im.save(out, 'PNG', compress_level=3)
        else:
            (im if im.mode in ('RGB', 'L') else im.convert('RGB')).save(out, 'JPEG', quality=85)
        return out.getvalue()
    except Exception:                            # noqa: BLE001 — картинка остаётся как есть
        return None


def _light_key(data):
    import zlib
    return '%08x%x' % (zlib.crc32(data) & 0xffffffff, len(data))


def _light(data):
    key = _light_key(data)
    if key in _LIGHT:
        return _LIGHT[key] or data
    built, saved = _light_dirs()
    out = None
    for d in (built, saved):
        f = d / key
        if f.exists():
            out = f.read_bytes()
            break
    else:
        out = light_image(data)
        if out:
            try:
                saved.mkdir(parents=True, exist_ok=True)
                (saved / key).write_bytes(out)
            except OSError:
                pass
    if len(_LIGHT) > 400:
        _LIGHT.clear()
    _LIGHT[key] = out if out and len(out) < len(data) * 1.5 else None
    return _LIGHT[key] or data


def lighten_pptx(data):
    """Копия презентации с уменьшенными картинками — для просмотра в браузере."""
    import zipfile
    src = zipfile.ZipFile(io.BytesIO(data))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED, compresslevel=1) as z:
        for info in src.infolist():
            d = src.read(info.filename)
            media = info.filename.startswith('ppt/media/')
            if media and len(d) > 20000 and info.filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                d = _light(d)
            z.writestr(info.filename, d, compress_type=zipfile.ZIP_STORED if media else zipfile.ZIP_DEFLATED)
    return buf.getvalue()


@A.app.post('/api/m/preview_deck')
def m_preview_deck():
    """Облегчённая презентация для просмотра на телефоне: {"slides": [...], "meta": {...}, "number": 1} →
    .pptx (слайды, как в итоговой презентации) и заголовок X-Starts — номера первых страниц слайдов."""
    import tempfile
    from pathlib import Path
    body = A.request.get_json(silent=True) or {}
    slides = body.get('slides')
    if not isinstance(slides, list) or not slides or len(slides) > 80:
        return A.jsonify({'error': 'Нужен список слайдов.'}), 400
    meta = body.get('meta') if isinstance(body.get('meta'), dict) else {}
    try:
        number = max(1, min(300, int(body.get('number') or 1)))
    except (TypeError, ValueError):
        number = 1
    slides = [{k: v for k, v in s.items() if k not in ('alts', 'remarks')} if isinstance(s, dict) else s
              for s in slides]
    tmp = Path(tempfile.mkdtemp(prefix='zn_m_prev_'))
    try:
        path, starts = engine.build_preview_deck(slides, tmp / 'preview.pptx', meta, number=number, pad_hidden=False)
        data = lighten_pptx(Path(path).read_bytes())
    except Exception as e:                       # noqa: BLE001
        A.app.logger.exception('preview_deck')
        return A.jsonify({'error': f'Не удалось подготовить слайды: {type(e).__name__}: {e}'}), 500
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    resp = A.send_file(io.BytesIO(data), mimetype='application/vnd.openxmlformats-officedocument.'
                                                    'presentationml.presentation', download_name='preview.pptx')
    resp.headers['X-Starts'] = json.dumps(starts)
    return resp


@A.app.get('/api/m/template_deck/<tid>')
def m_template_deck(tid):
    """Образцы шаблона (титул, слайд, раздел, финал) — презентацией: страница рисует их сама,
    вместо картинок LibreOffice (A.template_previews)."""
    import shutil
    import tempfile
    from pathlib import Path
    if not engine.templates.get(tid):
        return A.jsonify({'error': 'Шаблон не найден.'}), 404
    tmp = Path(tempfile.mkdtemp(prefix='zn_m_tpl_'))
    try:
        spec = {'meta': {'title': 'Название презентации', 'subtitle': 'Подзаголовок презентации',
                         'event': 'Мероприятие · дата', 'template': tid, 'animations': False},
                'slides': A.TPL_SAMPLE}
        path, _, _ = engine.build(spec, tmp / 'sample.pptx')
        data = lighten_pptx(Path(path).read_bytes())
    except Exception as e:                       # noqa: BLE001
        A.app.logger.exception('template_deck')
        return A.jsonify({'error': f'Не удалось построить образцы: {type(e).__name__}: {e}'}), 500
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return A.send_file(io.BytesIO(data), mimetype='application/octet-stream', download_name='sample.pptx')


# --------------------------------------------------------------------------------------
# Встроенные фотографии (1.7). В сборке для телефона у движка только каталог, а сами снимки лежат на сайте
# (photos/<id>.jpg): первый запуск не скачивает 60 МБ. Снимок берётся с сайта, когда он нужен: заранее —
# worker.js (по id в запросе), а если не успел — здесь, синхронным запросом (в Web Worker это разрешено).
# Пока снимка нет, на его месте пустой файл: так каталог движка видит фото (проверка «файл есть»).
# --------------------------------------------------------------------------------------
SITE_URL = ''                                    # адрес сайта, задаёт worker.js (set_site)


def set_site(url):
    global SITE_URL
    SITE_URL = str(url or '')


def _photo_placeholders():
    from pathlib import Path
    try:
        from engine import pictures as P
        raw = json.loads(P.PHOTO_CATALOG.read_text(encoding='utf-8'))
    except Exception:                            # noqa: BLE001 — нет каталога (старая версия): нечего делать
        return
    for e in raw if isinstance(raw, list) else []:
        if isinstance(e, dict) and P.PHOTO_RX.fullmatch(str(e.get('id') or '')):
            f = P.PHOTO_DIR / str(e.get('file') or f'photos/{e["id"]}.jpg')
            if not f.exists():
                f.parent.mkdir(parents=True, exist_ok=True)
                f.write_bytes(b'')


def ensure_photo(path):
    """Снимок на диске движка: пустая заглушка → скачать с сайта. True — файл готов."""
    from pathlib import Path
    p = Path(str(path))
    try:
        if p.stat().st_size > 0:
            return True
    except OSError:
        return False                             # не встроенное фото — не наше дело
    if not SITE_URL:
        return False
    try:
        from js import Uint8Array, XMLHttpRequest
        xhr = XMLHttpRequest.new()
        xhr.open('GET', SITE_URL + 'photos/' + p.name, False)
        xhr.responseType = 'arraybuffer'
        xhr.send()
        if int(xhr.status or 0) != 200 or not xhr.response:
            return False
        data = bytes(Uint8Array.new(xhr.response).to_py())
    except Exception:                            # noqa: BLE001 — нет сети
        return False
    if not data:
        return False
    tmp = p.with_name(p.name + '.part')
    tmp.write_bytes(data)
    tmp.replace(p)
    return True


def _patch_photos():
    try:
        from engine import pictures as P
    except Exception:                            # noqa: BLE001
        return
    if not hasattr(P, 'PHOTO_DIR'):
        return
    _photo_placeholders()
    builtin = P.PHOTO_DIR.resolve()

    def ours(path):
        try:
            return path and P.Path(str(path)).resolve().is_relative_to(builtin)
        except (OSError, ValueError):
            return False

    orig_resolve, orig_photo_path, orig_thumb = P.resolve, P.photo_path, P.thumb

    def resolve(im):
        r = orig_resolve(im)
        if r and r.get('path') and ours(r['path']) and not ensure_photo(r['path']):
            return None                          # нет сети, а снимок ещё не скачан — как будто файла нет
        return r

    def photo_path(pid):
        p = orig_photo_path(pid)
        return p if (p is None or not ours(p) or ensure_photo(p)) else None

    def thumb(path, width=360):
        if ours(path) and not ensure_photo(path):
            raise OSError('снимок ещё не скачан')
        return orig_thumb(path, width)

    P.resolve, P.photo_path, P.thumb = resolve, photo_path, thumb
    if hasattr(P, 'vision_jpeg'):
        orig_vj = P.vision_jpeg

        def vision_jpeg(path, *a, **k):
            if ours(path):
                ensure_photo(path)
            return orig_vj(path, *a, **k)
        P.vision_jpeg = vision_jpeg


_patch_photos()


# --------------------------------------------------------------------------------------
# Обработка запроса страницы
# --------------------------------------------------------------------------------------
_CLIENT = A.app.test_client()


def handle(method, path, headers_json, body):
    """Запрос интерфейса → (код, заголовки JSON, байты ответа)."""
    headers = json.loads(headers_json or '{}')
    data = None
    if body is not None:
        data = bytes(body.to_py() if hasattr(body, 'to_py') else body)
    try:
        resp = _CLIENT.open(path, method=method, headers=headers, data=data)
        out = resp.get_data()
        hdr = {k: v for k, v in resp.headers.items()}
        status = resp.status_code
        resp.close()
    except Exception as e:                       # noqa: BLE001 — ответ всегда понятный
        A.app.logger.exception('mobile handle')
        status, hdr = 500, {'Content-Type': 'application/json'}
        out = json.dumps({'error': f'Ошибка: {type(e).__name__}: {e}'}, ensure_ascii=False).encode('utf-8')
    return status, json.dumps(hdr), out


def warmup():
    """Подготовка заранее, пока человек выбирает файлы: импорт тяжёлых модулей."""
    t = time.time()
    import pptx  # noqa: F401
    import docx  # noqa: F401
    import openpyxl  # noqa: F401
    import engine.layouts  # noqa: F401
    return round(time.time() - t, 2)
