# -*- coding: utf-8 -*-
"""
extra.py — ДОПОЛНИТЕЛЬНЫЕ СХЕМЫ (версия 1.4): SWOT, «рыбья кость», план-график (Гант),
матрица рисков, айсберг, пазл, весы, чек-лист, главная цифра, «было → стало», лепестки,
извилистый путь, ментальная карта, «факторы → результат»
=====================================================================================

Типы схем взяты из открытых каталогов бесплатных шаблонов презентаций (PresentationGO,
SlideModel Free, Slidesgo Infographics, категории SmartArt): это самые частые деловые
диаграммы, которых не было в конструкторе. Сами файлы шаблонов не копировались (их лицензии
запрещают распространение): каждая схема нарисована заново стандартными фигурами
PowerPoint в фирменной палитре — градиенты синий → зелёный (pair), мягкие тени, крупные
полупрозрачные номера, текст подгоняется по метрикам шрифтов.

Формат данных — как у остальных схем: items [{'title', 'text', 'icon', 'value', 'unit', 'label'}],
center — центральная фраза. Особые поля:
  gantt     — label: срок («2026», «I кв. 2026», «март–май 2027», «2026–2028»);
  risk      — prob / impact: вероятность и последствия (1–3 или «высокая/средняя/низкая»;
              можно и словами в тексте: «вероятность высокая, последствия средние»);
  checklist — label: статус («выполнено», «в работе», «план»; иначе — по словам в тексте);
  iceberg   — visible: сколько первых элементов «над водой» (по умолчанию 1–2);
  balance, shift — как у «Сравнения»: left/right = {'title', 'items'}.
"""
import math
import re

from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Pt

from ..nts import config as C
from ..nts.config import CARD, LGRAY, PALEG, PALEG2, SOFT, rgb
from ..nts.effects import alpha_fill, glow, grad, set_av, shadow, text_alpha
from ..nts.shapes import circ_icon, freeform, grect, group, icon, line, rect, shape_text, text
from ..textfit import clip, text_height
from ..textutil import parse_number
from .base import (BLUE, DBLUE, DGREEN, GRAY, GREEN, LGREEN, NAVY, WHITE, common_size, conclusion, content_slide,
                   pair)

MIDBLUE = rgb('2E95C4')
SAFE = 0.85     # запас по ширине для крупных надписей в фигурах (если на компьютере нет фирменного шрифта)


def _tt(it):
    return it.get('title') or '', it.get('text') or ''


def _P(t):
    """Строка с переводами строк → список абзацев (в одном фрагменте PowerPoint «\\n» не переносит)."""
    return t.split('\n') if isinstance(t, str) and '\n' in t else t


def grad_alpha(shape, c1, c2, angle, a1, a2):
    """Градиент c1 → c2 с прозрачностью: a1, a2 — непрозрачность концов, %."""
    grad(shape, c1, c2, angle)
    from lxml import etree
    from pptx.oxml.ns import qn
    gs = shape._element.spPr.find(qn('a:gradFill')).find(qn('a:gsLst'))
    for g_, a in zip(gs, (a1, a2)):
        clr = g_.find(qn('a:srgbClr'))
        if clr is not None:
            etree.SubElement(clr, qn('a:alpha')).set('val', str(int(a * 1000)))
    return shape


def _bullets(t, limit=5):
    """«причина 1; причина 2» или строки → список пунктов."""
    parts = [p.strip(' .;—-') for p in re.split(r'[;\n]|\s•\s', t or '') if p.strip(' .;—-')]
    return parts[:limit]


def _mix(c1, c2, f):
    """Цвет между c1 и c2 (f = 0 → c1, 1 → c2)."""
    from pptx.dml.color import RGBColor
    return RGBColor(*[int(round(a + (b - a) * f)) for a, b in zip(c1, c2)])


def _block(g, x, y, w, h, title, body, ts, xs, tcol=NAVY, bcol=GRAY, align=PP_ALIGN.LEFT, t_lines=2):
    """Заголовок + текст в рамке w×h (кегли заданы). Возвращает занятую высоту."""
    yy = y
    if title:
        tt = clip(title, w, h, ts, 'mj', t_lines)
        th = text_height(tt, w, ts, 'mj')
        text(g, x, yy, w, th + 0.04, tt, size=ts, color=tcol, font='mj', align=align)
        yy += th + 0.05
    if body and h - (yy - y) > 0.2:
        bt = clip(body, w, h - (yy - y), xs, 'mn')
        bh = text_height(bt, w, xs, 'mn')
        text(g, x, yy, w, bh + 0.05, bt, size=xs, color=bcol, align=align)
        yy += bh
    return yy - y


def _block_h(w, h, title, body, ts, xs, t_lines=2):
    th = text_height(clip(title, w, h, ts, 'mj', t_lines), w, ts, 'mj') + 0.05 if title else 0
    bh = text_height(clip(body, w, max(0.2, h - th), xs, 'mn'), w, xs, 'mn') if body else 0
    return th + bh


def _side_labels(ctx, sl, items, idx, anchors, x, w, top, bottom, align, delay=400):
    """Подписи элементов idx в колонке x..x+w, привязанные по высоте к точкам anchors
    (y-центры); от подписи к точке — пунктирная выноска."""
    if not idx:
        return
    n = len(idx)
    avail = (bottom - top) / max(n, 1)
    titles = [_tt(items[i])[0] for i in idx]
    texts = [_tt(items[i])[1] for i in idx]
    ts = common_size(titles, w - 0.5, 0.5, 16 if n <= 3 else 14, 10.5, 'mj', max_lines=2) if any(titles) else 12
    xs = common_size(texts, w - 0.5, max(0.3, avail - 0.55), 13 if n <= 3 else 12, 9.5, 'mn') if any(texts) else 11
    order = sorted(range(n), key=lambda k: anchors[k][1])
    ys = []
    for k in order:
        bh = _block_h(w - 0.5, avail - 0.05, titles[k], texts[k], ts, xs)
        y = anchors[k][1] - bh / 2
        y = max(top if not ys else ys[-1][1] + 0.08, y)
        ys.append((k, y + bh, y, bh))
    # если вылезли за низ — сдвигаем вверх
    over = ys[-1][1] - bottom if ys else 0
    if over > 0:
        ys = [(k, e - over, y - over, bh) for k, e, y, bh in ys]
    for k, _, y, bh in ys:
        i = idx[k]
        c1, c2 = pair(i, len(items))
        g = group(sl)
        nx = x if align == PP_ALIGN.LEFT else x + w - 0.36
        b = rect(g, nx, y + 0.02, 0.36, 0.36, fill=c1, shape=MSO_SHAPE.OVAL)
        grad(b, c1, c2, 45)
        shape_text(b, str(i + 1), size=11, color=WHITE, font='b', margins=(0, 0, 0, 0))
        tx = x + 0.48 if align == PP_ALIGN.LEFT else x
        _block(g, tx, y, w - 0.5, bh + 0.1, titles[k], texts[k], ts, xs, align=align)
        ax, ay = anchors[k]
        lx = x - 0.05 if align == PP_ALIGN.LEFT else x + w + 0.05
        line(g, lx, y + 0.2, ax, ay, color=c1, w=1.0, head=False, dash='sysDot')
        ctx.anim(sl, g, 'fade', delay + i * 150, 400)


# ======================================================================================
# SWOT: сильные и слабые стороны, возможности, угрозы
# ======================================================================================
SWOT_KEYS = [('S', r'сильн|strength|преимуществ'), ('W', r'слаб|weak|недостат'),
             ('O', r'возможн|opportun|перспектив'), ('T', r'угроз|threat|риск')]
SWOT_COLORS = {'S': (DGREEN, GREEN), 'W': (NAVY, DBLUE), 'O': (GREEN, LGREEN), 'T': (BLUE, MIDBLUE)}
SWOT_NAMES = {'S': 'Сильные стороны', 'W': 'Слабые стороны', 'O': 'Возможности', 'T': 'Угрозы'}


def swot_order(items):
    """Элементы SWOT по буквам S, W, O, T (по словам в заголовках; иначе — как даны)."""
    found = {}
    for it in items:
        t = (it.get('title') or '').lower()
        for k, rx in SWOT_KEYS:
            if k not in found and re.search(rx, t):
                found[k] = it
                break
    if len(found) == 4:
        return [(k, found[k]) for k in 'SWOT']
    return list(zip('SWOT', items[:4]))


def swot_ok(items):
    """Четыре элемента, и по заголовкам понятно, где S, W, O и T."""
    if len(items) != 4:
        return False
    found = set()
    for it in items:
        tl = (it.get('title') or '').lower()
        found |= {k for k, rx in SWOT_KEYS if re.search(rx, tl)}
    return found == set('SWOT')


def render_swot(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    pairs = swot_order(s['items'])
    gap = 0.16
    qw = (C.CW - gap) / 2
    qh = (bottom - top - gap) / 2
    cx, cy = C.L + qw + gap / 2, top + qh + gap / 2
    rc = min(0.62, qh * 0.32)
    lw = 0.95                                          # колонка буквы
    inset = rc + 0.1 - gap / 2 + 0.15                  # у внутреннего угла — центральный круг
    bodies = []
    for k, it in pairs:
        title = it.get('title') or SWOT_NAMES[k]
        bodies.append((title, _bullets(it.get('text') or '') or [it.get('text') or '']))
    tw = qw - lw - 0.3 - inset
    ts = common_size([b[0] for b in bodies], tw, 0.45, 19, 13, 'mj', max_lines=1)
    xs = common_size(['\n'.join('• ' + p for p in b[1]) for b in bodies], tw, qh - 0.85, 15, 10, 'mn')
    for i, (k, it) in enumerate(pairs):
        r, c = divmod(i, 2)
        x = C.L + c * (qw + gap)
        y = top + r * (qh + gap)
        c1, c2 = SWOT_COLORS[k]
        g = group(sl)
        bg = rect(g, x, y, qw, qh, fill=PALEG if k in 'SO' else SOFT, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.07)
        shadow(bg, 10, 3, 16)
        side = grect(g, x if c == 0 else x + qw - lw, y, lw, qh, c1, c2, 90, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
        set_av(side, {'adj': 16000})
        sq = rect(g, x + lw - 0.25 if c == 0 else x + qw - lw, y, 0.25, qh, fill=c1)   # прямой внутренний край
        grad(sq, c1, c2, 90)
        lx = x if c == 0 else x + qw - lw
        text(g, lx, y + 0.12, lw, 1.0, k, size=54, color=WHITE, font='b', align=PP_ALIGN.CENTER)
        icon(g, it.get('icon') or 'TbBulb', 'w', lx + (lw - 0.42) / 2, y + qh - 0.62, 0.42)
        tx = x + lw + 0.3 if c == 0 else x + inset
        title, pts = bodies[i]
        text(g, tx, y + 0.18, tw, 0.5, clip(title, tw, 0.45, ts, 'mj', 1), size=ts, color=c1, font='mj',
             align=PP_ALIGN.LEFT)
        body = [[('• ', {'color': c2, 'font': 'b'}), (p, {})] for p in pts] if len(pts) > 1 else \
            clip(pts[0] if pts else '', tw, qh - 0.85, xs, 'mn')
        if len(pts) > 1:
            plain = '\n'.join('• ' + p for p in pts)
            if clip(plain, tw, qh - 0.85, xs, 'mn') != plain:
                body = _P(clip(plain, tw, qh - 0.85, xs, 'mn'))
        text(g, tx, y + 0.72, tw, qh - 0.85, body, size=xs, color=GRAY, space_after=3)
        ctx.anim(sl, g, 'zoom', 150 + i * 170, 450)
    gc = group(sl)
    halo = rect(gc, cx - rc - 0.1, cy - rc - 0.1, 2 * rc + 0.2, 2 * rc + 0.2, fill=WHITE, shape=MSO_SHAPE.OVAL)
    shadow(halo, 12, 3, 25)
    core = rect(gc, cx - rc, cy - rc, 2 * rc, 2 * rc, fill=NAVY, shape=MSO_SHAPE.OVAL)
    grad(core, NAVY, BLUE, 45)
    shape_text(core, 'SWOT', size=20 if rc > 0.6 else 16, color=WHITE, font='b', margins=(0, 0, 0, 0))
    ctx.anim(sl, gc, 'zoom', 0, 500)
    conclusion(ctx, sl, s, 900)
    return sl


# ======================================================================================
# «РЫБЬЯ КОСТЬ» (диаграмма Исикавы): причины → следствие
# ======================================================================================
def render_fishbone(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:6]
    n = len(items)
    effect = s.get('center') or s.get('title') or ''
    head_w = 2.6
    spine_y = (top + bottom) / 2
    hx = C.R - head_w
    # голова — следствие
    gh = group(sl)
    hb = grect(gh, hx, spine_y - 0.85, head_w, 1.7, NAVY, BLUE, 0, shape=MSO_SHAPE.PENTAGON)
    set_av(hb, {'adj': 30000})
    shadow(hb, 12, 3, 24)
    es = common_size([effect], (head_w - 0.75) * SAFE, 1.45, 17, 10.5, 'mj')
    text(gh, hx + 0.15, spine_y - 0.75, head_w - 0.75, 1.5, clip(effect, (head_w - 0.75) * SAFE, 1.45, es, 'mj'), size=es,
         color=WHITE, font='mj', anchor=MSO_ANCHOR.MIDDLE)
    ctx.anim(sl, gh, 'zoom', 0, 500)
    # хребет
    gs = group(sl)
    sp = rect(gs, C.L, spine_y - 0.06, hx - C.L + 0.05, 0.12, fill=NAVY)
    grad(sp, LGRAY, NAVY, 0)
    ctx.anim(sl, gs, 'wipe_l', 200, 700)
    k = -(-n // 2)                                     # костей на сторону
    colw = (hx - C.L - 0.2) / k
    pill_h = 0.5
    titles = [_tt(it)[0] for it in items]
    causes = [_bullets(_tt(it)[1], 4) for it in items]
    ts = common_size(titles, colw - 0.3, pill_h - 0.06, 15, 10, 'mj', max_lines=1)
    zone = spine_y - top - pill_h - 0.35
    maxc = max([len(c) for c in causes] + [1])
    rib_h = zone / maxc
    xs = common_size([c for cs in causes for c in cs], colw - 0.7, min(0.62, rib_h - 0.04), 13, 9, 'mn',
                     max_lines=2) if any(causes) else 11
    for i, it in enumerate(items):
        up = i % 2 == 0
        col = i // 2
        x0 = C.L + 0.1 + col * colw
        c1, c2 = pair(i, n)
        g = group(sl)
        bx_far, bx_near = x0 + colw * 0.55, x0 + colw * 0.97    # кость: от плашки к хребту, наклон к голове
        py = top if up else bottom - pill_h
        pill = grect(g, x0 + 0.05, py, colw - 0.25, pill_h, c1, c2, 0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
        set_av(pill, {'adj': 50000})
        shadow(pill, 8, 2, 20)
        shape_text(pill, clip(titles[i] or f'Фактор {i + 1}', colw - 0.5, pill_h, ts, 'mj', 1), size=ts, color=WHITE,
                   font='mj', margins=(0.1, 0, 0.1, 0))
        y_far = py + pill_h if up else py
        line(g, bx_far, y_far, bx_near, spine_y, color=c1, w=2.5, head=False)
        # рёбра-причины: короткие горизонтальные линии от кости к хвосту, текст слева от них
        for j, cz in enumerate(causes[i]):
            t = (j + 0.6) / (len(causes[i]) + 0.2)
            yy = y_far + (spine_y - y_far) * t
            bxx = bx_far + (bx_near - bx_far) * t
            left = max(C.L, bxx - colw + 0.25)          # текст — до соседней кости слева
            lw_ = bxx - 0.38 - left
            line(g, bxx - 0.32, yy, bxx, yy, color=c1, w=1.25, head=False)
            tb = clip(cz, lw_, min(0.62, rib_h - 0.04), xs, 'mn', 2)
            text(g, left, yy - 0.3, lw_, 0.6, tb, size=xs, color=GRAY, align=PP_ALIGN.RIGHT,
                 anchor=MSO_ANCHOR.MIDDLE)
        ctx.anim(sl, g, 'fade', 500 + i * 170, 450)
    conclusion(ctx, sl, s, 700 + n * 170)
    return sl


# ======================================================================================
# ПЛАН-ГРАФИК (диаграмма Ганта)
# ======================================================================================
MONTHS = [r'январ', r'феврал', r'март', r'апрел', r'ма[йяе]', r'июн', r'июл', r'август', r'сентябр', r'октябр',
          r'ноябр', r'декабр']
_ROMAN = {'I': 1, 'II': 2, 'III': 3, 'IV': 4}
_TOK = re.compile(
    r'(?P<qr>\b(?P<qa>IV|I{1,3}|[1-4])\s*[–—-]\s*(?P<qb>IV|I{1,3}|[1-4])\s*(?:-?(?:й|ый|ой))?\s*(?:квартал\w*|кв\.?)'
    r'(?:\s*(?P<qry>\d{4}))?)'
    r'|(?P<q>\b(?P<qn>IV|I{1,3}|[1-4])\s*(?:-?(?:й|ый|ой))?\s*(?:квартал\w*|кв\.?)(?:\s*(?P<qy>\d{4}))?)'
    r'|(?P<qq>\bQ(?P<qqn>[1-4])\s*(?P<qqy>\d{4})?)'
    r'|(?P<h>\b(?P<hn>II|I|[12])\s*(?:-?(?:е|ое))?\s*(?:полугоди\w*|пол\.?)(?:\s*(?P<hy>\d{4}))?)'
    r'|(?P<m>\b(?P<mn>' + '|'.join(MONTHS) + r')\w*(?:\s*(?P<my>\d{4}))?)'
    r'|(?P<nm>\b(?P<nmm>0?[1-9]|1[0-2])\.(?P<nmy>\d{4})\b)'
    r'|(?P<y>\b(?P<yy>20\d{2}|19\d{2})\b)', re.I)


def period(label):
    """Срок → (начало, конец) в месяцах от нулевого года (включительно) или None.
    «2026» → весь год; «I кв. 2026»; «2 полугодие 2027»; «март–май 2026»; «03.2026–06.2027»; «2026–2028»."""
    if not label:
        return None
    toks = []
    for m in _TOK.finditer(str(label)):
        if m.group('qr'):                                   # «II–III кв. 2026»
            qa = _ROMAN.get(m.group('qa').upper()) or int(m.group('qa'))
            qb = _ROMAN.get(m.group('qb').upper()) or int(m.group('qb'))
            toks.append([3 * min(qa, qb) - 2, 3 * max(qa, qb), m.group('qry')])
        elif m.group('q'):
            q = _ROMAN.get(m.group('qn').upper()) or int(m.group('qn'))
            toks.append([3 * q - 2, 3 * q, m.group('qy')])
        elif m.group('qq'):
            q = int(m.group('qqn'))
            toks.append([3 * q - 2, 3 * q, m.group('qqy')])
        elif m.group('h'):
            h = _ROMAN.get(m.group('hn').upper()) or int(m.group('hn'))
            toks.append([1, 6, m.group('hy')] if h == 1 else [7, 12, m.group('hy')])
        elif m.group('m'):
            k = next(i for i, rx in enumerate(MONTHS) if re.match(rx, m.group('mn'), re.I)) + 1
            toks.append([k, k, m.group('my')])
        elif m.group('nm'):
            k = int(m.group('nmm'))
            toks.append([k, k, m.group('nmy')])
        elif m.group('y'):
            toks.append([1, 12, m.group('yy')])
    if not toks:
        return None
    # год у «март–май 2026»: берём у ближайшего следующего, иначе у предыдущего
    for i, t in enumerate(toks):
        if not t[2]:
            nxt = next((u[2] for u in toks[i + 1:] if u[2]), None)
            prv = next((u[2] for u in reversed(toks[:i]) if u[2]), None)
            t[2] = nxt or prv
    if any(not t[2] for t in toks):
        return None
    # «год» сразу за кварталом/месяцем — это его год, а не отдельный период
    spans = [(int(t[2]) * 12 + t[0] - 1, int(t[2]) * 12 + t[1] - 1) for t in toks]
    return min(a for a, _ in spans), max(b for _, b in spans)


def gantt_ok(items):
    """У всех этапов разбирается срок, и сроки не одинаковые."""
    sp = [period(it.get('label') or '') for it in items]
    return 2 <= len(items) <= 10 and all(sp) and len(set(sp)) >= 2


def date_span(text):
    """Срок из текста пункта: «Бурение: март–май 2026 г.» → «март–май 2026» (или '')."""
    toks = list(_TOK.finditer(text or ''))
    if not toks:
        return ''
    a, b = toks[0], toks[-1]
    span = text[a.start():b.end()].strip()
    if len(span) <= 32:
        return span
    return f'{a.group(0).strip()}–{b.group(0).strip()}' if len(toks) > 1 else a.group(0).strip()


def render_gantt(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:10]
    n = len(items)
    spans = [period(it.get('label') or '') for it in items]
    if not all(spans):                                  # без сроков — по порядку, шаг за шагом
        spans = [(i * 3, i * 3 + 2) for i in range(n)]
    s0, e0 = min(a for a, _ in spans), max(b for _, b in spans)
    months = e0 - s0 + 1
    if months > 36:
        unit = 12
    elif months > 9:
        unit = 3
    else:
        unit = 1
    a0 = s0 - s0 % unit
    b0 = e0 - e0 % unit + unit - 1
    ncol = (b0 - a0 + 1) // unit
    left_w = 3.6 if n <= 6 else 3.2
    gx = C.L + left_w + 0.15
    gw = C.R - gx
    two = unit != 12                                    # шапка в два яруса: годы и кварталы/месяцы
    head_h = 0.68 if two else 0.5
    bottom -= 0.08
    rh = min(1.0, (bottom - top - head_h - 0.08) / n)
    top += max(0.0, (bottom - top - head_h - 0.08 - rh * n) / 2)     # мало работ — блок по центру
    y0 = top + head_h + 0.08
    colw = gw / ncol
    span = b0 - a0 + 1
    xm = lambda m: gx + (m - a0) / span * gw            # noqa: E731  (месяц → координата)
    gh = group(sl)
    if two:
        for k, yr in enumerate(range(a0 // 12, b0 // 12 + 1)):
            m1, m2 = max(a0, yr * 12), min(b0 + 1, yr * 12 + 12)
            yc_ = rect(gh, xm(m1) + 0.02, top, xm(m2) - xm(m1) - 0.04, 0.32, fill=NAVY if k % 2 == 0 else DBLUE,
                       shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.25)
            shape_text(yc_, str(yr), size=12.5, color=WHITE, font='mj', margins=(0, 0, 0, 0))
    for j in range(ncol):
        m = a0 + j * unit
        yr, mo = divmod(m, 12)
        if unit == 12:
            lab = str(yr)
        elif unit == 3:
            q = ['I', 'II', 'III', 'IV'][mo // 3]
            lab = f'{q} кв.' if colw > 0.62 else q
        else:
            lab = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'][mo]
        hy = top + (0.36 if two else 0)
        hc = rect(gh, gx + j * colw + 0.02, hy, colw - 0.04, head_h - (0.36 if two else 0),
                  fill=CARD if two else (NAVY if j % 2 == 0 else DBLUE), shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.25)
        shape_text(hc, lab, size=11 if two else 12.5, color=NAVY if two else WHITE, font='mj', margins=(0, 0, 0, 0))
        bandc = rect(gh, gx + j * colw + 0.02, y0, colw - 0.04, rh * n, fill=SOFT if j % 2 == 0 else WHITE)
        bandc.line.color.rgb = LGRAY
        bandc.line.width = Pt(0.5)
    ctx.anim(sl, gh, 'fade', 0, 400)
    titles = [_tt(it)[0] or _tt(it)[1] for it in items]
    texts = [_tt(it)[1] if _tt(it)[0] else '' for it in items]
    texts = [x if x.strip(' .;—-') != str(it.get('label') or '').strip() else '' for x, it in zip(texts, items)]
    ts = common_size(titles, left_w - 0.5, min(0.5, rh - 0.12) if any(texts) else rh - 0.1, 15, 10, 'mj',
                     max_lines=1 if any(texts) else 2)
    xs = common_size(texts, left_w - 0.5, max(0.2, rh - 0.42), 11.5, 9, 'mn', max_lines=1) if any(texts) else 0
    for i, it in enumerate(items):
        y = y0 + i * rh
        c1, c2 = pair(i, n)
        g = group(sl)
        num = rect(g, C.L, y + (rh - 0.34) / 2, 0.34, 0.34, fill=c1, shape=MSO_SHAPE.OVAL)
        grad(num, c1, c2, 45)
        shape_text(num, str(i + 1), size=10.5, color=WHITE, font='b', margins=(0, 0, 0, 0))
        has_t = bool(texts[i]) and rh > 0.5
        text(g, C.L + 0.45, y, left_w - 0.5, rh if not has_t else rh * 0.55,
             clip(titles[i], left_w - 0.5, rh - 0.1, ts, 'mj', 1 if has_t else 2), size=ts, color=NAVY, font='mj',
             anchor=MSO_ANCHOR.BOTTOM if has_t else MSO_ANCHOR.MIDDLE)
        if has_t:
            text(g, C.L + 0.45, y + rh * 0.55, left_w - 0.5, rh * 0.45, clip(texts[i], left_w - 0.5, rh * 0.45, xs, 'mn', 1),
                 size=xs, color=GRAY)
        a, b = spans[i]
        bx = gx + (a - a0) / (b0 - a0 + 1) * gw + 0.03
        bw = max(0.18, (b - a + 1) / (b0 - a0 + 1) * gw - 0.06)
        bh = min(0.42, rh * 0.62)
        bar = grect(g, bx, y + (rh - bh) / 2, bw, bh, c1, c2, 0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
        set_av(bar, {'adj': 50000})
        shadow(bar, 8, 2, 22)
        lab = it.get('label') or ''
        if lab and bw > 1.2:
            shape_text(bar, clip(lab, bw - 0.2, bh, 11, 'mn', 1), size=11, color=WHITE, font='mj',
                       margins=(0.08, 0, 0.08, 0))
        elif lab:
            tx = bx + bw + 0.08
            if tx + 1.4 > C.R:
                text(g, bx - 1.5, y, 1.42, rh, clip(lab, 1.42, rh, 10.5, 'mn', 1), size=10.5, color=c1, font='mj',
                     align=PP_ALIGN.RIGHT, anchor=MSO_ANCHOR.MIDDLE)
            else:
                text(g, tx, y, 1.5, rh, clip(lab, 1.5, rh, 10.5, 'mn', 1), size=10.5, color=c1, font='mj',
                     anchor=MSO_ANCHOR.MIDDLE)
        ctx.anim(sl, g, 'wipe_l', 300 + i * 150, 500)
    conclusion(ctx, sl, s, 500 + n * 150)
    return sl


# ======================================================================================
# МАТРИЦА РИСКОВ: вероятность × последствия
# ======================================================================================
_LVL = [(3, r'высок|значит|крит|катастроф|существенн|сильн'), (2, r'средн|умерен|возможн'),
        (1, r'низк|мал|незначит|слаб|маловероятн')]


def _level(v):
    if v is None or v == '':
        return None
    x = parse_number(str(v))
    if x is not None:
        x = int(round(x))
        if 1 <= x <= 3:
            return x
        if 4 <= x <= 5:                                 # шкала 1–5 → 1–3
            return 3 if x == 5 else 2 if x == 4 else None
        return None
    for k, rx in _LVL:
        if re.search(rx, str(v), re.I):
            return k
    return None


def risk_levels(it):
    """(вероятность, последствия) 1–3 из полей prob/impact или из текста."""
    p, i = _level(it.get('prob')), _level(it.get('impact'))
    t = ' '.join(str(it.get(k) or '') for k in ('label', 'text', 'title'))
    if p is None:
        m = re.search(r'(?i)вероятн\w*\s*[:—–-]?\s*(\w+)', t)
        p = _level(m.group(1)) if m else None
    if i is None:
        m = re.search(r'(?i)(?:последстви|влияни|ущерб|тяжест|воздейств)\w*\s*[:—–-]?\s*(\w+)', t)
        i = _level(m.group(1)) if m else None
    return p, i


def risk_ok(items):
    return len(items) >= 2 and all(None not in risk_levels(it) for it in items)


RISK_FILL = {1: rgb('DCEFD0'), 2: rgb('FBE7B5'), 3: rgb('F6CBC5')}
RISK_LINE = {1: GREEN, 2: rgb('E3A21A'), 3: rgb('C8483A')}
RISK_NAME = {1: 'Низкий', 2: 'Средний', 3: 'Высокий'}


def _score(p, i):
    sc = p * i
    return 3 if sc >= 6 else 2 if sc >= 3 else 1


def render_risk(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:9]
    n = len(items)
    lv = [risk_levels(it) for it in items]
    lv = [(p or 2, i or 2) for p, i in lv]
    side = min(bottom - top - 0.55, 5.0)
    gx, gy = C.L + 1.05, top
    cell = side / 3
    g = group(sl)
    for r in range(3):                                  # строки: вероятность сверху вниз 3 → 1
        for c in range(3):                              # столбцы: последствия слева направо 1 → 3
            p, i = 3 - r, c + 1
            lvl = _score(p, i)
            b = rect(g, gx + c * cell + 0.03, gy + r * cell + 0.03, cell - 0.06, cell - 0.06, fill=RISK_FILL[lvl],
                     shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.08)
            b.line.color.rgb = RISK_LINE[lvl]
            b.line.width = Pt(0.75)
    for c, lab in enumerate(['низкие', 'средние', 'высокие']):
        text(g, gx + c * cell, gy + side + 0.04, cell, 0.25, lab, size=10.5, color=GRAY, align=PP_ALIGN.CENTER)
    text(g, gx, gy + side + 0.27, side, 0.28, 'Последствия →', size=12, color=NAVY, font='mj', align=PP_ALIGN.CENTER)
    for r, lab in enumerate(['высокая', 'средняя', 'низкая']):
        text(g, gx - 0.8, gy + r * cell + cell / 2 - 0.13, 0.74, 0.26, lab, size=10, color=GRAY, align=PP_ALIGN.RIGHT)
    ax_c = C.L + 0.14                                   # подпись оси, повёрнутая на 90°: центр рамки у левого края
    tb = text(g, ax_c - 1.2, gy + side / 2 - 0.15, 2.4, 0.3, 'Вероятность →', size=12, color=NAVY, font='mj',
              align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    tb.rotation = -90
    ctx.anim(sl, g, 'fade', 0, 500)
    # метки рисков в клетках
    cells = {}
    for k, (p, i) in enumerate(lv):
        cells.setdefault((p, i), []).append(k)
    md = min(0.46, cell / 3.2)
    for (p, i), ks in cells.items():
        r, c = 3 - p, i - 1
        per = min(3, len(ks))
        rows = -(-len(ks) // per)
        for j, k in enumerate(ks):
            rr, cc = divmod(j, per)
            mx = gx + c * cell + cell / 2 + (cc - (per - 1) / 2) * (md + 0.08) - md / 2
            my = gy + r * cell + cell / 2 + (rr - (rows - 1) / 2) * (md + 0.08) - md / 2
            gm = group(sl)
            mk = rect(gm, mx, my, md, md, fill=NAVY, shape=MSO_SHAPE.OVAL)
            grad(mk, NAVY, BLUE, 45)
            shadow(mk, 6, 2, 30)
            shape_text(mk, str(k + 1), size=12 if md > 0.4 else 10, color=WHITE, font='b', margins=(0, 0, 0, 0))
            ctx.anim(sl, gm, 'zoom', 400 + k * 120, 350)
    # перечень рисков справа
    lx = gx + side + 0.55
    lw = C.R - lx
    rh = (bottom - top) / n
    titles = [_tt(it)[0] or _tt(it)[1] for it in items]
    texts = [_tt(it)[1] if _tt(it)[0] else '' for it in items]
    texts = [re.sub(r'(?i)[,;.]?\s*(вероятн|последстви|влияни)\w*\s*[:—–-]?\s*\w+', '', t).strip(' ,;.') for t in texts]
    ts = common_size(titles, lw - 1.85, min(0.5, rh - 0.1), 15, 10, 'mj', max_lines=2 if not any(texts) else 1)
    xs = common_size(texts, lw - 1.85, max(0.2, rh - 0.45), 12, 9, 'mn') if any(texts) else 0
    for k, it in enumerate(items):
        y = top + k * rh
        lvl = _score(*lv[k])
        gl = group(sl)
        b = rect(gl, lx, y + 0.04, lw, rh - 0.08, fill=WHITE, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.12)
        b.line.color.rgb = LGRAY
        b.line.width = Pt(0.75)
        rect(gl, lx, y + 0.04, 0.09, rh - 0.08, fill=RISK_LINE[lvl])
        mk = rect(gl, lx + 0.2, y + (rh - 0.36) / 2, 0.36, 0.36, fill=NAVY, shape=MSO_SHAPE.OVAL)
        grad(mk, NAVY, BLUE, 45)
        shape_text(mk, str(k + 1), size=11, color=WHITE, font='b', margins=(0, 0, 0, 0))
        tw = lw - 1.85
        has_t = bool(texts[k]) and rh > 0.62
        text(gl, lx + 0.7, y + 0.06, tw, (rh - 0.12) * (0.5 if has_t else 1),
             clip(titles[k], tw, rh - 0.12, ts, 'mj', 1 if has_t else 2), size=ts, color=NAVY, font='mj',
             anchor=MSO_ANCHOR.BOTTOM if has_t else MSO_ANCHOR.MIDDLE)
        if has_t:
            text(gl, lx + 0.7, y + 0.06 + (rh - 0.12) * 0.5, tw, (rh - 0.12) * 0.5,
                 clip(texts[k], tw, (rh - 0.12) * 0.5, xs, 'mn'), size=xs, color=GRAY)
        pill = rect(gl, lx + lw - 1.1, y + (rh - 0.32) / 2, 1.0, 0.32, fill=RISK_FILL[lvl],
                    shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.5)
        pill.line.color.rgb = RISK_LINE[lvl]
        shape_text(pill, RISK_NAME[lvl], size=10.5, color=RISK_LINE[lvl], font='mj', margins=(0, 0, 0, 0))
        ctx.anim(sl, gl, 'wipe_l', 300 + k * 120, 400)
    conclusion(ctx, sl, s, 500 + n * 120)
    return sl


# ======================================================================================
# АЙСБЕРГ: видимая часть и скрытая под водой
# ======================================================================================
def render_iceberg(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:8]
    n = len(items)
    nv = s.get('visible')
    nv = int(nv) if isinstance(nv, (int, float)) or str(nv or '').isdigit() else (1 if n <= 4 else 2)
    nv = max(1, min(n - 1, nv))
    cx = 6.67
    water = top + (bottom - top) * 0.33
    # вода
    gw = group(sl)
    wbox = rect(gw, C.L, water, C.CW, bottom - water, fill=BLUE, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.06)
    grad_alpha(wbox, rgb('9FD0EA'), BLUE, 90, 45, 40)
    rect(gw, C.L, water - 0.02, C.CW, 0.05, fill=BLUE)
    text(gw, C.L + 0.12, water - 0.36, 3.0, 0.3, 'Видимая часть', size=11, color=BLUE, font='mj')
    text(gw, C.L + 0.12, water + 0.08, 3.0, 0.3, 'Скрытая часть', size=11, color=NAVY, font='mj')
    ctx.anim(sl, gw, 'fade', 0, 500)
    # айсберг: верхушка и подводная часть
    gi = group(sl)
    tip_h = water - top - 0.1
    tip = freeform(gi, [(cx - 0.25, top + 0.15), (cx + 0.35, top + 0.05), (cx + 0.9, water - tip_h * 0.45),
                        (cx + 1.35, water), (cx - 1.4, water), (cx - 0.85, water - tip_h * 0.55)], fill=WHITE)
    grad(tip, WHITE, CARD, 90)
    tip.line.color.rgb = BLUE
    tip.line.width = Pt(1.25)
    shadow(tip, 10, 3, 20)
    dh = bottom - water - 0.15
    body = freeform(gi, [(cx - 1.4, water), (cx + 1.35, water), (cx + 2.3, water + dh * 0.35), (cx + 1.9, water + dh * 0.8),
                         (cx + 0.6, water + dh), (cx - 0.9, water + dh * 0.95), (cx - 2.2, water + dh * 0.6),
                         (cx - 2.05, water + dh * 0.25)], fill=PALEG)
    grad_alpha(body, WHITE, rgb('B9DAEC'), 90, 95, 90)
    body.line.color.rgb = BLUE
    body.line.width = Pt(1.0)
    ctx.anim(sl, gi, 'rise', 200, 600)
    vis, hid = list(range(nv)), list(range(nv, n))
    colw = cx - 2.55 - C.L
    # видимые — справа и слева от верхушки; скрытые — по обе стороны подводной части
    va = [(cx + (0.6 if k % 2 == 0 else -0.6), top + (water - top) * (0.45 + 0.1 * k)) for k in range(len(vis))]
    ha = []
    for k in range(len(hid)):
        right = k % 2 == 0
        row = k // 2
        nr = -(-len(hid) // 2)
        ha.append((cx + (1.9 if right else -1.9), water + 0.35 + (bottom - water - 0.6) * (row + 0.5) / nr))
    for grp_, anchors, y1, y2 in ((vis, va, top, water - 0.4), (hid, ha, water + 0.42, bottom)):
        right = [j for j in range(len(grp_)) if anchors[j][0] > cx]
        left = [j for j in range(len(grp_)) if anchors[j][0] <= cx]
        _side_labels(ctx, sl, items, [grp_[j] for j in right], [anchors[j] for j in right], C.R - colw, colw, y1, y2,
                     PP_ALIGN.LEFT, 500)
        _side_labels(ctx, sl, items, [grp_[j] for j in left], [anchors[j] for j in left], C.L, colw, y1, y2,
                     PP_ALIGN.RIGHT, 500)
    conclusion(ctx, sl, s, 600 + n * 150)
    return sl


# ======================================================================================
# ПАЗЛ: составляющие, которые вместе дают целое
# ======================================================================================
def render_puzzle(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:6]
    n = len(items)
    rows = [n] if n <= 4 else [3, n - 3]
    knob = 0.42
    H = bottom - top - 0.1
    ph = (H - 0.05) / len(rows)
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    pw = C.CW / max(rows)
    tw = pw - 0.8
    ts = common_size(titles, tw, 0.6, 18 if n <= 4 else 16, 11, 'mj', max_lines=2)
    xs = common_size(texts, tw, ph - 1.45, 14 if n <= 4 else 12.5, 9.5, 'mn') if any(texts) else 0
    k = 0
    pieces = []
    for r, cnt in enumerate(rows):
        x0 = C.L + (C.CW - cnt * pw) / 2
        for c in range(cnt):
            pieces.append((k, x0 + c * pw, top + r * ph, c < cnt - 1, r == 0 and len(rows) > 1 and c < rows[-1]))
            k += 1
    knobs = []
    for i, x, y, kr, kb in pieces:
        c1, c2 = pair(i, n)
        g = group(sl)
        p = rect(g, x, y, pw, ph, fill=c1)
        grad(p, c1, c2, 45)
        p.line.color.rgb = WHITE
        p.line.width = Pt(2.5)
        big = text(g, x + pw - 1.25, y + 0.05, 1.15, 0.9, f'{i + 1:02d}', size=40, color=WHITE, font='b',
                   align=PP_ALIGN.RIGHT)
        text_alpha(big, 35)
        bh = 0.8 + _block_h(tw, ph - 1.2, titles[i], texts[i], ts, xs)
        yb = y + max(0.3, (ph - bh) / 2)                  # содержимое детали — по центру по высоте
        circ_icon(g, items[i].get('icon') or 'TbPuzzle', x + 0.45, yb, 0.62, fill=WHITE, ic='n')
        _block(g, x + 0.45, yb + 0.8, tw, ph - 1.2, titles[i], texts[i], ts, xs, tcol=WHITE, bcol=WHITE)
        ctx.anim(sl, g, 'zoom', 100 + i * 170, 450)
        if kr:
            knobs.append((i, x + pw - knob / 2, y + ph / 2 - knob / 2))
        if kb:
            knobs.append((i, x + pw / 2 - knob / 2, y + ph - knob / 2))
    for i, kx, ky in knobs:          # выступы — цветом своей детали у края, заходят на соседнюю
        c1, c2 = pair(i, n)
        gk = group(sl)
        rect(gk, kx, ky, knob, knob, fill=_mix(c1, c2, 0.75), shape=MSO_SHAPE.OVAL)
        ctx.anim(sl, gk, 'zoom', 100 + i * 170, 450)
    conclusion(ctx, sl, s, 400 + n * 170)
    return sl


# ======================================================================================
# ВЕСЫ: аргументы «за» и «против» (две чаши)
# ======================================================================================
def render_balance(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    Ls, Rs = s['left'], s['right']
    nl, nr = len(Ls['items']), len(Rs['items'])
    tilt = 0 if nl == nr else (6 if nr > nl else -6)     # перевешивает сторона с большим числом доводов
    cx = 6.67
    cw = 3.75
    # колонки доводов
    for side, data in ((0, Ls), (1, Rs)):
        x = C.L if side == 0 else C.R - cw
        c1, c2 = (NAVY, DBLUE) if side == 0 else (DGREEN, GREEN)
        g = group(sl)
        hdr = grect(g, x, top, cw, 0.6, c1, c2, 0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
        set_av(hdr, {'adj': 30000})
        shadow(hdr, 10, 3, 22)
        shape_text(hdr, clip(data['title'], cw - 0.3, 0.6, 17, 'mj', 1), size=17, color=WHITE, font='mj')
        ctx.anim(sl, g, 'fade', side * 250, 450)
        its = data['items']
        m = max(len(its), 1)
        y0 = top + 0.78
        rh = min(1.0, (bottom - y0) / m)
        xs = common_size(its, cw - 0.6, rh - 0.12, 15, 10, 'mn')
        for j, t in enumerate(its):
            gi = group(sl)
            rect(gi, x, y0 + j * rh, cw, rh - 0.1, fill=SOFT if side == 0 else PALEG,
                     shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.15)
            mark = rect(gi, x + 0.14, y0 + j * rh + (rh - 0.1 - 0.26) / 2, 0.26, 0.26, fill=c1, shape=MSO_SHAPE.OVAL)
            grad(mark, c1, c2, 45)
            text(gi, x + 0.5, y0 + j * rh, cw - 0.6, rh - 0.1, clip(t, cw - 0.6, rh - 0.12, xs, 'mn'), size=xs,
                 color=GRAY, anchor=MSO_ANCHOR.MIDDLE)
            ctx.anim(sl, gi, 'wipe_l', 400 + side * 250 + j * 120, 350)
    # весы
    gs = group(sl)
    base_y = bottom - 0.25
    post_top = top + 1.35
    foot = freeform(gs, [(cx - 0.75, base_y), (cx + 0.75, base_y), (cx + 0.18, base_y - 0.45), (cx - 0.18, base_y - 0.45)],
                    fill=NAVY)
    grad(foot, NAVY, BLUE, 0)
    rect(gs, cx - 0.06, post_top, 0.12, base_y - 0.45 - post_top, fill=NAVY)
    half = 1.45
    beam = rect(gs, cx - half, post_top - 0.06, 2 * half, 0.12, fill=NAVY, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.5)
    grad(beam, NAVY, BLUE, 0)
    beam.rotation = tilt
    piv = rect(gs, cx - 0.16, post_top - 0.16, 0.32, 0.32, fill=GREEN, shape=MSO_SHAPE.OVAL)
    glow(piv, '9AC854', 6, 50)
    dy = math.sin(math.radians(tilt)) * half
    for sgn, c1, c2 in ((-1, NAVY, DBLUE), (1, DGREEN, GREEN)):
        ex = cx + sgn * half * math.cos(math.radians(tilt))
        ey = post_top + sgn * dy
        pan_y = ey + 1.1
        line(gs, ex, ey, ex - 0.45, pan_y, color=GRAY, w=1.0, head=False)
        line(gs, ex, ey, ex + 0.45, pan_y, color=GRAY, w=1.0, head=False)
        pan = freeform(gs, [(ex - 0.65, pan_y), (ex + 0.65, pan_y), (ex + 0.4, pan_y + 0.3), (ex - 0.4, pan_y + 0.3)],
                       fill=c1)
        grad(pan, c1, c2, 0)
        shadow(pan, 8, 2, 22)
        cnt = nl if sgn < 0 else nr
        text(gs, ex - 0.5, pan_y + 0.36, 1.0, 0.4, str(cnt), size=20, color=c1, font='b', align=PP_ALIGN.CENTER)
    ctx.anim(sl, gs, 'zoom', 200, 600)
    conclusion(ctx, sl, s, 800 + (nl + nr) * 120)
    return sl


# ======================================================================================
# ЧЕК-ЛИСТ: что сделано, что в работе, что в плане
# ======================================================================================
_DONE = re.compile(r'(?i)выполнен|заверш|готов|сделан|достигнут|введен|внедр[её]н|реализован|✓|✔|done')
_PROG = re.compile(r'(?i)в\s+работе|выполняется|реализуется|в\s+процессе|вед[её]тся|ид[её]т|частично|начат')


def status_of(it):
    lab = str(it.get('label') or '')
    for src in (lab, f"{it.get('title') or ''} {it.get('text') or ''}"):
        if _PROG.search(src):
            return 'progress'
        if _DONE.search(src):
            return 'done'
        if re.search(r'(?i)план|предстоит|будет|запланир', src):
            return 'plan'
    return 'plan'


def checklist_ok(items):
    st = [status_of(it) for it in items]
    return len(items) >= 3 and len(set(st)) >= 2


ST_STYLE = {'done': (DGREEN, GREEN, 'Выполнено', '✓'), 'progress': (BLUE, MIDBLUE, 'В работе', '…'),
            'plan': (LGRAY, LGRAY, 'План', '')}


def render_checklist(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:12]
    n = len(items)
    st = [status_of(it) for it in items]
    done = st.count('done')
    prog = st.count('progress')
    # сводка: прогресс выполнения
    g = group(sl)
    bar_w = C.CW - 3.2
    text(g, C.L, top, 3.0, 0.5, [[(f'{done}', {'font': 'b', 'color': DGREEN, 'size': 26}),
                                 (f' из {n} выполнено', {'color': NAVY, 'font': 'mj', 'size': 15})]], size=15,
         anchor=MSO_ANCHOR.MIDDLE)
    track = rect(g, C.L + 3.2, top + 0.14, bar_w, 0.24, fill=SOFT, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.5)
    track.line.color.rgb = LGRAY
    if done:
        fb = grect(g, C.L + 3.2, top + 0.14, max(0.3, bar_w * done / n), 0.24, DGREEN, GREEN, 0,
                   shape=MSO_SHAPE.ROUNDED_RECTANGLE)
        set_av(fb, {'adj': 50000})
    if prog:
        pb = rect(g, C.L + 3.2 + bar_w * done / n, top + 0.14, bar_w * prog / n, 0.24, fill=MIDBLUE,
                  shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.5)
        alpha_fill(pb, '2E95C4', 60)
    ctx.anim(sl, g, 'wipe_l', 0, 700)
    cols = 1 if n <= 6 else 2
    per = -(-n // cols)
    y0 = top + 0.7
    gapx = 0.3
    cw = (C.CW - gapx * (cols - 1)) / cols
    rh = min(0.95, (bottom - y0) / per)
    titles = [_tt(it)[0] or _tt(it)[1] for it in items]
    texts = [_tt(it)[1] if _tt(it)[0] else '' for it in items]
    texts = ['' if len(x) < 25 and (_DONE.search(x) or _PROG.search(x) or re.search(r'(?i)план|запланир', x)) else x
             for x in texts]                       # «выполнено», «в работе» — уже на плашке статуса
    tw = cw - 0.85 - 1.35
    ts = common_size(titles, tw, min(0.5, rh - 0.12), 16 if cols == 1 else 14, 10, 'mj', max_lines=1 if any(texts) else 2)
    xs = common_size(texts, tw, max(0.2, rh - 0.5), 12.5, 9, 'mn') if any(texts) else 0
    for i, it in enumerate(items):
        c, r = divmod(i, per)
        x = C.L + c * (cw + gapx)
        y = y0 + r * rh
        c1, c2, name, mk = ST_STYLE[st[i]]
        gi = group(sl)
        b = rect(gi, x, y + 0.04, cw, rh - 0.08, fill=WHITE if st[i] == 'plan' else (PALEG if st[i] == 'done' else SOFT),
                 shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.15)
        b.line.color.rgb = LGRAY
        b.line.width = Pt(0.75)
        d = min(0.42, rh - 0.2)
        circ = rect(gi, x + 0.18, y + (rh - d) / 2, d, d, fill=c1 if st[i] != 'plan' else WHITE, shape=MSO_SHAPE.OVAL)
        if st[i] != 'plan':
            grad(circ, c1, c2, 45)
            shape_text(circ, mk, size=15 if mk == '✓' else 12, color=WHITE, font='b', margins=(0, 0, 0, 0))
        else:
            circ.line.color.rgb = GRAY
            circ.line.width = Pt(1.5)
        has_t = bool(texts[i]) and rh > 0.62
        tx = x + 0.3 + d
        text(gi, tx, y + 0.06, tw, (rh - 0.12) * (0.52 if has_t else 1),
             clip(titles[i], tw, rh - 0.12, ts, 'mj', 1 if has_t else 2), size=ts,
             color=NAVY if st[i] != 'plan' else GRAY, font='mj', anchor=MSO_ANCHOR.BOTTOM if has_t else MSO_ANCHOR.MIDDLE)
        if has_t:
            text(gi, tx, y + 0.06 + (rh - 0.12) * 0.52, tw, (rh - 0.12) * 0.48,
                 clip(texts[i], tw, (rh - 0.12) * 0.48, xs, 'mn'), size=xs, color=GRAY)
        pill = rect(gi, x + cw - 1.3, y + (rh - 0.32) / 2, 1.18, 0.32, fill=c1, shape=MSO_SHAPE.ROUNDED_RECTANGLE,
                    adj=0.5)
        if st[i] != 'plan':
            grad(pill, c1, c2, 0)
        shape_text(pill, name, size=10.5, color=WHITE if st[i] != 'plan' else GRAY, font='mj', margins=(0, 0, 0, 0))
        ctx.anim(sl, gi, 'rise', 300 + i * 110, 400)
    conclusion(ctx, sl, s, 500 + n * 110)
    return sl


# ======================================================================================
# ГЛАВНАЯ ЦИФРА: одно ключевое число крупно (+ до двух поддерживающих)
# ======================================================================================
def hero_ok(items):
    return 1 <= len(items) <= 3 and bool(items) and parse_number(str(items[0].get('value') or '')) is not None


def render_hero(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:3]
    main = items[0]
    sup = items[1:]
    expl = main.get('text') or ''
    alone = not sup and not expl                         # одно число без пояснений — панель на всю ширину
    pw = C.CW if alone else 5.6
    H = bottom - top
    g = group(sl)
    panel = grect(g, C.L, top, pw, H, NAVY, BLUE, 45, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    set_av(panel, {'adj': 7000})
    shadow(panel, 14, 4, 26)
    bubbles = ((2.4, C.L + pw - 2.75, top + 0.35, 9), (1.1, C.L + pw - 1.4, top + 2.25, 14)) if not alone else \
        ((2.2, C.L + pw - 2.5, bottom - 2.45, 7), (1.0, C.L + pw - 1.25, bottom - 1.2, 10))
    for d_, bx_, by_, a_ in bubbles:
        dc = rect(g, bx_, by_, d_, d_, fill=WHITE, shape=MSO_SHAPE.OVAL)      # декоративные «пузыри»
        alpha_fill(dc, 'FFFFFF', a_)
    val = str(main.get('value') or '').replace(' ', '\u00a0')                # число со знаком — одной строкой
    unit = str(main.get('unit') or '')
    vw = pw * 0.52 if alone else pw - 0.8
    vh = min(2.2, H * 0.48)
    vs = common_size([val], vw * SAFE, vh - 0.2, 120 if alone else 110, 40, 'b', max_lines=1)
    vy = top + (H - vh - (0.65 if unit else 0)) / 2 if alone else top + 0.35
    text(g, C.L + 0.4, vy, vw, vh, val, size=vs, color=WHITE, font='b', anchor=MSO_ANCHOR.BOTTOM)
    yy = vy + vh + 0.05
    if unit:
        us = common_size([unit], vw, 0.6, 28, 14, 'mj', max_lines=1)
        text(g, C.L + 0.4, yy, vw, 0.6, clip(unit, vw, 0.6, us, 'mj', 1), size=us, color=LGREEN, font='mj')
        yy += 0.65
    t = main.get('title') or ''
    if t and alone:
        tx, tw_ = C.L + pw * 0.58, pw * 0.37
        ts = common_size([t], tw_, H - 0.8, 30, 14, 'mj', max_lines=5)
        rect(g, tx - 0.3, top + H * 0.25, 0.06, H * 0.5, fill=LGREEN)
        text(g, tx, top + 0.4, tw_, H - 0.8, clip(t, tw_, H - 0.8, ts, 'mj', 5), size=ts, color=WHITE, font='mj',
             anchor=MSO_ANCHOR.MIDDLE)
    elif t:
        ts = common_size([t], pw - 0.8, bottom - yy - 0.3, 22, 13, 'mj', max_lines=3)
        text(g, C.L + 0.4, yy + 0.1, pw - 0.8, bottom - yy - 0.3, clip(t, pw - 0.8, bottom - yy - 0.3, ts, 'mj', 3),
             size=ts, color=WHITE, font='mj')
    ctx.anim(sl, g, 'zoom', 0, 600)
    # справа: пояснение и поддерживающие числа
    if alone:
        conclusion(ctx, sl, s, 800)
        return sl
    rx = C.L + pw + 0.45
    rw = C.R - rx
    sup_h = 1.55 if sup else 0
    gr = group(sl)
    if expl:
        es = common_size([expl], rw, H - sup_h - 0.3, 24, 13, 'mn')
        rect(gr, rx, top + 0.1, 0.08, min(H - sup_h - 0.3, text_height(clip(expl, rw - 0.3, H - sup_h - 0.3, es, 'mn'),
                                                                                 rw - 0.3, es, 'mn') + 0.1), fill=GREEN)
        text(gr, rx + 0.3, top + 0.1, rw - 0.3, H - sup_h - 0.3, clip(expl, rw - 0.3, H - sup_h - 0.3, es, 'mn'),
             size=es, color=NAVY)
    ctx.anim(sl, gr, 'fade', 400, 500)
    if sup:
        sw = (rw - 0.25 * (len(sup) - 1)) / len(sup)
        for j, it in enumerate(sup):
            x = rx + j * (sw + 0.25)
            y = bottom - sup_h
            c1, c2 = pair(j + 3, 6)
            gs = group(sl)
            rect(gs, x, y, sw, sup_h, fill=PALEG if j % 2 == 0 else SOFT, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.1)
            v = f"{it.get('value') or ''} {it.get('unit') or ''}".strip()
            vs2 = common_size([v], sw - 0.4, 0.62, 30, 14, 'b', max_lines=1)
            text(gs, x + 0.2, y + 0.12, sw - 0.4, 0.62, clip(v, sw - 0.4, 0.62, vs2, 'b', 1), size=vs2, color=c1, font='b')
            t2 = it.get('title') or it.get('text') or ''
            ts2 = common_size([t2], sw - 0.4, sup_h - 0.85, 13.5, 9.5, 'mn')
            text(gs, x + 0.2, y + 0.78, sw - 0.4, sup_h - 0.85, clip(t2, sw - 0.4, sup_h - 0.85, ts2, 'mn'), size=ts2,
                 color=GRAY)
            ctx.anim(sl, gs, 'rise', 600 + j * 200, 450)
    conclusion(ctx, sl, s, 1000)
    return sl


# ======================================================================================
# «БЫЛО → СТАЛО»: результат крупно, с большой стрелкой
# ======================================================================================
def render_shift(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    Ls, Rs = s['left'], s['right']
    aw = 1.3
    cw = (C.CW - aw) / 2
    H = bottom - top
    for side, data in ((0, Ls), (1, Rs)):
        x = C.L if side == 0 else C.L + cw + aw
        g = group(sl)
        if side == 0:
            b = rect(g, x, top + 0.25, cw, H - 0.5, fill=SOFT, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.06)
            b.line.color.rgb = LGRAY
            hdr_c = (LGRAY, LGRAY)
            tcol, ic = NAVY, 'TbClockHour4'
            yb, hb = top + 0.25, H - 0.5
        else:
            b = grect(g, x, top, cw, H, PALEG, rgb('DDEBC2'), 90, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
            set_av(b, {'adj': 6000})
            shadow(b, 14, 4, 24)
            hdr_c = (DGREEN, GREEN)
            tcol, ic = WHITE, 'TbRocket'
            yb, hb = top, H
        hdr = grect(g, x, yb, cw, 0.7, hdr_c[0], hdr_c[1], 0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
        set_av(hdr, {'adj': 25000})
        rect(g, x, yb + 0.45, cw, 0.25, fill=hdr_c[0]) if side == 0 else grad(rect(g, x, yb + 0.45, cw, 0.25,
                                                                                     fill=hdr_c[0]), hdr_c[0], hdr_c[1], 0)
        icon(g, ic, 'n' if side == 0 else 'w', x + 0.25, yb + 0.15, 0.4)
        text(g, x + 0.8, yb, cw - 1.0, 0.7, clip(data['title'], cw - 1.0, 0.7, 19, 'mj', 1), size=19, color=tcol,
             font='mj', anchor=MSO_ANCHOR.MIDDLE)
        its = data['items']
        m = max(len(its), 1)
        y0 = yb + 0.9
        rh = (hb - 1.05) / m
        xs = common_size(its, cw - 0.95, rh - 0.08, 17 if side else 15, 10, 'mn')
        for j, t in enumerate(its):
            yy = y0 + j * rh
            if side:
                mk = rect(g, x + 0.3, yy + (rh - 0.3) / 2, 0.3, 0.3, fill=DGREEN, shape=MSO_SHAPE.OVAL)
                grad(mk, DGREEN, GREEN, 45)
                shape_text(mk, '✓', size=11, color=WHITE, font='b', margins=(0, 0, 0, 0))
            else:
                rect(g, x + 0.36, yy + rh / 2 - 0.04, 0.18, 0.08, fill=GRAY)
            text(g, x + 0.75, yy, cw - 0.95, rh, clip(t, cw - 0.95, rh - 0.08, xs, 'mn'), size=xs,
                 color=GRAY if side == 0 else NAVY, anchor=MSO_ANCHOR.MIDDLE)
        ctx.anim(sl, g, 'fade' if side == 0 else 'zoom', side * 600, 500)
    ga = group(sl)
    ax = C.L + cw + 0.12
    arr = grect(ga, ax, (top + bottom) / 2 - 0.65, aw - 0.24, 1.3, BLUE, GREEN, 0, shape=MSO_SHAPE.RIGHT_ARROW)
    shadow(arr, 10, 3, 22)
    ctx.anim(sl, ga, 'wipe_l', 350, 400)
    conclusion(ctx, sl, s, 1200)
    return sl


# ======================================================================================
# ЛЕПЕСТКИ: грани одной идеи вокруг центра
# ======================================================================================
def render_petals(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:6]
    n = len(items)
    cx, cy = 6.67, (top + bottom) / 2
    R = min(1.95, (bottom - top) / 2 - 0.1)
    plen, pwid = R * 1.02, R * 0.62
    start = -90 + (180 / n if n % 2 == 0 else 0)       # нечётное число — лепесток вверх, чётное — симметрично
    angs = [start + i * 360 / n for i in range(n)]
    tips = []
    for i, a in enumerate(angs):
        c1, c2 = pair(i, n)
        ar = math.radians(a)
        mx, my = cx + math.cos(ar) * (plen / 2 + 0.25), cy + math.sin(ar) * (plen / 2 + 0.25)
        g = group(sl)
        p = rect(g, mx - plen / 2, my - pwid / 2, plen, pwid, fill=c1, shape=MSO_SHAPE.OVAL)
        grad_alpha(p, c1, c2, 0, 80, 100)
        p.rotation = a
        shadow(p, 8, 2, 18)
        nx, ny = cx + math.cos(ar) * (plen * 0.72 + 0.25), cy + math.sin(ar) * (plen * 0.72 + 0.25)
        text(g, nx - 0.4, ny - 0.3, 0.8, 0.6, str(i + 1), size=20, color=WHITE, font='b', align=PP_ALIGN.CENTER,
             anchor=MSO_ANCHOR.MIDDLE)
        ctx.anim(sl, g, 'zoom', 200 + i * 150, 450)
        tips.append((cx + math.cos(ar) * (plen + 0.3), cy + math.sin(ar) * (plen + 0.3)))
    # центр
    gc = group(sl)
    rc = R * 0.56
    core = rect(gc, cx - rc, cy - rc, 2 * rc, 2 * rc, fill=WHITE, shape=MSO_SHAPE.OVAL)
    shadow(core, 12, 3, 26)
    core.line.color.rgb = PALEG2
    core.line.width = Pt(4)
    center = s.get('center') or s.get('title') or ''
    cs = common_size([center], rc * 1.5 * SAFE, rc * 1.4, 16, 9.5, 'mj')
    text(gc, cx - rc * 0.75, cy - rc * 0.7, rc * 1.5, rc * 1.4, clip(center, rc * 1.5 * SAFE, rc * 1.4, cs, 'mj'), size=cs,
         color=NAVY, font='mj', align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    ctx.anim(sl, gc, 'zoom', 0, 500)
    colw = cx - R * 1.3 - 0.45 - C.L
    right = [i for i in range(n) if tips[i][0] > cx + 0.01 or (abs(tips[i][0] - cx) <= 0.01 and i % 2 == 0)]
    left = [i for i in range(n) if i not in right]
    _side_labels(ctx, sl, items, right, [tips[i] for i in right], C.R - colw, colw, top, bottom, PP_ALIGN.LEFT, 600)
    _side_labels(ctx, sl, items, left, [tips[i] for i in left], C.L, colw, top, bottom, PP_ALIGN.RIGHT, 600)
    conclusion(ctx, sl, s, 800 + n * 150)
    return sl


# ======================================================================================
# ИЗВИЛИСТЫЙ ПУТЬ: этапы на дороге-«змейке»
# ======================================================================================
def render_path(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:8]
    n = len(items)
    cy = (top + bottom) / 2
    A = min(0.75, (bottom - top) * 0.14)
    x1, x2 = C.L + 0.35, C.R - 0.35
    wband = 0.42
    xs_ = [x1 + (x2 - x1) * (i + 0.5) / n for i in range(n)]

    def yc(x):                                      # пики и впадины — ровно под метками этапов
        t = (x - x1) / (x2 - x1) * n - 0.5
        return cy - A * math.cos(math.pi * t)

    N = 90
    xsamp = [x1 + (x2 - x1) * k / N for k in range(N + 1)]
    upper, lower = [], []
    for k, x in enumerate(xsamp):
        dx = (x2 - x1) / N
        dy = yc(min(x2, x + dx / 2)) - yc(max(x1, x - dx / 2))
        ln_ = math.hypot(dx, dy) or 1
        nx, ny = -dy / ln_, dx / ln_
        upper.append((x + nx * wband / 2, yc(x) + ny * wband / 2))
        lower.append((x - nx * wband / 2, yc(x) - ny * wband / 2))
    g = group(sl)
    road = freeform(g, upper + lower[::-1], fill=NAVY)
    grad(road, NAVY, GREEN, 0)
    shadow(road, 10, 3, 20)
    ctx.anim(sl, g, 'wipe_l', 0, 1000)
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    labels = [it.get('label') or '' for it in items]
    zone = cy - A - top - 0.55
    bw = min(2.9, (x2 - x1) / n * 2 - 0.2)
    ts = common_size(titles, bw - 0.1, 0.55, 15.5, 10.5, 'mj', max_lines=2) if any(titles) else 0
    xs = common_size(texts, bw - 0.1, zone - 0.75, 12.5, 9, 'mn') if any(texts) else 0
    for i, it in enumerate(items):
        x = xs_[i]
        y = yc(x)
        up = i % 2 == 0                                  # пики (y меньше) — подпись сверху
        c1, c2 = pair(i, n)
        gi = group(sl)
        pin = rect(gi, x - 0.32, y - 0.32, 0.64, 0.64, fill=WHITE, shape=MSO_SHAPE.OVAL)
        pin.line.color.rgb = c1
        pin.line.width = Pt(3.5)
        shadow(pin, 8, 2, 26)
        shape_text(pin, str(i + 1), size=15, color=c1, font='b', margins=(0, 0, 0, 0))
        bx = max(C.L, min(C.R - bw, x - bw / 2))
        col = c1 if c1 != LGREEN else DGREEN
        lab = clip(labels[i], bw - 0.1, 0.5, ts + 6, 'b', 1) if labels[i] else ''
        lh = (ts + 6) / 72 * 1.2 + 0.02 if lab else 0       # срок (год) — отдельной крупной строкой
        hh = lh + _block_h(bw - 0.1, zone - lh, titles[i], texts[i], ts, xs)
        if up:
            by = max(top, y - 0.45 - hh)
            line(gi, x, y - 0.32, x, by + hh + 0.04, color=c1, w=1.25, head=False, dash='sysDot')
        else:
            by = min(bottom - hh, y + 0.45)
            line(gi, x, y + 0.32, x, by - 0.04, color=c1, w=1.25, head=False, dash='sysDot')
        if lab:
            text(gi, bx, by, bw - 0.1, lh, lab, size=ts + 6, color=col, font='b', align=PP_ALIGN.CENTER)
        _block(gi, bx, by + lh, bw - 0.1, hh - lh + 0.1, titles[i], texts[i], ts, xs, tcol=col, align=PP_ALIGN.CENTER)
        ctx.anim(sl, gi, 'rise', 400 + i * 160, 450)
    conclusion(ctx, sl, s, 600 + n * 160)
    return sl


# ======================================================================================
# МЕНТАЛЬНАЯ КАРТА: центр → ветви → пункты
# ======================================================================================
def render_mindmap(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:6]
    n = len(items)
    cx, cy = 6.67, (top + bottom) / 2
    cw_, ch_ = 2.8, 1.4
    gc = group(sl)
    core = grect(gc, cx - cw_ / 2, cy - ch_ / 2, cw_, ch_, NAVY, BLUE, 45, shape=MSO_SHAPE.OVAL)
    glow(core, 'CEE1A5', 10, 55)
    center = s.get('center') or s.get('title') or ''
    cs = common_size([center], cw_ * 0.72 * SAFE, ch_ * 0.7, 17, 10, 'mj')
    shape_text(core, clip(center, cw_ * 0.72 * SAFE, ch_ * 0.7, cs, 'mj'), size=cs, color=WHITE, font='mj',
               margins=(0.25, 0.1, 0.25, 0.1))
    ctx.anim(sl, gc, 'zoom', 0, 500)
    right = list(range(0, n, 2)) if n > 1 else [0]
    left = [i for i in range(n) if i not in right]
    nodew = 2.15
    subw = C.R - (cx + cw_ / 2 + 0.45 + nodew + 0.2)
    titles = [_tt(it)[0] or f'Направление {k + 1}' for k, it in enumerate(items)]
    subs = [_bullets(_tt(it)[1], 4) for it in items]
    ts = common_size(titles, nodew - 0.3, 0.6, 15, 10, 'mj', max_lines=2)
    per_side = max(len(right), len(left), 1)
    slot = (bottom - top) / per_side
    xs = common_size(['\n'.join(sb) for sb in subs], subw - 0.15, slot - 0.15, 14, 9, 'mn') if any(subs) else 0
    for side, idx in ((1, right), (-1, left)):
        m = len(idx)
        for k, i in enumerate(idx):
            c1, c2 = pair(i, n)
            ny = top + (bottom - top) * (k + 0.5) / m
            nx = cx + side * (cw_ / 2 + 0.45) - (0 if side > 0 else nodew)
            g = group(sl)
            sx = cx + side * cw_ * 0.42
            sy = cy + (ny - cy) * 0.25
            ex = nx if side > 0 else nx + nodew
            line(g, sx, sy, ex, ny, color=c1, w=3, head=False)
            node = grect(g, nx, ny - 0.36, nodew, 0.72, c1, c2, 0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
            set_av(node, {'adj': 50000})
            shadow(node, 8, 2, 22)
            shape_text(node, clip(titles[i], nodew - 0.3, 0.6, ts, 'mj', 2), size=ts, color=WHITE, font='mj',
                       margins=(0.12, 0, 0.12, 0))
            if subs[i]:
                bx = nx + nodew + 0.2 if side > 0 else nx - 0.2 - subw
                body = '\n'.join(subs[i])
                bt = clip(body, subw, slot - 0.15, xs, 'mn')
                bh = text_height(bt, subw, xs, 'mn')
                by = max(top, min(bottom - bh, ny - bh / 2))
                rect(g, bx if side > 0 else bx + subw - 0.05, by, 0.05, bh, fill=c1)
                text(g, bx + (0.15 if side > 0 else 0), by, subw - 0.15, bh + 0.05, _P(bt), size=xs, color=GRAY,
                     align=PP_ALIGN.LEFT if side > 0 else PP_ALIGN.RIGHT)
            ctx.anim(sl, g, 'fade', 300 + i * 150, 450)
    conclusion(ctx, sl, s, 500 + n * 150)
    return sl


# ======================================================================================
# ФАКТОРЫ → РЕЗУЛЬТАТ
# ======================================================================================
def render_converge(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:6]
    n = len(items)
    fw = 5.2
    rw = 3.3
    rx = C.R - rw
    H = bottom - top
    rh = (H - 0.15 * (n - 1)) / n
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    tw = fw - 1.05
    ts = common_size(titles, tw, min(0.5, rh * 0.45), 16, 10.5, 'mj', max_lines=1 if any(texts) else 2)
    xs = common_size(texts, tw, max(0.2, rh - 0.5), 13, 9, 'mn') if any(texts) else 0
    ry0, ry1 = top + H * 0.12, bottom - H * 0.12
    for i, it in enumerate(items):
        y = top + i * (rh + 0.15)
        c1, c2 = pair(i, n)
        g = group(sl)
        b = rect(g, C.L, y, fw, rh, fill=WHITE, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.15)
        b.line.color.rgb = LGRAY
        shadow(b, 8, 2, 14)
        grect(g, C.L, y, 0.12, rh, c1, c2, 90)
        d = min(0.55, rh - 0.2)
        circ_icon(g, it.get('icon') or 'TbBulb', C.L + 0.28, y + (rh - d) / 2, d, fill=c1, fill2=c2)
        has_t = bool(texts[i]) and rh > 0.65
        tx = C.L + 0.42 + d
        text(g, tx, y + 0.05, tw, (rh - 0.1) * (0.48 if has_t else 1),
             clip(titles[i] or texts[i], tw, rh - 0.1, ts, 'mj', 1 if has_t else 2), size=ts, color=NAVY, font='mj',
             anchor=MSO_ANCHOR.BOTTOM if has_t else MSO_ANCHOR.MIDDLE)
        if has_t:
            text(g, tx, y + 0.05 + (rh - 0.1) * 0.48, tw, (rh - 0.1) * 0.52,
                 clip(texts[i], tw, (rh - 0.1) * 0.52, xs, 'mn'), size=xs, color=GRAY)
        ty = ry0 + (ry1 - ry0) * (i + 0.5) / n
        line(g, C.L + fw + 0.05, y + rh / 2, rx - 0.12, ty, color=c1, w=2, head=True)
        ctx.anim(sl, g, 'wipe_l', 100 + i * 150, 450)
    gr = group(sl)
    res = grect(gr, rx, ry0 - 0.15, rw, ry1 - ry0 + 0.3, DGREEN, GREEN, 90, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    set_av(res, {'adj': 9000})
    shadow(res, 14, 4, 26)
    glow(res, 'CEE1A5', 8, 45)
    icon(gr, 'TbTargetArrow', 'w', rx + (rw - 0.8) / 2, ry0 + 0.15, 0.8)
    center = s.get('center') or s.get('title') or ''
    hh = ry1 - ry0 - 1.15
    cs = common_size([center], (rw - 0.5) * SAFE, hh, 22, 11, 'mj')
    text(gr, rx + 0.25, ry0 + 1.05, rw - 0.5, hh, clip(center, (rw - 0.5) * SAFE, hh, cs, 'mj'), size=cs, color=WHITE, font='mj',
         align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    ctx.anim(sl, gr, 'zoom', 300 + n * 150, 500)
    conclusion(ctx, sl, s, 600 + n * 150)
    return sl


RENDERERS_EXTRA = {
    'swot': render_swot, 'fishbone': render_fishbone, 'gantt': render_gantt, 'risk': render_risk,
    'iceberg': render_iceberg, 'puzzle': render_puzzle, 'balance': render_balance, 'checklist': render_checklist,
    'hero': render_hero, 'shift': render_shift, 'petals': render_petals, 'path': render_path,
    'mindmap': render_mindmap, 'converge': render_converge,
}
