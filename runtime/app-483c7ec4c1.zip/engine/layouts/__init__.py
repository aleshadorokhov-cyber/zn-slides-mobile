# -*- coding: utf-8 -*-
"""
layouts — РЕЕСТР УНИВЕРСАЛЬНЫХ МАКЕТОВ.

RENDERERS: имя макета из спецификации → функция отрисовки render(ctx, slide_spec).
Чтобы добавить новый макет:
  1) напишите функцию render_xxx(ctx, s) (образец — любой макет в items.py);
  2) зарегистрируйте её здесь в RENDERERS;
  3) опишите макет в engine/spec.py → LAYOUTS (название, описание, ограничения) —
     тогда его увидят веб-интерфейс и ИИ-планировщик.
"""
from .base import Ctx  # noqa: F401
from .data import render_chart, render_compare, render_table, render_text
from .items import (render_cards, render_conclusions, render_cycle, render_kpi, render_list, render_process,
                    render_target, render_timeline)
from .meta import render_agenda, render_end, render_section, render_title
from .schemes import (render_bars, render_bubbles, render_funnel, render_gauge, render_gears, render_honeycomb,
                      render_hub, render_image, render_layers, render_matrix, render_pillars, render_pyramid, render_roadmap,
                      render_stairs, render_tree, render_venn)
from .extra import RENDERERS_EXTRA
from .mapslide import RENDERERS_MAP
from .oilgas import RENDERERS_OILGAS

RENDERERS = {
    'title': render_title,
    'agenda': render_agenda,
    'section': render_section,
    'cards': render_cards,
    'list': render_list,
    'process': render_process,
    'timeline': render_timeline,
    'cycle': render_cycle,
    'target': render_target,
    'kpi': render_kpi,
    'table': render_table,
    'chart': render_chart,
    'compare': render_compare,
    'text': render_text,
    'conclusions': render_conclusions,
    # схемы и инфографика (schemes.py)
    'pyramid': render_pyramid,
    'funnel': render_funnel,
    'stairs': render_stairs,
    'matrix': render_matrix,
    'hub': render_hub,
    'honeycomb': render_honeycomb,
    'layers': render_layers,
    'pillars': render_pillars,
    'roadmap': render_roadmap,
    'gears': render_gears,
    'venn': render_venn,
    'gauge': render_gauge,
    'bars': render_bars,
    'bubbles': render_bubbles,
    'tree': render_tree,
    'image': render_image,
    'end': render_end,
}
# дополнительные схемы версии 1.4 (extra.py): SWOT, «рыбья кость», план-график, риски, айсберг…
RENDERERS.update(RENDERERS_EXTRA)
RENDERERS.update(RENDERERS_MAP)
# нефтегазовые схемы (oilgas.py): цепочка создания стоимости, скважина по интервалам, обустройство месторождения
RENDERERS.update(RENDERERS_OILGAS)
