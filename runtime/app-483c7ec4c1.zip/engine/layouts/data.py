# -*- coding: utf-8 -*-
"""
data.py — МАКЕТЫ ДЛЯ ДАННЫХ И ТЕКСТА: таблица, диаграмма, сравнение, текст с тезисом
==================================================================================

    table    — нативная таблица PowerPoint; ширины столбцов — по длине содержимого;
               высота строк оценивается заранее, и большая таблица сама делится на
               несколько слайдов «(продолжение)».
    chart    — нативная диаграмма (11 видов: столбцы, полосы, линия, кольцо, круг, с накоплением,
               100 %, области, радар, «столбцы и линия» на двух осях) + панель «Что показывают
               данные» с выводами (insights).
    compare  — две колонки: «было → стало», «плюсы / минусы», «вариант А / Б».
    text     — крупный ключевой тезис на синей панели + 1–4 абзаца пояснений.
"""
import math

from pptx.chart.axis import ValueAxis
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION, XL_MARKER_STYLE
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches as I
from pptx.util import Pt

from ..nts import config as C
from ..nts.config import CARD, LGRAY, PALEG, SOFT, rgb
from ..nts.effects import grad, shadow, text_alpha
from ..nts.shapes import grect, group, icon, line, rect, text
from ..nts.tables import NO_STYLE_TABLE_ID, cell_set
from ..textfit import LINE_FACTOR, clip, wrap_lines
from ..textutil import parse_number
from .base import (BLUE, DBLUE, DGREEN, GRAY, GREEN, LGREEN, NAVY, WHITE, common_size, conclusion,
                   content_slide, pair, stack_fit)

SERIES_COLORS = [NAVY, GREEN, BLUE, LGREEN, DBLUE, DGREEN]
POINT_COLORS = [NAVY, GREEN, BLUE, LGREEN, DBLUE, DGREEN, rgb('7FBFDD'), rgb('A5D8A2'), rgb('5A7FA8'), LGRAY]


# ======================================================================================
# ТАБЛИЦА
# ======================================================================================
def _is_numeric_col(rows, j):
    vals = [r[j] for r in rows if j < len(r) and str(r[j]).strip()]
    return bool(vals) and sum(parse_number(v) is not None for v in vals) >= 0.7 * len(vals)


def _lines(txt, w, size, font):
    return max(1, len(wrap_lines(txt or '', w, size, font)))


def _cell_grad(cell, j, ncol):
    """Градиентная шапка таблицы: от NAVY слева к BLUE справа (по столбцам)."""
    from lxml import etree
    tcPr = cell._tc.get_or_add_tcPr()
    for tag in ('a:solidFill', 'a:gradFill', 'a:noFill'):
        for el in tcPr.findall(qn(tag)):
            tcPr.remove(el)
    k1 = j / max(1, ncol)
    k2 = (j + 1) / max(1, ncol)

    def mix(k):
        a, b = (0x00, 0x32, 0x6E), (0x00, 0x78, 0xAE)
        return ''.join(f'{int(x + (y - x) * k):02X}' for x, y in zip(a, b))
    gf = etree.SubElement(tcPr, qn('a:gradFill'))
    gf.set('rotWithShape', '1')
    gs = etree.SubElement(gf, qn('a:gsLst'))
    for pos, col in ((0, mix(k1)), (100000, mix(k2))):
        g_ = etree.SubElement(gs, qn('a:gs'))
        g_.set('pos', str(pos))
        etree.SubElement(g_, qn('a:srgbClr')).set('val', col)
    etree.SubElement(gf, qn('a:lin')).set('ang', '0')
    # порядок дочерних элементов tcPr: границы (lnX) → заливка; заливку переносим в конец
    tcPr.remove(gf)
    tcPr.append(gf)


def render_table(ctx, s):
    cols, rows = s['columns'], s['rows']
    ncol = len(cols)
    size = 13 if ncol <= 4 else (12 if ncol <= 6 else (11 if ncol <= 8 else 10))
    hsize = size + 0.5
    lens = [max([len(str(cols[j]))] + [len(str(r[j])) for r in rows]) for j in range(ncol)]
    weights = [min(max(l, 5), 70) ** 0.75 for l in lens]
    widths = [C.CW * w / sum(weights) for w in weights]
    min_w = min(0.85, C.CW / ncol)                        # минимальная ширина столбца
    if min(widths) < min_w:
        # каждому столбцу — минимум, остаток ширины — пропорционально длине текста
        # (сумма всегда равна ширине слайда, отрицательных ширин не бывает)
        free = C.CW - min_w * ncol
        widths = [min_w + free * w / sum(weights) for w in weights]
    numeric = [_is_numeric_col(rows, j) for j in range(ncol)]
    pad = 0.2                                             # поля ячейки слева+справа

    def row_h(cells, sz, font_first='mj'):
        h = 0
        for j, c in enumerate(cells):
            font = 'b' if numeric[j] else (font_first if j == 0 else 'mn')
            h = max(h, _lines(str(c), widths[j] - pad, sz, font) * sz * LINE_FACTOR / 72)
        return max(0.36, h + 0.1)

    probe_top = 1.65 if s.get('subtitle') else 1.35
    probe_bottom = 5.95 if s.get('conclusion') else 6.85
    # маленькая таблица — крупнее шрифт (до 16 пт), пока помещается на один слайд с запасом
    for bigger in (16, 15, 14):
        if bigger <= size:
            break
        h_try = row_h(cols, bigger + 0.5, 'b') + sum(row_h(r, bigger) for r in rows) + len(rows) * 0.1
        if h_try <= (probe_bottom - probe_top) * 0.8:
            size, hsize = bigger, bigger + 0.5
            break
    def paginate(sz):
        """Деление строк на страницы при кегле sz: сначала «жадно» — сколько страниц нужно,
        затем строки распределяются РАВНОМЕРНО (без «хвоста» из 1–2 строк на последнем слайде)."""
        hh_ = row_h(cols, sz + 0.5, 'b')
        rh_ = [max(row_h(r, sz), 0.3 + sz / 72) for r in rows]
        av = probe_bottom - probe_top - hh_ - 0.05
        n_pages, used = 1, 0
        for h in rh_:
            if used and used + h > av:
                n_pages += 1
                used = 0
            used += h
        target = sum(rh_) / n_pages
        pg, cur, used = [], [], 0
        for i, h in enumerate(rh_):
            left_pages = n_pages - len(pg)
            if cur and (used + h > av or (used + h / 2 > target and left_pages > 1)):
                pg.append(cur)
                cur, used = [], 0
            cur.append(i)
            used += h
        pg.append(cur)
        return pg, hh_, rh_

    # если «хвост» маленький — пробуем шрифт на 0,5–1,5 пт меньше, чтобы уложиться в меньшее число слайдов
    best = None
    for sz in [size - d for d in (0, 0.5, 1, 1.5)]:
        if sz < 9.5:
            break
        pg, hh_, rh_ = paginate(sz)
        if best is None or len(pg) < len(best[0]):
            best = (pg, hh_, rh_, sz)
    pages, hh, rhs, size = best
    hsize = size + 0.5
    if len(pages) == 1:                                   # одна страница — строки растягиваются на всю высоту
        free = (probe_bottom - probe_top - 0.1) - hh - sum(rhs[i] for i in pages[0])
        if free > 0 and pages[0]:
            add = min(free / len(pages[0]), 0.55)
            rhs = [h + add for h in rhs]
            hh = hh + min(0.2, free * 0.05)
    first = None
    for pi, idxs in enumerate(pages):
        s2 = dict(s)
        if pi:
            s2['title'] = f'{s["title"]} (продолжение {pi + 1})' if len(pages) > 2 else f'{s["title"]} (продолжение)'
        if pi < len(pages) - 1:
            s2['conclusion'] = ''
        sl, top, bottom = content_slide(ctx, s2)
        first = first or sl
        total_h = hh + sum(rhs[i] for i in idxs)
        gf = sl.shapes.add_table(len(idxs) + 1, ncol, I(C.L), I(top + 0.05), I(C.CW), I(total_h))
        tbl = gf.table
        tblPr = tbl._tbl.tblPr
        for a in ('firstRow', 'bandRow'):
            tblPr.set(a, '0')
        sid = tblPr.find(qn('a:tableStyleId'))
        if sid is not None:
            sid.text = NO_STYLE_TABLE_ID
        for j, w in enumerate(widths):
            tbl.columns[j].width = I(w)
        tbl.rows[0].height = I(hh)
        for j, h_ in enumerate(cols):
            cell_set(tbl.cell(0, j), str(h_), size=hsize, color=WHITE, font='b', fill=NAVY,
                     align=PP_ALIGN.RIGHT if numeric[j] else PP_ALIGN.LEFT, sides='')
            _cell_grad(tbl.cell(0, j), j, ncol)
        for k, i in enumerate(idxs):
            tbl.rows[k + 1].height = I(rhs[i])
            zebra = WHITE if k % 2 == 0 else rgb('F3F6F9')
            for j in range(ncol):
                v = str(rows[i][j])
                if numeric[j]:
                    cell_set(tbl.cell(k + 1, j), v, size=size, color=NAVY, font='b', fill=zebra, align=PP_ALIGN.RIGHT)
                elif j == 0:
                    cell_set(tbl.cell(k + 1, j), v, size=size, color=NAVY, font='mj', fill=zebra)
                else:
                    cell_set(tbl.cell(k + 1, j), v, size=size, color=GRAY, fill=zebra)
        ctx.anim(sl, gf, 'wipe_b', 0, 800)
        conclusion(ctx, sl, s2, 900)
    return first


# ======================================================================================
# ДИАГРАММА
# ======================================================================================
CT = {'column': XL_CHART_TYPE.COLUMN_CLUSTERED, 'bar': XL_CHART_TYPE.BAR_CLUSTERED,
      'line': XL_CHART_TYPE.LINE_MARKERS, 'pie': XL_CHART_TYPE.PIE, 'doughnut': XL_CHART_TYPE.DOUGHNUT,
      'stacked': XL_CHART_TYPE.COLUMN_STACKED, 'area': XL_CHART_TYPE.AREA, 'radar': XL_CHART_TYPE.RADAR_FILLED,
      'stacked100': XL_CHART_TYPE.COLUMN_STACKED_100, 'bar_stacked': XL_CHART_TYPE.BAR_STACKED,
      'combo': XL_CHART_TYPE.COLUMN_CLUSTERED}         # combo: последний ряд переносится в линию (_to_combo)
STACKED = ('stacked', 'stacked100', 'bar_stacked')


def _xl_type(ctype, series):
    """Тип диаграммы PowerPoint. Несколько рядов «области» складываются (иначе передние закрывают задние)."""
    if ctype == 'area' and len(series) > 1 and all(v is None or v >= 0 for s in series for v in s['values']):
        return XL_CHART_TYPE.AREA_STACKED
    return CT[ctype]


def _series_alpha(ser, alpha):
    """Полупрозрачная заливка ряда диаграммы (alpha — непрозрачность в %)."""
    from lxml import etree
    sp = ser._element.find(qn('c:spPr'))
    clr = sp.find(qn('a:solidFill')).find(qn('a:srgbClr')) if sp is not None and sp.find(qn('a:solidFill')) is not None else None
    if clr is not None:
        for a in clr.findall(qn('a:alpha')):
            clr.remove(a)
        etree.SubElement(clr, qn('a:alpha')).set('val', str(int(alpha * 1000)))


def _num_format(series, unit):
    vals = [v for s in series for v in s['values'] if v is not None]
    if unit == '%':
        dec = 0 if all(float(v).is_integer() for v in vals) else 1
        return ('0' if dec == 0 else '0.0') + '"%"'
    if not vals:
        return 'General'
    if all(float(v).is_integer() for v in vals) or max(abs(v) for v in vals) >= 1000:
        return '#,##0'
    return '#,##0.0' if max(abs(v) for v in vals) >= 10 else '#,##0.00'


def _nice_step(span, ticks=5):
    """«Круглый» шаг оси (1, 2, 2,5, 5 × 10ⁿ), чтобы на span пришлось около ticks делений."""
    raw = span / ticks if span > 0 else 1
    e = 10 ** math.floor(math.log10(raw))
    return next(k * e for k in (1, 2, 2.5, 5, 10) if raw / e <= k + 1e-9)


def _combo_scales(bars, line):
    """Шкалы осей «столбцов и линии»: столбцы — в нижних ~2/3 высоты, линия — над ними, чтобы подписи
    столбцов и точек линии не налезали друг на друга. Числа не меняются — только пределы осей.
    → ((min, max, шаг) левой оси или None, (min, max, шаг) правой оси или None)."""
    def tidy(x, step):                                   # 1.2000000000000002 → 1.2
        return round(x, max(0, 2 - math.floor(math.log10(step))))
    left = right = None
    if bars and min(bars) >= 0 and max(bars) > 0:
        step = _nice_step(max(bars) / 0.68)
        left = (0, tidy(math.ceil(max(bars) / 0.68 / step) * step, step), step)
    if line:
        lo, hi = min(line), max(line)
        rng = (hi - lo) or (abs(hi) * 0.1) or 1
        step = _nice_step(rng / 0.2)                     # линия — полоса от 72 до ~92 % высоты
        amax = math.ceil((hi + 0.4 * rng) / step) * step
        amin = math.floor((lo - 0.72 * amax) / 0.28 / step) * step   # нижняя точка линии не ниже 72 %
        if lo >= 0 and amin < 0:                         # неотрицательные значения — ось от нуля, верх линии ~92 %
            step = _nice_step(hi / 0.92) if hi > 0 else 1
            amin, amax = 0, math.ceil(hi / 0.92 / step) * step if hi > 0 else 1
        right = (tidy(amin, step), tidy(amax, step), step)
    return left, right


def _to_combo(chart, fmt2):
    """«Столбцы + линия»: последний ряд столбчатой диаграммы переносится в линию по второй оси (справа),
    например добыча (тыс. т) и обводнённость (%). Ряд сохраняет ссылки на ячейки встроенной таблицы Excel."""
    from lxml import etree
    pa = chart._chartSpace.find('.//' + qn('c:plotArea'))
    bar = pa.find(qn('c:barChart'))
    ser = bar.findall(qn('c:ser'))[-1]
    bar.remove(ser)
    for tag in ('c:invertIfNegative', 'c:shape', 'c:pictureOptions'):     # в ряду линии их нет по схеме
        for e in ser.findall(qn(tag)):
            ser.remove(e)
    etree.SubElement(ser, qn('c:smooth')).set('val', '0')
    used = {a.get('val') for a in pa.iter(qn('c:axId'))}
    cat2, val2 = next(str(x) for x in range(50001, 60000) if str(x) not in used), None
    val2 = next(str(x) for x in range(int(cat2) + 1, 60000) if str(x) not in used)
    ln = etree.Element(qn('c:lineChart'))
    etree.SubElement(ln, qn('c:grouping')).set('val', 'standard')
    etree.SubElement(ln, qn('c:varyColors')).set('val', '0')
    ln.append(ser)
    etree.SubElement(ln, qn('c:marker')).set('val', '1')
    etree.SubElement(ln, qn('c:axId')).set('val', cat2)
    etree.SubElement(ln, qn('c:axId')).set('val', val2)
    bar.addnext(ln)

    def ax(tag, kids):
        a = etree.Element(qn(tag))
        for k, attrs in kids:
            e = etree.SubElement(a, qn(k))
            e.attrib.update(attrs)
            if k == 'c:scaling':
                etree.SubElement(e, qn('c:orientation')).set('val', 'minMax')
        return a
    cat = ax('c:catAx', [('c:axId', {'val': cat2}), ('c:scaling', {}), ('c:delete', {'val': '1'}),
                         ('c:axPos', {'val': 'b'}), ('c:majorTickMark', {'val': 'none'}),
                         ('c:minorTickMark', {'val': 'none'}), ('c:tickLblPos', {'val': 'nextTo'}),
                         ('c:crossAx', {'val': val2}), ('c:crosses', {'val': 'autoZero'}), ('c:auto', {'val': '1'}),
                         ('c:lblAlgn', {'val': 'ctr'}), ('c:lblOffset', {'val': '100'}),
                         ('c:noMultiLvlLbl', {'val': '0'})])
    val = ax('c:valAx', [('c:axId', {'val': val2}), ('c:scaling', {}), ('c:delete', {'val': '0'}),
                         ('c:axPos', {'val': 'r'}), ('c:numFmt', {'formatCode': fmt2, 'sourceLinked': '0'}),
                         ('c:majorTickMark', {'val': 'out'}), ('c:minorTickMark', {'val': 'none'}),
                         ('c:tickLblPos', {'val': 'nextTo'}), ('c:crossAx', {'val': cat2}),
                         ('c:crosses', {'val': 'max'}), ('c:crossBetween', {'val': 'between'})])
    last = [e for e in pa if e.tag in (qn('c:catAx'), qn('c:valAx'), qn('c:dateAx'), qn('c:serAx'))][-1]
    last.addnext(cat)
    cat.addnext(val)


def render_chart(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    ch = s['chart']
    ins = s.get('insights') or []
    ctype = ch['type']
    cats, series, unit = ch['categories'], ch['series'], ch.get('unit') or ''
    has_ins = bool(ins)
    cw = C.CW * 0.63 if has_ins else C.CW
    fmt = _num_format(series, unit)
    cd = CategoryChartData(number_format=fmt)
    cd.categories = cats
    for sr in series:
        cd.add_series(sr['name'], sr['values'])
    gf = sl.shapes.add_chart(_xl_type(ctype, series), I(C.L), I(top + 0.05), I(cw), I(bottom - top - 0.1), cd)
    chart = gf.chart
    fmt2 = ''
    if ctype == 'combo':
        fmt2 = _num_format(series[-1:], ch.get('unit2') or '')
        _to_combo(chart, fmt2)
        fmt = _num_format(series[:-1], unit)
    chart.font.size = Pt(11)
    chart.font.name = '+mn-lt'
    chart.font.color.rgb = GRAY
    chart.has_title = False
    multi = len(series) > 1
    if ctype in ('pie', 'doughnut'):
        chart.has_legend = True
        chart.legend.position = XL_LEGEND_POSITION.RIGHT
        chart.legend.include_in_layout = False
        chart.legend.font.size = Pt(12)
        plot = chart.plots[0]
        for i, pt in enumerate(plot.series[0].points):
            pt.format.fill.solid()
            pt.format.fill.fore_color.rgb = POINT_COLORS[i % len(POINT_COLORS)]
            pt.format.line.color.rgb = WHITE
            pt.format.line.width = Pt(2)
        plot.has_data_labels = True
        dl = plot.data_labels
        dl.number_format = '0%' if unit != '%' else fmt
        dl.number_format_is_linked = False
        if unit == '%':
            dl.show_value = True
        else:
            dl.show_percentage = True
            dl.show_value = False
        dl.font.size = Pt(13)
        dl.font.bold = True
        dl.font.color.rgb = WHITE
        if ctype == 'doughnut':
            dn = chart._chartSpace.find('.//' + qn('c:doughnutChart'))
            hs = dn.find(qn('c:holeSize'))
            if hs is not None:
                hs.set('val', '52')
    else:
        chart.has_legend = multi
        if multi:
            chart.legend.position = XL_LEGEND_POSITION.BOTTOM
            chart.legend.include_in_layout = False
            chart.legend.font.size = Pt(12)
        plot = chart.plots[0]
        # у «столбцов + линии» две оси значений; chart.value_axis в python-pptx отдаёт вторую — берём первую явно
        va = ValueAxis(chart._chartSpace.valAx_lst[0]) if ctype == 'combo' else chart.value_axis
        va.has_major_gridlines = True
        va.major_gridlines.format.line.color.rgb = rgb('E3E8EF')
        va.major_gridlines.format.line.width = Pt(0.75)
        va.format.line.fill.background()
        va.tick_labels.font.size = Pt(11)
        vmax = max([abs(v) for sr_ in series for v in sr_['values'] if v is not None] or [0])
        if ctype == 'combo':
            vmax = max([abs(v) for sr_ in series[:-1] for v in sr_['values'] if v is not None] or [0])
        va.tick_labels.number_format = ('0%' if ctype == 'stacked100'
                                        else '#,##0' if (vmax >= 10 and unit != '%') else fmt)
        va.tick_labels.number_format_is_linked = False
        ca = chart.category_axis
        ca.format.line.color.rgb = LGRAY
        ca.tick_labels.font.size = Pt(11 if len(cats) <= 8 else 10)
        ca.has_major_gridlines = False
        if ctype in ('bar', 'bar_stacked'):
            ca.reverse_order = True                     # первая категория — сверху
        if ctype in ('column', 'bar', 'combo') + STACKED:
            plot.gap_width = 50 if ctype in STACKED else 60
            if ctype not in STACKED:
                plot.overlap = -10 if len(plot.series) > 1 else 0
        if ctype == 'radar':
            ca.format.line.color.rgb = rgb('E3E8EF')           # «паутина» — светлая
            va.tick_labels.font.size = Pt(9)
            ca.tick_labels.font.size = Pt(12 if len(cats) <= 8 else 10.5)
            ca.tick_labels.font.color.rgb = NAVY
        for k, sr in enumerate(plot.series):
            col = SERIES_COLORS[k % len(SERIES_COLORS)]
            if ctype == 'radar':
                # полупрозрачные многоугольники с чёткой обводкой: видно и форму профиля, и наложение рядов
                sr.format.fill.solid()
                sr.format.fill.fore_color.rgb = col if multi else BLUE
                _series_alpha(sr, 30 if multi else 32)
                sr.format.line.color.rgb = col
                sr.format.line.width = Pt(2.5)
                continue
            if ctype == 'area':
                # несколько рядов — плотные слои с белыми границами; один ряд — светлая заливка под тёмной линией,
                # чтобы подписи значений читались и на заливке, и над ней
                sr.format.fill.solid()
                sr.format.fill.fore_color.rgb = col if multi else BLUE
                _series_alpha(sr, 88 if multi else 30)
                sr.format.line.color.rgb = WHITE if multi else NAVY
                sr.format.line.width = Pt(1.5 if multi else 2.75)
                continue
            if ctype == 'line':
                sr.format.line.color.rgb = col
                sr.format.line.width = Pt(2.75)
                sr.smooth = False
                sr.marker.style = XL_MARKER_STYLE.CIRCLE
                sr.marker.size = 7
                sr.marker.format.fill.solid()
                sr.marker.format.fill.fore_color.rgb = WHITE
                sr.marker.format.line.color.rgb = col
            else:
                sr.format.fill.solid()
                sr.format.fill.fore_color.rgb = col
                if not multi and ctype != 'combo':
                    # один ряд: максимальное значение выделяем зелёным
                    vals = series[0]['values']
                    good = [v for v in vals if v is not None]
                    if good:
                        mi = vals.index(max(good))
                        pt = sr.points[mi]
                        pt.format.fill.solid()
                        pt.format.fill.fore_color.rgb = GREEN
        if ctype == 'combo':
            va2 = ValueAxis(chart._chartSpace.valAx_lst[1])          # правая ось — для ряда-линии
            left, right = _combo_scales([v for sr_ in series[:-1] for v in sr_['values'] if v is not None],
                                        [v for v in series[-1]['values'] if v is not None])
            if all(v is None or v >= 0 for sr_ in series[:-1] for v in sr_['values']):
                va.minimum_scale = 0                    # столбцы — от нуля (иначе разница кажется больше, чем есть)
            for ax, sc in ((va, left), (va2, right)):
                if sc:
                    ax.minimum_scale, ax.maximum_scale, ax.major_unit = sc
            va2.has_major_gridlines = False
            va2.format.line.fill.background()
            va2.tick_labels.font.size = Pt(11)
            va2.tick_labels.font.color.rgb = DGREEN
            va2.tick_labels.number_format = fmt2
            va2.tick_labels.number_format_is_linked = False
            # ряд-линия по второй оси: тёмно-зелёная линия с белыми маркерами, подписи — над точками
            lsr = chart.plots[1].series[0]
            lsr.format.line.color.rgb = DGREEN
            lsr.format.line.width = Pt(3)
            lsr.smooth = False
            lsr.marker.style = XL_MARKER_STYLE.CIRCLE
            lsr.marker.size = 8
            lsr.marker.format.fill.solid()
            lsr.marker.format.fill.fore_color.rgb = WHITE
            lsr.marker.format.line.color.rgb = DGREEN
            if len(cats) <= 10:
                lp = chart.plots[1]
                lp.has_data_labels = True
                ldl = lp.data_labels
                ldl.number_format = fmt2
                ldl.number_format_is_linked = False
                ldl.font.size = Pt(10.5)
                ldl.font.bold = True
                ldl.font.color.rgb = DGREEN
                ldl.position = XL_LABEL_POSITION.ABOVE
        nbar = len(series) - (1 if ctype == 'combo' else 0)
        show_labels = ((nbar == 1 and len(cats) <= 12)
                       or (nbar > 1 and ctype not in STACKED and len(cats) * nbar <= 10)
                       or (ctype in STACKED and len(cats) <= 8))
        if ctype == 'radar':
            show_labels = not multi and len(cats) <= 10
        elif ctype == 'area':
            show_labels = False          # подписи «области» встают в середину заливки и налезают на края — читаем по оси
        if show_labels:
            plot.has_data_labels = True
            dl = plot.data_labels
            dl.number_format = fmt
            dl.number_format_is_linked = False
            dl.font.size = Pt(10.5 if len(cats) > 6 else 11.5)
            dl.font.bold = True
            # значения подписаны на столбцах — ось значений и сетка не нужны (чище)
            if ctype in ('column', 'bar') and not multi:
                va.visible = False
                va.has_major_gridlines = False
            if ctype in ('radar', 'area'):
                # у «радара» и «области» положение подписи не задаётся (формат PowerPoint его не допускает)
                dl.font.color.rgb = NAVY
                dl.show_value = True
            elif ctype in STACKED:
                dl.font.color.rgb = WHITE
                dl.position = XL_LABEL_POSITION.CENTER
                # маленькие сегменты (< 7 % высоты самого высокого столбца, у нормированной — < 7 % своего столбца)
                # — без подписи, чтобы не налезали
                tots = [sum(abs(sr_['values'][k] or 0) for sr_ in series) for k in range(len(cats))]
                lim = 0.07 * max(tots or [0])
                for si, sr_ in enumerate(series):
                    for k, v in enumerate(sr_['values']):
                        if v is None or abs(v) < (0.07 * tots[k] if ctype == 'stacked100' else lim):
                            _hide_label(plot.series[si], k)
            else:
                dl.font.color.rgb = NAVY
                dl.position = XL_LABEL_POSITION.ABOVE if ctype == 'line' else XL_LABEL_POSITION.OUTSIDE_END
    ctx.anim(sl, gf, 'wipe_l' if ctype not in ('pie', 'doughnut', 'radar') else 'zoom', 0, 900)
    # ---- панель выводов ----------------------------------------------------------------
    if has_ins:
        px = C.L + cw + 0.3
        pw = C.R - px
        g = group(sl)
        icon(g, 'TbBulb', 'd', px, top + 0.08, 0.42)
        text(g, px + 0.52, top + 0.05, pw - 0.52, 0.48, 'Что показывают данные', size=16, color=NAVY, font='mj',
             anchor=MSO_ANCHOR.MIDDLE)
        ctx.anim(sl, g, 'fade', 500, 500)
        n = len(ins)
        gap = 0.14
        y0 = top + 0.65
        bh = min(1.25, (bottom - y0 - gap * (n - 1)) / n)
        size = common_size(ins, pw - 0.4, bh - 0.16, 14, 10.5, 'mn')
        for i, t in enumerate(ins):
            gi = group(sl)
            y = y0 + i * (bh + gap)
            b = rect(gi, px, y, pw, bh, fill=SOFT)
            shadow(b, 8, 2, 12)
            rect(gi, px, y, 0.07, bh, fill=[NAVY, BLUE, DGREEN, GREEN][i % 4])
            text(gi, px + 0.22, y, pw - 0.32, bh, clip(t, pw - 0.4, bh - 0.16, size, 'mn'), size=size, color=NAVY,
                 anchor=MSO_ANCHOR.MIDDLE)
            ctx.anim(sl, gi, 'wipe_l', 800 + i * 200, 450)
    conclusion(ctx, sl, s, 1200 + len(ins) * 200)
    return sl


def _hide_label(ser, idx):
    """Скрыть подпись одной точки ряда (c:dLbl с c:delete)."""
    from lxml import etree
    dLbls = ser._element.get_or_add_dLbls()
    d = etree.Element(qn('c:dLbl'))
    etree.SubElement(d, qn('c:idx')).set('val', str(idx))
    etree.SubElement(d, qn('c:delete')).set('val', '1')
    first = dLbls.find(qn('c:numFmt'))
    dLbls.insert(0, d) if first is None else first.addprevious(d)


# ======================================================================================
# СРАВНЕНИЕ
# ======================================================================================
STYLES = {
    # стиль: (левая шапка: цвета, иконка шапки, иконка пункта, фон пункта), (правая …)
    'before_after': (((LGRAY, LGRAY), 'TbClockHour4', 'TbX', SOFT, NAVY),
                     ((DGREEN, GREEN), 'TbRocket', 'TbCircleCheck', PALEG, WHITE)),
    'pros_cons':    (((DGREEN, GREEN), 'TbThumbUp', 'TbCircleCheck', PALEG, WHITE),
                     ((LGRAY, LGRAY), 'TbAlertCircle', 'TbX', SOFT, NAVY)),
    'neutral':      (((NAVY, DBLUE), 'TbCircleDot', 'TbPoint', SOFT, WHITE),
                     ((BLUE, rgb('2E95C4')), 'TbCircleDot', 'TbPoint', CARD, WHITE)),
}


def render_compare(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    st = STYLES[s.get('style') or 'before_after']
    L_, R_ = s['left'], s['right']
    aligned = len(L_['items']) == len(R_['items']) and s.get('style', 'before_after') == 'before_after'
    mid = 0.6 if aligned else 0.35
    cw = (C.CW - mid) / 2
    hh = 0.62
    n = max(len(L_['items']), len(R_['items']), 1)
    gap = 0.1
    y0 = top + hh + 0.18
    rh = min(1.0, (bottom - y0 - gap * (n - 1)) / n)
    tw = cw - 0.62 - 0.15
    size = common_size(L_['items'] + R_['items'], tw, rh - 0.1, 15, 10.5, 'mn')
    for side, data, (cols, hic, iic, bg, tcol) in ((0, L_, st[0]), (1, R_, st[1])):
        x = C.L + side * (cw + mid)
        g = group(sl)
        hdr = grect(g, x, top, cw, hh, cols[0], cols[1], 0)
        if cols[0] != LGRAY:
            shadow(hdr, 10, 3, 22)
        icn = 'w' if tcol == WHITE else 'n'
        icon(g, hic, icn, x + 0.2, top + (hh - 0.38) / 2, 0.38)
        text(g, x + 0.72, top, cw - 0.8, hh, clip(data['title'], cw - 0.8, hh, 17, 'mj', 1), size=17, color=tcol,
             font='mj', anchor=MSO_ANCHOR.MIDDLE)
        ctx.anim(sl, g, 'fade' if side == 0 else 'zoom', side * 300, 500)
        for i, t in enumerate(data['items']):
            y = y0 + i * (rh + gap)
            gi = group(sl)
            b = rect(gi, x, y, cw, rh, fill=bg)
            if side == 1:
                shadow(b, 8, 2, 14)
            icon(gi, iic, 'd' if iic == 'TbCircleCheck' else 'n', x + 0.17, y + (rh - 0.34) / 2, 0.34)
            text(gi, x + 0.62, y, tw, rh, clip(t, tw, rh - 0.1, size, 'mn'), size=size,
                 color=NAVY if side == 1 and s.get('style', 'before_after') == 'before_after' else GRAY,
                 font='b' if side == 1 and s.get('style', 'before_after') == 'before_after' else 'mn',
                 anchor=MSO_ANCHOR.MIDDLE)
            if aligned and side == 1:
                line(gi, C.L + cw + 0.1, y + rh / 2, C.L + cw + mid - 0.1, y + rh / 2, color=GREEN, w=2.25)
            ctx.anim(sl, gi, 'fade' if side == 0 else 'wipe_l', 500 + i * 160 + side * 120, 400)
    conclusion(ctx, sl, s, 800 + n * 160)
    return sl


# ======================================================================================
# ТЕКСТ С КЛЮЧЕВЫМ ТЕЗИСОМ
# ======================================================================================
def _render_quote(ctx, s):
    """Вариант «цитата»: ключевая мысль крупно на светлом фоне с кавычкой, пояснения — плитками снизу."""
    sl, top, bottom = content_slide(ctx, s)
    lead = s.get('lead') or ''
    paras = [p for p in (s.get('paragraphs') or []) if p]
    avail = bottom - top - 0.05
    lw = C.CW - 1.9
    qh = avail
    if paras:                                    # высота цитаты — по тексту: длинным пояснениям — больше места
        n = len(paras)
        pw = (C.CW - 0.22 * (n - 1)) / n
        best = None
        for r in (0.3, 0.35, 0.4, 0.45, 0.5, 0.55):
            qh_ = avail * r
            ph_ = avail - qh_ - 0.3
            ls_ = common_size([lead], lw, qh_ - 0.5, 28, 15, 'mj')
            ps_ = common_size(paras, pw - 0.5, ph_ - 0.35, 18, 10.5, 'mn')
            sc = min(ls_ / 28, ps_ / 16)
            if best is None or sc > best[0] + 1e-6:
                best = (sc, qh_)
        qh = best[1]
    g = group(sl)
    bg = rect(g, C.L, top, C.CW, qh, fill=SOFT, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.06)
    grad(bg, rgb('EEF3F8'), rgb('F7FAF2'), 0)
    shadow(bg, 10, 3, 14)
    side = grect(g, C.L, top, 0.14, qh, GREEN, NAVY, 90)
    q = text(g, C.L + 0.35, top - 0.25, 1.6, 1.6, '«', size=120, color=GREEN, font='b')
    text_alpha(q, 35)
    lsz = common_size([lead], lw, qh - 0.5, 34 if not paras else 28, 15, 'mj')
    text(g, C.L + 1.5, top + 0.2, lw, qh - 0.4, clip(lead, lw, qh - 0.5, lsz, 'mj'), size=lsz, color=NAVY, font='mj',
         anchor=MSO_ANCHOR.MIDDLE)
    ctx.anim(sl, g, 'fade', 0, 600)
    if paras:
        n = len(paras)
        gap = 0.22
        pw = (C.CW - gap * (n - 1)) / n
        py = top + qh + 0.25
        ph = bottom - py - 0.05
        size = common_size(paras, pw - 0.5, ph - 0.35, 18, 10.5, 'mn')
        for i, p in enumerate(paras):
            c1, c2 = pair(i, n)
            gi = group(sl)
            card = rect(gi, C.L + i * (pw + gap), py, pw, ph, fill=WHITE)
            shadow(card, 10, 3, 16)
            st = rect(gi, C.L + i * (pw + gap), py, 0.08, ph, fill=c1)
            grad(st, c1, c2, 90)
            text(gi, C.L + i * (pw + gap) + 0.3, py + 0.15, pw - 0.5, ph - 0.3, clip(p, pw - 0.5, ph - 0.35, size, 'mn'),
                 size=size, color=GRAY, anchor=MSO_ANCHOR.MIDDLE)
            ctx.anim(sl, gi, 'rise', 400 + i * 200, 450)
    conclusion(ctx, sl, s, 800)
    return sl


def render_text(ctx, s):
    if s.get('variant') == 'quote' or not [p for p in (s.get('paragraphs') or []) if p]:
        return _render_quote(ctx, s)
    sl, top, bottom = content_slide(ctx, s)
    lead = s.get('lead') or ''
    paras = s.get('paragraphs') or []
    avail = bottom - top - 0.05
    px = C.L
    if lead:
        lw = 4.6 if paras else C.CW
        g = group(sl)
        panel = grect(g, C.L, top, lw, avail, NAVY, BLUE, 90)
        shadow(panel, 14, 4, 24)
        icon(g, 'TbBulb', 'w', C.L + 0.35, top + 0.35, 0.55)
        lh = avail - 1.6                                # между значком и чертой внизу
        lsz = common_size([lead], lw - 0.7, lh, 30 if paras else 36, 15, 'mj')
        text(g, C.L + 0.35, top + 1.0, lw - 0.7, lh, clip(lead, lw - 0.7, lh, lsz, 'mj'),
             size=lsz, color=WHITE, font='mj', anchor=MSO_ANCHOR.MIDDLE)
        rect(g, C.L + 0.35, top + avail - 0.35, 0.9, 0.05, fill=LGREEN)
        ctx.anim(sl, g, 'rise', 0, 600)
        px = C.L + lw + 0.4
    if paras:
        pw = C.R - px
        n = len(paras)
        gap = 0.22
        # общий кегль — наибольший, при котором все абзацы вместе занимают колонку; высоты — по тексту
        size, hs = stack_fit(paras, pw - 0.35, avail, 22 if n <= 2 else (20 if n == 3 else 18), 11, 'mn',
                             pad=0.14, gap=gap)
        y = top
        for i, (p, h) in enumerate(zip(paras, hs)):
            gi = group(sl)
            rect(gi, px, y + 0.05, 0.06, h - 0.1, fill=[GREEN, BLUE, DGREEN, NAVY][i % 4])
            text(gi, px + 0.3, y, pw - 0.3, h, clip(p, pw - 0.35, h - 0.1, size, 'mn'), size=size, color=GRAY,
                 anchor=MSO_ANCHOR.MIDDLE if n > 1 else MSO_ANCHOR.TOP)
            ctx.anim(sl, gi, 'fade', 500 + i * 250, 500)
            y += h + gap
    conclusion(ctx, sl, s, 800 + len(paras) * 250)
    return sl
