# -*- coding: utf-8 -*-
"""
llm_client.py — ПОДКЛЮЧЕНИЕ К МОДЕЛИ ИИ: ЛОКАЛЬНОЙ (ПО УМОЛЧАНИЮ) ИЛИ ОБЛАЧНОЙ (ТОЛЬКО ПО СОГЛАСИЮ)
=================================================================================================

Локальные модели — данные остаются в Компании:

  provider = 'ollama'  — Ollama (https://ollama.com), «родной» API:  POST {base_url}/api/chat
                         base_url по умолчанию: http://localhost:11434
  provider = 'openai'  — любой OpenAI-совместимый сервер: LM Studio (http://localhost:1234/v1),
                         vLLM (http://сервер:8000/v1), llama.cpp server, LocalAI, TGI и т. п.
                         POST {base_url}/chat/completions

Облачные модели — данные уходят во внешний сервис (таблица PROVIDERS ниже): GigaChat, YandexGPT,
OpenAI, Anthropic (Claude), Google Gemini, DeepSeek, Mistral, xAI, Qwen, Kimi, GLM, Groq, Together AI,
OpenRouter и «другой облачный сервис». Почти все они понимают API OpenAI (адрес + ключ + модель),
поэтому описаны данными, а не отдельным кодом. Особых случаев три:
  * Anthropic — собственный Messages API: POST {base}/v1/messages, заголовки x-api-key и anthropic-version;
  * GigaChat  — сначала OAuth: «ключ авторизации» (Basic) → токен доступа на 30 минут (хранится в памяти
                до истечения), дальше — API как у OpenAI с этим токеном;
  * YandexGPT — заголовок «Api-Key <ключ>» или «Bearer <IAM-токен>», модель — gpt://<каталог>/<модель>/latest.
Адрес (base_url) можно поменять у любого сервиса — например, на шлюз Компании или агрегатор.

Правила безопасности проверяются здесь же, в chat() и list_models(), — их не обойти из других модулей:
  * облачная модель вызывается только при согласии пользователя: cloud_consent = true
    (галочка в окне «⚙ Модель ИИ»);
  * администратор запрещает облачные модели совсем: "allow_cloud": false в settings.json
    (приложение передаёт его сюда как cfg['allow_cloud']) или переменная окружения ZN_NO_CLOUD=1;
  * облачной считается и «локальная» модель, если её адрес — вне сети Компании (is_cloud);
  * локальные серверы — без системного прокси (use_proxy=false, как раньше), чтобы запросы
    не ушли «наружу»; облачные — через системный прокси (как браузер) или явно указанный proxy;
  * ключи API не попадают в журналы и тексты ошибок.

Используется только стандартная библиотека Python (urllib, ssl) — дополнительных пакетов не нужно.
"""
import hashlib
import ipaddress
import json
import os
import re
import socket
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

DEFAULTS = {
    'provider': 'ollama',
    'base_url': 'http://localhost:11434',
    'model': 'qwen3:14b',
    'temperature': 0.2,
    'num_ctx': 16384,          # размер контекста (только Ollama): документ + ответ должны поместиться
    'timeout': 600,            # секунд на ответ модели (большие модели на CPU думают долго)
    'json_mode': True,         # просить сервер вернуть строго JSON (если сервер это умеет)
    'api_key': '',             # ключ выбранного сервиса (локальные — если сервер запущен с ключом: vLLM --api-key …)
    'api_keys': {},            # ключи по сервисам {provider: ключ}: при смене сервиса ключи не теряются
    'max_chars': 14000,        # сколько символов документа отправлять модели (сжатая выжимка)
    'use_proxy': False,        # ЛОКАЛЬНЫЕ серверы: системный прокси не используется
    'keep_alive': '30m',       # Ollama: держать модель в памяти после запроса (не грузить заново)
    'illustrations': 2,        # сколько иллюстраций модель рисует сама при ИИ-анализе (0 — только по кнопке)
    # ---- облачные модели ----
    'cloud_consent': False,    # согласие отправлять текст документов во внешний сервис
    'proxy': '',               # прокси облачных запросов: '' — системный, 'нет' — напрямую, http://прокси:порт
    'ca_file': '',             # дополнительные корневые сертификаты (PEM): НУЦ Минцифры, прокси Компании
    'folder_id': '',           # YandexGPT: идентификатор каталога Yandex Cloud
    'yandex_auth': 'api_key',  # YandexGPT: 'api_key' — «Api-Key <ключ>», 'bearer' — «Bearer <IAM-токен>»
    'gigachat_scope': 'GIGACHAT_API_PERS',   # GigaChat: область доступа (PERS / B2B / CORP)
    'auth_url': '',            # GigaChat: адрес выдачи токена ('' — стандартный)
}

# --------------------------------------------------------------------------------------
# Таблица сервисов
# --------------------------------------------------------------------------------------
# Группы — в таком порядке они идут в списке «Где работает модель».
GROUPS = [
    ('local', 'Локальная — данные остаются в Компании'),
    ('ru', 'Облачная российская — данные уходят во внешний сервис в РФ'),
    ('intl', 'Облачная международная — данные уходят за рубеж'),
    ('open', 'Открытые модели в облаке — данные уходят за рубеж'),
    ('agg', 'Агрегатор — данные уходят за рубеж'),
    ('other', 'Другой облачный сервис'),
]
ABROAD = 'Из России может понадобиться шлюз Компании или агрегатор: укажите его адрес и прокси.'
GIGACHAT_SCOPES = ('GIGACHAT_API_PERS', 'GIGACHAT_API_B2B', 'GIGACHAT_API_CORP')


def _p(pid, name, short, group, base_url, model, models, hint, key_url='', note='', api='openai',
       auth='bearer', json_ok=True, **extra):
    """Строка таблицы сервисов.
    api  — протокол: 'ollama', 'openai' (почти все) или 'anthropic';
    auth — 'none' (ключ необязателен), 'bearer', 'anthropic', 'gigachat' (OAuth), 'yandex';
    json_ok — понимает ли сервис response_format {"type": "json_object"};
    extra: max_field (имя поля «длина ответа»), usage (просить счёт токенов в потоке),
           headers (доп. заголовки), auth_url (GigaChat), key_required."""
    return {'id': pid, 'name': name, 'short': short, 'group': group, 'cloud': group != 'local',
            'base_url': base_url, 'model': model, 'models': list(models), 'hint': hint, 'key_url': key_url,
            'note': note, 'api': api, 'auth': auth, 'json': json_ok, **extra}


PROVIDERS = [
    _p('ollama', 'Ollama', 'Ollama', 'local', 'http://localhost:11434', 'qwen3:14b',
       ['qwen3:14b', 'qwen2.5:14b-instruct', 'qwen2.5:7b-instruct'],
       'на этом компьютере или сервере Компании', api='ollama', auth='none'),
    _p('openai', 'OpenAI-совместимый сервер (LM Studio, vLLM, llama.cpp…)', 'Локальный сервер', 'local',
       'http://localhost:1234/v1', '', [], 'LM Studio, vLLM, llama.cpp, LocalAI — в сети Компании', auth='none'),
    # ---- российские ----
    _p('gigachat', 'GigaChat (Сбер)', 'GigaChat', 'ru', 'https://gigachat.devices.sberbank.ru/api/v1', 'GigaChat-2',
       ['GigaChat-2', 'GigaChat-2-Pro', 'GigaChat-2-Max'], 'российская, данные в РФ; хорошо пишет по-русски',
       'https://developers.sber.ru/studio',
       'Ключ — «Ключ авторизации» из личного кабинета GigaChat API. Нужен корневой сертификат НУЦ Минцифры: '
       'установлен в Windows или файл в поле «Сертификаты».',
       auth='gigachat', json_ok=False, auth_url='https://ngw.devices.sberbank.ru:9443/api/v2/oauth'),
    _p('yandexgpt', 'YandexGPT (Yandex Cloud)', 'YandexGPT', 'ru', 'https://llm.api.cloud.yandex.net/v1',
       'yandexgpt/latest', ['yandexgpt/latest', 'yandexgpt-lite/latest'],
       'российская, данные в РФ; lite — быстро и дёшево', 'https://console.yandex.cloud',
       'API-ключ сервисного аккаунта с ролью ai.languageModels.user и идентификатор каталога (folder_id).',
       auth='yandex'),
    # ---- международные ----
    _p('openai_cloud', 'OpenAI (GPT)', 'OpenAI', 'intl', 'https://api.openai.com/v1', 'gpt-5-mini',
       ['gpt-5', 'gpt-5-mini', 'gpt-4.1'], 'универсальная, сильные рассуждения',
       'https://platform.openai.com/api-keys', ABROAD, max_field='max_completion_tokens', usage=True),
    _p('anthropic', 'Anthropic (Claude)', 'Anthropic', 'intl', 'https://api.anthropic.com', 'claude-sonnet-5-5',
       ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-5-5'], 'большие документы, аккуратный деловой текст',
       'https://console.anthropic.com/settings/keys', ABROAD, api='anthropic', auth='anthropic', json_ok=False),
    _p('gemini', 'Google Gemini', 'Google Gemini', 'intl', 'https://generativelanguage.googleapis.com/v1beta/openai',
       'gemini-2.5-flash', ['gemini-2.5-pro', 'gemini-2.5-flash'], 'очень большой контекст; flash — быстро',
       'https://aistudio.google.com/apikey', ABROAD),
    _p('deepseek', 'DeepSeek', 'DeepSeek', 'intl', 'https://api.deepseek.com/v1', 'deepseek-chat',
       ['deepseek-chat', 'deepseek-reasoner'], 'дёшево; deepseek-reasoner — рассуждения',
       'https://platform.deepseek.com/api_keys', 'Серверы сервиса — в КНР.', usage=True),
    _p('mistral', 'Mistral AI', 'Mistral', 'intl', 'https://api.mistral.ai/v1', 'mistral-large-latest',
       ['mistral-large-latest', 'mistral-small-latest'], 'европейский сервис; small — быстро и дёшево',
       'https://console.mistral.ai/api-keys', ABROAD),
    _p('xai', 'xAI (Grok)', 'xAI Grok', 'intl', 'https://api.x.ai/v1', 'grok-4', ['grok-4'], 'рассуждения',
       'https://console.x.ai', ABROAD),
    # ---- открытые модели в облаке ----
    _p('qwen', 'Alibaba Qwen (DashScope)', 'Qwen', 'open', 'https://dashscope-intl.aliyuncs.com/compatible-mode/v1',
       'qwen-plus', ['qwen-max', 'qwen-plus', 'qwen-turbo'], 'открытые модели Qwen; turbo — быстро и дёшево',
       'https://www.alibabacloud.com/help/en/model-studio/get-api-key'),
    _p('kimi', 'Moonshot Kimi', 'Kimi', 'open', 'https://api.moonshot.ai/v1', 'kimi-k2-0905-preview',
       ['kimi-k2-0905-preview', 'kimi-k2-turbo-preview', 'kimi-k2-thinking'], 'большой контекст — длинные документы',
       'https://platform.moonshot.ai/console/api-keys'),
    _p('glm', 'Zhipu GLM', 'GLM', 'open', 'https://open.bigmodel.cn/api/paas/v4', 'glm-4.6',
       ['glm-4.6', 'glm-4.5-air'], 'открытые модели GLM', 'https://open.bigmodel.cn/usercenter/apikeys',
       'Международный адрес: https://api.z.ai/api/paas/v4'),
    _p('groq', 'Groq', 'Groq', 'open', 'https://api.groq.com/openai/v1', 'llama-3.3-70b-versatile',
       ['llama-3.3-70b-versatile', 'openai/gpt-oss-120b'], 'очень быстро: сотни токенов в секунду',
       'https://console.groq.com/keys', ABROAD),
    _p('together', 'Together AI', 'Together AI', 'open', 'https://api.together.xyz/v1',
       'meta-llama/Llama-3.3-70B-Instruct-Turbo',
       ['meta-llama/Llama-3.3-70B-Instruct-Turbo', 'Qwen/Qwen2.5-72B-Instruct-Turbo', 'deepseek-ai/DeepSeek-V3'],
       'открытые модели: Llama, Qwen, DeepSeek', 'https://api.together.ai/settings/api-keys', ABROAD),
    # ---- агрегаторы ----
    _p('openrouter', 'OpenRouter', 'OpenRouter', 'agg', 'https://openrouter.ai/api/v1', 'openai/gpt-5-mini',
       ['openai/gpt-5-mini', 'openai/gpt-5', 'anthropic/claude-sonnet-5.5', 'deepseek/deepseek-chat',
        'google/gemini-2.5-flash', 'qwen/qwen-plus'],
       'один ключ — много моделей разных компаний', 'https://openrouter.ai/keys',
       headers={'X-Title': 'ZN Presentation Builder'}),
    # ---- свой адрес ----
    _p('cloud_openai', 'Другой облачный сервис (OpenAI-совместимый)', 'Облачный сервис', 'other', '', '', [],
       'шлюз Компании или любой сервис с API как у OpenAI', note='Адрес — до /chat/completions, например https://шлюз/v1.',
       key_required=False),
]
PROVIDER = {p['id']: p for p in PROVIDERS}
CLOUD_PROVIDERS = tuple(p['id'] for p in PROVIDERS if p['cloud'])

# внутренние имена: этот компьютер, сеть Компании (кроме того, адреса из internal_domains в settings.json)
LOCAL_SUFFIXES = ('.local', '.lan', '.corp', '.internal', '.intranet', '.localdomain', '.home.arpa', '.localhost')
LOCKED_MSG = ('Облачные модели отключены администратором. Выберите локальную модель (Ollama или сервер '
              'Компании) в окне «⚙ Модель ИИ».')
MASK = '••••'


class LLMError(Exception):
    """Ошибка обращения к модели. status — код HTTP (если был), raw — текст ответа сервера (без ключей)."""

    def __init__(self, msg='', status=None, raw=''):
        super().__init__(msg)
        self.status, self.raw = status, raw


class Cancelled(LLMError):
    """Пользователь отменил запрос."""


class CloudRefused(LLMError):
    """Облачная модель не вызвана: нет согласия или запрет администратора (документы не отправлены)."""


def provider_table():
    """Таблица сервисов для окна настроек (без служебных полей)."""
    keys = ('id', 'name', 'short', 'group', 'cloud', 'base_url', 'model', 'models', 'hint', 'key_url', 'note', 'auth')
    return [{k: p[k] for k in keys} | {'key_required': p['auth'] != 'none' and p.get('key_required', True)}
            for p in PROVIDERS]


def _provider(cfg):
    p = PROVIDER.get(cfg.get('provider') or 'ollama')
    if p is None:
        raise LLMError(f'неизвестный тип сервера модели «{cfg.get("provider")}»')
    return p


# --------------------------------------------------------------------------------------
# Облако: что считается облачным, согласие, запрет администратора
# --------------------------------------------------------------------------------------
def _domains(cfg):
    d = cfg.get('internal_domains') or []
    if isinstance(d, str):
        d = re.split(r'[,;\s]+', d)
    return [str(x).strip().lower().lstrip('.') for x in d if str(x).strip()]


def _local_host(host, internal=()):
    """Адрес внутри Компании: этот компьютер, частная сеть (10.*, 172.16–31.*, 192.168.*), имя без точки
    («llm-server»), внутренние зоны (.local, .corp…) и домены из internal_domains."""
    host = (host or '').strip('[]').lower().rstrip('.')
    if not host:
        return True
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_private or ip.is_loopback or ip.is_link_local
    except ValueError:
        pass
    if host == 'localhost' or '.' not in host:
        return True
    return host.endswith(LOCAL_SUFFIXES) or any(host == d or host.endswith('.' + d) for d in internal)


def _host(url):
    try:
        return urllib.parse.urlsplit(str(url or '')).hostname or ''
    except ValueError:
        return ''


def is_cloud(cfg):
    """Облачная ли модель (текст документов уходит за пределы Компании). Все облачные сервисы таблицы —
    да; локальный тип сервера — если его адрес вне сети Компании (например, https://api.openai.com/v1
    в поле «Адрес» у «OpenAI-совместимого сервера»). Неизвестный тип — осторожно считается облачным."""
    cfg = cfg or {}
    p = PROVIDER.get(cfg.get('provider') or 'ollama')
    if p is None or p['cloud']:
        return True
    return not _local_host(_host(cfg.get('base_url') or DEFAULTS['base_url']), _domains(cfg))


def cloud_locked(cfg=None):
    """Облачные модели запрещены администратором: ZN_NO_CLOUD=1 или "allow_cloud": false в settings.json."""
    env = str(os.environ.get('ZN_NO_CLOUD') or '').strip().lower()
    return env in ('1', 'true', 'yes', 'on', 'да') or (cfg or {}).get('allow_cloud') is False


def provider_name(cfg):
    p = PROVIDER.get((cfg or {}).get('provider') or 'ollama')
    return p['short'] if p else str((cfg or {}).get('provider'))


def cloud_refusal(cfg, consent=True):
    """None — обращение к модели разрешено; иначе понятный текст отказа: облачная модель запрещена
    администратором или (при consent=True) пользователь не дал согласия. consent=False — проверяется
    только запрет: так проверяется список моделей, при котором документы не отправляются."""
    cfg = cfg or {}
    if not is_cloud(cfg):
        return None
    if cloud_locked(cfg):
        return LOCKED_MSG
    if consent and not cfg.get('cloud_consent'):
        p = PROVIDER.get(cfg.get('provider') or 'ollama')
        if p is not None and not p['cloud']:
            return (f'Адрес модели {_host(cfg.get("base_url"))} — вне сети Компании, текст документов ушёл бы '
                    'во внешний сервис. Запрос не отправлен. Если это сервер Компании, администратор может '
                    'добавить его домен в "internal_domains" файла settings.json; если сервис внешний и '
                    'материалы разрешено передавать — отметьте в окне «⚙ Модель ИИ» галочку согласия.')
        return (f'Модель «{provider_name(cfg)}» — облачная: текст документов уйдёт во внешний сервис. '
                'Без согласия запрос не отправлен. Если материалы разрешено передавать за пределы Компании, '
                'отметьте в окне «⚙ Модель ИИ» галочку «Разрешаю отправлять документы во внешний облачный сервис».')
    return None


def describe(cfg):
    """Сведения о модели для интерфейса и сведений анализа: сервис, модель, облачная ли."""
    cfg = {**DEFAULTS, **(cfg or {})}
    return {'llm_provider': cfg.get('provider'), 'llm_provider_name': provider_name(cfg),
            'llm_model': cfg.get('model') or '', 'llm_cloud': is_cloud(cfg)}


# --------------------------------------------------------------------------------------
# Соединение: прокси, сертификаты, ключи
# --------------------------------------------------------------------------------------
def _proxy_setting(cfg):
    p = str(cfg.get('proxy') or '').strip()
    return 'direct' if p.lower() in ('нет', 'none', 'direct', 'no', 'off', '-', 'напрямую') else p


def _ssl_context(cfg):
    """Контекст TLS с дополнительными корневыми сертификатами из ca_file (к системным, не вместо них).
    Проверка сертификатов не отключается никогда."""
    ca = str(cfg.get('ca_file') or '').strip().strip('"')
    if not ca:
        return None
    ctx = ssl.create_default_context()
    try:
        ctx.load_verify_locations(cafile=ca)
    except (OSError, ssl.SSLError) as e:
        raise LLMError(f'файл сертификатов «{ca}» не прочитан ({e}). Нужен файл PEM (Base64) с корневым сертификатом.')
    # Python 3.13+ по умолчанию требует строгого соответствия RFC 5280; корневые сертификаты НУЦ Минцифры
    # и прокси Компаний ему соответствуют не всегда. Цепочка и имя сервера по-прежнему проверяются.
    ctx.verify_flags &= ~getattr(ssl, 'VERIFY_X509_STRICT', 0)
    return ctx


def _opener(cfg, url=''):
    """Локальный тип сервера — как раньше: без системного прокси, если use_proxy не включён.
    Облачный сервис — явный proxy, «нет» (напрямую) или системный прокси (переменные окружения,
    настройки Windows — как у браузера); адреса внутри сети Компании — напрямую."""
    handlers = []
    p = PROVIDER.get(cfg.get('provider') or 'ollama')
    if p is None or not p['cloud']:
        if not cfg.get('use_proxy'):
            handlers.append(urllib.request.ProxyHandler({}))
    else:
        px = _proxy_setting(cfg)
        if px == 'direct' or (not px and _local_host(_host(url), _domains(cfg))):
            handlers.append(urllib.request.ProxyHandler({}))
        elif px:
            handlers.append(urllib.request.ProxyHandler({'http': px, 'https': px}))
    ctx = _ssl_context(cfg)
    if ctx is not None:
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
    return urllib.request.build_opener(*handlers)


def _key(cfg):
    """Ключ выбранного сервиса (api_key; для командной строки — из api_keys). Лишние приставки
    («Bearer », «Basic », «Api-Key »), скопированные вместе с ключом, отбрасываются."""
    k = str(cfg.get('api_key') or '').strip()
    if not k or k == MASK:
        k = str((cfg.get('api_keys') or {}).get(cfg.get('provider')) or '').strip()
    return re.sub(r'(?i)^(bearer|basic|api-key)\s+', '', k)


def _scrub(cfg, text):
    """Убирает из текста ошибки ключ и пароль прокси."""
    text = str(text)
    secrets = [_key(cfg)]
    m = re.match(r'(?i)^[a-z]+://[^:/@]+:([^@]+)@', str(cfg.get('proxy') or ''))
    if m:
        secrets.append(m.group(1))
    for s in secrets:
        if s and len(s) >= 4:
            text = text.replace(s, MASK)
    return text


def _auth_headers(cfg, p, fresh_token=False):
    key = _key(cfg)
    if p['auth'] == 'none':
        return {'Authorization': f'Bearer {key}'} if key else {}
    if not key and p.get('key_required', True):
        raise LLMError(f'не указан ключ API для «{p["short"]}» — введите его в окне «⚙ Модель ИИ»'
                       + (f' (получить: {p["key_url"]})' if p.get('key_url') else '') + '.')
    if p['auth'] == 'anthropic':
        return {'x-api-key': key, 'anthropic-version': '2023-06-01'}
    if p['auth'] == 'gigachat':
        return {'Authorization': f'Bearer {_giga_token(cfg, p, key, fresh_token)}'}
    if p['auth'] == 'yandex':
        h = {'Authorization': ('Bearer ' if cfg.get('yandex_auth') == 'bearer' else 'Api-Key ') + key}
        if str(cfg.get('folder_id') or '').strip():
            h['x-folder-id'] = str(cfg['folder_id']).strip()
        return h
    h = {'Authorization': f'Bearer {key}'} if key else {}
    h.update(p.get('headers') or {})
    return h


# GigaChat: токены доступа живут ~30 минут; храним в памяти процесса до истечения (минус минута)
_TOKENS = {}
_TOKENS_LOCK = threading.Lock()


def _giga_token(cfg, p, key, fresh=False):
    url = str(cfg.get('auth_url') or '').strip() or p['auth_url']
    scope = cfg.get('gigachat_scope') if cfg.get('gigachat_scope') in GIGACHAT_SCOPES else GIGACHAT_SCOPES[0]
    ck = (url, scope, hashlib.sha256(key.encode('utf-8')).hexdigest())
    with _TOKENS_LOCK:
        tok = _TOKENS.get(ck)
        if tok and not fresh and tok[1] - 60 > time.time():
            return tok[0]
    req = urllib.request.Request(url, data=urllib.parse.urlencode({'scope': scope}).encode('ascii'), method='POST')
    req.add_header('Authorization', f'Basic {key}')
    req.add_header('RqUID', str(uuid.uuid4()))
    req.add_header('Content-Type', 'application/x-www-form-urlencoded')
    req.add_header('Accept', 'application/json')
    try:
        with _open(cfg, req, min(float(cfg.get('timeout') or 600), 60)) as r:
            d = json.loads(r.read().decode('utf-8'))
    except LLMError as e:
        if e.status in (400, 401, 403):
            raise LLMError(f'GigaChat: ключ авторизации не принят ({e.status}). Проверьте «Ключ авторизации» и '
                           f'область доступа ({scope}) в личном кабинете GigaChat API.', e.status, e.raw)
        raise
    except ValueError:
        raise LLMError('GigaChat: сервер выдачи токенов ответил не JSON')
    token = d.get('access_token') or d.get('tok')
    if not token:
        raise LLMError('GigaChat: сервер не выдал токен доступа')
    exp = float(d.get('expires_at') or d.get('exp') or 0)
    exp = exp / 1000 if exp > 1e11 else exp                     # expires_at — в миллисекундах
    with _TOKENS_LOCK:
        _TOKENS[ck] = (token, exp or time.time() + 25 * 60)
    return token


# --------------------------------------------------------------------------------------
# Ошибки → понятные сообщения
# --------------------------------------------------------------------------------------
def _error_text(body):
    """Текст ошибки из ответа сервера: {"error": "…"}, {"error": {"message": …}}, {"message": …}, […]."""
    try:
        d = json.loads(body)
    except ValueError:
        return body
    if isinstance(d, list) and d:
        d = d[0]
    if not isinstance(d, dict):
        return body
    e = d.get('error')
    if isinstance(e, str):
        return e
    if isinstance(e, dict) and (e.get('message') or e.get('type')):
        return str(e.get('message') or e.get('type'))
    for k in ('message', 'detail', 'error_description'):
        if d.get(k):
            return str(d[k])
    return body


def _timeout_error(cfg):
    sec = int(float(cfg.get('timeout') or 600))
    if is_cloud(cfg):
        return LLMError(f'{provider_name(cfg)} не ответил за {sec} с. Повторите позже или увеличьте «Ожидание».')
    return LLMError(f'модель не ответила за {sec} с: слишком долго загружается или читает документ. '
                    'Увеличьте «Ожидание» или возьмите модель меньше.')


def _http_error(cfg, e):
    """Ошибка HTTP от сервера модели → понятное сообщение с подсказкой."""
    try:
        body = e.read().decode('utf-8', 'replace')[:800]
    except Exception:                                     # noqa: BLE001 — тело ответа может быть недоступно
        body = ''
    msg = _scrub(cfg, _error_text(body) or e.reason or '')
    low = msg.lower()
    code = e.code
    model = cfg.get('model') or ''
    if not is_cloud(cfg):                                 # локальный сервер — прежние подсказки
        if 'not found' in low and ('model' in low or 'pull' in low):
            return LLMError(f'модель «{model}» не найдена на сервере. Для Ollama выполните в командной строке: '
                            f'ollama pull {model} — или выберите имя из списка в настройках.', code, msg)
        if 'memory' in low or 'out of memory' in low or 'cuda' in low and 'alloc' in low:
            return LLMError(f'модели «{model}» не хватает памяти ({msg[:200]}). Возьмите модель меньше '
                            f'(например, qwen2.5:7b-instruct) или уменьшите «Контекст».', code, msg)
        return LLMError(f'сервер модели ответил ошибкой {code}: {msg[:300]}', code, msg)
    name = provider_name(cfg)
    p = PROVIDER.get(cfg.get('provider')) or {}
    tail = f' ({msg[:200]})' if msg else ''
    if code == 401:
        what = {'gigachat': 'токен доступа или ключ авторизации', 'yandex': 'API-ключ, IAM-токен или «Вид ключа»'}
        text = f'{name}: неверный ключ API (401) — проверьте {what.get(p.get("auth"), "ключ")} в окне «⚙ Модель ИИ».'
    elif code == 402:
        text = f'{name}: на счёте недостаточно средств (402) — пополните баланс в личном кабинете сервиса.'
    elif code == 403:
        text = (f'{name}: нет доступа (403) — у ключа нет прав на эту модель, или сервис недоступен из вашей '
                f'страны или сети. Используйте шлюз Компании или агрегатор.{tail}')
    elif code == 404:
        text = (f'{name}: неверная модель «{model}» или адрес (404). Нажмите «Проверить связь» — будет показан '
                f'список моделей.{tail}')
    elif code == 413:
        text = f'{name}: запрос слишком большой (413) — уменьшите «Объём выжимки».'
    elif code == 429:
        if any(w in low for w in ('quota', 'billing', 'insufficient', 'balance', 'credit')):
            text = f'{name}: закончилась оплаченная квота (429) — пополните баланс или смените тариф.{tail}'
        else:
            text = f'{name}: превышен лимит запросов (429) — подождите минуту и повторите.'
    elif code == 529 or 'overloaded' in low:
        text = f'{name}: сервис перегружен ({code}) — повторите через несколько минут.'
    elif code in (408, 504):
        text = f'{name}: сервис не дождался ответа модели ({code}) — повторите позже или уменьшите «Объём выжимки».'
    elif code >= 500:
        text = f'{name}: сервис временно недоступен ({code}) — повторите позже.'
    elif any(w in low for w in ('context length', 'context_length', 'maximum context', 'too long', 'too many tokens')):
        text = f'{name}: документ не помещается в контекст модели ({code}) — уменьшите «Объём выжимки».'
    else:
        text = f'{name}: сервис отклонил запрос ({code}): {msg[:300]}'
    return LLMError(text, code, msg)


def _net_error(cfg, url, reason):
    """Нет соединения (DNS, прокси, сертификат…) → понятное сообщение."""
    text = _scrub(cfg, reason)
    if isinstance(reason, (TimeoutError, socket.timeout)) or 'timed out' in text.lower():
        return _timeout_error(cfg)
    if not is_cloud(cfg):
        return LLMError(f'нет связи с сервером модели {url}: {text}')
    host = _host(url)
    px = _proxy_setting(cfg)
    p = PROVIDER.get(cfg.get('provider')) or {}
    if isinstance(reason, ssl.SSLCertVerificationError) or 'CERTIFICATE_VERIFY_FAILED' in text:
        hint = ('Для GigaChat нужен корневой сертификат НУЦ Минцифры: установите его в Windows или укажите файл '
                'в поле «Сертификаты». ' if p.get('auth') == 'gigachat' else '')
        return LLMError(f'не удалось проверить сертификат {host}. {hint}Если прокси Компании проверяет HTTPS, '
                        'укажите в поле «Сертификаты» корневой сертификат Компании (его выдаёт ИТ-служба).')
    if isinstance(reason, ssl.SSLError):
        return LLMError(f'ошибка защищённого соединения с {host} ({text[:150]}) — возможно, прокси Компании '
                        'не пропускает запрос.')
    if '407' in text:
        return LLMError('прокси требует авторизацию (407): укажите в поле «Прокси» адрес вида '
                        'http://логин:пароль@прокси:порт или обратитесь в ИТ-службу.')
    if 'tunnel connection failed' in text.lower():
        return LLMError(f'прокси Компании не пропускает запрос к {host} ({text[:120]}). Обратитесь в ИТ-службу '
                        'или используйте шлюз Компании.')
    if px and px != 'direct' and isinstance(reason, (ConnectionRefusedError, socket.gaierror)):
        return LLMError(f'прокси {_scrub(cfg, px)} недоступен ({text[:120]}) — проверьте поле «Прокси».')
    if isinstance(reason, socket.gaierror) or any(w in text for w in ('Name or service not known', 'getaddrinfo',
                                                                      'nodename nor servname', '11001')):
        return LLMError(f'нет доступа в интернет или прокси Компании не пропускает запрос: адрес {host} не найден. '
                        'Проверьте поле «Прокси» (пусто — системный прокси, как у браузера).')
    return LLMError(f'нет связи с {host} ({text[:150]}) — нет доступа в интернет или прокси Компании '
                    'не пропускает запрос.')


def _open(cfg, req, timeout):
    """Открывает запрос; любые сбои соединения → LLMError с понятным текстом."""
    try:
        return _opener(cfg, req.full_url).open(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        raise _http_error(cfg, e)
    except urllib.error.URLError as e:
        raise _net_error(cfg, req.full_url, getattr(e, 'reason', e))
    except UnicodeEncodeError:
        raise LLMError('ключ API или другой заголовок содержит недопустимые символы (русские буквы, пробелы) — '
                       'скопируйте ключ заново.')
    except (TimeoutError, socket.timeout):
        raise _timeout_error(cfg)
    except (ssl.SSLError, OSError) as e:
        raise _net_error(cfg, req.full_url, e)


def _request(url, payload=None, headers=None):
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(url, data=data, method='GET' if data is None else 'POST')
    if data is not None:
        req.add_header('Content-Type', 'application/json; charset=utf-8')
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    return req


def _stream(cfg, url, payload, on_line, headers=None):
    """Потоковый POST: каждая строка ответа (NDJSON у Ollama, «data: …» у остальных) передаётся
    в on_line(str). Если on_line бросает Cancelled, соединение закрывается — генерация прекращается."""
    timeout = float(cfg.get('timeout') or 600)
    try:
        with _open(cfg, _request(url, payload, headers), timeout) as r:
            for raw in r:
                line = raw.decode('utf-8', 'replace').strip()
                if line:
                    on_line(line)
    except (TimeoutError, socket.timeout):
        raise _timeout_error(cfg)
    except (ssl.SSLError, ConnectionError) as e:
        raise _net_error(cfg, url, e)


def _get(cfg, url, headers=None):
    try:
        with _open(cfg, _request(url, None, headers), 30 if is_cloud(cfg) else 15) as r:
            return json.loads(r.read().decode('utf-8'))
    except ValueError:
        raise LLMError(f'сервер {_host(url)} ответил не JSON — проверьте адрес')
    except (TimeoutError, socket.timeout):
        raise _timeout_error(cfg)


def _base(cfg):
    return (cfg.get('base_url') or '').strip().rstrip('/')


def _openai_base(cfg):
    """Адрес до /chat/completions. Локальный сервер — как раньше: /v1 дописывается, если его нет.
    Облачные сервисы — как указано (у Gemini, GLM, Qwen свой путь), без «/chat/completions» на конце."""
    b = re.sub(r'/(chat/completions|models)$', '', _base(cfg))
    if cfg.get('provider') == 'openai':
        return b if b.endswith('/v1') else b + '/v1'
    return b


def _anthropic_url(cfg, tail):
    b = re.sub(r'/(v1/)?(messages|models)$', '', _base(cfg) or PROVIDER['anthropic']['base_url'])
    return b + ('/' if b.endswith('/v1') else '/v1/') + tail


def _model_name(cfg, p):
    """Имя модели для запроса. YandexGPT: короткое имя → gpt://<каталог>/<модель>/latest."""
    m = str(cfg.get('model') or '').strip()
    if p['auth'] == 'yandex' and '://' not in m:
        folder = str(cfg.get('folder_id') or '').strip()
        if not folder:
            raise LLMError('YandexGPT: укажите идентификатор каталога (folder_id) в окне «⚙ Модель ИИ» — или модель '
                           'целиком: gpt://<каталог>/yandexgpt/latest.')
        m = m or 'yandexgpt/latest'
        return f'gpt://{folder}/{m if "/" in m else m + "/latest"}'
    if not m and p['cloud']:
        raise LLMError('не указана модель — выберите её в окне «⚙ Модель ИИ»')
    return m


# «рассуждающие» облачные модели: черновик рассуждений тоже расходует лимит длины ответа
_REASONING = re.compile(r'reason|thinking|(^|/)o\d|gpt-5|gpt-oss|gemini-(2\.5|[3-9])|grok-(3-mini|4)|deepseek-r1|qwq|'
                        r'glm-4\.[5-9]', re.I)


def _budget(cfg, max_tokens):
    """Потолок длины ответа: у облачных «рассуждающих» моделей — с запасом на рассуждения
    (иначе на сам ответ не останется токенов). Оплачиваются только реально написанные токены."""
    n = int(max_tokens)
    if is_cloud(cfg) and _REASONING.search(str(cfg.get('model') or '')):
        n = min(n + 12000, 32000)
    return n


def _fix_payload(payload, e, cloud):
    """Сервер отклонил параметр запроса (400/422) → убрать или заменить его. True — можно повторить."""
    if e.status not in (400, 422) and not (not cloud and '400' in str(e)):
        return False
    low = (e.raw or str(e)).lower()
    if 'response_format' in payload and ('response_format' in low or 'json' in low):
        payload.pop('response_format')
        return True
    if 'stream_options' in payload and 'stream_options' in low:
        payload.pop('stream_options')
        return True
    if 'temperature' in payload and 'temperature' in low:
        payload.pop('temperature')
        return True
    for a, b in (('max_tokens', 'max_completion_tokens'), ('max_completion_tokens', 'max_tokens')):
        if a in payload and a in low:
            m = re.search(r'\[\s*\d+\s*,\s*(\d+)\s*\]', low)       # «valid range of max_tokens is [1, 8192]»
            if m and 0 < int(m.group(1)) < payload[a]:
                payload[a] = int(m.group(1))
            else:
                payload[b] = payload.pop(a)
            return True
    if 'response_format' in payload:                  # прочие 400: сервер мог не понять json_object
        payload.pop('response_format')
        return True
    return False


# --------------------------------------------------------------------------------------
# Запрос к модели
# --------------------------------------------------------------------------------------
def estimate_tokens(text):
    """Грубая оценка числа токенов (русский текст ≈ 2,6 символа на токен у Qwen/Llama)."""
    return int(len(text) / 2.6) + 1


def _num_ctx(cfg, system, user, max_out):
    """Размер контекста под конкретный запрос: запрос + ответ, с запасом, шагом 4096,
    но не больше настройки. Меньший контекст — меньше памяти и быстрее на CPU."""
    need = int((estimate_tokens(system) + estimate_tokens(user)) * 1.25) + max_out + 256
    step = 4096
    want = max(step, ((need + step - 1) // step) * step)
    return min(want, int(cfg.get('num_ctx') or 16384))


class _Out:
    """Накопитель потокового ответа: текст, счётчик токенов, время первого токена, события индикатора."""

    def __init__(self, notify, stats, t0):
        self.notify, self.stats, self.t0 = notify, stats, t0
        self.first, self.parts, self.thought = None, [], 0

    def _mark(self):
        if self.first is None:
            self.first = time.time()
            self.stats['prompt_seconds'] = round(self.first - self.t0, 1)

    def add(self, piece):
        self._mark()
        if piece:
            self.parts.append(piece)
            self.stats['out_tokens'] += 1
        n = self.stats['out_tokens']
        if n % 8 == 1 or not piece:
            self.notify({'phase': 'gen', 'tokens': n, 'text': ''.join(self.parts)})

    def think(self, piece):
        """Рассуждения модели (в ответ не входят) — только для индикатора хода."""
        if piece:
            self.thought += 1
            if self.thought % 16 == 1:
                self.notify({'phase': 'think', 'tokens': self.thought})

    def reset(self):
        self.first = None


def _chat_ollama(cfg, p, system, user, max_tokens, out, stats):
    msgs = [{'role': 'system', 'content': system}, {'role': 'user', 'content': user}]
    payload = {'model': cfg['model'], 'messages': msgs, 'stream': True,
               'keep_alive': cfg.get('keep_alive') or '30m',   # модель остаётся в памяти между запросами
               'think': False,                                  # «рассуждающие» модели — без черновика
               'options': {'temperature': float(cfg['temperature']),
                           'num_ctx': _num_ctx(cfg, system, user, max_tokens),
                           'num_predict': int(max_tokens)}}
    if cfg.get('json_mode'):
        payload['format'] = 'json'

    def on_line(line):
        try:
            d = json.loads(line)
        except ValueError:
            return
        if d.get('error'):
            raise LLMError(f'Ollama: {d["error"]}')
        out.add((d.get('message') or {}).get('content') or '')
        if d.get('done'):
            ns = 1e9
            stats.update({'prompt_tokens': d.get('prompt_eval_count') or stats['prompt_tokens'],
                          'out_tokens': d.get('eval_count') or stats['out_tokens'],
                          'prompt_seconds': round((d.get('prompt_eval_duration') or 0) / ns, 1),
                          'out_seconds': round((d.get('eval_duration') or 0) / ns, 1),
                          'load_seconds': round((d.get('load_duration') or 0) / ns, 1),
                          'estimated': False, 'done_reason': d.get('done_reason')})
    headers = _auth_headers(cfg, p)
    try:
        _stream(cfg, _base(cfg) + '/api/chat', payload, on_line, headers)
    except LLMError as e:
        # старый или особый сервер не принимает поле think — повторяем без него
        if not isinstance(e, Cancelled) and not out.parts and 'think' in str(e).lower():
            payload.pop('think', None)
            out.reset()
            _stream(cfg, _base(cfg) + '/api/chat', payload, on_line, headers)
        else:
            raise


def _chat_openai(cfg, p, system, user, max_tokens, out, stats):
    """OpenAI-совместимый API: локальные серверы и почти все облачные сервисы (включая GigaChat и YandexGPT)."""
    cloud = p['cloud']
    msgs = [{'role': 'system', 'content': system}, {'role': 'user', 'content': user}]
    payload = {'model': _model_name(cfg, p), 'messages': msgs, 'temperature': float(cfg['temperature']), 'stream': True,
               p.get('max_field') or 'max_tokens': _budget(cfg, max_tokens)}
    if cfg.get('json_mode') and p['json']:
        payload['response_format'] = {'type': 'json_object'}
    if p.get('usage'):
        payload['stream_options'] = {'include_usage': True}

    def on_line(line):
        if not line.startswith('data:'):
            return
        body = line[5:].strip()
        if body == '[DONE]':
            return
        try:
            d = json.loads(body)
        except ValueError:
            return
        if d.get('error'):
            err = d['error']
            raise LLMError(f'{provider_name(cfg) if cloud else "сервер модели"}: '
                           f'{_scrub(cfg, err.get("message") if isinstance(err, dict) else err)}')
        ch = (d.get('choices') or [{}])[0]
        delta = ch.get('delta') or {}
        thinking = delta.get('reasoning_content') or delta.get('reasoning')
        content = delta.get('content') or ''
        if thinking and isinstance(thinking, str) and not content:  # рассуждения (DeepSeek, OpenRouter, Groq)
            out.think(thinking)
        else:
            out.add(content)
        if ch.get('finish_reason'):
            stats['done_reason'] = ch['finish_reason']
        u = d.get('usage')
        if u:
            stats.update({'prompt_tokens': u.get('prompt_tokens') or stats['prompt_tokens'],
                          'out_tokens': u.get('completion_tokens') or stats['out_tokens'], 'estimated': False})
    url = _openai_base(cfg) + '/chat/completions'
    fresh = False
    for _ in range(5):
        try:
            _stream(cfg, url, payload, on_line, _auth_headers(cfg, p, fresh))
            return
        except LLMError as e:
            if isinstance(e, Cancelled) or out.parts:
                raise
            if p['auth'] == 'gigachat' and e.status == 401 and not fresh:
                fresh = True                                    # токен отозван или истёк — получить новый
            elif not _fix_payload(payload, e, cloud):
                raise
            out.reset()
    raise LLMError(f'{provider_name(cfg)}: сервис не принял запрос')


def _chat_anthropic(cfg, p, system, user, max_tokens, out, stats):
    """Anthropic Messages API: POST {base}/v1/messages, ответ — события SSE (content_block_delta)."""
    payload = {'model': _model_name(cfg, p), 'max_tokens': _budget(cfg, max_tokens), 'system': system,
               'messages': [{'role': 'user', 'content': user}],
               'temperature': min(1.0, float(cfg['temperature'])), 'stream': True}

    def on_line(line):
        if not line.startswith('data:'):
            return
        try:
            d = json.loads(line[5:].strip())
        except ValueError:
            return
        t = d.get('type')
        if t == 'content_block_delta':
            dl = d.get('delta') or {}
            if dl.get('type') == 'text_delta':
                out.add(dl.get('text') or '')
            elif dl.get('type') == 'thinking_delta':
                out.think(dl.get('thinking') or '')
        elif t == 'message_start':
            u = (d.get('message') or {}).get('usage') or {}
            if u.get('input_tokens'):
                stats.update({'prompt_tokens': u['input_tokens'], 'estimated': False})
        elif t == 'message_delta':
            u = d.get('usage') or {}
            if u.get('output_tokens'):
                stats['out_tokens'] = u['output_tokens']
            stats['done_reason'] = (d.get('delta') or {}).get('stop_reason')
        elif t == 'error':
            err = d.get('error') or {}
            kind = str(err.get('type') or '')
            if 'overloaded' in kind:
                raise LLMError(f'{p["short"]}: сервис перегружен — повторите через несколько минут.', 529)
            raise LLMError(f'{p["short"]}: {_scrub(cfg, err.get("message") or kind)}')
    url = _anthropic_url(cfg, 'messages')
    for _ in range(3):
        try:
            _stream(cfg, url, payload, on_line, _auth_headers(cfg, p))
            return
        except LLMError as e:
            if isinstance(e, Cancelled) or out.parts or not _fix_payload(payload, e, True):
                raise
            out.reset()


def chat(cfg, system, user, progress=None, max_tokens=4096):
    """Отправляет запрос модели и возвращает текст ответа (потоково).

    progress(event) — необязательный обратный вызов, event — словарь:
      {'phase': 'wait', 'cloud': …, 'provider': …} — запрос отправлен, ждём первый токен (загрузка
                                                     модели, чтение документа);
      {'phase': 'think', 'tokens': n}          — облачная модель рассуждает (черновик в ответ не входит);
      {'phase': 'gen', 'tokens': n, 'text': …} — модель пишет ответ (накопленный текст);
      {'phase': 'done', 'stats': {...}}       — готово; stats: prompt_tokens, prompt_seconds, out_tokens,
                                                 out_seconds, load_seconds, tok_per_s, model, provider, cloud.
    Если progress бросает Cancelled, генерация прерывается. Облачная модель без согласия или при запрете
    администратора не вызывается — CloudRefused (документы никуда не отправлены).
    """
    cfg = {**DEFAULTS, **(cfg or {})}
    p = _provider(cfg)
    refusal = cloud_refusal(cfg)
    if refusal:
        raise CloudRefused(refusal)
    cloud = is_cloud(cfg)
    notify = progress or (lambda e: None)
    t0 = time.time()
    stats = {'prompt_tokens': estimate_tokens(system) + estimate_tokens(user), 'out_tokens': 0,
             'prompt_seconds': None, 'out_seconds': None, 'load_seconds': None, 'estimated': True}
    out = _Out(notify, stats, t0)
    notify({'phase': 'wait', 'prompt_tokens': stats['prompt_tokens'], 'cloud': cloud, 'provider': p['short']})
    {'ollama': _chat_ollama, 'anthropic': _chat_anthropic}.get(p['api'], _chat_openai)(
        cfg, p, system, user, max_tokens, out, stats)
    end = time.time()
    if stats['out_seconds'] is None:
        stats['out_seconds'] = round(end - (out.first or end), 1)
    if stats['prompt_seconds'] is None:
        stats['prompt_seconds'] = round((out.first or end) - t0, 1)
    stats['total_seconds'] = round(end - t0, 1)
    stats['tok_per_s'] = round(stats['out_tokens'] / stats['out_seconds'], 1) if stats['out_seconds'] else None
    stats.update(model=cfg['model'], provider=p['id'], provider_name=p['short'], cloud=cloud)
    notify({'phase': 'done', 'stats': stats})
    text = ''.join(out.parts)
    if not text.strip():
        if stats.get('done_reason') in ('length', 'max_tokens'):
            raise LLMError('модель не успела написать ответ: лимит длины ответа израсходован на рассуждения — '
                           'выберите модель без рассуждений или режим «Быстро»')
        raise LLMError('модель вернула пустой ответ')
    return text


def ping_model(cfg):
    """Пробный запрос к модели: загружается ли она, за сколько секунд, с какой скоростью пишет
    и на чём работает (Ollama: доля модели в памяти видеокарты из /api/ps).
    Возвращает словарь: ok, stats, gpu_percent (или None), answer, cloud, provider."""
    cfg = {**DEFAULTS, **(cfg or {})}
    cfg['timeout'] = min(float(cfg.get('timeout') or 600), 240)
    got = {}
    cloud = is_cloud(cfg)
    text = chat(cfg, 'Отвечай одним словом.', 'Напиши слово: готово',
                progress=lambda e: got.update(e) if e.get('phase') == 'done' else None, max_tokens=16 if cloud else 8)
    out = {'ok': True, 'stats': got.get('stats') or {}, 'answer': text.strip()[:40], 'gpu_percent': None,
           'cloud': cloud, 'provider': provider_name(cfg)}
    if cfg['provider'] == 'ollama':
        try:
            ps = _get(cfg, _base(cfg) + '/api/ps')
            for m in ps.get('models') or []:
                if m.get('name') == cfg['model'] or m.get('model') == cfg['model']:
                    size, vram = float(m.get('size') or 0), float(m.get('size_vram') or 0)
                    out['gpu_percent'] = int(round(100 * vram / size)) if size else None
                    out['context'] = (m.get('context_length') or None)
        except LLMError:
            pass
    return out


def list_models(cfg):
    """Список моделей на сервере (для проверки связи из веб-интерфейса). Документы при этом
    не отправляются, поэтому согласие не нужно; запрет администратора действует."""
    cfg = {**DEFAULTS, **(cfg or {})}
    p = _provider(cfg)
    refusal = cloud_refusal(cfg, consent=False)
    if refusal:
        raise CloudRefused(refusal)
    if p['api'] == 'ollama':
        r = _get(cfg, _base(cfg) + '/api/tags', _auth_headers(cfg, p))
        return [m.get('name') for m in r.get('models', [])]
    if p['api'] == 'anthropic':
        r = _get(cfg, _anthropic_url(cfg, 'models') + '?limit=100', _auth_headers(cfg, p))
    else:
        url = _openai_base(cfg) + '/models'
        try:
            r = _get(cfg, url, _auth_headers(cfg, p))
        except LLMError as e:
            if p['auth'] != 'gigachat' or e.status != 401:
                raise
            r = _get(cfg, url, _auth_headers(cfg, p, fresh_token=True))
    items = r if isinstance(r, list) else (r.get('data') or r.get('models') or [])
    names = [str(m.get('id') or m.get('name') or '') if isinstance(m, dict) else str(m) for m in items]
    return [re.sub(r'^models/', '', n) for n in names if n]


def extract_json(text):
    """Достаёт JSON-объект из ответа модели (даже если вокруг есть пояснения или ```json … ```)."""
    if not text:
        raise LLMError('модель вернула пустой ответ')
    t = re.sub(r'(?s)<think>.*?</think>', '', text).strip()      # «рассуждающие» модели пишут черновик в <think>
    if t.startswith('```'):
        t = t.strip('`')
        t = t[t.find('{'):] if '{' in t else t
    try:
        return json.loads(t)
    except json.JSONDecodeError:
        pass
    start = t.find('{')
    if start < 0:
        raise LLMError('в ответе модели нет JSON')
    depth, in_str, esc = 0, False, False
    for i in range(start, len(t)):
        ch = t[i]
        if in_str:
            if esc:
                esc = False
            elif ch == '\\':
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == '{':
            depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(t[start:i + 1])
                except json.JSONDecodeError as e:
                    raise LLMError(f'модель вернула некорректный JSON: {e}')
    raise LLMError('ответ модели оборван (JSON не закрыт) — увеличьте num_ctx или уменьшите max_chars')
