# -*- coding: utf-8 -*-
"""
shapes.py — «КИРПИЧИКИ» СЛАЙДОВ: фигуры, текст, иконки, линии, баннеры
=====================================================================

Все слайды собираются из небольшого набора функций этого модуля:

    rect(...)        — прямоугольник / круг / любая стандартная фигура PowerPoint;
    grect(...)       — то же с градиентной заливкой;
    text(...)        — текстовое поле (поддерживает несколько абзацев и «цветные» слова);
    shape_text(...)  — текст ВНУТРИ фигуры (плашки, чипы, бейджи);
    icon(...)        — иконка-картинка из assets/icons;
    circ_icon(...)   — иконка в цветном круге (основной «значок» шагов и задач);
    line(...)        — линия / стрелка (сплошная или пунктир);
    banner(...)      — картинка из assets/deco (фирменная волна);
    bottom_banner(...) — нижний баннер-вывод «волна + лампочка + текст»;
    group(...)       — группа фигур (группа анимируется как одно целое).

ОБЩИЕ ПРАВИЛА ДЛЯ ВСЕХ ФУНКЦИЙ
  * Первый аргумент sl — КУДА добавить фигуру: слайд ИЛИ группа (group(...)).
    Это позволяет сначала создать группу, а потом «складывать» в неё фигуры.
  * x, y — левый верхний угол, w, h — ширина и высота. Всё в ДЮЙМАХ.
  * Цвета — константы из config.py (NAVY, GREEN, …).
  * Функции возвращают созданную фигуру — к ней можно применить shadow(), glow() и т. п.

ФОРМАТ ТЕКСТА (параметр content в text() и shape_text())
  1) Просто строка:                    'Один абзац'
  2) Список строк = несколько абзацев:  ['Абзац 1', 'Абзац 2']
  3) Абзац из «кусочков» с разным оформлением — список пар (текст, настройки):
        [[('Вывод: ', {'font': 'b', 'color': LGREEN}), ('обычный текст', {})]]
     Доступные настройки кусочка: 'size' (пт), 'font' ('mn'|'mj'|'b'),
     'bold' (True/False), 'color' (RGBColor), 'baseline' (-25000 — нижний индекс,
     30000 — верхний индекс).
"""
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches as I
from pptx.util import Pt
from lxml import etree

from . import config as C
from . import theme as _theme
from .config import BLUE, DECO_DIR, FONTS, GRAY, ICON_DIR, LGREEN, NAVY, WHITE
from .effects import grad, no_shadow


# --------------------------------------------------------------------------------------
# Фигуры
# --------------------------------------------------------------------------------------
def rect(sl, x, y, w, h, fill=None, line=None, lw=0.75, shape=MSO_SHAPE.RECTANGLE, name=None, adj=None):
    """Добавляет стандартную фигуру (по умолчанию прямоугольник).

    fill  — цвет заливки или None (без заливки);
    line  — цвет контура или None (без контура);
    lw    — толщина контура, пт;
    shape — тип фигуры: MSO_SHAPE.RECTANGLE, OVAL (круг/овал), ROUNDED_RECTANGLE,
            CHEVRON, PENTAGON, ARC и др. (полный список — в документации python-pptx);
    adj   — первый «регулятор» фигуры (0…1), например скругление углов:
            ROUNDED_RECTANGLE + adj=0.5 → «таблетка» с полностью круглыми торцами;
    name  — имя фигуры (видно в «Области выделения» PowerPoint).

    Внутренние поля текста обнулены, тень темы отключена.
    """
    s = sl.shapes.add_shape(shape, I(x), I(y), I(w), I(h))
    if fill is None:
        s.fill.background()
    else:
        s.fill.solid()
        s.fill.fore_color.rgb = fill
    if line is None:
        s.line.fill.background()
    else:
        s.line.color.rgb = line
        s.line.width = Pt(lw)
    no_shadow(s)
    if adj is not None:
        s.adjustments[0] = adj
    if name:
        s.name = name
    tf = s.text_frame
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    return s


def grect(sl, x, y, w, h, c1, c2, angle=0, shape=MSO_SHAPE.RECTANGLE):
    """Фигура с градиентной заливкой c1 → c2 (angle: 0 — слева направо, 90 — сверху вниз)."""
    s = rect(sl, x, y, w, h, fill=c1, shape=shape)
    grad(s, c1, c2, angle)
    return s


def freeform(sl, pts, fill=None, line_=None, lw=1.0):
    """Произвольный замкнутый многоугольник по точкам pts = [(x1, y1), (x2, y2), …] (дюймы).

    В текущих слайдах не используется — пригодится для «крыш», стрелок необычной
    формы, треугольников-указателей.
    """
    fb = sl.shapes.build_freeform(I(pts[0][0]), I(pts[0][1]), scale=1.0)
    fb.add_line_segments([(I(x), I(y)) for x, y in pts[1:]], close=True)
    shp = fb.convert_to_shape()
    if fill is None:
        shp.fill.background()
    else:
        shp.fill.solid()
        shp.fill.fore_color.rgb = fill
    if line_ is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = line_
        shp.line.width = Pt(lw)
    no_shadow(shp)
    return shp


def group(sl):
    """Создаёт пустую группу на слайде.

    Зачем группы: анимация назначается группе целиком — карточка с иконкой,
    заголовком и текстом «вылетает» одним блоком. Кроме того, в PowerPoint группу
    удобно двигать мышью при ручной доводке.
    Использование:  g = group(s);  rect(g, ...);  text(g, ...);  anim(s, g, 'rise', 0, 500)
    """
    return sl.shapes.add_group_shape()


# --------------------------------------------------------------------------------------
# Текст
# --------------------------------------------------------------------------------------
def _fill_tf(tf, content, size, color, font, bold, align, space_after, line_spacing):
    """Внутренняя функция: заполняет текстовую рамку tf содержимым content.

    Формат content описан в начале модуля. Шрифт 'b' всегда жирный.
    """
    if isinstance(content, str):
        content = [content]
    first = True
    for para in content:
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.alignment = align
        if space_after:
            p.space_after = Pt(space_after)        # отступ после абзаца, пт
        if line_spacing:
            p.line_spacing = line_spacing          # межстрочный (1.0 — одинарный)
        runs = [(para, {})] if isinstance(para, str) else para
        for txt, o in runs:
            r = p.add_run()
            r.text = txt
            f = r.font
            f.size = Pt(o.get('size', size))
            fk = o.get('font', font)
            f.name = FONTS[fk]
            f.bold = True if fk == 'b' else o.get('bold', bold)
            f.color.rgb = o.get('color', color)
            if o.get('baseline'):                  # индекс: -25000 нижний, 30000 верхний
                r._r.get_or_add_rPr().set('baseline', str(o['baseline']))


def text(sl, x, y, w, h, content, size=12, color=GRAY, font='mn', bold=False,
         align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, space_after=0, line_spacing=None, name=None):
    """Текстовое поле фиксированного размера.

    size   — кегль, пт (правила размеров — в 02_RULES_and_ARCHITECTURE.md);
    color  — цвет текста; font — 'mn' (основной), 'mj' (заголовочный), 'b' (жирный акцент);
    align  — PP_ALIGN.LEFT / CENTER / RIGHT;
    anchor — вертикальное выравнивание: MSO_ANCHOR.TOP / MIDDLE / BOTTOM.

    Автоподбор размера ВЫКЛЮЧЕН (MSO_AUTO_SIZE.NONE): кегль всегда ровно тот, что задан.
    Перенос строк включён. Поля внутри рамки = 0, поэтому x/y — это точное начало текста.
    ВНИМАНИЕ: если текст не помещается в h, он «вылезет» за рамку — проверяйте
    результат глазами (см. раздел «Контроль качества» в инструкции).
    """
    tb = sl.shapes.add_textbox(I(x), I(y), I(w), I(h))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = anchor
    _fill_tf(tf, content, size, color, font, bold, align, space_after, line_spacing)
    if name:
        tb.name = name
    return tb


def shape_text(s, content, size=12, color=GRAY, font='mn', bold=False, align=PP_ALIGN.CENTER,
               anchor=MSO_ANCHOR.MIDDLE, margins=(0.08, 0.04, 0.08, 0.04), space_after=0, line_spacing=None):
    """Пишет текст внутрь уже созданной фигуры s (по умолчанию — по центру).

    margins — внутренние поля (слева, сверху, справа, снизу), дюймы.
    Для маленьких кружков-бейджей с цифрой ставьте margins=(0, 0, 0, 0).
    """
    tf = s.text_frame
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.margin_left, tf.margin_top, tf.margin_right, tf.margin_bottom = [I(m) for m in margins]
    tf.vertical_anchor = anchor
    _fill_tf(tf, content, size, color, font, bold, align, space_after, line_spacing)
    return s


# --------------------------------------------------------------------------------------
# Иконки и картинки
# --------------------------------------------------------------------------------------
def icon(sl, name, color, x, y, s):
    """Вставляет иконку assets/icons/<name>_<color>.png квадратом s × s дюймов.

    name  — имя иконки Tabler, например 'TbRobot', 'TbGauge' (список — в assets/icons);
    color — буква цвета: 'w' белый, 'n' NAVY, 'b' BLUE, 'g' GREEN, 'd' DGREEN.
    Новую иконку или новый цвет можно получить скриптом tools/icons (см. инструкцию).
    """
    path = ICON_DIR / f'{name}_{color}.png'
    if not path.exists():                     # неизвестное имя иконки — нейтральная «лампочка»
        path = ICON_DIR / f'TbBulb_{color}.png'
    path = _theme.icon_file(path, color)      # свой шаблон — иконка в его цветах
    return sl.shapes.add_picture(str(path), I(x), I(y), I(s), I(s))


def circ_icon(sl, name, x, y, d, fill=NAVY, ic='w', fill2=None, ratio=0.56):
    """Иконка в цветном круге — главный «значок» карточек, шагов и задач.

    d      — диаметр круга, дюймы; (x, y) — левый верхний угол описанного квадрата;
    fill   — цвет круга; fill2 — если задан, круг получает градиент fill → fill2 (45°);
    ic     — цвет иконки (обычно 'w' на тёмном круге; 'n'/'d' на белом круге);
    ratio  — доля диаметра, которую занимает иконка (0,52–0,56 — «дышит» внутри круга).
    Возвращает фигуру-круг (к ней можно применить shadow/glow).
    """
    c = rect(sl, x, y, d, d, fill=fill, shape=MSO_SHAPE.OVAL)
    if fill2 is not None:
        grad(c, fill, fill2, 45)
    s_ = d * ratio
    icon(sl, name, ic, x + (d - s_) / 2, y + (d - s_) / 2, s_)
    return c


def banner(sl, img, x, y, w, h):
    """Вставляет декоративную картинку assets/deco/<img> (фирменная волна шаблона).
    На своём шаблоне волна Зарубежнефти не к месту — вместо неё плашка с градиентом (её цвета
    перекрашиваются в цвета шаблона)."""
    if _theme.active() is not None:
        return grect(sl, x, y, w, h, NAVY, BLUE, 0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    return sl.shapes.add_picture(str(DECO_DIR / img), I(x), I(y), I(w), I(h))


def badge(sl, x, y, num, d=0.36, fill=NAVY):
    """Круглый бейдж с номером (белая цифра в цветном круге). В текущих слайдах не
    используется — номера шагов рисуются «обратным» вариантом (белый круг, цветная цифра)."""
    c_ = rect(sl, x, y, d, d, fill=fill, shape=MSO_SHAPE.OVAL)
    shape_text(c_, num, size=11, color=WHITE, font='b', margins=(0, 0, 0, 0))


# --------------------------------------------------------------------------------------
# Линии
# --------------------------------------------------------------------------------------
def line(sl, x1, y1, x2, y2, color=NAVY, w=1.5, head=True, dash=None):
    """Прямая линия из (x1, y1) в (x2, y2).

    w    — толщина, пт;
    head — True: стрелка-треугольник на конце (x2, y2); False: просто линия;
    dash — None (сплошная) или тип пунктира: 'dash', 'sysDot', 'lgDash' и т. п.
    """
    c = sl.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, I(x1), I(y1), I(x2), I(y2))
    c.line.color.rgb = color
    c.line.width = Pt(w)
    ln = c.line._get_or_add_ln()
    if dash:
        pd = etree.SubElement(ln, qn('a:prstDash'))
        pd.set('val', dash)
    if head:
        t = etree.SubElement(ln, qn('a:tailEnd'))
        t.set('type', 'triangle')
        t.set('w', 'med')
        t.set('len', 'med')
    return c


# --------------------------------------------------------------------------------------
# Составные элементы
# --------------------------------------------------------------------------------------
def bottom_banner(sl, lead, body, ic='TbBulb', y=6.12, h=0.7, size=14.5):
    """Нижний баннер-вывод: фирменная волна на всю ширину + белая иконка + текст.

    lead — выделенное начало фразы (салатовым жирным), например 'Вывод: ';
    body — основной текст (белым);
    ic   — иконка слева (по умолчанию лампочка TbBulb).
    Текст занимает левые ~70 % ширины — справа на картинке «волна», текст её не перекрывает.
    Правило: каждый «аналитический» слайд заканчивается таким выводом в одну-две строки.
    """
    L, CW = C.L, C.CW
    b = banner(sl, 'banner_thin.png', L, y, CW, h)
    if _theme.active() is not None:
        b.adjustments[0] = 0.18
    icon(sl, ic, 'w', L + 0.25, y + (h - 0.5) / 2, 0.5)
    text(sl, L + 0.95, y, CW * 0.7, h, [[(lead, {'font': 'b', 'color': LGREEN}), (body, {})]],
         size=size, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
