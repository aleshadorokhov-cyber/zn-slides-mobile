# -*- coding: utf-8 -*-
"""
pptx_reader.py — ЧТЕНИЕ ПРЕЗЕНТАЦИИ POWERPOINT (.pptx) В МОДЕЛЬ ДОКУМЕНТА
=========================================================================

Старая презентация — такой же исходный материал, как Word или PDF: из неё берутся тексты, таблицы
и числа диаграмм, а слайды новой презентации строит конструктор. Модель — та же, что у PDF из
PowerPoint (pdf_reader, режим «по слайдам»): слайд — раздел 1-го уровня.

  * Заголовок слайда — из поля заголовка; если его нет — самая крупная короткая надпись вверху.
  * Титульный слайд (первый, с макетом «Титульный»/Title Slide или почти без текста) — название
    и подзаголовок документа. «Содержание», «Спасибо за внимание» и скрытые слайды пропускаются.
  * Надписи читаются по рядам и колонкам (как глаз читает слайд), а не по порядку в файле.
  * Группа фигур — карточка: короткая первая надпись — заголовок пункта («Рост тарифов: в среднем
    8–10 % в год»); плитка «число + единица + подпись» — пункт «Экономия электроэнергии — 85 млн
    кВт·ч в год». Номера шагов («1», «01») не переносятся, но задают порядок пунктов.
  * Короткая надпись над другой (шеврон этапа над описанием) — заголовок этой надписи; над столбцом
    надписей — заголовок столбца, надписи — его вложенные пункты.
  * Надпись из нескольких абзацев — пункты (с уровнями вложенности), из одного — абзац; «Вывод: …»
    и «Цель» — абзацы. Жирное начало абзаца сохраняется (это готовый заголовок карточки).
  * Таблицы — как таблицы Word; диаграммы — таблицей с их числами (подписи × ряды; проценты — с
    единицей «%»); SmartArt — пунктами с вложенностью.
  * Рисунки — от 2 % площади слайда (значки, полосы-украшения, фоновые картинки во весь слайд и
    логотипы, повторяющиеся на слайдах, пропускаются).
  * Заметки докладчика — абзацами после содержимого слайда, если в них есть то, чего нет на слайде.
  * Колонтитулы, номера слайдов и надписи, повторяющиеся на большинстве слайдов, пропускаются.
Нужна только библиотека python-pptx (она же собирает презентации).
"""
import hashlib
import re
from collections import Counter

from lxml import etree
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE, PP_PLACEHOLDER
from pptx.oxml.ns import qn

from ..model import Block, Document, ListItem, Section
from ..textutil import clean, sentences
from .docx_reader import _save_images
from .pdf_reader import (DECK_CONCL_RX, DECK_END_RX, DECK_TOC_RX, GOAL_RX, LEAD_NUM_RX, NUM_ONLY_RX, UNIT_RX,
                         VALUE_RX, WORD_RX, YEAR_RX, _add_item, _join_head)

EMU = 914400                                           # EMU в дюйме
DGM = 'http://schemas.openxmlformats.org/drawingml/2006/diagram'
SKIP_PH = (PP_PLACEHOLDER.DATE, PP_PLACEHOLDER.FOOTER, PP_PLACEHOLDER.SLIDE_NUMBER, PP_PLACEHOLDER.HEADER)
TITLE_PH = (PP_PLACEHOLDER.TITLE, PP_PLACEHOLDER.CENTER_TITLE, PP_PLACEHOLDER.VERTICAL_TITLE)
TITLE_LAYOUT_RX = re.compile(r'(?i)титул|обложк|заглавн|title\s*slide|cover')
DATE_RX = re.compile(r'(?i)^\W*(\d{1,2}[./]\d{1,2}[./]\d{2,4}|\d{1,2}\s+[а-я]+\s+(19|20)\d\d(\s*г\.?)?|'
                     r'([а-яёa-z.-]+,?\s+)?(19|20)\d\d(\s*г(од|\.)?)?)\W*$')
VALUE_HEAD_RX = re.compile(r'^\s*(?:[+±−–-]|≈|~|>|<|до|более|свыше|около)?\s*\d[\d\s.,]*\s*(?:%|‰)?')
PERIOD_RX = re.compile(r'(?i)^\W*((I{1,3}|IV|[1-4])\s*(кв\.?|квартал)\s*(19|20)\d\d(\s*г\.?)?|[12]\s*(полугодие|пол\.)\s*'
                       r'(19|20)\d\d|(19|20)\d\d(\s*[–—-]\s*((19|20)\d\d|\d\d))?(\s*гг?\.?)?|(январ|феврал|март|апрел|ма[йя]|'
                       r'июн|июл|август|сентябр|октябр|ноябр|декабр)\w*\s+(19|20)\d\d(\s*г\.?)?|q[1-4]\s*(19|20)\d\d)\W*$')
# подпись столбца выводов макета «Диаграмма» (layouts/data.py): эти выводы конструктор сам считает по числам
# диаграммы, поэтому из своей же старой презентации они не переносятся (иначе — лишний слайд-повтор)
INSIGHTS_HEAD = 'Что показывают данные'
LABEL_RX = re.compile(r'(?i)^\W*(цел[ьи]|задач[аи]|миссия|проблема|решение|вывод[ы]?|итог[и]?|результат[ы]?|'
                      r'эффект[ы]?|предложени[ея]|рекомендаци[яи])\W*$')
CAPS_WORDS = {'ЦЕЛЬ', 'ЦЕЛИ', 'ИТОГ', 'ИТОГИ', 'ВЫВОД', 'МИССИЯ', 'ЗАДАЧА', 'ЗАДАЧИ', 'ЭФФЕКТ', 'ИДЕЯ', 'ПЛАН', 'РИСК', 'РИСКИ'}
META_TITLE_RX = re.compile(r'(?i)^(презентация\s+powerpoint|powerpoint\s+presentation|слайд\s*\d*|slide\s*\d*|'
                           r'без\s+названия|untitled|presentation\d*|презентация\d*)$')


class _Par:
    """Абзац надписи: текст, жирное начало, уровень, кегль (пт), целиком жирный, выделен маркером."""
    __slots__ = ('text', 'bold', 'level', 'size', 'allbold', 'mark')

    def __init__(self, text, bold='', level=0, size=None, allbold=False, mark=False):
        self.text, self.bold, self.level, self.size, self.allbold, self.mark = text, bold, level, size, allbold, mark


class _Unit:
    """Элемент слайда в дюймах: надпись/карточка ('text'), столбец с заголовком ('column'), таблица,
    диаграмма, SmartArt ('items'), рисунок."""

    def __init__(self, kind, box, pars=None, data=None, group=False, ph=None):
        self.kind = kind
        self.x0, self.y0, self.x1, self.y1 = box
        self.pars = pars or []
        self.data = data
        self.group = group              # из группы фигур (карточка)
        self.ph = ph                    # 'sub' — подзаголовок, 'body' — поле текста макета
        self.head = None                # заголовок карточки
        self.num = None                 # номер шага («01») — порядок пунктов
        self.fixed = ''                 # готовый пункт «подпись — число»
        self.ordered = False
        self.sib = False                # одна из ≥ 3 одинаковых надписей ряда или столбца — пункт списка
        self.children = []              # для столбца с заголовком

    @property
    def text(self):
        return ' '.join(p.text for p in self.pars)

    @property
    def size(self):
        s = [p.size for p in self.pars if p.size]
        return max(s) if s else None

    @property
    def allbold(self):
        return bool(self.pars) and all(p.allbold for p in self.pars)

    def absorb(self, other):
        self.x0, self.y0 = min(self.x0, other.x0), min(self.y0, other.y0)
        self.x1, self.y1 = max(self.x1, other.x1), max(self.y1, other.y1)


# ---------------------------------------------------------------- текст фигур

def _sz(el):
    """Кегль по умолчанию (пт) из списка стилей: lvl1pPr/defRPr@sz."""
    lvl = el.find(qn('a:lvl1pPr')) if el is not None else None
    d = lvl.find(qn('a:defRPr')) if lvl is not None else None
    return int(d.get('sz')) / 100 if d is not None and d.get('sz') else None


def _dflt(sh, base):
    """Кегль надписи без явного размера: стиль самой надписи или стиль текста презентации по умолчанию. У полей
    макета кегль задаёт макет — он не вычисляется (None)."""
    if sh.is_placeholder:
        return None
    return _sz(sh.text_frame._txBody.find(qn('a:lstStyle'))) or base


def _pars(tf, dflt=None):
    """Абзацы рамки текста; абзац, разорванный переносом строки (продолжение со строчной буквы), склеивается."""
    out, prev_raw = [], ''
    for p in tf.paragraphs:
        text = clean(p.text.replace('\v', ' ').replace('\x0b', ' '))
        if not text or not re.search(r'[\w%‰]', text):
            continue
        bold, done, sizes, mark = '', False, [], False
        for r in p.runs:
            if r.font.size is not None:
                sizes.append(r.font.size.pt)
            elif dflt and r.text.strip():
                sizes.append(dflt)
            rpr = r._r.find(qn('a:rPr'))
            if rpr is not None and rpr.find(qn('a:highlight')) is not None:
                mark = True
            if not done:
                if r.font.bold and r.text.strip():
                    bold += r.text
                elif r.text.strip():
                    done = True
                else:
                    bold += r.text
        bold = clean(bold)
        allbold = bool(bold) and len(bold) >= len(text) - 1
        if allbold and len(WORD_RX.findall(text)) > 10:
            bold = ''                                  # целиком жирный длинный абзац — не «заголовок»
        if mark is False and text.startswith('!'):
            mark, text = True, text.lstrip('! ')
        prev = out[-1] if out else None
        if prev is not None and text[:1].islower() and not re.search(r'[.!?:;,]$', prev_raw) and \
                p.level == prev.level:
            prev.text = clean(prev.text + ' ' + text)
            prev_raw = p.text.rstrip()
            continue
        prev_raw = p.text.rstrip()                    # clean() снимает «;» в конце — признак пункта списка
        out.append(_Par(text, bold, min(p.level, 2), max(sizes) if sizes else None, allbold, mark))
    return out


def _value(text):
    """«85», «3,8», «+12 %», «640 млн руб.» — число-показатель (не номер шага «1», «01»); иначе None."""
    m = VALUE_HEAD_RX.match(text)
    if not m or not VALUE_RX.search(m.group(0)) or YEAR_RX.match(text):           # год — подпись, не показатель
        return None
    rest = text[m.end():].strip()
    return text if not rest or UNIT_RX.match(rest) else None


def _step(text):
    """Номер шага («1», «01», «2.») — число без признаков показателя; иначе None."""
    if NUM_ONLY_RX.match(text) and not VALUE_RX.search(text):
        digits = re.sub(r'\D', '', text)
        return int(digits) if digits and len(digits) <= 2 else -1
    return None


def _cut_num(u):
    """«01 Внедрить…» → номер 1 и текст без него (в первом абзаце или заголовке)."""
    if u.head is not None:
        m = LEAD_NUM_RX.match(u.head)
        if m:
            u.num, u.head = int(m.group(1)), u.head[m.end():].strip()
        return
    if u.pars:
        p = u.pars[0]
        m = LEAD_NUM_RX.match(p.text)
        if m and p.text[m.end():].strip():
            u.num = int(m.group(1))
            p.text = p.text[m.end():].strip()
            bm = LEAD_NUM_RX.match(p.bold)
            p.bold = p.bold[bm.end():].strip() if bm else ('' if re.fullmatch(r'\d{1,2}', p.bold) else p.bold)


def _heading_like(u):
    """Короткая надпись в одну строку без точки в конце — может быть заголовком соседней надписи."""
    if u.kind != 'text' or u.head is not None or u.fixed or len(u.pars) != 1:
        return False
    t = u.pars[0].text
    return len(WORD_RX.findall(t)) <= 10 and len(t) <= 90 and not re.search(r'[.;,]$', t) and \
        not NUM_ONLY_RX.match(t) and not t[:1].islower()


def _dominant(h, b):
    """Надпись h выделена сильнее b: крупнее, жирнее или прописными; одинаковые по виду надписи — равные.
    Подписи «Цель», «Задача», «Вывод» — заголовок того, что под ними, при любом шрифте."""
    if LABEL_RX.match(h.text):
        return True
    if h.size and b.size:
        if h.size >= b.size + 0.5:
            return True
        if h.size <= b.size - 0.5:
            return False
    if h.allbold != b.allbold:
        return h.allbold
    if h.text.isupper() and not b.text.isupper():
        return True
    # шрифт не задан ни там, ни там: короткая подпись над блоком из нескольких абзацев — его заголовок
    return not h.size and not b.size and len(b.pars) >= 2 and len(b.text) >= 3 * len(h.text)


# ---------------------------------------------------------------- фигуры слайда

def _xfrm(tr, sh):
    """Прямоугольник фигуры в дюймах слайда с учётом групп (tr — пересчёт координат группы)."""
    ax, bx, ay, by = tr
    x, y, w, h = (sh.left or 0), (sh.top or 0), (sh.width or 0), (sh.height or 0)
    return ax * x + bx, ay * y + by, ax * (x + w) + bx, ay * (y + h) + by


def _group_tr(tr, g):
    """Координаты детей группы → координаты слайда: off + (x − chOff) × ext / chExt."""
    ax, bx, ay, by = tr
    xfrm = g._element.grpSpPr.find(qn('a:xfrm'))
    off = (g.left or 0, g.top or 0)
    ext = (g.width or 0, g.height or 0)
    choff, chext = off, ext
    if xfrm is not None:
        co, ce = xfrm.find(qn('a:chOff')), xfrm.find(qn('a:chExt'))
        if co is not None and ce is not None:
            choff = (int(co.get('x', 0)), int(co.get('y', 0)))
            chext = (int(ce.get('cx', 0)), int(ce.get('cy', 0)))
    sx = ext[0] / chext[0] if chext[0] else 1.0
    sy = ext[1] / chext[1] if chext[1] else 1.0
    return ax * sx, ax * (off[0] - choff[0] * sx) + bx, ay * sy, ay * (off[1] - choff[1] * sy) + by


def _leaves(shapes, tr):
    """Все фигуры группы (вложенные группы раскрыты) с прямоугольниками."""
    for sh in shapes:
        if sh.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from _leaves(sh.shapes, _group_tr(tr, sh))
        else:
            yield sh, _xfrm(tr, sh)


def _columns(texts):
    """Сколько колонок с настоящим текстом (не номерами шагов) образуют надписи группы: две и больше — это
    не одна карточка, а ряд карточек."""
    boxes = sorted(((b[0], b[2], _step(clean(sh.text_frame.text)) is None) for sh, b in texts), key=lambda x: x[0])
    if not boxes:
        return 0
    groups, edge = [[boxes[0]]], boxes[0][1]
    for b in boxes[1:]:
        if b[0] >= edge - 0.05:
            groups.append([b])
            edge = b[1]
        else:
            groups[-1].append(b)
            edge = max(edge, b[1])
    return sum(1 for g in groups if any(real for _, _, real in g))


def _has_text(sh):
    return getattr(sh, 'has_text_frame', False) and sh.has_text_frame and bool(sh.text_frame.text.strip())


def _frame_kind(sh):
    if getattr(sh, 'has_table', False) and sh.has_table:
        return 'table'
    if getattr(sh, 'has_chart', False) and sh.has_chart:
        return 'chart'
    gd = sh._element.find('.//' + qn('a:graphicData'))
    if gd is not None and gd.get('uri', '').endswith('/diagram'):
        return 'smartart'
    return None


def _ph_type(sh):
    if not sh.is_placeholder:
        return None
    try:
        return sh.placeholder_format.type
    except (ValueError, AttributeError):
        return None


class _Slide:
    """Сбор элементов одного слайда."""

    def __init__(self, slide, sw, shh, model, name, base=None):
        self.slide, self.sw, self.sh, self.base = slide, sw, shh, base
        self.model, self.name = model, name
        self.title, self.title_box, self.title_size = '', None, None
        self.units, self.images = [], []
        root = (1.0 / EMU, 0.0, 1.0 / EMU, 0.0)
        self._collect(slide.shapes, root)

    # --- фигуры
    def _collect(self, shapes, tr):
        for sh in shapes:
            st = sh.shape_type
            if st == MSO_SHAPE_TYPE.GROUP:
                self._group(sh, tr)
                continue
            box = _xfrm(tr, sh)
            kind = _frame_kind(sh) if sh._element.tag == qn('p:graphicFrame') else None
            if kind:
                self._frame(sh, kind, box)
                continue
            pht = _ph_type(sh)
            if pht in SKIP_PH:
                continue
            if self._picture(sh, box):
                continue
            if not _has_text(sh):
                continue
            pars = _pars(sh.text_frame, _dflt(sh, self.base))
            if not pars:
                continue
            if pht in TITLE_PH and not self.title:
                self.title = clean(' '.join(p.text for p in pars))
                self.title_box, self.title_size = box, max((p.size for p in pars if p.size), default=None)
                continue
            ph = 'sub' if pht == PP_PLACEHOLDER.SUBTITLE else ('body' if pht is not None else None)
            if ph == 'body' and sh.placeholder_format.idx >= 0x7FFFFFFF:
                ph = None                             # поле, скопированное с другого слайда, — обычная надпись
            if len(pars) == 1 and _step(pars[0].text) is not None:
                continue                              # номер шага, номер слайда — не текст
            u = _Unit('text', box, pars, ph=ph)
            _cut_num(u)
            self.units.append(u)

    def _picture(self, sh, box, small_ok=False):
        """Рисунок фигуры (или поля рисунка макета) → в список рисунков слайда; True — это рисунок."""
        if sh.shape_type != MSO_SHAPE_TYPE.PICTURE and not (sh.is_placeholder and hasattr(sh, 'image')):
            return False
        try:
            img = sh.image
            blob, ext = img.blob, '.' + (img.ext or 'png').lower()
        except Exception:                           # noqa: BLE001 — поле рисунка без рисунка, связанный файл
            return sh.shape_type == MSO_SHAPE_TYPE.PICTURE
        w, h = box[2] - box[0], box[3] - box[1]
        area = w * h / max(self.sw * self.sh, 1e-6)
        if area < (0.02 if not small_ok else 0.04) or area > 0.85 or max(w, h) >= 5 * max(min(w, h), 1e-3):
            return True                             # значок, полоса-украшение, фон во весь слайд
        self.images.append((hashlib.sha1(blob).hexdigest(), blob, ext, sh.width or 0, sh.height or 0, box))
        return True

    def _frame(self, sh, kind, box):
        if kind == 'table':
            rows = []
            for r in sh.table.rows:
                rows.append([clean(c.text.replace('\v', ' ')) if not c.is_spanned else '' for c in r.cells])
            rows = [r for r in rows if any(r)]
            if rows:
                self.units.append(_Unit('table', box, data=rows))
        elif kind == 'chart':
            data = _chart_data(sh.chart)
            if data:
                self.units.append(_Unit('chart', box, data=data))
        elif kind == 'smartart':
            items = _smartart(sh, self.slide.part)
            if items:
                self.units.append(_Unit('items', box, data=items))

    def _group(self, g, tr):
        """Группа: карточка (одна единица) или контейнер (ряд карточек, схема) — тогда её части по отдельности."""
        tr2 = _group_tr(tr, g)
        leaves = list(_leaves(g.shapes, tr2))
        texts = [(sh, b) for sh, b in leaves if _has_text(sh) and _ph_type(sh) not in SKIP_PH]
        frames = [sh for sh, b in leaves if sh._element.tag == qn('p:graphicFrame')]
        sub = sum(1 for c in g.shapes if c.shape_type == MSO_SHAPE_TYPE.GROUP and
                  any(_has_text(s) for s, _ in _leaves(c.shapes, _group_tr(tr2, c))))
        if frames or sub >= 2 or len(texts) > 6 or _columns(texts) >= 2:
            self._collect(g.shapes, tr2)              # ряд карточек, схема — части по отдельности
            return
        for sh, b in leaves:
            if sh.shape_type == MSO_SHAPE_TYPE.PICTURE:
                self._picture(sh, b, small_ok=True)
        if not texts:
            return
        texts.sort(key=lambda t: (round(t[1][1] / 0.08), t[1][0]))
        u = _Unit('text', _xfrm(tr, g), group=True)          # рамка группы: карточка целиком
        leaf_pars = []
        for sh, b in texts:
            ps = _pars(sh.text_frame, _dflt(sh, self.base))
            if not ps:
                continue
            whole = clean(' '.join(p.text for p in ps))
            n = _step(whole) if len(ps) == 1 else None
            if n is not None:                         # номер шага — порядок, а не текст
                if n >= 0 and u.num is None:
                    u.num = n
                continue
            leaf_pars.append((ps, whole))
        if not leaf_pars:
            return
        vals = [k for k, (ps, whole) in enumerate(leaf_pars) if len(ps) == 1 and _value(whole)]
        if vals and len(leaf_pars) > 1:              # плитка-показатель: число, единица, подпись
            k = vals[0]
            value = leaf_pars[k][1]
            unit = ''
            for j in (k + 1, k - 1):
                if 0 <= j < len(leaf_pars) and j not in vals and len(leaf_pars[j][0]) == 1 and \
                        UNIT_RX.match(leaf_pars[j][1]):
                    unit = leaf_pars[j][1]
                    break
            rest = [w for j, (ps, w) in enumerate(leaf_pars) if j != k and w != unit]
            label = clean(' '.join(rest))
            if rest and len(rest) <= 2 and len(WORD_RX.findall(label)) <= 25:
                tail = ' '.join(rest[1:])                 # пояснение под подписью — после числа
                u.fixed = f'{rest[0]} — {clean(value + " " + unit)}' + (f'. {tail}' if tail else '')
                u.pars = [p for ps, w in leaf_pars for p in ps]
                self.units.append(u)
                return
        period = next((w for ps, w in leaf_pars if len(ps) == 1 and PERIOD_RX.match(w)), None)
        if period is not None and len(leaf_pars) >= 2:     # «I кв. 2026», «2028» — срок к заголовку пункта
            leaf_pars = [x for x in leaf_pars if x[1] != period]
            if len(leaf_pars) == 1 and len(leaf_pars[0][0]) == 1 and len(WORD_RX.findall(leaf_pars[0][1])) <= 12:
                u.head, u.pars = period, leaf_pars[0][0]
                _cut_num(u)
                self.units.append(u)
                return
        first_ps, first = leaf_pars[0]
        if len(leaf_pars) >= 2 and len(first_ps) == 1 and len(WORD_RX.findall(first)) <= 12 and \
                len(first) <= 100 and not re.search(r'[.;]$', first) and not first[:1].islower():
            caps = first.isupper() and (len(first) >= 7 or ' ' in first or first in CAPS_WORDS)   # не «ГПЭС»
            u.head = first.capitalize() if caps else first                                # «ЦЕЛЬ» → «Цель»
            u.pars = [p for ps, w in leaf_pars[1:] for p in ps]
        elif period is not None and len(leaf_pars) == 1 and len(first_ps) >= 1:
            u.head, u.pars = period, first_ps
            period = None
        elif len(leaf_pars) == 1 and len(first_ps) >= 2 and len(WORD_RX.findall(first_ps[0].text)) <= 12 and \
                (first_ps[0].allbold and not first_ps[1].allbold or
                 (first_ps[0].size and first_ps[1].size and first_ps[0].size >= first_ps[1].size + 1)):
            u.head = first_ps[0].text
            u.pars = first_ps[1:]
        else:
            u.pars = [p for ps, w in leaf_pars for p in ps]
        if period is not None:
            u.head = f'{period}. {u.head}' if u.head else period
        _cut_num(u)
        self.units.append(u)

    # --- после сбора
    def finish_title(self):
        """Заголовок без поля заголовка — крупная короткая надпись в верхней части слайда. Затем подзаголовок —
        поле текста макета или надпись в 1–2 строки сразу под заголовком (в пары «заголовок — текст» не входит)."""
        self._find_title()
        if self.title_box is None:
            return
        tx0, ty1, tw = self.title_box[0], self.title_box[3], self.title_box[2] - self.title_box[0]
        for u in self.units:
            if u.kind == 'text' and not u.group and u.ph != 'sub' and -0.2 <= u.y0 - ty1 <= 0.5 and \
                    len(u.pars) <= 2 and u.y1 - u.y0 <= 1.3 and len(u.text) <= 240 and \
                    (u.ph == 'body' or abs(u.x0 - tx0) <= 0.3 and u.x1 - u.x0 >= 0.4 * tw and
                     len(WORD_RX.findall(u.text)) >= 2) and not LABEL_RX.match(u.text):
                u.ph = 'sub'
                break

    def _find_title(self):
        if self.title:
            return
        cands = [u for u in self.units if u.kind == 'text' and not u.group and len(u.pars) == 1 and
                 u.y0 < 0.3 * self.sh and 2 <= len(u.text) <= 120 and not NUM_ONLY_RX.match(u.text)]
        if not cands:
            return
        sizes = sorted(u.size for u in self.units if u.kind == 'text' and u.size)
        best = max(cands, key=lambda u: (u.size or 0, -u.y0))
        median = sizes[len(sizes) // 2] if sizes else None
        if best.size and median and best.size >= 1.2 * median or best is min(cands, key=lambda u: u.y0):
            self.title, self.title_box, self.title_size = best.text, (best.x0, best.y0, best.x1, best.y1), best.size
            self.units.remove(best)

    def drop_footers(self, running):
        """Колонтитулы: узкие надписи у нижнего края, номера слайдов, повторяющиеся на слайдах подписи."""
        keep = []
        for u in self.units:
            if u.kind == 'text' and not u.group:
                t = u.text
                if u.y0 >= 0.9 * self.sh and u.y1 - u.y0 <= 0.1 * self.sh and len(t) <= 120:
                    continue
                if _key(t) in running:
                    continue
                if re.fullmatch(r'(?i)(стр\.?|слайд|slide)?\s*\d{1,3}(\s*(/|из)\s*\d{1,3})?', t):
                    continue
            keep.append(u)
        self.units = keep


def _key(t):
    return re.sub(r'\W+', ' ', t.lower()).strip()


# ---------------------------------------------------------------- диаграммы и SmartArt

def _fmt(v, pct=False):
    if v is None:
        return ''
    try:
        v = float(v) * (100 if pct else 1)
    except (TypeError, ValueError):
        return ''
    s = ('%.6f' % v).rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s.replace('.', ',')


def _pct_kind(ser_el):
    """Формат чисел ряда: 'frac' — «0%» (0,31 показывается как 31 %), 'lit' — «0"%"» (31 → «31 %»), '' — без %."""
    fc = ser_el.find('.//' + qn('c:val') + '//' + qn('c:formatCode'))
    code = fc.text if fc is not None and fc.text else ''
    if '%' not in code:
        return ''
    return 'frac' if '%' in re.sub(r'"[^"]*"|\\.', '', code) else 'lit'


def _chart_data(chart):
    """Числа диаграммы → (название, подписи, [(ряд, [значения])], признак процентов) или None."""
    try:
        plots = list(chart.plots)
        if not plots:
            return None
        cats = plots[0].categories
        try:
            labels = [' '.join(str(x) for x in t) if isinstance(t, tuple) else str(t)
                      for t in (cats.flattened_labels if cats.depth > 1 else list(cats))]
        except Exception:                           # noqa: BLE001
            labels = [str(c) for c in cats]
        labels = [re.sub(r'^((?:19|20)\d\d)\.0$', r'\1', clean(x)) for x in labels]
        series, pct = [], []
        for p in plots:
            for s in p.series:
                vals = list(s.values)
                kind = _pct_kind(s._element)
                if kind == 'frac' and all(v is None or abs(v) <= 1.5 for v in vals):
                    vals = [_fmt(v, True) for v in vals]
                else:
                    vals = [_fmt(v) for v in vals]
                pct.append(bool(kind))
                series.append((clean(s.name or '') or f'Ряд {len(series) + 1}', vals))
    except Exception:                               # noqa: BLE001 — точечная, пузырьковая и прочие без подписей
        return None
    if not labels or not series or not any(v for _, vals in series for v in vals):
        return None
    title = ''
    try:
        if chart.has_title and chart.chart_title.has_text_frame:
            title = clean(chart.chart_title.text_frame.text)
    except Exception:                               # noqa: BLE001
        pass
    return title, labels, series, pct


def _smartart(gf, part):
    """Текст SmartArt (часть данных схемы): [(текст, уровень)] в порядке схемы."""
    gd = gf._element.find('.//' + qn('a:graphicData'))
    rel = gd.find('{%s}relIds' % DGM) if gd is not None else None
    rid = rel.get(qn('r:dm')) if rel is not None else None
    if not rid:
        return []
    try:
        root = etree.fromstring(part.related_part(rid).blob)
    except Exception:                               # noqa: BLE001
        return []
    pts, kids, doc = {}, {}, None
    for pt in root.iter('{%s}pt' % DGM):
        typ = pt.get('type') or 'node'
        mid = pt.get('modelId')
        if typ == 'doc':
            doc = mid
        if typ in ('node', 'doc'):
            tb = pt.find('{%s}t' % DGM)
            txt = ''
            if tb is not None:
                txt = clean(' '.join(''.join(t.text or '' for t in p.iter(qn('a:t'))) for p in tb.iter(qn('a:p'))))
            pts[mid] = txt
    for c in root.iter('{%s}cxn' % DGM):
        if (c.get('type') or 'parOf') == 'parOf':
            kids.setdefault(c.get('srcId'), []).append((int(c.get('srcOrd') or 0), c.get('destId')))
    out, seen = [], set()

    def walk(mid, depth):
        for _, d in sorted(kids.get(mid, [])):
            if d in seen or d not in pts:
                continue
            seen.add(d)
            if pts[d]:
                out.append((pts[d], max(0, min(2, depth))))
            walk(d, depth + 1)
    if doc is not None:
        walk(doc, 0)
    if not out:                                     # без связей — по порядку
        out = [(t, 0) for m, t in pts.items() if t and m != doc]
    return out


# ---------------------------------------------------------------- порядок чтения

def _xy(units):
    """Порядок чтения: ряды сверху вниз (по просветам между ними), внутри ряда — колонки слева направо."""
    if len(units) <= 1:
        return list(units)
    tol = 0.05
    for axis in ('y', 'x'):
        lo, hi = ('y0', 'y1') if axis == 'y' else ('x0', 'x1')
        us = sorted(units, key=lambda u: (getattr(u, lo), getattr(u, 'x0' if axis == 'y' else 'y0')))
        groups, cur, edge = [], [us[0]], getattr(us[0], hi)
        for u in us[1:]:
            if getattr(u, lo) >= edge - tol:
                groups.append(cur)
                cur, edge = [u], getattr(u, hi)
            else:
                cur.append(u)
                edge = max(edge, getattr(u, hi))
        groups.append(cur)
        if len(groups) > 1:
            return [x for g in groups for x in _xy(g)]
    return sorted(units, key=lambda u: (round(u.y0 / 0.3), u.x0))


def _pair(units):
    """Короткая надпись над другой — её заголовок; над столбцом надписей — заголовок столбца; число над
    подписью — плитка-показатель."""
    units = list(units)

    def below(h, pool):
        c = [b for b in pool if b is not h and b.kind == 'text' and b.ph != 'sub' and b.y0 >= h.y1 - 0.15 and
             b.y0 - h.y1 <= 0.7 and
             min(h.x1, b.x1) - max(h.x0, b.x0) >= 0.5 * min(h.x1 - h.x0, b.x1 - b.x0)]
        return min(c, key=lambda b: b.y0) if c else None

    for h in sorted([u for u in units if u.kind == 'text' and not u.group and not u.fixed and u.head is None and
                     u.ph != 'sub' and len(u.pars) == 1 and _value(u.text)], key=lambda u: u.y0):
        if h not in units:
            continue
        b = below(h, units)
        unit = ''
        if b is not None and len(b.pars) == 1 and UNIT_RX.match(b.text):
            unit, nb = b.text, below(b, units)
            units.remove(b)
            h.absorb(b)
            b = nb
        if b is not None and b.head is None and not b.fixed and not _value(b.text) and \
                len(WORD_RX.findall(b.text)) <= 20:
            b.fixed = f'{b.text} — {clean(h.text + " " + unit)}'
            b.absorb(h)
            units.remove(h)
        elif unit:
            h.pars[0].text = clean(h.text + ' ' + unit)
    for h in sorted([u for u in units if _heading_like(u) and u.ph != 'sub' and not _value(u.text)],
                    key=lambda u: u.y0):
        if h not in units:
            continue
        b = below(h, units)
        if b is None or b.fixed or b.head is not None or not _dominant(h, b):
            continue
        stack = [b]
        while True:
            last = stack[-1]
            nxt = [c for c in units if c not in stack and c is not h and c.kind == 'text' and
                   0 <= c.y0 - last.y1 + 0.15 and c.y0 - last.y1 <= 0.6 and abs(c.x0 - b.x0) <= 0.3 and
                   abs((c.x1 - c.x0) - (b.x1 - b.x0)) <= 0.25 * (b.x1 - b.x0)]
            if not nxt:
                break
            c = min(nxt, key=lambda c: c.y0)
            cb = below(c, units) if _heading_like(c) else None
            if cb is not None and cb is not h and _dominant(c, cb):
                break                                # следующая подпись — заголовок своего блока, не пункт
            stack.append(c)
        if len(stack) >= 2:                          # заголовок столбца
            col = _Unit('column', (h.x0, h.y0, h.x1, h.y1))
            col.head, col.num, col.children = h.text, h.num, stack
            for c in stack:
                col.absorb(c)
                units.remove(c)
            units[units.index(h)] = col
        else:
            b.head = h.text
            b.num = b.num if b.num is not None else h.num
            b.absorb(h)
            units.remove(h)
    return units


def _siblings(units):
    """Одинаковые по размеру надписи (≥ 3) в столбец или в ряд — пункты одного списка, а не абзацы."""
    loose = [u for u in units if u.kind == 'text' and not u.group and u.ph is None and u.head is None and not u.fixed]
    for u in loose:
        w, h = u.x1 - u.x0, u.y1 - u.y0
        same = [c for c in loose if abs((c.x1 - c.x0) - w) <= 0.1 * w and abs((c.y1 - c.y0) - h) <= 0.35 * max(h, 0.3)
                and (abs(c.x0 - u.x0) <= 0.15 or abs(c.y0 - u.y0) <= 0.15)]
        if len(same) >= 3:
            u.sib = True
    return units


def _by_numbers(units):
    """Пункты с номерами шагов (≥ 3, номера подряд с 0 или 1) — по номерам, с места первого из них."""
    found = [(u.num, k) for k, u in enumerate(units) if u.num is not None and u.num >= 0]
    nums = sorted(n for n, _ in found)
    if len(found) < 3 or nums[0] not in (0, 1) or nums != list(range(nums[0], nums[0] + len(nums))):
        for u in units:
            u.num = None
        return units
    for _, k in found:
        units[k].ordered = True
    first, ks = min(k for _, k in found), {k for _, k in found}
    return ([u for k, u in enumerate(units) if k < first] + [units[k] for _, k in sorted(found)] +
            [u for k, u in enumerate(units) if k > first and k not in ks])


# ---------------------------------------------------------------- в модель документа

def _emit(model, sec, u, title, name):
    if u.kind == 'table':
        rows = u.data
        w = max(len(r) for r in rows)
        rows = [(r + [''] * w)[:w] for r in rows]
        if len(rows) >= 2:
            header = [c or f'Столбец {k + 1}' for k, c in enumerate(rows[0])]
            tb = model.add_table(header, rows[1:], title=title, source=name)
        else:
            tb = model.add_table([f'Столбец {k + 1}' for k in range(w)], rows, title=title, source=name)
        sec.blocks.append(Block('table', table_id=tb.id))
        return
    if u.kind == 'chart':
        ctitle, labels, series, pct = u.data
        n = len(labels)
        yearly = all(re.fullmatch(r'(19|20)\d\d', x) for x in labels)
        cols = ['Год' if yearly else 'Показатель'] + [s for s, _ in series]
        rows = [[labels[i]] + [(vals[i] if i < len(vals) else '') for _, vals in series] for i in range(n)]
        units = [''] + ['%' if p else '' for p in pct]
        tb = model.add_table(cols, rows, title=ctitle or title, source=name, units=units)
        sec.blocks.append(Block('table', table_id=tb.id))
        return
    if u.kind == 'items':
        for t, lvl in u.data:
            _add_item(sec, ListItem(t, '', lvl), False)
        return
    if u.kind == 'column':
        _add_item(sec, ListItem(u.head, u.head, 0), u.ordered)
        for c in u.children:
            if c.fixed:
                _add_item(sec, ListItem(c.fixed, '', 1), False)
            elif c.head is not None:
                _add_item(sec, ListItem(_join_head(c.head, ' '.join(p.text for p in c.pars)), c.head, 1), False)
            else:
                for p in c.pars:
                    _add_item(sec, ListItem(p.text, p.bold, 1 + min(p.level, 1), p.mark), False)
        return
    if u.fixed:
        _add_item(sec, ListItem(u.fixed, '', 0, any(p.mark for p in u.pars)), u.ordered)
        return
    pars = u.pars
    if u.head is not None:
        head, body = u.head, ' '.join(p.text for p in pars)
        mark = any(p.mark for p in pars)
        if DECK_CONCL_RX.match(head) or GOAL_RX.match(head):
            sec.blocks.append(Block('para', text=_join_head(head, body), bold=head, mark=mark))
        elif len(pars) <= 1:
            _add_item(sec, ListItem(_join_head(head, body), head, 0, mark), u.ordered)
        else:
            _add_item(sec, ListItem(head, head, 0, False), u.ordered)
            for p in pars:
                _add_item(sec, ListItem(p.text, p.bold, 1 + min(p.level, 1), p.mark), u.ordered)
        return
    if not pars:
        return
    concl = len(pars) == 1 and (DECK_CONCL_RX.match(pars[0].text) or GOAL_RX.match(pars[0].bold or ''))
    if u.ph == 'sub' or concl or (not u.group and not u.ordered and not u.sib and
                                  (len(pars) == 1 or all(len(p.text) > 200 for p in pars))):
        for p in pars:
            sec.blocks.append(Block('para', text=p.text, bold=p.bold, mark=p.mark))
        return
    for p in pars:
        if DECK_CONCL_RX.match(p.text) and not u.group:
            sec.blocks.append(Block('para', text=p.text, bold=p.bold, mark=p.mark))
        else:
            _add_item(sec, ListItem(p.text, p.bold, p.level, p.mark), u.ordered)


def _notes(slide, seen_words):
    """Заметки докладчика: строки, в которых есть то, чего нет на слайде."""
    if not slide.has_notes_slide:
        return []
    tf = slide.notes_slide.notes_text_frame
    if tf is None:
        return []
    out = []
    for p in tf.paragraphs:
        keep = []
        for t in sentences(clean(p.text.replace('\v', ' '))):
            words = [w.lower() for w in WORD_RX.findall(t) if len(w) > 2]
            if len(words) >= 3 and sum(1 for w in words if w not in seen_words) >= 0.3 * len(words):
                keep.append(t)
        if keep:
            out.append(clean(' '.join(keep)))
    return out if sum(len(t) for t in out) >= 40 else []


def _is_title_slide(s, slide):
    lay = slide.slide_layout
    if TITLE_LAYOUT_RX.search(lay.name or ''):
        return True
    for ph in lay.placeholders:
        try:
            if ph.placeholder_format.type in (PP_PLACEHOLDER.CENTER_TITLE, PP_PLACEHOLDER.SUBTITLE):
                return True
        except (ValueError, AttributeError):
            pass
    return not any(u.kind in ('table', 'chart') for u in s.units) and \
        sum(1 for u in s.units if u.kind == 'text') <= 3 and sum(len(u.text) for u in s.units) <= 400


def _subtitle(s):
    """Подзаголовок титула: подзаголовок или поле текста макета, иначе самая крупная надпись (без дат, городов)."""
    cands = [u for u in s.units if u.kind == 'text' and not DATE_RX.match(u.text) and len(u.text) >= 3]
    ph = [u for u in cands if u.ph in ('sub', 'body')]
    pick = (ph or sorted(cands, key=lambda u: (-(u.size or 0), u.y0)))[:1]
    return clean(pick[0].text)[:300] if pick else ''


def read_pptx(path, doc_model=None, name=None, progress=None):
    """Читает .pptx и добавляет его содержимое в модель Document (или создаёт новую).
    progress(event) — ход чтения ({'phase': 'read', 'file', 'slide', 'slides'} на каждый слайд, 'images' —
    перед сохранением рисунков); если он бросает исключение (отмена), чтение прерывается."""
    tick = progress or (lambda e: None)
    model = doc_model or Document()
    name = name or str(path)
    model.sources.append(name)
    try:
        prs = Presentation(str(path))
    except Exception:                               # noqa: BLE001
        model.warnings.append(f'{name}: не удалось открыть презентацию — файл повреждён, защищён паролем '
                              f'или это не .pptx (старый .ppt пересохраните в PowerPoint как .pptx).')
        return model
    sw, shh = (prs.slide_width or 12192000) / EMU, (prs.slide_height or 6858000) / EMU
    slides = [(i, sl) for i, sl in enumerate(prs.slides, 1) if sl._element.get('show') not in ('0', 'false')]
    base = _sz(prs.part._element.find(qn('p:defaultTextStyle'))) or 18.0     # кегль надписей по умолчанию
    parsed = []
    for k, (i, sl) in enumerate(slides):
        tick({'phase': 'read', 'file': name, 'slide': k + 1, 'slides': len(slides)})
        parsed.append((i, sl, _Slide(sl, sw, shh, model, name, base)))
    for _, _, s in parsed:
        s.finish_title()
    # повторяющиеся подписи (колонтитул «Раздел 1», название компании) — не текст слайда
    cnt = Counter(k for _, _, s in parsed for k in {_key(u.text) for u in s.units
                                                    if u.kind == 'text' and not u.group and len(u.text) <= 80})
    running = {k for k, c in cnt.items() if k and len(parsed) >= 3 and c >= max(3, 0.5 * len(parsed))}
    imgs = Counter(h for _, _, s in parsed for h in {im[0] for im in s.images})
    logos = {h for h, c in imgs.items() if len(parsed) >= 3 and c >= max(3, 0.5 * len(parsed))}
    todo = [(im[0], im[1], im[2]) for _, _, s in parsed for im in s.images if im[0] not in logos]
    if todo:                                         # все рисунки разом: EMF/WMF — одним запуском LibreOffice
        tick({'phase': 'read', 'file': name, 'images': len({h for h, _, _ in todo})})
    saved = _save_images(todo, model.warnings, name) if todo else {}
    title = subtitle = ''
    secs = []
    for k, (i, sl, s) in enumerate(parsed):
        s.drop_footers(running)
        if k == 0 and s.title and _is_title_slide(s, sl):
            title = s.title
            subtitle = _subtitle(s)
            continue
        chars = sum(len(u.text) for u in s.units)
        if DECK_TOC_RX.match(s.title) or (DECK_END_RX.match(s.title) and chars <= 300 and
                                           not any(u.kind in ('table', 'chart') for u in s.units)):
            continue
        units = _by_numbers(_xy(_siblings(_pair(s.units))))
        if any(u.kind == 'chart' for u in units):
            units = [u for u in units if not (u.kind == 'column' and u.head == INSIGHTS_HEAD)]
        blocks = []
        for h, blob, ext, cx, cy, box in s.images:
            if h in logos:
                continue
            img = saved.get(h)
            if img is not None:
                blocks.append(Block('image', image_id=model.add_image(img, cx, cy)))
        if not s.title and not units:
            if secs and blocks:                      # слайд-картинка без текста — к предыдущему слайду
                secs[-1].blocks.extend(blocks)
            continue
        sec = Section(title=s.title or f'Слайд {i}', level=1, source=name)
        divider = not blocks and len(units) <= 1 and all(
            u.kind == 'text' and not u.group and len(WORD_RX.findall(u.text)) <= 6 for u in units)
        if not divider:                              # слайд-разделитель («Раздел 2. …») — только заголовок
            for u in units:
                _emit(model, sec, u, sec.title, name)
            sec.blocks.extend(blocks)
            goal = next((b for b in sec.blocks if b.kind == 'para' and GOAL_RX.match(b.bold or '')), None)
            if goal is not None:                     # «Цель: …» — первым абзацем: это главная мысль слайда
                sec.blocks.remove(goal)
                sec.blocks.insert(0, goal)
            seen = {w.lower() for w in WORD_RX.findall(sec.title + ' ' + sec.all_text(False))}
            for t in _notes(sl, seen):
                sec.blocks.append(Block('para', text=t))
        secs.append(sec)
    if not secs and not title:
        model.warnings.append(f'{name}: в презентации не найден текст (возможно, слайды сохранены картинками).')
        return model
    meta = ''
    try:
        meta = clean(prs.core_properties.title or '')
    except Exception:                               # noqa: BLE001
        pass
    if META_TITLE_RX.match(meta) or len(meta) < 4:
        meta = ''
    if not model.title:
        model.title = title or meta or (secs[0].title if secs else '')
    if subtitle and not model.subtitle and subtitle != model.title:
        model.subtitle = subtitle
    model.sections.extend(secs)
    return model
