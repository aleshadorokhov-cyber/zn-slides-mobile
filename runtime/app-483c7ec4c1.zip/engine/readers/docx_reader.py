# -*- coding: utf-8 -*-
"""
docx_reader.py — ЧТЕНИЕ WORD (.docx) В МОДЕЛЬ ДОКУМЕНТА
======================================================

Что распознаётся:
  * Заголовки — по стилям «Заголовок 1/2/3» (Heading 1/2/3), «Название» (Title),
    по уровню структуры абзаца (outline level), а если стилей нет — «псевдозаголовки»:
    короткий абзац целиком жирным шрифтом без точки в конце.
  * Списки — маркированные и нумерованные (по нумерации Word или по символам «•», «–», «1)»).
  * Таблицы — с объединёнными ячейками; первая строка считается шапкой.
  * Жирное начало абзаца/пункта («Мониторинг. Робот проверяет…») — сохраняется отдельно:
    это готовый заголовок карточки.
  * Подписи «Таблица N. …» перед таблицей — становятся названием таблицы.
Пропускаются: пустые абзацы, оглавление (стили TOC), колонтитулы.
Формат .doc (старый Word) не поддерживается — пересохраните файл как .docx.
"""
import hashlib
import os
import re
import shutil
import signal
import subprocess
import time
from pathlib import Path

from docx import Document as DocxDocument
from docx.oxml.ns import qn
from docx.table import Table as DocxTable
from docx.text.paragraph import Paragraph

from ..model import Block, Document, ListItem, Section
from ..textutil import clean

HEADING_RX = re.compile(r'^(heading|заголовок)\s*(\d)', re.I)
# Пометки автора «это — на слайд»: маркер-выделение, красный шрифт, стиль со словом «слайд»/«важно»,
# либо «!» / «[!]» / «★» в начале абзаца (работает и в простом тексте)
MARK_PREFIX_RX = re.compile(r'^\s*(\[!\]|!{1,3}|★|⭐|⚑|►►)\s*')
MARK_STYLE_RX = re.compile(r'(?i)слайд|важн|выдел|ключев|highlight|important')
CAP_WORD = r'(?:рисунок|рис\.|рис(?=\s*№?\s*\d)|схема|фото|диаграмма|figure|fig\.?)(?![а-яёa-z])'   # не «Риски…»
CAPTION_RX = re.compile(r'(?i)^' + CAP_WORD + r'\s*№?\s*\d*')
IMAGE_CACHE = Path(__file__).resolve().parents[2] / 'output' / 'cache'
RASTER_EXT = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tif', '.tiff'}


def _style_name(p):
    try:
        return p.style.name or ''
    except Exception:
        return ''


def _outline_level(p):
    """Уровень структуры абзаца (w:outlineLvl): 0 → заголовок 1-го уровня."""
    ppr = p._p.pPr
    if ppr is not None:
        ol = ppr.find(qn('w:outlineLvl'))
        if ol is not None:
            try:
                v = int(ol.get(qn('w:val')))
                return v + 1 if v < 9 else None
            except (TypeError, ValueError):
                return None
    return None


def _num_info(p, numbering):
    """Если абзац — элемент списка Word, возвращает (уровень, нумерованный?)."""
    ppr = p._p.pPr
    numpr = ppr.find(qn('w:numPr')) if ppr is not None else None
    if numpr is None:
        # список может быть задан стилем (List Bullet, Список …)
        st = _style_name(p).lower()
        if 'list' in st or 'спис' in st:
            return 0, ('number' in st or 'нумер' in st)
        return None
    ilvl_el = numpr.find(qn('w:ilvl'))
    numid_el = numpr.find(qn('w:numId'))
    ilvl = int(ilvl_el.get(qn('w:val'))) if ilvl_el is not None else 0
    numid = numid_el.get(qn('w:val')) if numid_el is not None else None
    if numid in (None, '0'):
        return None
    ordered = False
    fmt = numbering.get((numid, ilvl))
    if fmt:
        ordered = fmt not in ('bullet', 'none')
    return ilvl, ordered


def _numbering_formats(doc):
    """Таблица (numId, уровень) → формат нумерации ('decimal', 'bullet' …)."""
    out = {}
    try:
        npart = doc.part.numbering_part.element
    except Exception:
        return out
    abstract = {}
    for an in npart.findall(qn('w:abstractNum')):
        aid = an.get(qn('w:abstractNumId'))
        for lvl in an.findall(qn('w:lvl')):
            il = int(lvl.get(qn('w:ilvl')))
            nf = lvl.find(qn('w:numFmt'))
            abstract[(aid, il)] = nf.get(qn('w:val')) if nf is not None else 'bullet'
    for num in npart.findall(qn('w:num')):
        nid = num.get(qn('w:numId'))
        aref = num.find(qn('w:abstractNumId'))
        if aref is None:
            continue
        aid = aref.get(qn('w:val'))
        for (a, il), f in abstract.items():
            if a == aid:
                out[(nid, il)] = f
    return out


def _bold_prefix(p):
    """Жирное начало абзаца (подряд идущие жирные фрагменты с начала)."""
    acc = ''
    for r in p.runs:
        t = r.text
        if not t:
            continue
        b = r.bold
        if b is None and r.style is not None:
            try:
                b = r.style.font.bold
            except Exception:
                b = None
        if b:
            acc += t
        else:
            break
    return acc.strip()


def _all_bold(p):
    runs = [r for r in p.runs if r.text.strip()]
    return bool(runs) and all(r.bold for r in runs)


def _run_marked(r):
    """Выделен ли фрагмент текста: маркером (заливка) или красным цветом шрифта."""
    try:
        if r.font.highlight_color is not None:
            return True
    except Exception:
        pass
    try:
        c = r.font.color
        if c is not None and c.type is not None and c.rgb is not None:
            rr, gg, bb = c.rgb[0], c.rgb[1], c.rgb[2]
            if rr >= 170 and gg <= 90 and bb <= 90:
                return True
    except Exception:
        pass
    # заливка абзаца/текста через w:shd в свойствах run
    rpr = r._r.find(qn('w:rPr'))
    if rpr is not None:
        shd = rpr.find(qn('w:shd'))
        if shd is not None and (shd.get(qn('w:fill')) or 'auto').lower() not in ('auto', 'ffffff', 'none'):
            return True
    return False


def _mark_info(p, style_name=''):
    """(выделен весь абзац, выделенная часть текста, текст без префикса-пометки)."""
    text = clean(p.text)
    whole = False
    m = MARK_PREFIX_RX.match(p.text or '')
    if m:
        whole = True
        text = clean(p.text[m.end():])
    if style_name and MARK_STYLE_RX.search(style_name):
        whole = True
    ppr = p._p.find(qn('w:pPr'))
    if ppr is not None:
        shd = ppr.find(qn('w:shd'))
        if shd is not None and (shd.get(qn('w:fill')) or 'auto').lower() not in ('auto', 'ffffff', 'none'):
            whole = True
    runs = [r for r in p.runs if r.text.strip()]
    marked = [r for r in runs if _run_marked(r)]
    part = ''
    if runs and marked:
        if len(marked) == len(runs):
            whole = True
        else:
            part = clean(''.join(r.text for r in marked))
            if len(part) >= 0.8 * len(text):
                whole = True
                part = ''
    return whole, part, text


def _para_images(p, d):
    """Картинки внутри абзаца: [(bytes, расширение, ширина EMU, высота EMU)]."""
    out = []
    for blip in p._p.iter(qn('a:blip')):
        rid = blip.get(qn('r:embed'))
        if not rid or rid not in d.part.rels:
            continue
        part = d.part.rels[rid].target_part
        ext = '.' + (part.partname.ext or 'png').lower().lstrip('.')
        cx = cy = 0
        drawing = blip.getparent()
        while drawing is not None and drawing.tag != qn('w:drawing'):
            drawing = drawing.getparent()
        if drawing is not None:
            ext_el = drawing.find('.//' + qn('wp:extent'))
            if ext_el is not None:
                cx, cy = int(ext_el.get('cx') or 0), int(ext_el.get('cy') or 0)
        out.append((part.blob, ext, cx, cy))
    return out


def _soffice():
    """Путь к LibreOffice (soffice) или None."""
    return shutil.which('soffice') or shutil.which('libreoffice') or next(
        (c for c in (r'C:\Program Files\LibreOffice\program\soffice.exe',
                     r'C:\Program Files (x86)\LibreOffice\program\soffice.exe',
                     '/Applications/LibreOffice.app/Contents/MacOS/soffice') if Path(c).exists()), None)


def _to_png(files, timeout):
    """EMF/WMF → PNG рядом (в IMAGE_CACHE) одним запуском LibreOffice на пачку файлов. По истечении
    времени LibreOffice завершается вместе с дочерними процессами."""
    soffice = _soffice()
    if not soffice or not files:
        return bool(soffice)
    prof = IMAGE_CACHE / 'lo_profile'
    kw = {'stdout': subprocess.DEVNULL, 'stderr': subprocess.DEVNULL}
    if os.name == 'nt':
        kw['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP | getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    else:
        kw['start_new_session'] = True
    try:
        proc = subprocess.Popen([soffice, f'-env:UserInstallation={prof.as_uri()}', '--headless', '--convert-to', 'png',
                                 '--outdir', str(IMAGE_CACHE)] + [str(f) for f in files], **kw)
    except OSError:
        return True
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        if os.name == 'nt':
            subprocess.run(['taskkill', '/F', '/T', '/PID', str(proc.pid)], capture_output=True)
        else:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except OSError:
                proc.kill()
        proc.wait()
    return True


def _save_image(blob, ext, warnings, name):
    """Сохраняет картинку в кэш (output/cache); EMF/WMF переводит в PNG через LibreOffice."""
    IMAGE_CACHE.mkdir(parents=True, exist_ok=True)
    h = hashlib.sha1(blob).hexdigest()[:16]
    dst = IMAGE_CACHE / f'{h}{ext}'
    if not dst.exists():
        dst.write_bytes(blob)
    if ext in RASTER_EXT:
        return dst
    png = IMAGE_CACHE / f'{h}.png'
    if png.exists():
        return png
    if _to_png([dst], 120) and png.exists():
        return png
    warnings.append(f'{name}: рисунок в формате {ext} пропущен (для переноса EMF/WMF нужен LibreOffice).')
    return None


BIG_SIDE = 2000      # фото крупнее (по длинной стороне) уменьшаются: слайду хватает, а сборка и миниатюры не тяжелеют


def _shrink(path):
    """Крупное фото → копия не больше BIG_SIDE точек по длинной стороне (JPEG; с прозрачностью — PNG)."""
    try:
        from PIL import Image
        with Image.open(path) as im:
            if getattr(im, 'is_animated', False) or max(im.size) <= BIG_SIDE * 1.1:
                return path
            alpha = im.mode in ('RGBA', 'LA') or (im.mode == 'P' and 'transparency' in im.info)
            out = path.with_name(path.stem + ('_2k.png' if alpha else '_2k.jpg'))
            if not out.exists():
                small = im.convert('RGBA' if alpha else 'RGB')
                small.thumbnail((BIG_SIDE, BIG_SIDE))
                small.save(out, 'PNG' if alpha else 'JPEG', quality=88, optimize=True)
            return out
    except Exception:                               # noqa: BLE001 — не вышло уменьшить: берём как есть
        return path


def _save_images(items, warnings, name, budget=150):
    """Пачка рисунков [(sha1, blob, ext)] → {sha1: путь | None}. Растровые сохраняются (крупные фото
    уменьшаются), EMF/WMF переводятся в PNG одним запуском LibreOffice на все (запуск на каждый рисунок
    на Windows — секунды, в презентации таких рисунков десятки). Не уложились в budget секунд — остальные
    пропускаются с предупреждением."""
    IMAGE_CACHE.mkdir(parents=True, exist_ok=True)
    out, vec = {}, []
    for h, blob, ext in items:
        if h in out:
            continue
        dst = IMAGE_CACHE / f'{h[:16]}{ext}'
        if not dst.exists():
            dst.write_bytes(blob)
        if ext in RASTER_EXT:
            out[h] = _shrink(dst)
            continue
        png = dst.with_suffix('.png')
        out[h] = png if png.exists() else None
        if out[h] is None:
            vec.append((h, dst, png))
    have, deadline = True, time.monotonic() + budget
    for k in range(0, len(vec), 80):                # командная строка Windows — до 32 тыс. символов
        left = deadline - time.monotonic()
        if left < 5:
            break
        have = _to_png([d for _, d, _ in vec[k:k + 80]], left)
        if not have:
            break
    for h, _, png in vec:
        if png.exists():
            out[h] = png
    missing = sum(1 for h, _, _ in vec if out[h] is None)
    if missing:
        warnings.append(f'{name}: рисунков EMF/WMF пропущено: {missing} ' +
                        ('(для их переноса нужен LibreOffice).' if not have else '(LibreOffice не смог их перевести).'))
    return out


def _table_marked(t):
    """Таблица выделена автором: заливка первой ячейки (не белая, не «шапочная» серая) или маркер в тексте."""
    try:
        first = t.rows[0].cells[0]
        tcpr = first._tc.find(qn('w:tcPr'))
        shd = tcpr.find(qn('w:shd')) if tcpr is not None else None
        fill = (shd.get(qn('w:fill')) or 'auto').lower() if shd is not None else 'auto'
        if fill not in ('auto', 'ffffff', 'none') and fill not in ('d9d9d9', 'f2f2f2', 'e7e6e6', 'dddddd', 'bfbfbf'):
            if MARK_PREFIX_RX.match(first.text or '') or fill in ('ffff00', 'ffc000', 'ffff99', 'ffe699', 'ffd966'):
                return True
        for par in first.paragraphs:
            if MARK_PREFIX_RX.match(par.text or '') or any(_run_marked(r) for r in par.runs if r.text.strip()):
                return True
    except Exception:
        pass
    return False


def _table_rows(t):
    """Таблица Word → (строки, пометки «копий»).

    Объединённая по горизонтали ячейка повторяется во всех столбцах, которые она
    занимает, чтобы столбцы не съезжали; повторы помечаются как «копии» (True).
    """
    rows, copies = [], []
    for row in t.rows:
        cells, flags, prev = [], [], None
        for c in row.cells:
            same = prev is not None and c._tc is prev
            prev = c._tc
            cells.append(clean(' '.join(par.text for par in c.paragraphs)))
            flags.append(same)
        rows.append(cells)
        copies.append(flags)
    width = max((len(r) for r in rows), default=0)
    rows = [r + [''] * (width - len(r)) for r in rows]
    copies = [c + [True] * (width - len(c)) for c in copies]
    return rows, copies


def _is_num(s):
    from ..textutil import parse_number
    return parse_number(s) is not None


def _split_table(rows, copies):
    """Строки таблицы Word → (название из объединённой строки, шапка, тело).

    * первая строка, объединённая на всю ширину (одна ячейка), — название таблицы;
    * двухуровневая шапка (год над «План | Факт») склеивается: «2023 План», «2023 Факт»;
    * в остальных строках повторы объединённых ячеек убираются.
    """
    title = ''
    filled = lambda r, c: sum(1 for x, f in zip(r, c) if x.strip() and not f)
    if len(rows) >= 3 and filled(rows[0], copies[0]) == 1 and len(rows[0]) >= 2:
        title = next(x for x in rows[0] if x.strip())
        rows, copies = rows[1:], copies[1:]
    header, start = list(rows[0]), 1
    if (len(rows) >= 3 and any(copies[0]) and
            sum(1 for x in rows[1] if x.strip() and not _is_num(x)) >= 2 and
            any(_is_num(x) for x in rows[2])):
        header = [' '.join(dict.fromkeys(p for p in (h.strip(), s.strip()) if p))
                  for h, s in zip(rows[0], rows[1])]
        start = 2
    else:
        # в одноуровневой шапке повтор объединённой ячейки не нужен
        header = ['' if f else h for h, f in zip(header, copies[0])]
    body = [['' if f else x for x, f in zip(r, c)] for r, c in zip(rows[start:], copies[start:])]
    keep = [j for j in range(len(header)) if header[j].strip() or any(r[j].strip() for r in body)]
    header = [header[j] for j in keep]
    body = [[r[j] for j in keep] for r in body]
    return title, header, body


def read_docx(path, doc_model=None, name=None):
    """Читает .docx и добавляет его содержимое в модель Document (или создаёт новую)."""
    d = DocxDocument(path)
    model = doc_model or Document()
    name = name or str(path)
    model.sources.append(name)
    numbering = _numbering_formats(d)

    # Название документа: свойства файла или абзац со стилем «Название»
    title = clean(d.core_properties.title or '')

    root = Section(title='', level=0, source=name)    # «корень»: текст до первого заголовка
    stack = [root]
    pending_caption = ''
    last_image = None                                   # картинка, ждущая подпись «Рис. N»

    def current():
        return stack[-1]

    def add_list_item(text, bold, level, ordered, mark=False):
        sec = current()
        if sec.blocks and sec.blocks[-1].kind == 'list':
            sec.blocks[-1].items.append(ListItem(text, bold, level, mark))
        else:
            sec.blocks.append(Block('list', items=[ListItem(text, bold, level, mark)], ordered=ordered))
    pending_mark = False

    body = d.element.body
    for el in body.iterchildren():
        tag = el.tag.split('}')[-1]
        if tag == 'p':
            p = Paragraph(el, d)
            st = _style_name(p)
            stl = st.lower()
            # картинки (рисунки, схемы) — отдельный блок; подпись — текст этого же или следующего абзаца
            imgs = _para_images(p, d)
            if imgs:
                for blob, ext, cx, cy in imgs:
                    if cx and cx < 914400 * 0.8:          # мелкие значки (меньше 0,8") — не рисунки
                        continue
                    path = _save_image(blob, ext, model.warnings, name)
                    if path is None:
                        continue
                    fid = model.add_image(path, cx, cy)
                    blk = Block('image', image_id=fid, mark=bool(MARK_PREFIX_RX.match(p.text or '')))
                    current().blocks.append(blk)
                    last_image = blk
                cap = clean(p.text)
                if cap and last_image is not None and len(cap) < 200:
                    last_image.text = re.sub(r'(?i)^(рис\.?|рисунок|схема|figure|fig\.?)\s*№?\s*\d*\s*[.:—–-]?\s*', '', cap)
                    last_image = None
                continue
            whole_mark, part_mark, text = _mark_info(p, st)
            if not text:
                continue
            if last_image is not None and CAPTION_RX.match(text) and len(text) < 200:
                last_image.text = re.sub(r'(?i)^' + CAP_WORD + r'\s*№?\s*\d*\s*[.:—–-]?\s*', '', text)
                last_image = None
                continue
            last_image = None
            if stl.startswith('toc') or 'оглавлен' in stl or stl.startswith('header') or stl.startswith('footer'):
                continue
            if stl in ('title', 'название', 'заголовок'):
                if not title:
                    title = text
                continue
            if stl in ('subtitle', 'подзаголовок') and not model.subtitle:
                model.subtitle = text
                continue
            # Заголовок?
            level = None
            m = HEADING_RX.match(st)
            if m:
                level = int(m.group(2))
            elif _outline_level(p):
                level = _outline_level(p)
            elif (_all_bold(p) and len(text) <= 90 and not text.endswith(('.', ':', ';', ','))
                  and len(text.split()) <= 12 and _num_info(p, numbering) is None):
                level = 3                       # псевдозаголовок: короткий жирный абзац
            if level is not None:
                level = max(1, min(level, 3))
                sec = Section(title=text, level=level, source=name, mark=whole_mark or bool(part_mark))
                while len(stack) > 1 and stack[-1].level >= level:
                    stack.pop()
                stack[-1].children.append(sec)
                stack.append(sec)
                continue
            # Подпись к таблице
            if re.match(r'(?i)^(таблица|табл\.)\s*\d*', text) and len(text) < 160:
                pending_caption = re.sub(r'(?i)^(таблица|табл\.)\s*\d*\s*[.:—–-]?\s*', '', text)
                pending_mark = whole_mark
                continue
            # Элемент списка?
            ni = _num_info(p, numbering)
            bold = _bold_prefix(p)
            if ni is not None:
                add_list_item(text, bold, ni[0], ni[1], whole_mark or bool(part_mark))
                continue
            mb = re.match(r'^\s*([•●▪■◦○\-–—*·►✓✔]|\d{1,2}[.)])\s+', p.text or '')
            if mb:                              # маркер набран вручную («– согласовать …;», «1) …»)
                item = re.sub(r'[;,]$', '.', text.rstrip())
                add_list_item(item[:1].upper() + item[1:], bold, 0, mb.group(1)[0].isdigit(), whole_mark or bool(part_mark))
                continue
            current().blocks.append(Block('para', text=text, bold=bold, mark=whole_mark, mark_text=part_mark))
        elif tag == 'tbl':
            t = DocxTable(el, d)
            rows, copies = _table_rows(t)
            nz = [i for i, r in enumerate(rows) if any(c.strip() for c in r)]
            rows, copies = [rows[i] for i in nz], [copies[i] for i in nz]
            distinct = max((sum(1 for x, f in zip(r, c) if x.strip() and not f) for r, c in zip(rows, copies)),
                           default=0)
            if len(rows) >= 2 and distinct >= 2:
                cap, header, body = _split_table(rows, copies)
                if body and len(header) >= 2:
                    cap = re.sub(r'(?i)^(таблица|табл\.)\s*\d*\s*[.:—–-]?\s*', '', cap)
                    tb = model.add_table(header, body, title=pending_caption or cap, source=name)
                    current().blocks.append(Block('table', table_id=tb.id, mark=pending_mark or _table_marked(t)))
            elif rows:
                # таблица-«рамка» из одной колонки — это просто текст
                for r, cf in zip(rows, copies):
                    for c, f in zip(r, cf):
                        if c.strip() and not f:
                            current().blocks.append(Block('para', text=c))
            pending_caption = ''
            pending_mark = False

    # Сборка разделов: текст до первого заголовка становится вводным разделом
    secs = []
    if root.blocks:
        secs.append(Section(title='Введение' if root.children else (title or 'Основное'), level=1,
                            blocks=root.blocks, source=name))
    secs.extend(root.children)

    # Если весь документ — один раздел 1-го уровня, его заголовок — это название документа
    if len([s for s in secs if s.level == 1]) == 1 and len(secs) == 1 and secs[0].children:
        if not title:
            title = secs[0].title
        intro = secs[0]
        secs = ([Section('Введение', 1, intro.blocks, source=name)] if intro.blocks else []) + intro.children
        for s in secs:
            _promote(s)

    if not title and secs:
        title = secs[0].title
    if not model.title:
        model.title = title
    model.sections.extend(secs)
    return model


def _promote(sec):
    """Поднимает уровень раздела на 1 (когда верхний уровень оказался «обёрткой»)."""
    sec.level = max(1, sec.level - 1)
    for c in sec.children:
        _promote(c)
