# -*- coding: utf-8 -*-
"""
pictures.py — КАРТИНКИ К СЛАЙДАМ: БИБЛИОТЕКА, КАРТЫ СТРАН И СВОИ КАРТИНКИ ПОЛЬЗОВАТЕЛЯ
====================================================================================

Библиотека — assets/pictures/*.svg и каталог assets/pictures/catalog.json (название, раздел, основы
слов для подбора, источник). Все рисунки векторные, в фирменной палитре; при сборке svgdraw
переводит их в обычные фигуры PowerPoint (их можно перекрасить и подвинуть).

Карта страны — та же карта мира (engine/geo.py), выбранная страна выделена: код «map_VNM».

Свои картинки пользователя (PNG, JPEG, GIF, BMP, WEBP, TIFF, SVG) сохраняются в output/uploads/ под
именем-хэшем; растровые приводятся к PNG/JPEG и уменьшаются до 2400 точек по большей стороне,
SVG очищается (svgdraw.sanitize), хранится файлом .svg и при сборке становится фигурами, как рисунки
библиотеки. Исходное имя файла и время загрузки — в output/uploads/index.json (для окна «Мои картинки»
и подбора по словам из имени файла).

В плане рисунок слайда «image» — элемент images: {'picture': код} (библиотека или карта),
{'upload': имя файла} (своя картинка), {'svg': текст} (рисунок модели ИИ), {'path': путь}
(рисунок из документа). resolve() превращает ссылку в то, что умеет рисовать макет.

  catalog(), get(id), svg(id), countries_list()
  suggest(slide, n)      — картинки, подходящие к слайду по словам заголовка и текста;
  deck_suggest(slides)   — картинки, подходящие к презентации в целом (окно «Картинки к слайдам»);
  picture_alt(slide, im, full=False, label=…) — вариант слайда с картинкой (im — одна или список до 3);
  distribute(slides, images, mode) — раскладка выбранных картинок по слайдам (по смыслу или по порядку);
  save_upload(data, filename) → элемент images для своей картинки;
  list_uploads(), delete_upload(name) — свои картинки: список и удаление;
  auto_pictures(slides)  — при анализе: картинка-вариант к подходящим слайдам.
"""
import hashlib
import io
import json
import re
import threading
import time
from functools import lru_cache
from pathlib import Path

from .nts import config as C

PIC_DIR = C.ASSETS / 'pictures'
CATALOG_FILE = PIC_DIR / 'catalog.json'
UPLOAD_DIR = C.OUTPUT_DIR / 'uploads'
CATEGORIES = ['Нефть и газ', 'Разведка и добыча', 'Шельф', 'Переработка и сбыт', 'Наука и технологии',
              'Энергетика', 'Низкоуглеродное развитие', 'Экология и безопасность', 'Логистика и строительство',
              'Финансы', 'Управление и стратегия', 'Цифровизация', 'Люди и коммуникации', 'Документы и контроль',
              'Карты']
RASTER = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp', '.tif', '.tiff'}
MAX_UPLOAD = 25 * 1024 * 1024
MAX_SIDE = 2400
# слайды, к которым картинка подходит как вариант (тезисы рядом с рисунком)
PICTURE_LAYOUTS = ('text', 'list', 'cards', 'conclusions', 'process', 'target', 'honeycomb', 'pillars', 'hub',
                   'petals', 'puzzle', 'converge', 'checklist')
# слайды, на которые картинку не ставим даже вручную: титул, разделы, содержание, финал, таблица, диаграмма
NO_PICTURE = ('title', 'section', 'end', 'agenda', 'table', 'chart')
MAX_PER_SLIDE = 3                                           # столько картинок помещается на слайд (макет image)
UPLOAD_RX = re.compile(r'[0-9a-f]{20}\.(png|jpg|svg)')


class PictureError(Exception):
    pass


# --------------------------------------------------------------------------------------
# Каталог
# --------------------------------------------------------------------------------------
@lru_cache(maxsize=1)
def catalog():
    """Рисунки библиотеки (только те, у которых есть файл), в порядке разделов."""
    try:
        raw = json.loads(CATALOG_FILE.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        raw = []
    out = []
    for e in raw:
        if isinstance(e, dict) and re.fullmatch(r'[a-z0-9_]+', str(e.get('id') or '')) \
                and (PIC_DIR / f'{e["id"]}.svg').exists():
            out.append({'id': e['id'], 'name': e.get('name') or e['id'], 'cat': e.get('cat') or 'Разное',
                        'tags': [t.lower() for t in e.get('tags') or [] if isinstance(t, str) and len(t) >= 3],
                        'source': e.get('source') or {}})
    order = {c: i for i, c in enumerate(CATEGORIES)}
    out.sort(key=lambda e: (order.get(e['cat'], 99), e['id'].startswith('fe_')))
    return out


def _by_id():
    return {e['id']: e for e in catalog()}


def countries_list():
    """[{'id': 'map_VNM', 'name': 'Вьетнам'}] — для выбора карты страны."""
    from .geo import countries
    return sorted(({'id': f'map_{c["id"]}', 'name': c['name']} for c in countries().values() if c['name']),
                  key=lambda c: c['name'])


COUNTRY_RX = re.compile(r'map_[A-Z0-9]{3}')                 # карта страны: map_ + код ISO (заглавными); id библиотеки — строчными


def get(pid):
    pid = str(pid or '')
    if COUNTRY_RX.fullmatch(pid):
        from .geo import countries
        c = countries().get(pid[4:])
        return {'id': pid, 'name': f'Карта: {c["name"]}', 'cat': 'Карты', 'tags': [], 'source': {}} if c else None
    return _by_id().get(pid)


@lru_cache(maxsize=256)
def svg(pid):
    """Текст SVG рисунка (очищенный). Нет такого — PictureError."""
    from .svgdraw import SvgError, sanitize
    pid = str(pid or '')
    if COUNTRY_RX.fullmatch(pid):
        if not get(pid):
            raise PictureError(f'нет страны {pid[4:]}')
        from .geo import picture_svg
        return picture_svg([pid[4:]])
    if not re.fullmatch(r'[a-z0-9_]+', pid) or not (PIC_DIR / f'{pid}.svg').exists():
        raise PictureError(f'нет картинки «{pid}» в библиотеке')
    try:
        return sanitize((PIC_DIR / f'{pid}.svg').read_text(encoding='utf-8'))
    except (OSError, SvgError) as e:
        raise PictureError(f'картинка «{pid}» повреждена: {e}')


# --------------------------------------------------------------------------------------
# Подбор по смыслу
# --------------------------------------------------------------------------------------
_TOK = re.compile(r'[а-яёa-z0-9]+')


def _tokens(text):
    return _TOK.findall((text or '').lower().replace('ё', 'е'))


def _hits(tags, toks):
    """Совпавшие основы. Основа из нескольких слов («ремонт скважин») совпадает, только если есть все её слова."""
    out = set()
    for t in tags:
        if all(any(w.startswith(p) for w in toks) for p in t.replace('ё', 'е').split()):
            out.add(t)
    return out


def _matched_tokens(tags, toks):
    parts = {p for t in tags for p in t.replace('ё', 'е').split()}
    return {w for w in toks if any(w.startswith(p) for p in parts)}


def _slide_texts(s):
    from .illustrate import slide_subject
    return s.get('title') or '', slide_subject(s)


def suggest(s, n=8, query=None):
    """[(запись каталога, баллы)] по убыванию: совпадение основы в заголовке — 3 балла, в тексте — 1;
    у пиктограмм (fe_…) баллы ×0,6, поэтому сами по себе они добавляются, только если совпали два слова заголовка."""
    title, body = (query, '') if query else _slide_texts(s)
    tt, bt = _tokens(title), _tokens(body)
    res, df = [], {}
    for e in catalog():
        th = _hits(e['tags'], tt)
        bh = _hits(e['tags'], bt) - th
        sc = 3 * len(th) + len(bh) + (2 if query and _tokens(e['name']) and
                                      all(any(w.startswith(x[:5]) for w in tt) for x in _tokens(e['name'])) else 0)
        if sc and e['id'].startswith('fe_'):                 # пиктограммы — запасной вариант после сюжетных картинок
            sc = round(sc * 0.6, 1)
        if sc:
            mt = _matched_tokens(th, tt)
            for w in mt:
                df[w] = df.get(w, 0) + 1
            res.append((e, sc, len(th), mt))
    # при равных баллах выше картинка, совпавшая по более редкому слову заголовка («двойник» точнее, чем «месторождение»)
    res.sort(key=lambda r: (-r[1], -r[2], -sum(1 / df[w] for w in r[3]), r[0]['id'].startswith('fe_')))
    return [(e, sc) for e, sc, _, _ in res[:n]]


def search(query, cat=None, limit=200):
    """Поиск по названию и основам слов (для окна выбора)."""
    q = _tokens(query)
    out = []
    for e in catalog():
        if cat and e['cat'] != cat:
            continue
        if q:
            name = _tokens(e['name'])
            if not all(any(w.startswith(x) or x.startswith(w[:4]) for w in name + e['tags']) for x in q):
                continue
        out.append(e)
    return out[:limit]


# --------------------------------------------------------------------------------------
# Свои картинки
# --------------------------------------------------------------------------------------
def save_upload(data, filename):
    """Байты файла → элемент images: {'upload': имя} (растр) или {'svg': текст} (SVG). Ошибка → PictureError."""
    ext = Path(filename or '').suffix.lower()
    if not data:
        raise PictureError('файл пустой')
    if len(data) > MAX_UPLOAD:
        raise PictureError('файл больше 25 МБ')
    if ext == '.svg' or data.lstrip()[:5] in (b'<?xml', b'<svg ') and b'<svg' in data[:2000]:
        from .svgdraw import SvgError, sanitize
        try:
            text = sanitize(data.decode('utf-8', errors='replace'))
        except SvgError as e:
            raise PictureError(f'SVG не подходит: {e}')
        return {'upload': _store(text.encode('utf-8'), '.svg', filename), 'caption': ''}
    from PIL import Image, ImageOps
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
    except Exception:                                        # noqa: BLE001
        raise PictureError('это не картинка (поддерживаются PNG, JPEG, GIF, BMP, WEBP, TIFF и SVG)')
    im = ImageOps.exif_transpose(im)
    if max(im.size) > MAX_SIDE:
        im.thumbnail((MAX_SIDE, MAX_SIDE), Image.LANCZOS)
    alpha = im.mode in ('RGBA', 'LA', 'P') and ('transparency' in im.info or im.mode != 'P')
    out = io.BytesIO()
    if alpha:
        im.convert('RGBA').save(out, 'PNG', optimize=True)
        ext2 = '.png'
    else:
        im.convert('RGB').save(out, 'JPEG', quality=90, optimize=True)
        ext2 = '.jpg'
    return {'upload': _store(out.getvalue(), ext2, filename), 'caption': ''}


_INDEX_LOCK = threading.Lock()


def _index_file():
    return UPLOAD_DIR / 'index.json'


def _load_index():
    try:
        d = json.loads(_index_file().read_text(encoding='utf-8'))
        return d if isinstance(d, dict) else {}
    except Exception:                                        # noqa: BLE001 — нет файла или он испорчен: начинаем заново
        return {}


def _save_index(d):
    tmp = _index_file().with_suffix('.tmp')
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding='utf-8')
    tmp.replace(_index_file())


def _store(b, ext, filename):
    """Сохраняет файл под именем-хэшем и записывает в индекс исходное имя. Возвращает имя файла."""
    name = hashlib.sha1(b).hexdigest()[:20] + ext
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    dst = UPLOAD_DIR / name
    if not dst.exists():
        dst.write_bytes(b)
    orig = Path(str(filename or '').replace('\\', '/')).name[:120]
    with _INDEX_LOCK:
        idx = _load_index()
        if orig or name not in idx:
            idx[name] = {'name': orig or (idx.get(name) or {}).get('name', ''),
                         'added': time.strftime('%Y-%m-%dT%H:%M:%S')}
            try:
                _save_index(idx)
            except OSError:                                  # индекс — только для удобства; без него картинка работает
                pass
    return name


def upload_path(name):
    """Путь к своей картинке по имени (только файлы output/uploads/ с именем-хэшем) или None."""
    if not UPLOAD_RX.fullmatch(str(name or '')):
        return None
    p = UPLOAD_DIR / name
    return p if p.exists() else None


def list_uploads(names=None):
    """Свои картинки, новые первыми: [{'upload', 'name' (исходное имя файла), 'added', 'size'}].
    names — только эти файлы (для пользователя с другого компьютера: он видит лишь свои загрузки)."""
    idx = _load_index()
    if names is None:
        paths = sorted(UPLOAD_DIR.iterdir()) if UPLOAD_DIR.exists() else []
    else:
        paths = [UPLOAD_DIR / n for n in dict.fromkeys(str(n) for n in names) if UPLOAD_RX.fullmatch(n)]
    out = []
    for p in paths:
        if not UPLOAD_RX.fullmatch(p.name) or not p.is_file():
            continue
        st = p.stat()
        info = idx.get(p.name) or {}
        out.append({'upload': p.name, 'name': str(info.get('name') or ''), 'size': st.st_size,
                    'added': str(info.get('added') or time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(st.st_mtime)))})
    out.sort(key=lambda e: e['added'], reverse=True)
    return out


def delete_upload(name):
    """Удаляет свою картинку из output/uploads/. True — удалена, False — такой нет."""
    p = upload_path(name)
    if not p:
        return False
    p.unlink()
    with _INDEX_LOCK:
        idx = _load_index()
        if idx.pop(name, None) is not None:
            try:
                _save_index(idx)
            except OSError:
                pass
    return True


def upload_name(name):
    """Исходное имя файла своей картинки (из индекса) или ''."""
    return str((_load_index().get(str(name or '')) or {}).get('name') or '')


def resolve(im):
    """Элемент images → то, что рисует макет: {'svg': …} или {'path': …}. Нет файла — None."""
    if not isinstance(im, dict):
        return None
    if im.get('svg'):
        return im
    if im.get('picture'):
        try:
            return dict(im, svg=svg(im['picture']))
        except PictureError:
            return None
    if im.get('upload'):
        p = upload_path(im['upload'])
        if p and p.suffix == '.svg':                         # свой векторный рисунок — фигурами, как библиотека
            return dict(im, svg=p.read_text(encoding='utf-8'))
        return dict(im, path=str(p)) if p else None
    if im.get('path') and Path(im['path']).exists():
        return im
    return None


# --------------------------------------------------------------------------------------
# Вариант слайда с картинкой
# --------------------------------------------------------------------------------------
def picture_alt(s, im, full=False, label=None):
    """Вариант слайда: картинка + тезисы слайда (full=True — только картинка крупно, с подписью).
    im — одна картинка или список (до трёх): одна стоит справа от тезисов, две-три — сеткой слева,
    тезисы — пронумерованным списком справа."""
    from .illustrate import illustrated_slide
    ims = [dict(x) for x in (im if isinstance(im, (list, tuple)) else [im]) if isinstance(x, dict)][:MAX_PER_SLIDE]
    if full:
        alt = {'layout': 'image', 'title': s.get('title') or '', 'subtitle': s.get('subtitle') or '',
               'section': s.get('section') or '', 'images': ims, 'items': [],
               'conclusion': s.get('conclusion') or ''}
    else:
        alt = illustrated_slide(s, None)
        alt['images'] = ims
        if len(ims) > 1:
            alt['illustration'] = False
    alt['pic_alt'] = True                                    # признак варианта «с картинкой» (его можно убрать в окне)
    alt['alt_label'] = label or (labels_of(ims) if len(ims) > 1 else 'С картинкой')
    return alt


def label_of(im):
    if im.get('picture'):
        e = get(im['picture'])
        return f'Картинка: {e["name"]}' if e else 'Картинка'
    if im.get('upload'):
        name = _short_name(im['upload'])
        return f'Своя картинка: {name}'[:60] if name else 'Своя картинка'
    if im.get('svg') and not im.get('ai'):
        return 'Своя картинка'
    return 'Иллюстрация'


def _short_name(upload):
    """Имя своей картинки для подписи варианта: исходное имя файла без расширения или ''."""
    return Path(upload_name(upload)).stem.replace('_', ' ').strip()[:30]


def labels_of(ims):
    """Подпись варианта с несколькими картинками: «Картинки: Буровая, Танкер» (не длиннее 60 знаков)."""
    if len(ims) == 1:
        return label_of(ims[0])
    names = []
    for im in ims:
        e = get(im['picture']) if im.get('picture') else None
        names.append(e['name'].replace('Карта: ', '') if e else (im.get('upload') and _short_name(im['upload'])) or 'своя')
    out = 'Картинки: ' + ', '.join(names)
    return out if len(out) <= 60 else out[:58].rstrip(' ,') + '…'


# --------------------------------------------------------------------------------------
# Раскладка выбранных картинок по слайдам (окно «Картинки к слайдам»)
# --------------------------------------------------------------------------------------
# слова, которые часто бывают в именах файлов, но о сюжете ничего не говорят
_FILE_NOISE = {'img', 'image', 'images', 'pic', 'picture', 'photo', 'foto', 'scan', 'dsc', 'dcim', 'screenshot', 'screen',
               'shot', 'copy', 'final', 'new', 'jpg', 'jpeg', 'png', 'svg', 'webp', 'tif', 'tiff', 'bmp', 'gif', 'фото',
               'картинка', 'изображение', 'рисунок', 'снимок', 'экрана', 'скриншот', 'копия', 'новый', 'новая', 'файл'}


def _file_stems(filename):
    """Основы слов из имени файла: «Буровая_установка-2024.jpg» → ['буров', 'устан']."""
    stem = Path(str(filename or '')).stem
    stem = re.sub(r'([a-zа-яё])([A-ZА-ЯЁ])', r'\1 \2', stem)     # ВерблюжийРегистр → два слова
    out = []
    for w in _tokens(stem.replace('_', ' ')):
        if len(w) < 3 or w.isdigit() or w in _FILE_NOISE:
            continue
        out.append(w[:5] if len(w) > 5 else w)
    return list(dict.fromkeys(out))


class _SlideWords:
    def __init__(self, s):
        title, body = _slide_texts(s)
        self.title, self.body = title, body
        self.tt, self.bt = _tokens(title), _tokens(body)
        self._countries = None

    def countries(self):
        if self._countries is None:
            from .geo import find_countries
            self._countries = (find_countries(self.title), find_countries(self.body))
        return self._countries


def _match(im, sw, names):
    """(баллы, почему) — насколько картинка подходит к слайду. Заголовок — 3 балла за слово, текст — 1."""
    if im.get('picture'):
        pid = str(im['picture'])
        if COUNTRY_RX.fullmatch(pid):
            t, b = sw.countries()
            c = get(pid)
            cname = c['name'].replace('Карта: ', '') if c else pid[4:]
            if pid[4:] in t:
                return 4, f'на слайде речь о стране: {cname}'
            if pid[4:] in b:
                return 2, f'на слайде упомянута страна: {cname}'
            return 0, ''
        e = get(pid)
        if not e:
            return 0, ''
        th = _hits(e['tags'], sw.tt)
        bh = _hits(e['tags'], sw.bt) - th
        sc = 3 * len(th) + len(bh)
        if sc and pid.startswith('fe_'):
            sc = round(sc * 0.6, 1)
        words = sorted(_matched_tokens(th, sw.tt) | _matched_tokens(bh, sw.bt))
        return sc, ('совпало: ' + ', '.join(words[:3])) if sc else ''
    if im.get('upload'):
        stems = _file_stems(names.get(im['upload']) or upload_name(im['upload']))
        th = {p for p in stems if any(w.startswith(p) for w in sw.tt)}
        bh = {p for p in stems if any(w.startswith(p) for w in sw.bt)} - th
        sc = 3 * len(th) + len(bh)
        words = sorted({w for w in sw.tt + sw.bt if any(w.startswith(p) for p in th | bh)})
        return sc, ('совпало с именем файла: ' + ', '.join(words[:3])) if sc else ''
    return 0, ''


def _key(im):
    return im.get('picture') or im.get('upload') or ''


def distribute(slides, images, mode='auto', busy=(), load=None, names=None):
    """Раскладка картинок по слайдам. slides — слайды плана (исходные тезисы, без вариантов),
    images — картинки, которые надо поставить ({'picture'} или {'upload'}), busy — номера слайдов,
    которые не трогаем (там рисунок из документа или модели ИИ), load — {номер слайда: сколько картинок
    на нём уже стоит} (такие слайды берутся, только когда свободных не осталось).
    mode='auto' — по смыслу, 'order' — по порядку. Возвращает [{'slide': номер или None, 'score', 'why'}]
    в порядке images.

    По смыслу: (1) каждой картинке — слайд с тезисами, где совпало больше слов (жадно, лучшие пары
    первыми; на слайд — одна картинка); (2) картинки без совпадений — равномерно на свободные слайды
    с тезисами; (3) свободных не осталось — вторая и третья картинка на слайд (лучше — туда, где
    есть совпадение); (4) и это занято — на прочие слайды (кроме титула, разделов, таблиц, диаграмм)."""
    names = names or {}
    busy = set(busy or ())
    n = len(images)
    res = [{'slide': None, 'score': 0, 'why': ''} for _ in range(n)]
    lay = [s.get('layout') if isinstance(s, dict) else None for s in slides]
    primary = [j for j, s in enumerate(slides) if j not in busy and (lay[j] in PICTURE_LAYOUTS or lay[j] == 'image')]
    secondary = [j for j, s in enumerate(slides) if j not in busy and j not in primary and lay[j] and lay[j] not in NO_PICTURE]
    if not n:
        return res
    if not primary and not secondary:
        for r in res:
            r['why'] = 'в плане нет слайдов, к которым можно поставить картинку'
        return res
    load = {int(k): int(v) for k, v in (load or {}).items() if str(k).lstrip('-').isdigit()}   # слайд → картинок на нём

    def put(i, j, sc, why):
        res[i].update(slide=j, score=sc, why=why)
        load[j] = load.get(j, 0) + 1

    if mode == 'order':
        pool = primary or secondary
        for i in range(n):
            free = [j for j in pool if not load.get(j)]
            cand = free or [j for j in pool if load.get(j, 0) < MAX_PER_SLIDE]
            if not cand:
                res[i]['why'] = 'не хватило слайдов (на слайд — не больше трёх картинок)'
                continue
            j = cand[0] if free else min(cand, key=lambda j: (load.get(j, 0), j))
            put(i, j, 0, 'по порядку' if free else 'по порядку, ещё одна картинка на слайде')
        return res

    words = {j: _SlideWords(slides[j]) for j in primary + secondary}
    score = {}
    for i, im in enumerate(images):
        for j in primary + secondary:
            sc, why = _match(im, words[j], names)
            if sc:
                score[i, j] = (sc, why)
    # (1) лучшие пары — первыми; при равных баллах — слайд раньше по ходу доклада
    for (i, j), (sc, why) in sorted(score.items(), key=lambda kv: (-kv[1][0], kv[0][1], kv[0][0])):
        if j in primary and res[i]['slide'] is None and not load.get(j):
            put(i, j, sc, why)
    # (2) без совпадений — равномерно по свободным слайдам с тезисами
    rest = [i for i in range(n) if res[i]['slide'] is None]
    free = [j for j in primary if not load.get(j)]
    if rest and free:
        k = min(len(rest), len(free))
        picks = [free[int((t + 0.5) * len(free) / k)] for t in range(k)]
        for i, j in zip(rest, picks):
            put(i, j, 0, 'по словам не совпала — поставил на свободный слайд с тезисами')
    # (3) вторая-третья картинка на слайд: сначала туда, где есть совпадение, затем по очереди
    for pool, why0 in ((primary, 'свободных слайдов не осталось — ещё одна картинка на слайде'),
                       (secondary, 'слайдов с тезисами не хватило — поставил на слайд-схему (её можно вернуть в «Вариантах»)')):
        rest = [i for i in range(n) if res[i]['slide'] is None]
        if not rest or not pool:
            continue
        if pool is secondary:                                # прочие слайды: сначала по одной картинке
            for i in list(rest):
                best = max((j for j in pool if not load.get(j)), key=lambda j: (score.get((i, j), (0,))[0], -j), default=None)
                if best is not None:
                    sc, why = score.get((i, best), (0, ''))
                    put(i, best, sc, why or why0)
            rest = [i for i in range(n) if res[i]['slide'] is None]
        for i in rest:
            cand = [j for j in pool if load.get(j, 0) < MAX_PER_SLIDE]
            if not cand:
                break
            best = max(cand, key=lambda j: (score.get((i, j), (0,))[0], -load.get(j, 0), -j))
            sc, why = score.get((i, best), (0, ''))
            put(i, best, sc, why or why0)
    for r in res:
        if r['slide'] is None:
            r['why'] = 'не хватило слайдов (на слайд — не больше трёх картинок)'
    return res


def deck_suggest(slides, n=36):
    """Картинки, подходящие к презентации: лучшие по слайдам с тезисами и карты упомянутых стран.
    [{'id', 'name', 'cat', 'slide': номер слайда, к которому подходит больше всего}]."""
    best = {}
    for j, s in enumerate(slides):
        if not isinstance(s, dict) or s.get('layout') in NO_PICTURE:
            continue
        for e, sc in suggest(s, 4):
            if sc >= 2 and (e['id'] not in best or sc > best[e['id']][0]):
                best[e['id']] = (sc, j, e)
    out = [{'id': e['id'], 'name': e['name'], 'cat': e['cat'], 'slide': j}
           for sc, j, e in sorted(best.values(), key=lambda v: (-v[0], v[1]))[:n]]
    from .geo import find_countries
    from .illustrate import slide_subject
    seen = set()
    for j, s in enumerate(slides):
        if not isinstance(s, dict) or s.get('layout') in NO_PICTURE:
            continue
        for cid in find_countries(slide_subject(s))[:3]:
            e = get(f'map_{cid}')
            if e and cid not in seen and len(seen) < 6:
                seen.add(cid)
                out.append({'id': e['id'], 'name': e['name'], 'cat': 'Карты стран', 'slide': j})
    return out


def auto_pictures(slides, main_for_text=True):
    """Картинка из библиотеки к подходящим слайдам — вариантом (в alts). Слайду «одна мысль» (text)
    с явным совпадением по заголовку картинка ставится основной. Одна картинка — не больше одного
    раза на доклад. Возвращает число слайдов с картинками."""
    from .variety import apply_alt
    used = set()
    n = 0
    for s in slides:
        if s.get('layout') not in PICTURE_LAYOUTS or s.get('keep_layout'):
            continue
        if any(a.get('layout') == 'image' for a in s.get('alts') or []):
            continue
        best = next(((e, sc) for e, sc in suggest(s, 6) if e['id'] not in used and sc >= 3), None)
        if not best:
            continue
        e, sc = best
        used.add(e['id'])
        alt = picture_alt(s, {'picture': e['id'], 'caption': ''}, label=f'Картинка: {e["name"]}')
        alts = s.get('alts') or [dict({k: v for k, v in s.items() if k not in ('alts', 'notes')},
                                      alt_label=s.get('alt_label') or 'Текущий')]
        alts = alts[:4] + [alt]
        s['alts'] = alts
        n += 1
        # основной картинка становится, только если совпало и слово заголовка, и что-то из текста (≥ 4 баллов):
        # одно общее слово («закачка») ещё не тема слайда
        title_hit = sc >= 4 and _hits(e['tags'], _tokens(s.get('title') or ''))
        if main_for_text and s.get('layout') == 'text' and title_hit:
            new = apply_alt(s, len(alts) - 1)
            s.clear()
            s.update(new)
    return n
