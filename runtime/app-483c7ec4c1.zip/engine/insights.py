# -*- coding: utf-8 -*-
"""
insights.py — АНАЛИЗ ТАБЛИЦ: выбор диаграммы и автоматические выводы по данным
=============================================================================

Для каждой таблицы с числами решается:
  * какую диаграмму строить (choose_chart):
      - подписи — годы/кварталы/месяцы → линия (много точек) или столбцы (мало точек);
      - один ряд, ≤ 6 категорий, это доли/проценты → кольцевая диаграмма;
      - длинные подписи категорий → горизонтальные полосы (bar), иначе столбцы;
      - больше 12 категорий → показываются 10 наибольших;
  * какие выводы написать рядом с диаграммой (make_insights) — только то, что СЧИТАЕТСЯ
    из данных: максимум/минимум, итог, доля лидера, изменение за период, среднегодовой
    темп роста, отклонение факта от плана. Никаких «додуманных» фактов.
"""
import re

from .textutil import NBSP, fmt_number, parse_number

SHARE_RX = re.compile(r'(?i)дол[яиюе]|структур|состав|распредел|%|процент|удельн')
PLAN_RX = re.compile(r'(?i)^план')
RADAR_RX = re.compile(r'(?i)критери|компетенц|оценк[аи] по|профил|зрелост|готовност|соответстви|рейтинг|балл')
AREA_RX = re.compile(r'(?i)накопленн|нарастающ|накоплени|совокупн')
FACT_RX = re.compile(r'(?i)^факт')


def _unit_of(table, j):
    """Единица столбца: из формата Excel или из заголовка («…, млн руб.»)."""
    if j < len(table.units) and table.units[j]:
        return table.units[j]
    m = re.search(r',\s*([^,]{1,20})$', table.columns[j]) if j < len(table.columns) else None
    return m.group(1).strip() if m else ''


def _common_unit(table):
    """Общая единица таблицы — из названия («…, млн руб.») или общей единицы столбцов."""
    us = {_unit_of(table, j) for j in table.numeric_cols}
    if len(us) == 1 and '' not in us:
        return us.pop()
    m = re.search(r',\s*([^,()]{1,20})(?:\s*\(.*\))?$', table.title or '')
    return m.group(1).strip() if m else ''


YEAR_HDR = re.compile(r'(?i)^\s*((19|20)\d\d|[1-4]\s?кв|q[1-4]|[IV]{1,3}\s?кв|(янв|фев|мар|апр|ма[йя]|июн|июл|авг|сен|окт|ноя|дек))')


def _transposed(table):
    """Шапка таблицы — годы/кварталы (2026 | 2027 | 2028), строки — статьи.
    Тогда по оси X — периоды, ряды — статьи (столбцы с накоплением: видно и итог, и состав)."""
    hs = [table.columns[j] for j in table.numeric_cols]
    if len(hs) < 2 or not all(YEAR_HDR.match(str(h)) for h in hs):
        return None
    rows = [r for i, r in enumerate(table.rows) if i != table.total_row]
    ser = []
    for r in rows:
        vals = [parse_number(r[j]) if j < len(r) else None for j in table.numeric_cols]
        if any(v is not None for v in vals):
            ser.append({'name': str(r[table.label_col]).strip(), 'values': vals})
    if len(ser) < 1:
        return None
    if len(ser) > 6:                                   # больше 6 статей: 5 крупнейших + «Прочие»
        ser.sort(key=lambda s: -sum(v or 0 for v in s['values']))
        other = [sum((s['values'][k] or 0) for s in ser[5:]) for k in range(len(hs))]
        ser = ser[:5] + [{'name': 'Прочие', 'values': other}]
    allpos = all((v or 0) >= 0 for s in ser for v in s['values'])
    ctype = 'stacked' if allpos and len(ser) >= 2 else ('line' if len(hs) > 7 else 'column')
    return {'type': ctype, 'categories': [str(h) for h in hs], 'series': ser, 'unit': _common_unit(table),
            'note': '', '_time': True}


LABEL_UNIT = re.compile(r',\s*([^,]{1,20})$')
KEY_COL = re.compile(r'(?i)добыч|прирост|выручк|прибыл|объ[её]м|запас|npv|чдд|затрат|инвестиц|вложени|эффект')


def label_units(table):
    """Единицы в подписях строк («Выручка, млрд руб.», «Рентабельность, %»): если строки в разных
    единицах — общей оси у них нет, диаграмма по такой таблице вводит в заблуждение."""
    labs = [str(r[table.label_col]) for r in table.rows if table.label_col < len(r)]
    us = [m.group(1).strip().lower() for m in (LABEL_UNIT.search(l) for l in labs) if m]
    return set(us) if labs and len(us) >= max(2, 0.6 * len(labs)) else set()


def choose_chart(table, title_hint=''):
    """Возвращает спецификацию диаграммы {'type', 'categories', 'series', 'unit', 'note'} или None."""
    if not table.numeric_cols or len(table.rows) < 2:
        return None
    if len(label_units(table)) >= 2:
        return None                                    # строки в разных единицах — только таблица
    if not table.is_time:
        tr = _transposed(table)
        if tr:
            return tr
    labels, series = table.series(max_series=4)
    sunits = [(LABEL_UNIT.search(str(nm)).group(1).strip() if LABEL_UNIT.search(str(nm)) else '') for nm, _ in series]
    if len(series) > 1 and len({u for u in sunits if u}) >= 2:
        # столбцы в разных единицах (скважины, тыс. т, т/сут) на одной оси не сравнить — один главный ряд
        k = next((i for i, (nm, _) in enumerate(series) if KEY_COL.search(str(nm))), 0)
        series = [series[k]]
    pairs = [(l, [s[1][i] for s in series]) for i, l in enumerate(labels)]
    pairs = [(l, vs) for l, vs in pairs if any(v is not None for v in vs)]
    if len(pairs) < 2:
        return None
    note = ''
    nser = len(series)
    unit = _common_unit(table)
    if nser == 1 and LABEL_UNIT.search(str(series[0][0])):
        unit = LABEL_UNIT.search(str(series[0][0])).group(1).strip()
    is_share = bool(SHARE_RX.search(' '.join([table.title, title_hint] + table.columns))) or unit == '%'
    hint = ' '.join([table.title, title_hint] + table.columns)
    vals_all = [v for _, vs in pairs for v in vs if v is not None]
    if table.is_time:
        ctype = 'line' if len(pairs) > 7 else 'column'
        if AREA_RX.search(hint) and vals_all and all(v >= 0 for v in vals_all) and len(pairs) >= 4:
            ctype = 'area'                              # накопленный итог — «область»
    elif (RADAR_RX.search(hint) and 4 <= len(pairs) <= 10 and nser <= 3 and vals_all
          and all(v >= 0 for v in vals_all)):
        ctype = 'radar'                                 # профиль по критериям — «радар»
    else:
        if len(pairs) > 12:
            key = [vs[0] or 0 for _, vs in pairs]
            order = sorted(range(len(pairs)), key=lambda i: -key[i])[:10]
            pairs = [pairs[i] for i in sorted(order)]
            note = 'Показаны 10 наибольших значений.'
        vals0 = [vs[0] for _, vs in pairs]
        if (nser == 1 and len(pairs) <= 6 and all(v is not None and v >= 0 for v in vals0)
                and (is_share or abs(sum(vals0) - 100) < 1.5)):
            ctype = 'doughnut'
        else:
            avg_len = sum(len(l) for l, _ in pairs) / len(pairs)
            ctype = 'bar' if avg_len > 14 or len(pairs) > 8 else 'column'
    cats = [l for l, _ in pairs]
    ser = [{'name': series[k][0], 'values': [vs[k] for _, vs in pairs]} for k in range(nser)]
    return {'type': ctype, 'categories': cats, 'series': ser, 'unit': unit, 'note': note}


def _pct(a, b):
    return (b - a) / abs(a) * 100 if a else None


def table_grid(table, max_cats=60, max_series=12):
    """Таблица документа → данные для окна «Диаграмма»: {'name', 'categories', 'series', 'type', 'unit', 'hint'}.
    В отличие от choose_chart, берутся ВСЕ числовые столбцы (выбирает пользователь); строка «Итого» не берётся.
    Шапка из годов (2026 | 2027 …) — периоды по оси X, ряды — строки таблицы."""
    table.analyze()
    rows = [r for i, r in enumerate(table.rows) if i != table.total_row]
    cols = list(table.numeric_cols)
    if not cols or not rows:
        return None
    cats = [str(r[table.label_col]).strip() if table.label_col < len(r) else '' for r in rows]
    series = [{'name': str(table.columns[j]).strip() or f'Ряд {k + 1}',
               'values': [parse_number(r[j]) if j < len(r) else None for r in rows]} for k, j in enumerate(cols)]
    hs = [str(table.columns[j]) for j in cols]
    if len(hs) >= 2 and all(YEAR_HDR.match(h) for h in hs):          # годы в шапке → по оси X периоды
        series = [{'name': c or f'Ряд {i + 1}', 'values': [s_['values'][i] for s_ in series]} for i, c in enumerate(cats)]
        cats = hs
    try:
        sug = choose_chart(table, table.title) or {}
    except Exception:                                   # noqa: BLE001 — подсказка необязательна
        sug = {}
    units = label_units(table)
    hint = ''
    if len(units) >= 2:
        hint = (f'Строки таблицы в разных единицах ({", ".join(sorted(units))}): на одной оси их не сравнить — '
                f'оставьте один ряд или выберите «Столбцы и линия».')
    unit = sug.get('unit') or _common_unit(table) or ''
    if not unit and len(series) == 1 and LABEL_UNIT.search(series[0]['name']):
        unit = LABEL_UNIT.search(series[0]['name']).group(1).strip()
    sun = [(LABEL_UNIT.search(s_['name']).group(1).strip() if LABEL_UNIT.search(s_['name']) else '') for s_ in series]
    ctype, unit2 = sug.get('type') or 'column', ''
    if len(series) == 2 and all(sun) and sun[0].lower() != sun[1].lower():
        ctype, unit, unit2 = 'combo', sun[0], sun[1]       # два ряда в разных единицах — столбцы и линия по второй оси
    elif len({u.lower() for u in sun if u}) >= 2:
        hint = (hint + ' ' if hint else '') + (f'Ряды в разных единицах ({", ".join(sorted(set(u for u in sun if u)))}): '
                                               f'оставьте ряды одной единицы или два ряда — «Столбцы и линия».')
    if len(cats) > max_cats or len(series) > max_series:
        hint = (hint + ' ' if hint else '') + f'Взяты первые {min(len(cats), max_cats)} строк и {min(len(series), max_series)} рядов.'
    return {'name': table.title or '', 'categories': cats[:max_cats],
            'series': [dict(s_, values=s_['values'][:max_cats]) for s_ in series[:max_series]],
            'type': ctype, 'unit': unit, 'unit2': unit2, 'hint': hint}


def make_insights(chart, max_items=4):
    """Выводы по данным диаграммы (строки на русском, числа в русском формате)."""
    cats, ser, unit = chart['categories'], chart['series'], chart.get('unit') or ''
    u = (NBSP + unit) if unit and unit != '%' else ('%' if unit == '%' else '')
    out = []
    if not ser:
        return out
    s0 = ser[0]
    vals = s0['values']
    pairs = [(c, v) for c, v in zip(cats, vals) if v is not None]
    if not pairs:
        return out
    ctype = chart['type']
    names = [s['name'] for s in ser]

    # План / факт
    if len(ser) >= 2 and PLAN_RX.search(names[0]) and FACT_RX.search(names[1]):
        plan, fact = ser[0]['values'], ser[1]['values']
        both = [(c, p, f) for c, p, f in zip(cats, plan, fact) if p is not None and f is not None]
        if both:
            over = [c for c, p, f in both if f >= p]
            out.append(f'План выполнен или перевыполнен в {len(over)} из {len(both)} периодов')
            c, p, f = both[-1]
            d = _pct(p, f)
            if d is not None:
                out.append(f'{c}: факт {fmt_number(f)}{u} — {"+" if d >= 0 else "−"}{fmt_number(abs(d), 1)}{NBSP}% к плану')
        vals = fact
        pairs = [(c, v) for c, v in zip(cats, vals) if v is not None]
        s0 = ser[1]

    if ctype == 'radar':
        if unit.lower().startswith('балл'):
            u = ''                                       # «8 баллов» по-русски склоняется — число без единицы
        for s in ser[:2]:
            pp = [(c, v) for c, v in zip(cats, s['values']) if v is not None]
            if pp:
                hi, lo = max(pp, key=lambda p: p[1]), min(pp, key=lambda p: p[1])
                nm = f'{s["name"]}: ' if len(ser) > 1 else ''
                out.append(f'{nm}сильнее всего — «{hi[0]}» ({fmt_number(hi[1])}{u}), слабее — «{lo[0]}» '
                           f'({fmt_number(lo[1])}{u})')
        if len(ser) >= 2:
            a, b = ser[0], ser[1]
            both = [(x, y) for x, y in zip(a['values'], b['values']) if x is not None and y is not None]
            better = sum(1 for x, y in both if y > x)
            out.append(f'«{b["name"]}» выше, чем «{a["name"]}», по {better} из {len(both)} критериев')
        if chart.get('note'):
            out.append(chart['note'])
        return out[:max_items]

    if ctype in ('stacked', 'stacked100', 'bar_stacked') or (ctype == 'area' and len(ser) > 1):
        totals = [sum((s['values'][k] or 0) for s in ser) for k in range(len(cats))]
        if len(totals) >= 2 and totals[0]:
            d = _pct(totals[0], totals[-1])
            out.append(f'Итог: {fmt_number(totals[0])}{u} ({cats[0]}) → {fmt_number(totals[-1])}{u} ({cats[-1]}), '
                       f'{"+" if d >= 0 else "−"}{fmt_number(abs(d), 1)}{NBSP}%')
        sums = sorted(((s['name'], sum(v or 0 for v in s['values'])) for s in ser), key=lambda x: -x[1])
        grand = sum(v for _, v in sums)
        if grand:
            out.append(f'Крупнейшая статья — «{sums[0][0]}»: {fmt_number(sums[0][1] / grand * 100, 1)}{NBSP}% '
                       f'от общего объёма ({fmt_number(grand)}{u} за период)')
        grow = [(s['name'], _pct(s['values'][0], s['values'][-1])) for s in ser
                if s['values'][0] and s['values'][-1] is not None]
        grow = [g for g in grow if g[1] is not None]
        if grow:
            g = max(grow, key=lambda x: x[1])
            if g[1] > 0:
                out.append(f'Быстрее всего растёт «{g[0]}»: +{fmt_number(g[1], 1)}{NBSP}% ({cats[0]}–{cats[-1]})')
        return out[:max_items]

    if chart.get('_time') or ctype in ('line', 'area') or _looks_time(cats):
        (c1, v1), (c2, v2) = pairs[0], pairs[-1]
        d = _pct(v1, v2)
        if d is not None:
            out.append(f'{s0["name"]}: {"рост" if d >= 0 else "снижение"} на {fmt_number(abs(d), 1)}{NBSP}% '
                       f'за период {c1}–{c2} ({fmt_number(v1)} → {fmt_number(v2)}{u})')
        n = len(pairs) - 1
        if n >= 2 and v1 > 0 and v2 > 0:
            cagr = ((v2 / v1) ** (1 / n) - 1) * 100
            out.append(f'Среднегодовой темп: {"+" if cagr >= 0 else "−"}{fmt_number(abs(cagr), 1)}{NBSP}% за период')
        mx = max(pairs, key=lambda p: p[1])
        out.append(f'Максимум — {fmt_number(mx[1])}{u} ({mx[0]})')
    elif ctype in ('pie', 'doughnut'):
        tot = sum(v for _, v in pairs)
        top = sorted(pairs, key=lambda p: -p[1])
        sh = top[0][1] / tot * 100 if tot else 0
        out.append(f'Наибольшая доля — «{top[0][0]}»: {fmt_number(sh, 1)}{NBSP}%')
        if len(top) >= 3 and tot:
            sh2 = (top[0][1] + top[1][1]) / tot * 100
            out.append(f'Две крупнейшие позиции дают {fmt_number(sh2, 1)}{NBSP}% от общего объёма')
        out.append(f'Наименьшая доля — «{top[-1][0]}»: {fmt_number(top[-1][1] / tot * 100 if tot else 0, 1)}{NBSP}%')
    else:
        top = sorted(pairs, key=lambda p: -p[1])
        tot = sum(v for _, v in pairs)
        out.append(f'Лидер — «{top[0][0]}»: {fmt_number(top[0][1])}{u}')
        if unit != '%' and tot and all(v >= 0 for _, v in pairs) and len(pairs) >= 3:
            out.append(f'Доля лидера — {fmt_number(top[0][1] / tot * 100, 1)}{NBSP}% от суммы '
                       f'({fmt_number(tot)}{u})')
        if len(top) >= 2:
            out.append(f'Минимум — «{top[-1][0]}»: {fmt_number(top[-1][1])}{u}')
        if len(ser) > 1:
            totals = [(s['name'], sum(v for v in s['values'] if v is not None)) for s in ser]
            if unit != '%':
                a, b = totals[0], totals[-1]
                d = _pct(a[1], b[1])
                if d is not None and len(ser) >= 2:
                    out.append(f'Итого: {a[0]} — {fmt_number(a[1])}{u}, {b[0]} — {fmt_number(b[1])}{u} '
                               f'({"+" if d >= 0 else "−"}{fmt_number(abs(d), 1)}{NBSP}%)')
    if chart.get('note'):
        out.append(chart['note'])
    return out[:max_items]


def _looks_time(cats):
    return len(cats) >= 3 and all(re.fullmatch(r'(19|20)\d\d', str(c).strip()) for c in cats)


def kpi_from_table(table):
    """Таблица «показатель — значение» (2 столбца, ≤ 6 строк) → элементы KPI-слайда."""
    if len(table.columns) != 2 or not table.numeric_cols or len(table.rows) > 6:
        return None
    j = table.numeric_cols[0]
    items = []
    for r in table.rows:
        label, val = r[table.label_col], r[j]
        if parse_number(val) is None:
            return None
        unit = _unit_of(table, j)
        m = re.match(r'^(.*?),\s*([^,]{1,25})$', label)          # «Экономия, млн руб.» → единица из подписи
        if m and not unit:
            label, unit = m.group(1), m.group(2)
        items.append({'value': val, 'unit': unit, 'title': label, 'text': ''})
    return items


def kpi_scale_diverse(table):
    """True, если значения в таблице разного масштаба/смысла (лучше KPI-плитки, чем диаграмма)."""
    j = table.numeric_cols[0]
    vals = [abs(parse_number(r[j]) or 0) for r in table.rows]
    vals = [v for v in vals if v]
    if not vals:
        return False
    units = set()
    for r in table.rows:                       # единицы из подписей: «Экономия, млн руб.»
        m = re.search(r',\s*([^,]{1,25})$', r[table.label_col])
        if m:
            units.add(m.group(1).strip())
    return (max(vals) / min(vals) > 30) or len(units) >= 2
