# -*- coding: utf-8 -*-
"""
alternatives.py — ВАРИАНТЫ СЛАЙДА НА ВЫБОР (3–4 для каждого слайда)
==================================================================

Для каждого содержательного слайда плана собираются альтернативы, которые отличаются
И СОДЕРЖАНИЕМ, И ФОРМОЙ:

  1. другой способ показать тот же материал, найденный анализом текста (smart.py):
     воронка чисел / показатели с пояснениями / цепочка «проблема → решение» / тезисы…;
  2. другая ЛОГИЧНАЯ форма тех же данных (FORMS): карточки ↔ соты ↔ список, процесс ↔
     нумерованные шаги ↔ таймлайн, показатели ↔ полосы/спидометры/таблица, цель и задачи
     ↔ опоры ↔ карточки, диаграмма ↔ таблица…; форма предлагается, только если для неё
     хватает данных (числа, сроки, центр, число элементов);
  3. «Кратко» — тот же слайд с меньшим числом элементов и без пояснений (крупнее, проще).

Иллюстрации в варианты добавляет модель ИИ (illustrate.py): при ИИ-анализе — к ключевым слайдам,
в плане — по кнопке «Нарисовать иллюстрацию». Встроенных картинок нет.

Результат — поле slide['alts'] = [вариант0, вариант1, …], где вариант0 — текущий слайд.
У каждого варианта есть подпись alt_label («Воронка чисел», «Соты», «Кратко: …»).
Интерфейс показывает их миниатюрами; выбранный вариант подставляется в слайд.
"""
import copy
import json
import re

from .convert import convert_slide
from .spec import LAYOUTS
from .variety import _ok

MAX_ALTS = 4
RADAR_RX = re.compile(r'(?i)критери|компетенц|оценк|балл|зрелост|готовност|соответстви|навык|качеств')

# логичные формы для каждого макета (в порядке предпочтения)
FORMS = {
    # нефтегазовые схемы (value_chain, well, field) стоят первыми, но проходят только для нефтегазового
    # содержания (oilgas_ok в variety._ok) — для остальных слайдов они не предлагаются
    'cards':       ['map', 'field', 'value_chain', 'honeycomb', 'list', 'puzzle', 'text'],
    'honeycomb':   ['map', 'field', 'cards', 'puzzle', 'list'],
    'list':        ['map', 'field', 'well', 'value_chain', 'cards', 'checklist', 'text'],
    'process':     ['value_chain', 'well', 'list', 'timeline', 'path', 'roadmap', 'cards'],
    'timeline':    ['well', 'gantt', 'process', 'roadmap', 'path', 'list'],
    'roadmap':     ['gantt', 'timeline', 'path', 'process'],
    'stairs':      ['process', 'path', 'list'],
    'target':      ['pillars', 'converge', 'cards', 'list'],
    'pillars':     ['target', 'converge', 'cards'],
    'cycle':       ['process', 'petals', 'cards'],
    'hub':         ['petals', 'mindmap', 'cards', 'honeycomb'],
    'pyramid':     ['layers', 'iceberg', 'list'],
    'layers':      ['well', 'pyramid', 'iceberg', 'list'],
    'funnel':      ['kpi', 'bars', 'list'],
    'kpi':         ['hero', 'bars', 'gauge', 'bubbles', 'table', 'cards'],
    'bars':        ['kpi', 'bubbles', 'table'],
    'gauge':       ['kpi', 'bars'],
    'bubbles':     ['kpi', 'bars'],
    'matrix':      ['swot', 'cards', 'table'],
    'compare':     ['shift', 'balance', 'table', 'cards'],
    'conclusions': ['list', 'cards', 'text'],
    'text':        ['list', 'cards'],
    'chart':       ['table', 'kpi', 'bars'],
    'table':       ['chart', 'map', 'cards', 'list'],
    'image':       [],
    'tree':        ['mindmap', 'cards', 'list'],
    'venn':        ['cards'],
    'gears':       ['process', 'puzzle', 'cards'],
    # дополнительные схемы версии 1.4
    'swot':        ['matrix', 'cards', 'table'],
    'fishbone':    ['mindmap', 'tree', 'cards'],
    'gantt':       ['roadmap', 'timeline', 'table'],
    'risk':        ['table', 'cards', 'list'],
    'iceberg':     ['layers', 'cards', 'list'],
    'puzzle':      ['honeycomb', 'cards', 'list'],
    'balance':     ['compare', 'shift', 'table'],
    'checklist':   ['list', 'table', 'cards'],
    'hero':        ['kpi', 'cards'],
    'shift':       ['compare', 'balance', 'table'],
    'petals':      ['hub', 'cards', 'honeycomb'],
    'path':        ['value_chain', 'timeline', 'process', 'roadmap'],
    'mindmap':     ['tree', 'hub', 'cards'],
    'converge':    ['target', 'pillars', 'cards'],
    'map':         ['cards', 'list', 'table'],
    # нефтегазовые схемы
    'value_chain': ['process', 'cards', 'path', 'list'],
    'well':        ['layers', 'timeline', 'list', 'cards'],
    'field':       ['cards', 'list', 'honeycomb', 'table'],
}

NAMES = {
    'cards': 'Карточки', 'honeycomb': 'Соты', 'list': 'Список', 'process': 'Процесс по шагам',
    'timeline': 'Таймлайн', 'roadmap': 'Дорожная карта', 'stairs': 'Ступени', 'target': 'Цель и задачи',
    'pillars': 'Опоры', 'cycle': 'Цикл', 'hub': 'Сеть связей', 'pyramid': 'Пирамида', 'layers': 'Слои',
    'funnel': 'Воронка', 'kpi': 'Плитки показателей', 'bars': 'Полосы-индикаторы', 'gauge': 'Спидометры',
    'bubbles': 'Пузыри', 'matrix': 'Матрица 2×2', 'compare': 'Сравнение', 'conclusions': 'Итоговые плитки',
    'text': 'Ключевая мысль и пояснения', 'chart': 'Диаграмма', 'table': 'Таблица', 'image': 'Рисунок',
    'tree': 'Дерево', 'venn': 'Пересечение', 'gears': 'Шестерёнки', 'agenda': 'Содержание',
    'swot': 'SWOT-анализ', 'fishbone': 'Причины и следствие', 'gantt': 'План-график (Гант)',
    'risk': 'Матрица рисков', 'iceberg': 'Айсберг', 'puzzle': 'Пазл', 'balance': 'Весы «за и против»',
    'checklist': 'Чек-лист статусов', 'hero': 'Главная цифра', 'shift': 'Было → стало', 'petals': 'Лепестки',
    'path': 'Извилистый путь', 'mindmap': 'Ментальная карта', 'converge': 'Факторы → результат',
    'map': 'Карта стран',
    'value_chain': 'Цепочка создания стоимости', 'well': 'Скважина по интервалам', 'field': 'Обустройство месторождения',
}
VARIANT_NAMES = {('kpi', 'ring'): 'Кольца показателей', ('list', 'tiles'): 'Нумерованные плашки',
                 ('cards', 'solid'): 'Карточки на подложке', ('text', 'quote'): 'Главная мысль крупно'}


def label_for(s):
    lay, v = s.get('layout'), s.get('variant') or ''
    if (lay, v) in VARIANT_NAMES:
        return VARIANT_NAMES[(lay, v)]
    if lay == 'image' and s.get('illustration'):
        return 'Иллюстрация модели ИИ'
    if lay == 'kpi' and s.get('aside'):
        return 'Показатели и пояснения'
    if lay == 'chart':
        return {'column': 'Столбчатая диаграмма', 'bar': 'Линейчатая диаграмма', 'line': 'График',
                'doughnut': 'Кольцевая диаграмма', 'pie': 'Круговая диаграмма',
                'stacked': 'Диаграмма с накоплением', 'radar': 'Радар (профиль по критериям)',
                'stacked100': 'Нормированная гистограмма (100 %)', 'bar_stacked': 'Линейчатая с накоплением',
                'combo': 'Столбцы и линия',
                'area': ('Области с накоплением' if len((s.get('chart') or {}).get('series') or []) > 1
                         else 'Диаграмма-область')}.get((s.get('chart') or {}).get('type'), 'Диаграмма')
    return NAMES.get(lay, LAYOUTS.get(lay, {}).get('name', lay))


def _sig(s):
    """Подпись содержимого — чтобы не предлагать одинаковые варианты."""
    keep = {k: s.get(k) for k in ('layout', 'variant', 'items', 'lead', 'paragraphs', 'left', 'right', 'columns',
                                  'chart', 'images', 'aside', 'center')}
    if isinstance(keep.get('items'), list):
        keep['items'] = [(it.get('title'), it.get('text'), it.get('value')) for it in keep['items'] if isinstance(it, dict)]
    return json.dumps(keep, ensure_ascii=False, sort_keys=True, default=str)


def _brief(s):
    """«Кратко»: не больше 4 элементов, без длинных пояснений; для текста — одна мысль."""
    lay = s.get('layout')
    info = LAYOUTS.get(lay) or {}
    b = copy.deepcopy(s)
    if info.get('kind') == 'items' and b.get('items'):
        items = b['items'][:4]
        if all(it.get('title') for it in items):
            for it in items:
                it['text'] = ''
        else:
            for it in items:
                t = it.get('text') or ''
                if len(t) > 90:
                    cut = t.split(',')[0].split(' — ')[0]
                    it['text'] = cut if len(cut) >= 25 else t[:90].rsplit(' ', 1)[0] + '…'
        b['items'] = items
        b['conclusion'] = ''
        b.pop('aside', None)
    elif lay == 'text':
        b['paragraphs'] = []
        b['variant'] = 'quote'
    elif lay == 'table' and len(b.get('rows') or []) > 6:
        b['rows'] = b['rows'][:6]
    else:
        return None
    if _sig(b) == _sig(s):
        return None
    lb = label_for(b)
    b['alt_label'] = f'{lb}: кратко' if not lb.lower().startswith('кратко') else lb
    return b


def _clean(s):
    s = {k: v for k, v in s.items() if not k.startswith('_') and k not in ('alts', 'notes')}
    if isinstance(s.get('items'), list):
        s['items'] = [{k: v for k, v in it.items() if not k.startswith('_')} if isinstance(it, dict) else it
                      for it in s['items']]
    return s


def _chart_types(ch):
    """Типы диаграмм, уместные для этих данных (кроме текущего)."""
    cur = ch.get('type')
    series = ch.get('series') or []
    cats = ch.get('categories') or []
    vals = [v for s_ in series for v in (s_.get('values') or []) if v is not None]
    time_like = all(str(c).strip()[:4].isdigit() for c in cats) if cats else False
    out = []
    nonneg = bool(vals) and all(v >= 0 for v in vals)
    # «радар» — профиль 1–3 объектов по 4–10 критериям одной шкалы (баллы, %, оценки)
    # доли целого (кольцо, круг) — не профиль; один ряд — только если категории похожи на критерии
    radar_ok = (not time_like and 4 <= len(cats) <= 10 and len(series) <= 3 and nonneg and cur not in ('pie', 'doughnut')
                and (RADAR_RX.search(' '.join(map(str, cats)))
                     or (len(series) >= 2 and ch.get('unit') in ('%', '', 'балл', 'баллов', 'баллы'))))
    if len(series) > 1:
        # «план/факт», «прогноз» — сравниваются рядом, их не складывают в накопление
        compare_like = any(re.search(r'(?i)план|факт|прогноз|цел|норматив|базов', str(s_.get('name') or ''))
                           for s_ in series)
        # оценки разных объектов по критериям тоже не складывают
        out = (['line'] if time_like else []) + ([] if compare_like or radar_ok else ['stacked']) + ['column', 'bar']
        if time_like and not compare_like and nonneg and len(cats) >= 4:
            out.insert(1, 'area')                     # составляющие во времени — области с накоплением
        if radar_ok:
            out.insert(0, 'radar')
    else:
        out = (['line', 'column'] if time_like else ['bar', 'column'])
        if time_like and nonneg and len(cats) >= 5:
            out.insert(1, 'area')                     # динамика объёма — «область»
        if radar_ok:
            out.insert(0, 'radar')
        if vals and len(cats) <= 6 and nonneg and not radar_ok:      # оценки по критериям — не доли целого
            out.append('doughnut')
    return [x for x in out if x != cur][:3]


def build_alts(s):
    """Слайд → список вариантов [текущий, …] (до MAX_ALTS). Кандидаты из анализа текста берутся
    из s['_cands'] (их кладёт smart.prose_slides)."""
    lay = s.get('layout')
    if lay in ('title', 'end', 'section', 'agenda') or not lay:
        return []
    cur = _clean(s)
    cur['alt_label'] = s.get('_alt_label') or s.get('alt_label') or label_for(s)
    out, seen = [cur], {_sig(cur)}

    def add(c, label=None):
        if len(out) >= MAX_ALTS or not c:
            return
        c = _clean(c)
        if c.get('layout') not in LAYOUTS:
            return
        c['title'] = cur.get('title') or c.get('title')      # у всех вариантов — заголовок текущего слайда
        sg = _sig(c)
        if sg in seen:
            return
        # не больше двух вариантов одного и того же макета
        look = lambda o: (o.get('layout'), o.get('variant') or '', (o.get('chart') or {}).get('type'))
        if any(look(o) == look(c) for o in out):
            return
        seen.add(sg)
        c['alt_label'] = label or c.get('alt_label') or label_for(c)
        out.append(c)

    # 1) другие способы, найденные анализом содержания
    for c in s.get('_cands') or []:
        add(c, c.get('_alt_label'))
    # 1а) диаграмма — другой тип для тех же данных (линия ↔ столбцы, накопление, полосы, кольцо)
    if lay == 'chart' and isinstance(s.get('chart'), dict):
        for ctype in _chart_types(s['chart']):
            c = copy.deepcopy(cur)
            c.pop('alt_label', None)
            c['chart']['type'] = ctype
            add(c)
    # 2) логичные формы тех же данных
    for to in FORMS.get(lay, []):
        if len(out) >= MAX_ALTS:
            break
        if to == 'shift' and s.get('style') == 'pros_cons' or to == 'balance' and s.get('style') == 'before_after':
            continue                              # «было → стало» — для изменений, весы — для доводов
        cand = convert_slide(copy.deepcopy(_clean(s)), to)
        if cand.get('layout') != to:
            continue
        if LAYOUTS.get(to, {}).get('kind') == 'items' and not _ok(cand, to):
            continue
        add(cand)
    # 3) «Кратко»
    if len(out) < MAX_ALTS:
        add(_brief(cur))
    # иллюстрации рисует модель ИИ (illustrate.py): при ИИ-анализе и по кнопке в плане
    return out if len(out) >= 2 else []


def attach_alts(slides):
    """Добавляет варианты всем содержательным слайдам плана (поле alts)."""
    for s in slides:
        alts = build_alts(s)
        if alts:
            s['alts'] = alts
        s.pop('_cands', None)
        s.pop('_alt_label', None)
    return slides
