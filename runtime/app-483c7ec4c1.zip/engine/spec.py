# -*- coding: utf-8 -*-
"""
spec.py — СПЕЦИФИКАЦИЯ ПРЕЗЕНТАЦИИ (JSON) И КАТАЛОГ МАКЕТОВ
==========================================================

Спецификация — «контракт» между частями приложения:

    планировщик (правила или ИИ)  ──▶  СПЕЦИФИКАЦИЯ (JSON)  ──▶  отрисовка в .pptx
                                         ▲
                     правка пользователем в веб-интерфейсе

Пример:
{
  "meta":   {"title": "…", "subtitle": "…", "event": "Доклад на НТС", "date": "14.10.2026",
             "animations": true},
  "slides": [
    {"layout": "title"},
    {"layout": "cards", "title": "…", "subtitle": "…", "section": "…",
     "items": [{"title": "…", "text": "…", "icon": "TbRobot"}, …],
     "conclusion": "…", "notes": "…"},
    {"layout": "chart", "title": "…", "chart": {"type": "column", "categories": […],
     "series": [{"name": "…", "values": […]}], "unit": "млн руб."}, "insights": ["…"]},
    …
    {"layout": "end"}
  ]
}

LAYOUTS — каталог макетов: название для интерфейса, описание (оно же подсказка для ИИ),
ограничения по числу элементов. normalize() приводит любую спецификацию (от правил,
от ИИ или после ручной правки) к корректному виду: обрезает лишнее, переносит
«не поместившиеся» элементы на слайды-продолжения, заполняет пропуски.
"""
import copy
import math

from .textutil import clean, pick_icon, shorten, split_title_text

# --------------------------------------------------------------------------------------
# Каталог макетов
# --------------------------------------------------------------------------------------
# kind: 'items' — список элементов {title, text, icon}; min/max — допустимое число элементов
LAYOUTS = {
    'title':       {'name': 'Титульный', 'kind': 'meta',
                    'desc': 'Титульный слайд: название, подзаголовок, мероприятие.'},
    'agenda':      {'name': 'Содержание', 'kind': 'items', 'min': 2, 'max': 10,
                    'desc': 'Нумерованный список разделов доклада (только заголовки).'},
    'section':     {'name': 'Раздел', 'kind': 'meta',
                    'desc': 'Слайд-разделитель раздела: крупный заголовок и подзаголовок.'},
    'cards':       {'name': 'Карточки', 'kind': 'items', 'min': 1, 'max': 6,
                    'desc': '1–6 равноправных тезисов: иконка, короткий заголовок (2–4 слова), пояснение 1–2 предложения.'},
    'list':        {'name': 'Список', 'kind': 'items', 'min': 2, 'max': 10,
                    'desc': '4–10 коротких пунктов в одну или две колонки (когда пунктов много).'},
    'process':     {'name': 'Процесс', 'kind': 'items', 'min': 2, 'max': 6,
                    'desc': '2–6 последовательных шагов слева направо со стрелками.'},
    'timeline':    {'name': 'Таймлайн', 'kind': 'items', 'min': 3, 'max': 8,
                    'desc': '3–8 этапов на линии времени; у этапа может быть срок (поле label).'},
    'cycle':       {'name': 'Цикл', 'kind': 'items', 'min': 3, 'max': 6,
                    'desc': '3–6 шагов замкнутого цикла вокруг центральной идеи (поле center).'},
    'target':      {'name': 'Цель и задачи', 'kind': 'items', 'min': 3, 'max': 6,
                    'desc': 'Цель в центре (поле center) и 3–6 задач вокруг неё.'},
    'kpi':         {'name': 'Показатели', 'kind': 'items', 'min': 1, 'max': 6,
                    'desc': '1–6 ключевых чисел: value (число), unit (единица), title (что это), text (пояснение).'},
    'table':       {'name': 'Таблица', 'kind': 'table',
                    'desc': 'Таблица данных (columns + rows). Большие таблицы делятся на несколько слайдов.'},
    'chart':       {'name': 'Диаграмма', 'kind': 'chart',
                    'desc': 'Диаграмма (column, bar, line, area, pie, doughnut, stacked, stacked100, bar_stacked, radar, combo — столбцы и последний ряд линией по второй оси) + до 4 выводов по данным (insights).'},
    'compare':     {'name': 'Сравнение', 'kind': 'compare',
                    'desc': 'Две колонки: «было/стало», «плюсы/минусы», «вариант А/Б» — по 1–7 пунктов.'},
    'text':        {'name': 'Текст с тезисом', 'kind': 'text',
                    'desc': 'Ключевой тезис (lead) крупно + 1–4 абзаца пояснений (paragraphs).'},
    'conclusions': {'name': 'Выводы', 'kind': 'items', 'min': 2, 'max': 6,
                    'desc': '2–6 итоговых выводов плитками с номерами.'},
    # ---- схемы и инфографика (engine/layouts/schemes.py) ----
    'pyramid':     {'name': 'Пирамида', 'kind': 'items', 'min': 3, 'max': 5,
                    'desc': 'Уровни сверху вниз: иерархия, приоритеты, «основа и надстройка» (3–5 уровней).'},
    'funnel':      {'name': 'Воронка', 'kind': 'items', 'min': 3, 'max': 5,
                    'desc': 'Сужающиеся стадии: отбор, фильтрация, «из многих — лучшие» (3–5 стадий).'},
    'stairs':      {'name': 'Ступени', 'kind': 'items', 'min': 3, 'max': 6,
                    'desc': 'Ступени роста слева направо: этапы развития, уровни зрелости (3–6).'},
    'matrix':      {'name': 'Матрица 2×2', 'kind': 'items', 'min': 4, 'max': 4,
                    'desc': 'Четыре квадранта: SWOT, «важно/срочно», сравнение по двум осям (ровно 4). '
                            'Необязательно axes: {"x": "…", "y": "…"}.'},
    'hub':         {'name': 'Сеть связей', 'kind': 'items', 'min': 3, 'max': 6,
                    'desc': 'Центр (center) и связанные с ним элементы вокруг: участники, экосистема, '
                            'взаимодействие (3–6).'},
    'honeycomb':   {'name': 'Соты', 'kind': 'items', 'min': 3, 'max': 7,
                    'desc': 'Равноправные модули-шестиугольники: компоненты, состав системы, направления (3–7).'},
    'layers':      {'name': 'Слои', 'kind': 'items', 'min': 3, 'max': 6,
                    'desc': 'Стек уровней сверху вниз: архитектура, уровни системы, слои (3–6).'},
    'pillars':     {'name': 'Опоры', 'kind': 'items', 'min': 2, 'max': 5,
                    'desc': '«Крыша» (center — цель) на колоннах: принципы, направления стратегии, опоры (2–5).'},
    'roadmap':     {'name': 'Дорожная карта', 'kind': 'items', 'min': 3, 'max': 8,
                    'desc': 'Дорога с вехами: план-график, ключевые события по срокам (label — срок; 3–8).'},
    'gears':       {'name': 'Шестерёнки', 'kind': 'items', 'min': 2, 'max': 4,
                    'desc': 'Шестерёнки в зацеплении: взаимосвязанные процессы, механизм (2–4).'},
    'venn':        {'name': 'Пересечение', 'kind': 'items', 'min': 2, 'max': 3,
                    'desc': 'Пересекающиеся круги: синергия, «на стыке», сочетание (2–3); center — что в пересечении.'},
    'gauge':       {'name': 'Спидометры', 'kind': 'items', 'min': 1, 'max': 4,
                    'desc': 'Дуговые индикаторы для показателей в процентах: выполнение плана, доля (1–4; '
                            'value — число, unit — «%»).'},
    'bars':        {'name': 'Полосы', 'kind': 'items', 'min': 2, 'max': 8,
                    'desc': 'Горизонтальные полосы-индикаторы «показатель — значение» (2–8; value — число).'},
    'bubbles':     {'name': 'Пузыри', 'kind': 'items', 'min': 3, 'max': 6,
                    'desc': 'Круги, размер которых пропорционален значению: доли, масштабы (3–6; value — число).'},
    'tree':        {'name': 'Дерево', 'kind': 'items', 'min': 2, 'max': 6,
                    'desc': 'Структура: корень (center) → ветви (title) → листья (text через «;»; 2–6 ветвей).'},
    # ---- дополнительные схемы версии 1.4 (engine/layouts/extra.py) ----
    'swot':        {'name': 'SWOT-анализ', 'kind': 'items', 'min': 4, 'max': 4,
                    'desc': 'Сильные стороны, слабые стороны, возможности, угрозы — ровно 4 элемента в этом порядке; '
                            'пункты внутри — в text через «;».'},
    'fishbone':    {'name': 'Причины и следствие', 'kind': 'items', 'min': 3, 'max': 6,
                    'desc': '«Рыбья кость» (Исикава): следствие или проблема (center) и группы причин (title), '
                            'причины внутри группы — в text через «;» (3–6 групп).'},
    'gantt':       {'name': 'План-график', 'kind': 'items', 'min': 2, 'max': 10,
                    'desc': 'Диаграмма Ганта: работы и их сроки на шкале времени (label — срок: «2026», «I кв. 2026», '
                            '«март–май 2026», «2026–2028»; 2–10 работ).'},
    'risk':        {'name': 'Матрица рисков', 'kind': 'items', 'min': 2, 'max': 9,
                    'desc': 'Риски на карте «вероятность × последствия» (prob и impact: 1–3 или низкая/средняя/высокая) '
                            'и перечень с уровнем риска (2–9).'},
    'iceberg':     {'name': 'Айсберг', 'kind': 'items', 'min': 2, 'max': 8,
                    'desc': 'Видимая часть (первые visible элементов, обычно 1–2) и скрытая «под водой»: '
                            'явное и неочевидное, симптомы и причины (2–8).'},
    'puzzle':      {'name': 'Пазл', 'kind': 'items', 'min': 2, 'max': 6,
                    'desc': 'Детали пазла: составляющие, которые вместе дают результат (2–6).'},
    'balance':     {'name': 'Весы', 'kind': 'compare',
                    'desc': 'Весы с двумя чашами: доводы «за» и «против», выгоды и затраты (left/right по 1–7 пунктов).'},
    'checklist':   {'name': 'Чек-лист', 'kind': 'items', 'min': 3, 'max': 12,
                    'desc': 'Статус мероприятий: выполнено / в работе / план (label — статус) и общая шкала выполнения (3–12).'},
    'hero':        {'name': 'Главная цифра', 'kind': 'items', 'min': 1, 'max': 3,
                    'desc': 'Одно ключевое число крупно (value, unit, title — что это, text — пояснение) '
                            'и до двух поддерживающих чисел.'},
    'shift':       {'name': 'Было → стало', 'kind': 'compare',
                    'desc': 'Переход из состояния «было» (left) в «стало» (right) с большой стрелкой; '
                            'результат выделен (по 1–7 пунктов).'},
    'petals':      {'name': 'Лепестки', 'kind': 'items', 'min': 3, 'max': 6,
                    'desc': 'Грани одной идеи (center) лепестками вокруг: ценности, аспекты, свойства (3–6).'},
    'path':        {'name': 'Путь', 'kind': 'items', 'min': 3, 'max': 8,
                    'desc': 'Извилистая дорога с этапами: история развития, путь к цели (label — год или срок; 3–8).'},
    'mindmap':     {'name': 'Ментальная карта', 'kind': 'items', 'min': 2, 'max': 6,
                    'desc': 'Центральная тема (center), ветви (title) и пункты ветвей (text через «;»; 2–6 ветвей).'},
    'converge':    {'name': 'Факторы → результат', 'kind': 'items', 'min': 2, 'max': 6,
                    'desc': 'Факторы, условия или предпосылки слева сходятся стрелками к результату (center) справа (2–6).'},
    'map':         {'name': 'Карта', 'kind': 'items', 'min': 2, 'max': 8,
                    'desc': 'Карта мира: страны из пунктов выделены цветом и пронумерованы, справа пояснения '
                            '(title — страна, text — что там: проект, актив, показатель; 2–8).'},
    # ---- нефтегазовые схемы (engine/layouts/oilgas.py) ----
    'value_chain': {'name': 'Цепочка создания стоимости', 'kind': 'items', 'min': 3, 'max': 7,
                    'desc': 'Звенья нефтегазовой цепочки слева направо с картинками: разведка → бурение → добыча → '
                            'подготовка → транспорт → переработка → сбыт (3–7 этапов; title — этап, text — что на нём).'},
    'well':        {'name': 'Скважина по интервалам', 'kind': 'items', 'min': 3, 'max': 6,
                    'desc': 'Разрез скважины (вышка, пласты, обсадные колонны, продуктивный пласт) и пункты по глубине '
                            'с выносками: конструкция скважины, этапы строительства, ГТМ по интервалам, горизонты и пласты '
                            '(3–6; label — глубина, интервал или срок).'},
    'field':       {'name': 'Обустройство месторождения', 'kind': 'items', 'min': 2, 'max': 6,
                    'desc': 'Схема-план месторождения (кусты скважин, трубопроводы, ДНС, УПН, резервуарный парк, '
                            'напорный нефтепровод, терминал, дороги, ЛЭП) с номерами на объектах и пояснениями: '
                            'объекты инфраструктуры, этапы обустройства, проекты на месторождении (2–6).'},
    'image':       {'name': 'Рисунок', 'kind': 'image',
                    'desc': 'Рисунки из документа (1–3: схемы, фото) или иллюстрация модели ИИ, с подписями и тезисами рядом.'},
    'end':         {'name': 'Финальный', 'kind': 'meta',
                    'desc': 'Заключительный слайд «Спасибо за внимание!».'},
}

ITEM_LAYOUTS = [k for k, v in LAYOUTS.items() if v['kind'] == 'items']
# макеты с центральной фразой (поле center: цель, тема, следствие, результат)
CENTERED = ('cycle', 'target', 'hub', 'pillars', 'tree', 'petals', 'mindmap', 'converge', 'fishbone')
CHART_TYPES = ['column', 'bar', 'line', 'pie', 'doughnut', 'stacked', 'area', 'radar',
               'stacked100', 'bar_stacked', 'combo']   # 1.5.1: нормированная, линейчатая с накоплением, столбцы + линия

MAX_COLS = 12               # шире таблица на слайде не читается

LIMITS = {'title': 90, 'subtitle': 160, 'item_title': 60, 'item_text': 300, 'lead': 240, 'para': 420,
          'conclusion': 200, 'cell': 160}


# --------------------------------------------------------------------------------------
# Нормализация
# --------------------------------------------------------------------------------------
def _s(v, limit=None):
    v = clean(v if isinstance(v, str) else ('' if v is None else str(v)))
    return shorten(v, limit) if limit else v


def _item(v):
    """Элемент списка → {'title', 'text', 'icon', 'label', 'value', 'unit'} (лишние поля сохраняются)."""
    if isinstance(v, str):
        t, x = split_title_text(v)
        v = {'title': t, 'text': x}
    elif not isinstance(v, dict):
        v = {'text': str(v)}
    out = dict(v)
    out['title'] = _s(v.get('title'), LIMITS['item_title'])
    out['text'] = _s(v.get('text'), LIMITS['item_text'])
    for k in ('icon', 'label', 'value', 'unit'):
        if k in v and v[k] is not None:
            out[k] = _s(v[k], 40)
    return out


def _list(v):
    """Значение → список: строка или объект → [значение], None → [] (ответы модели бывают «вольными»)."""
    if v is None or v == '':
        return []
    if isinstance(v, (list, tuple)):
        return list(v)
    return [v]


def _txt(v):
    """Абзац/пункт → строка (объект {'text': …} или {'title': …} тоже принимается)."""
    if isinstance(v, dict):
        return ' — '.join(x for x in (str(v.get('title') or '').strip(), str(v.get('text') or '').strip()) if x)
    return '' if v is None else str(v)


_ICON_NAMES = None


def icon_exists(name):
    """Есть ли иконка с таким именем в assets/icons (имена вида TbRobot)."""
    global _ICON_NAMES
    if _ICON_NAMES is None:
        from .nts.config import ICON_DIR
        _ICON_NAMES = {p.name.rsplit('_', 1)[0] for p in ICON_DIR.glob('*_w.png')}
    return name in _ICON_NAMES


def _split(items, n_max):
    """Делит пункты на слайды поровну (6 при максимуме 5 → 3 + 3, а не 5 + 1)."""
    if len(items) <= n_max:
        return [items] if items else [[]]
    k = -(-len(items) // n_max)
    size = -(-len(items) // k)
    return [items[i:i + size] for i in range(0, len(items), size)]


def normalize(spec, add_title_end=True):
    """Приводит спецификацию к корректному виду. Возвращает (новая_спецификация, предупреждения)."""
    spec = copy.deepcopy(spec or {})
    warn = []
    meta = spec.get('meta') if isinstance(spec.get('meta'), dict) else {}
    meta['title'] = _s(meta.get('title'), 160) or 'Презентация'
    for k in ('subtitle', 'event', 'date', 'author'):
        meta[k] = _s(meta.get(k), 200)
    meta.setdefault('animations', True)
    meta.setdefault('conclusion_lead', 'Вывод: ')
    meta['template'] = _s(meta.get('template'), 20)          # свой шаблон (engine/templates.py); пусто — корпоративный
    spec['meta'] = meta

    out = []
    for i, sl in enumerate(_list(spec.get('slides'))):
        if not isinstance(sl, dict):
            continue
        lay = sl.get('layout') or 'cards'
        if lay not in LAYOUTS:
            warn.append(f'Слайд {i + 1}: неизвестный макет «{lay}» заменён на «text».')
            lay = 'text'
        sl['layout'] = lay
        sl['title'] = _s(sl.get('title'), LIMITS['title'])
        sl['subtitle'] = _s(sl.get('subtitle'), LIMITS['subtitle'])
        sl['section'] = _s(sl.get('section'), 60)
        sl['notes'] = str(sl.get('notes') or '').strip()
        sl['conclusion'] = _s(sl.get('conclusion'), LIMITS['conclusion'])
        info = LAYOUTS[lay]

        if info['kind'] == 'items':
            items = [_item(x) for x in _list(sl.get('items')) if x]
            items = [x for x in items if x.get('title') or x.get('text') or x.get('value')]
            if lay in CENTERED:
                sl['center'] = _s(sl.get('center'), 200) or sl['title']
            elif lay == 'venn':
                sl['center'] = _s(sl.get('center'), 120)
            if lay == 'iceberg':
                try:
                    sl['visible'] = max(1, int(sl.get('visible') or 0)) if sl.get('visible') else None
                except (TypeError, ValueError):
                    sl['visible'] = None
                if not sl['visible']:
                    sl.pop('visible')
            if lay == 'matrix':
                ax = sl.get('axes') if isinstance(sl.get('axes'), dict) else {}
                sl['axes'] = {'x': _s(ax.get('x'), 60), 'y': _s(ax.get('y'), 60)} if (ax.get('x') or ax.get('y')) else {}
            if len(items) < info['min']:
                if lay in ('cards', 'list', 'conclusions', 'agenda') and items:
                    pass                                   # 1 элемент — допустимо для карточек
                elif items:
                    warn.append(f'Слайд «{sl["title"]}»: мало элементов для «{info["name"]}» — показан как карточки.')
                    lay = sl['layout'] = 'cards'
                    info = LAYOUTS['cards']
                else:
                    warn.append(f'Слайд «{sl["title"]}»: нет элементов — слайд пропущен.')
                    continue
            # иконки по ключевым словам (если не заданы)
            used = set()
            for it in items:
                if it.get('icon') and not icon_exists(it['icon']):
                    it['icon'] = ''                        # неизвестная иконка — подберём по словам
                if it.get('icon'):
                    used.add(it['icon'])
            for it in items:
                if not it.get('icon'):
                    it['icon'] = pick_icon(it.get('title', ''), it.get('text', ''), used=used)
            n_max = info['max']
            if lay in ('list', 'cards', 'conclusions'):      # длинные тексты — меньше элементов на слайде
                avg = sum(len(x.get('text') or '') + len(x.get('title') or '') for x in items) / max(1, len(items))
                if avg > 200:
                    n_max = min(n_max, 4 if lay != 'list' else 5)
                elif avg > 130 and lay == 'list':
                    n_max = min(n_max, 7)
            chunks = _split(items, n_max)
            for k, ch in enumerate(chunks):
                s2 = dict(sl, items=ch)
                if k:
                    s2.pop('alts', None)                  # варианты — только у первого слайда
                    s2['title'] = sl['title'] + ' (продолжение)'
                    s2['conclusion'] = sl['conclusion'] if k == len(chunks) - 1 else ''
                elif len(chunks) > 1:
                    s2['conclusion'] = ''
                out.append(s2)
            continue

        if info['kind'] == 'table':
            cols = [_s(c, 60) for c in _list(sl.get('columns'))]
            rows = [[_s(c, LIMITS['cell']) for c in _list(r)] for r in _list(sl.get('rows'))]
            if not cols and rows:
                cols, rows = rows[0], rows[1:]
            if not cols:
                warn.append(f'Слайд «{sl["title"]}»: пустая таблица — пропущен.')
                continue
            if len(cols) > MAX_COLS:
                warn.append(f'Слайд «{sl["title"]}»: в таблице {len(cols)} столбцов — показаны первые {MAX_COLS}.')
                cols = cols[:MAX_COLS]
            w = len(cols)
            rows = [(r + [''] * w)[:w] for r in rows]
            sl['columns'], sl['rows'] = cols, rows
            out.append(sl)                     # деление на страницы — при отрисовке (по высоте строк)
            continue

        if info['kind'] == 'chart':
            ch = sl.get('chart') if isinstance(sl.get('chart'), dict) else {}
            cats = [_s(c, 40) for c in _list(ch.get('categories'))]
            series = []
            for s in _list(ch.get('series')):
                if not isinstance(s, dict):
                    continue
                vals = []
                for v in _list(s.get('values'))[:len(cats)]:
                    try:
                        x = None if v is None or v == '' else float(str(v).replace(',', '.').replace('\u2212', '-')
                                                                   .replace(' ', '').replace('\u00a0', ''))
                        vals.append(x if x is None or math.isfinite(x) else None)   # NaN/∞ → пусто
                    except (TypeError, ValueError):
                        vals.append(None)
                vals += [None] * (len(cats) - len(vals))
                series.append({'name': _s(s.get('name'), 40) or 'Ряд', 'values': vals})
            if not cats or not series or all(v is None for s in series for v in s['values']):
                # без чисел диаграмму не построить, но слайд не теряем: пункты прежнего макета или подписи
                # категорий — списком (раньше слайд молча пропадал из презентации)
                items = [x for x in _list(sl.get('items')) if x] or [{'title': c, 'text': ''} for c in cats if c]
                if not items:
                    warn.append(f'Слайд «{sl["title"]}»: нет данных для диаграммы — пропущен. '
                                f'Данные задаются в окне «📊 Диаграмма» у слайда.')
                    continue
                warn.append(f'Слайд «{sl["title"]}»: нет чисел для диаграммы — показан списком. '
                            f'Числа задаются в окне «📊 Диаграмма» у слайда.')
                alt = {k: sl[k] for k in ('title', 'subtitle', 'section', 'notes', 'conclusion') if sl.get(k)}
                alt.update(layout='list', items=items)
                sub, w2 = normalize({'meta': meta, 'slides': [alt]}, add_title_end=False)
                out.extend(sub['slides'])
                warn.extend(w2)
                continue
            ctype = ch.get('type') if ch.get('type') in CHART_TYPES else 'column'
            if ctype in ('pie', 'doughnut') and len(series) > 1:
                ctype = 'column'
            if ctype in ('stacked', 'stacked100', 'combo') and len(series) < 2:
                ctype = 'column'
            if ctype == 'bar_stacked' and len(series) < 2:
                ctype = 'bar'
            if ctype == 'radar' and (len(cats) < 3 or len(series) > 4):   # «радару» нужно ≥ 3 осей и немного рядов
                ctype = 'column' if len(cats) < 3 else 'bar'
            sl['chart'] = {'type': ctype, 'categories': cats, 'series': series[:6],
                           'unit': _s(ch.get('unit'), 20), 'number_format': ch.get('number_format') or ''}
            if ctype == 'combo':
                sl['chart']['unit2'] = _s(ch.get('unit2'), 20)     # единицы второй оси (ряд-линия)
            sl['insights'] = [_s(_txt(x), 180) for x in _list(sl.get('insights')) if x][:4]
            out.append(sl)
            continue

        if info['kind'] == 'compare':
            for side, default in (('left', 'Было'), ('right', 'Стало')):
                v = sl.get(side) or {}
                if not isinstance(v, dict):
                    v = {'items': _list(v)}
                v = dict(v)
                v['title'] = _s(v.get('title'), 50) or default
                v['items'] = [_s(_txt(x), 200) for x in _list(v.get('items'))][:7]
                v['items'] = [x for x in v['items'] if x]
                sl[side] = v
            sl['style'] = sl.get('style') if sl.get('style') in ('before_after', 'pros_cons', 'neutral') else 'before_after'
            if not sl['left']['items'] and not sl['right']['items']:
                continue
            out.append(sl)
            continue

        if info['kind'] == 'image':
            from pathlib import Path as _P
            imgs = []
            for im in _list(sl.get('images')):
                if isinstance(im, dict) and isinstance(im.get('svg'), str) and im['svg'].strip():
                    try:                                  # рисунок модели ИИ (SVG) — только очищенный код
                        from .svgdraw import SvgError, sanitize
                        imgs.append(dict({'svg': sanitize(im['svg']), 'caption': _s(im.get('caption'), 120)},
                                         **({'ai': True} if im.get('ai') else {})))
                    except SvgError as e:
                        warn.append(f'Слайд «{sl["title"]}»: рисунок модели не прочитан ({e}).')
                    continue
                if isinstance(im, dict) and (im.get('picture') or im.get('upload')):
                    from .pictures import resolve        # библиотека / карта страны / своя картинка
                    key = 'picture' if im.get('picture') else 'upload'
                    if resolve({key: str(im[key])}):
                        imgs.append({key: str(im[key]), 'caption': _s(im.get('caption'), 120)})
                    else:
                        warn.append(f'Слайд «{sl["title"]}»: картинка «{im[key]}» не найдена.')
                    continue
                if isinstance(im, dict) and im.get('path') and _P(str(im['path'])).exists():
                    imgs.append({'path': str(im['path']), 'caption': _s(im.get('caption'), 120)})
            items = [_item(x) for x in _list(sl.get('items')) if x][:5]
            if not imgs:
                warn.append(f'Слайд «{sl["title"]}»: рисунок не найден — показан текстом.')
                if not items:
                    continue
                sl['layout'] = 'list'
                sl['items'] = items
                out.append(sl)
                continue
            sl['images'] = imgs[:3]
            sl['items'] = items
            sl['illustration'] = bool(sl.get('illustration'))
            out.append(sl)
            continue

        if info['kind'] == 'text':
            paras = [_s(_txt(p), LIMITS['para']) for p in _list(sl.get('paragraphs')) if p]
            paras = [p for p in paras if p]
            sl['lead'] = _s(sl.get('lead'), LIMITS['lead'])
            sl['paragraphs'] = paras[:4]
            if not sl['lead'] and not paras:
                continue
            out.append(sl)
            continue

        if lay == 'section':
            sl['number'] = _s(sl.get('number'), 4)
        out.append(sl)                         # title / section / end

    if add_title_end:
        if not out or out[0]['layout'] != 'title':
            out.insert(0, {'layout': 'title'})
        if out[-1]['layout'] != 'end':
            out.append({'layout': 'end'})
    spec['slides'] = out
    return spec, warn


def catalog():
    """Каталог макетов для веб-интерфейса."""
    return [{'id': k, 'name': v['name'], 'kind': v['kind'], 'desc': v['desc'],
             'min': v.get('min'), 'max': v.get('max')} for k, v in LAYOUTS.items()]
