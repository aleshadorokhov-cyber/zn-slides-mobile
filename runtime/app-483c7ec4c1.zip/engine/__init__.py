# -*- coding: utf-8 -*-
"""
engine — ДВИЖОК КОНСТРУКТОРА ПРЕЗЕНТАЦИЙ
=======================================

Конвейер:

  файлы Word/Excel ──▶ readers ──▶ Document (model.py)
                                     │
                     ┌───────────────┴───────────────┐
                     ▼                               ▼
            planner_rules (правила)        planner_llm (локальная ИИ)
                     └───────────────┬───────────────┘
                                     ▼
                       СПЕЦИФИКАЦИЯ (spec.py, JSON) ◀── правка в веб-интерфейсе
                                     ▼
                       render.build_pptx ──▶ layouts/* ──▶ .pptx (корпоративный шаблон)

Две функции верхнего уровня — их вызывают веб-приложение (app.py) и командная строка (cli.py):
    analyze(files, options, llm_settings) → (spec, warnings, info)
    build(spec, out_path)                 → (path, warnings, slides_count)
"""
from .planner_rules import plan_rules
from .readers import SUPPORTED, read_files
from .render import build_preview_deck, build_pptx  # noqa: F401
from . import templates  # noqa: F401  (свои шаблоны оформления)
from .spec import catalog, normalize  # noqa: F401


def analyze(files, options=None, llm=None, progress=None):
    """files — [(путь, исходное_имя)]; options — настройки плана; llm — настройки ИИ или None;
    progress(event) — обратный вызов для индикатора хода (см. planner_llm.plan_llm).

    Режим options['mode']: 'rules' (по умолчанию) или 'ai'. В режиме 'ai' при любой ошибке
    модели (нет связи, неверный ответ) используется план по правилам — с предупреждением.
    Отмена пользователем (llm_client.Cancelled) пробрасывается наверх.
    """
    from .revise import general_options
    remarks = str((options or {}).get('remarks') or '').strip()      # общие замечания автора к презентации
    options = general_options(remarks, options or {})
    notify = progress or (lambda e: None)
    notify({'phase': 'read'})
    doc = read_files(files, notify)
    from .prepare import prepare
    pinfo = prepare(doc, options)                 # документ-сценарий, пометки автора, название
    info = {'stats': doc.stats(), 'title': doc.title, 'sources': doc.sources, 'mode_used': 'rules',
            'script': pinfo['script'], 'marks': pinfo['marks']}
    if not doc.sections:
        return None, doc.warnings + ['В файлах не найдено текста или таблиц.'], info
    if options.get('mode') == 'ai' and llm:
        from .llm_client import Cancelled, describe
        from .planner_llm import plan_llm
        stats = {}
        info.update(describe(llm))              # llm_provider, llm_model, llm_cloud (облачная: данные уходят наружу)

        def prog(e):
            if e.get('phase') == 'done':
                stats.update(e.get('stats') or {})
            notify(e)
        try:
            spec, warnings = plan_llm(doc, options, llm, progress=prog)
            _general(spec, remarks, info, options)
            info['mode_used'] = 'ai'
            info['ai_level'] = 'full' if str(options.get('ai_level') or '').lower() == 'full' else 'fast'
            info['llm'] = stats
            return spec, warnings, info
        except Cancelled:
            raise
        except Exception as e:                      # noqa: BLE001
            info['llm'] = stats
            spec, warnings = plan_rules(doc, options)
            _general(spec, remarks, info, options)
            who = f'облачной модели {info["llm_provider_name"]}' if info['llm_cloud'] else 'локальной ИИ'
            return spec, [f'Не удалось получить план от {who}: {e} План построен по правилам.'] + warnings, info
    spec, warnings = plan_rules(doc, options)
    _general(spec, remarks, info, options)
    return spec, warnings, info


def _general(spec, remarks, info, options=None):
    """Картинки из библиотеки к подходящим слайдам (если не выключены) и общие замечания, которые
    выполняются правилами (сократить, без анимации, убрать раздел…)."""
    if (options or {}).get('pictures', True) is not False:
        from .pictures import auto_pictures
        info['pictures'] = auto_pictures(spec.get('slides') or [])
    if remarks:
        from .revise import apply_general
        _, done = apply_general(spec, remarks)
        info['remarks_done'] = done


def build(spec, out_path, template=None):
    return build_pptx(spec, out_path, template)
