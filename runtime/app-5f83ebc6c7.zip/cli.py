# -*- coding: utf-8 -*-
"""
cli.py — СБОРКА ПРЕЗЕНТАЦИИ ИЗ КОМАНДНОЙ СТРОКИ (без браузера)
=============================================================

Примеры:
  python cli.py отчёт.docx данные.xlsx                       → output/<Название>.pptx
  python cli.py отчёт.docx --slides 12 --event "Доклад на НТС"
  python cli.py отчёт.docx --mode ai                          (модель ИИ из settings.json)
  python cli.py отчёт.docx --plan-only plan.json             (только план, без сборки)
  python cli.py отчёт.pdf данные.xlsx                        (PDF с текстовым слоем)
  python -m engine.report справка.docx отчёт.docx данные.xlsx (справка в Word по материалам)
  python cli.py --from-plan plan.json --out итог.pptx         (собрать по готовому/исправленному плану)

Удобно для пакетной обработки и для планировщика заданий Windows.
"""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import engine  # noqa: E402

try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass


def main():
    ap = argparse.ArgumentParser(description='Конструктор презентаций: Word/Excel/PDF → .pptx')
    ap.add_argument('files', nargs='*', help='файлы .docx / .pdf / .xlsx / .csv / .txt')
    ap.add_argument('--slides', type=int, default=0, help='число слайдов (0 — по объёму материала)')
    ap.add_argument('--title', default='')
    ap.add_argument('--subtitle', default='')
    ap.add_argument('--event', default='', help='мероприятие, например «Доклад на НТС»')
    ap.add_argument('--date', default='')
    ap.add_argument('--mode', choices=['rules', 'ai'], default='rules')
    ap.add_argument('--ai-level', choices=['fast', 'full'], default='fast',
                    help='что делает ИИ: fast — структура и заголовки (быстро), full — и тексты слайдов')
    ap.add_argument('--no-anim', action='store_true', help='без анимаций')
    ap.add_argument('--out', default='', help='куда сохранить .pptx')
    ap.add_argument('--plan-only', default='', help='сохранить только план (JSON) в этот файл')
    ap.add_argument('--from-plan', default='', help='собрать по плану из JSON-файла')
    a = ap.parse_args()

    if a.from_plan:
        spec = json.loads(Path(a.from_plan).read_text(encoding='utf-8-sig'))
    else:
        if not a.files:
            ap.error('укажите файлы или --from-plan')
        opts = {'target_slides': a.slides, 'title': a.title, 'subtitle': a.subtitle, 'event': a.event,
                'date': a.date, 'mode': a.mode, 'ai_level': a.ai_level, 'animations': not a.no_anim}
        llm = None
        if a.mode == 'ai':
            from engine.llm_client import DEFAULTS, describe
            s = ROOT / 'settings.json'
            saved = json.loads(s.read_text(encoding='utf-8-sig')) if s.exists() else {}
            # запрет облачных моделей администратором ("allow_cloud": false) действует и здесь
            llm = {**DEFAULTS, **saved.get('llm', {}), 'allow_cloud': saved.get('allow_cloud', True) is not False,
                   'internal_domains': saved.get('internal_domains') or []}
            d = describe(llm)
            if d['llm_cloud']:
                print(f'☁ Облачная модель: {d["llm_provider_name"]} ({d["llm_model"]}) — текст документов '
                      'отправляется во внешний сервис', file=sys.stderr)
        def progress(e):                 # ход работы модели — в консоль
            ph = e.get('phase')
            if ph == 'wait':
                print(f'  модель читает документ (≈{e.get("prompt_tokens")} токенов)…', file=sys.stderr)
            elif ph == 'gen' and e.get('tokens', 0) % 64 == 1:
                print(f'  модель пишет: {e["tokens"]} токенов, слайдов {e.get("slides", 0)}', file=sys.stderr)
            elif ph == 'done':
                s = e.get('stats') or {}
                print(f'  готово: запрос {s.get("prompt_tokens")} ток., ответ {s.get("out_tokens")} ток., '
                      f'{s.get("tok_per_s")} ток/с', file=sys.stderr)
        spec, warnings, info = engine.analyze([(f, Path(f).name) for f in a.files], opts, llm, progress=progress)
        for w in warnings:
            print('⚠', w)
        if spec is None:
            sys.exit(1)
        print(f'План: {len(spec["slides"])} слайдов (анализ: {info["mode_used"]})')
        if a.plan_only:
            Path(a.plan_only).write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding='utf-8')
            print('План сохранён:', a.plan_only)
            return
    from app import safe_name
    out = Path(a.out) if a.out else ROOT / 'output' / (safe_name(spec.get('meta', {}).get('title')) + '.pptx')
    path, warnings, n = engine.build(spec, out)
    for w in warnings:
        print('⚠', w)
    print(f'Готово: {path} ({n} слайдов)')


if __name__ == '__main__':
    main()
