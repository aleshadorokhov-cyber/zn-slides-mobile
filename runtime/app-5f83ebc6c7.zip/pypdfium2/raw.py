# -*- coding: utf-8 -*-
"""
pypdfium2.raw для телефона: функции PDFium с теми же именами и аргументами (ctypes), что у настоящей
библиотеки, — но данные уже забраны из PDFium (WebAssembly) целой страницей, см. __init__.py.
Только то, что нужно чтению PDF в конструкторе.
"""
import ctypes

FPDF_ERR_SUCCESS, FPDF_ERR_UNKNOWN, FPDF_ERR_FILE, FPDF_ERR_FORMAT, FPDF_ERR_PASSWORD = 0, 1, 2, 3, 4
FPDF_ERR_SECURITY, FPDF_ERR_PAGE = 5, 6
FPDF_PAGEOBJ_UNKNOWN, FPDF_PAGEOBJ_TEXT, FPDF_PAGEOBJ_PATH, FPDF_PAGEOBJ_IMAGE = 0, 1, 2, 3
FPDF_PAGEOBJ_SHADING, FPDF_PAGEOBJ_FORM = 4, 5
FPDF_SEGMENT_UNKNOWN, FPDF_SEGMENT_LINETO, FPDF_SEGMENT_BEZIERTO, FPDF_SEGMENT_MOVETO = -1, 0, 1, 2
FPDF_ANNOT_HIGHLIGHT = 9


class FS_RECTF(ctypes.Structure):
    _fields_ = [('left', ctypes.c_float), ('top', ctypes.c_float), ('right', ctypes.c_float), ('bottom', ctypes.c_float)]


class FS_MATRIX(ctypes.Structure):
    _fields_ = [(k, ctypes.c_float) for k in 'abcdef']


class FS_QUADPOINTSF(ctypes.Structure):
    _fields_ = [(k, ctypes.c_float) for k in ('x1', 'y1', 'x2', 'y2', 'x3', 'y3', 'x4', 'y4')]


# ---------------------------------------------------------------- символы (PdfTextPage)
# запись символа: 0 код, 1 есть рамка, 2 left, 3 right, 4 bottom, 5 top, 6 угол, 7 кегль, 8 есть матрица,
# 9 c, 10 d, 11 номер шрифта, 12 жирность, 13 есть цвет, 14–17 R G B A
S = 18


def _rec(tp, i):
    return tp.data, i * S


def FPDFText_CountChars(tp):
    return tp.n


def FPDFText_GetUnicode(tp, i):
    if not 0 <= i < tp.n:
        return 0
    return int(tp.data[i * S])


def FPDFText_GetLooseCharBox(tp, i, rect):
    d, o = _rec(tp, i)
    if not d[o + 1]:
        return False
    rect.left, rect.right, rect.bottom, rect.top = d[o + 2], d[o + 3], d[o + 4], d[o + 5]
    return True


def FPDFText_GetCharAngle(tp, i):
    return tp.data[i * S + 6]


def FPDFText_GetFontSize(tp, i):
    return tp.data[i * S + 7]


def FPDFText_GetMatrix(tp, i, m):
    d, o = _rec(tp, i)
    if not d[o + 8]:
        return False
    m.a = m.b = m.e = m.f = 0.0
    m.c, m.d = d[o + 9], d[o + 10]
    return True


def FPDFText_GetFontInfo(tp, i, buf, buflen, flags):
    k = int(tp.data[i * S + 11])
    if k < 0 or k >= len(tp.fonts):
        return 0
    name, fl = tp.fonts[k]
    data = name[:max(0, buflen - 1)]
    if hasattr(buf, 'value'):
        buf.value = data
    else:
        ctypes.memmove(buf, data + b'\0', len(data) + 1)
    if flags is not None:
        flags.value = fl
    return len(name) + 1


def FPDFText_GetFontWeight(tp, i):
    return int(tp.data[i * S + 12])


def FPDFText_GetFillColor(tp, i, r, g, b, a):
    d, o = _rec(tp, i)
    if not d[o + 13]:
        return False
    r.value, g.value, b.value, a.value = int(d[o + 14]), int(d[o + 15]), int(d[o + 16]), int(d[o + 17])
    return True


# ---------------------------------------------------------------- фигуры (PdfObject.raw — словарь из pdf-bridge.js)
# {n: число отрезков, dm: [есть, заливка, обводка], fc/sc: [есть, R, G, B, A], m: [есть, a…f],
#  s: [[есть точка, x, y, тип, замкнут], …] — только если отрезков не слишком много}

def FPDFPath_CountSegments(o):
    return int(o.get('n', 0))


def FPDFPath_GetDrawMode(o, fill, stroke):
    dm = o.get('dm') or [0, 0, 0]
    if not dm[0]:
        return False
    fill.value, stroke.value = int(dm[1]), int(dm[2])
    return True


def _color(c, r, g, b, a):
    if not c or not c[0]:
        return False
    r.value, g.value, b.value, a.value = int(c[1]), int(c[2]), int(c[3]), int(c[4])
    return True


def FPDFPageObj_GetFillColor(o, r, g, b, a):
    return _color(o.get('fc'), r, g, b, a)


def FPDFPageObj_GetStrokeColor(o, r, g, b, a):
    return _color(o.get('sc'), r, g, b, a)


def FPDFPageObj_GetMatrix(o, m):
    v = o.get('m')
    if not v or not v[0]:
        return False
    m.a, m.b, m.c, m.d, m.e, m.f = v[1:7]
    return True


def FPDFPath_GetPathSegment(o, k):
    s = o.get('s') or []
    return s[k] if 0 <= k < len(s) else None


def FPDFPathSegment_GetPoint(seg, x, y):
    if not seg or not seg[0]:
        return False
    x.value, y.value = seg[1], seg[2]
    return True


def FPDFPathSegment_GetType(seg):
    return int(seg[3]) if seg else FPDF_SEGMENT_UNKNOWN


def FPDFPathSegment_GetClose(seg):
    return bool(seg and seg[4])


def FPDFPageObj_GetBounds(o, left, bottom, right, top):
    b = o.get('b')
    if not b or not b[0]:
        return False
    left.value, bottom.value, right.value, top.value = b[1:5]
    return True


def FPDFPageObj_GetType(o):
    return int(o.get('t', FPDF_PAGEOBJ_UNKNOWN))


# ---------------------------------------------------------------- примечания (PdfPage.raw — сама страница)
# [{st: подтип, q: [[x1, y1, … y4], …], r: [есть, left, top, right, bottom]}]

def FPDFPage_GetAnnotCount(page):
    return len(page.annots())


def FPDFPage_GetAnnot(page, i):
    a = page.annots()
    return a[i] if 0 <= i < len(a) else None


def FPDFPage_CloseAnnot(a):
    return None


def FPDFAnnot_GetSubtype(a):
    return int(a.get('st', 0))


def FPDFAnnot_CountAttachmentPoints(a):
    return len(a.get('q') or [])


def FPDFAnnot_GetAttachmentPoints(a, j, q):
    pts = a.get('q') or []
    if not 0 <= j < len(pts):
        return False
    q.x1, q.y1, q.x2, q.y2, q.x3, q.y3, q.x4, q.y4 = pts[j][:8]
    return True


def FPDFAnnot_GetRect(a, r):
    v = a.get('r')
    if not v or not v[0]:
        return False
    r.left, r.top, r.right, r.bottom = v[1:5]
    return True


# ---------------------------------------------------------------- выделения в копии PDF (1.7.2, engine/docview.py)
# Примечания копятся в документе и создаются в PDFium одним вызовом при pdf.save() (pdf-bridge.js, saveHighlights).
FPDFANNOT_COLORTYPE_Color, FPDFANNOT_COLORTYPE_InteriorColor = 0, 1


class _Annot:
    def __init__(self, page, subtype):
        self.rec = {'p': page.index, 'st': subtype, 'c': [255, 214, 0, 150], 'q': [], 'r': None}
        page.pdf._annots.append(self.rec)


def FPDFPage_CreateAnnot(page, subtype):
    return _Annot(page, subtype) if subtype == FPDF_ANNOT_HIGHLIGHT else None


def FPDFAnnot_SetColor(annot, color_type, r, g, b, a):
    if color_type == FPDFANNOT_COLORTYPE_Color:
        annot.rec['c'] = [int(r), int(g), int(b), int(a)]
    return True


def FPDFAnnot_AppendAttachmentPoints(annot, q):
    annot.rec['q'].append([float(getattr(q, k)) for k in ('x1', 'y1', 'x2', 'y2', 'x3', 'y3', 'x4', 'y4')])
    return True


def FPDFAnnot_SetRect(annot, rect):
    annot.rec['r'] = [float(rect.left), float(rect.top), float(rect.right), float(rect.bottom)]
    return True


def FPDFPage_CloseAnnot(annot):
    return None
