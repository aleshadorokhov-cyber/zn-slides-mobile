# -*- coding: utf-8 -*-
"""
users.py — ЛИЧНЫЕ КАБИНЕТЫ (1.8)
================================
У каждого пользователя — свой кабинет: вход по имени и паролю, текущая работа (план, параметры, открытые
слайды), которая сохраняется сама, в том числе при закрытии вкладки, и список «Мои презентации».

Хранение — output/users/:
  index.json              {uid: {name, key, pw, created, seen, full, phone, onboarded, cur, prefs}}
                          key — имя для сравнения (нижний регистр, ё = е); pw — хэш пароля (PBKDF2-SHA256,
                          сам пароль нигде не хранится)
  sessions.json           {sha256(токен): {uid, created, seen, long}} — входы; в cookie браузера — сам токен
  <uid>/works/<wid>.json  работа: {id, title, created, saved, slides, spec, opts, ui, files}

Вход обязателен (ключ администратора "require_login", по умолчанию true). При "require_login": false
кабинет один — «Этот компьютер» (uid local), без пароля: так конструктор работал до 1.8.
"""
import hashlib
import json
import re
import secrets
import threading
import time

from werkzeug.security import check_password_hash, generate_password_hash

from .nts import config as C

USERS_DIR = C.OUTPUT_DIR / 'users'
INDEX = USERS_DIR / 'index.json'
SESSIONS = USERS_DIR / 'sessions.json'
LOCAL_UID = 'local'
UID_RX = re.compile(r'^(?:[0-9a-f]{12}|local)$')
WID_RX = re.compile(r'^[0-9a-f]{12}$')
PW_METHOD = 'pbkdf2:sha256:600000'
MIN_PW = 6
MAX_WORK = 25 * 1024 * 1024            # одна работа (план со всеми вариантами слайдов) — не больше 25 МБ
MAX_WORKS = 300
LONG_DAYS = 60                         # «Запомнить меня»: вход действует 60 дней с последнего визита
SHORT_HOURS = 12                       # без «Запомнить меня» — до закрытия браузера, но не дольше 12 часов
FAIL_MAX, FAIL_LOCK = 5, 60            # 5 неверных паролей подряд — пауза 60 секунд
# вид в профиле: тема, размер текста, шрифт; с 1.9 — размер значков, миниатюр слайдов и свои цвета областей 1–3
# (шестнадцатеричный цвет без «#»; пустая строка — цвет по умолчанию)
PREF_KEYS = {'theme': r'[a-z\-]{1,24}', 'fz': r'[a-z]{1,4}', 'font': r'[a-z\-]{1,12}', 'ic': r'[a-z]{1,4}', 'thumb': r'[a-z]{1,4}',
             'c1': r'[0-9a-f]{6}|', 'c2': r'[0-9a-f]{6}|', 'c3': r'[0-9a-f]{6}|'}

_LOCK = threading.RLock()
_FAILS = {}                            # key → (число неудач, время последней)


class UserError(Exception):
    """Понятная пользователю причина отказа (неверный пароль, имя занято…)."""


def _now():
    return round(time.time(), 3)


def _read(path, default):
    try:
        d = json.loads(path.read_text(encoding='utf-8'))
        return d if isinstance(d, type(default)) else default
    except (OSError, ValueError):
        return default


def _write(path, data, indent=1):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f'.{threading.get_ident()}.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=indent), encoding='utf-8')
    tmp.replace(path)


def name_key(name):
    return re.sub(r'\s+', ' ', str(name or '')).strip().casefold().replace('ё', 'е')


def clean_name(name):
    return re.sub(r'\s+', ' ', str(name or '')).strip()


def _check_name(name):
    if not 2 <= len(name) <= 40:
        raise UserError('Имя пользователя — от 2 до 40 знаков.')
    if not re.search(r'[0-9A-Za-zА-Яа-яЁё]', name) or re.search(r'[<>"\\/\x00-\x1f]', name):
        raise UserError('В имени пользователя — буквы, цифры, пробел, точка, дефис.')


def _check_pw(pw):
    if len(str(pw or '')) < MIN_PW:
        raise UserError(f'Пароль — не короче {MIN_PW} знаков.')
    if len(str(pw)) > 200:
        raise UserError('Слишком длинный пароль.')


def _tok_hash(token):
    return hashlib.sha256(str(token).encode('utf-8')).hexdigest()


def _public(uid, u):
    return {'uid': uid, 'name': u.get('name') or '', 'full': u.get('full') or '', 'phone': u.get('phone') or '',
            'onboarded': bool(u.get('onboarded')), 'cur': u.get('cur') or '', 'prefs': u.get('prefs') or {},
            'created': u.get('created'), 'local': uid == LOCAL_UID}


def _users():
    return _read(INDEX, {})


def find(name):
    """uid пользователя с таким именем (или None)."""
    key = name_key(name)
    for uid, u in _users().items():
        if u.get('key') == key:
            return uid
    return None


def count():
    return sum(1 for uid in _users() if uid != LOCAL_UID)


# --------------------------------------------------------------------------------------
# Регистрация, вход, выход
# --------------------------------------------------------------------------------------
def _new_session(uid, long):
    token = secrets.token_urlsafe(32)
    ss = _read(SESSIONS, {})
    now = _now()
    # заодно убираем просроченные входы
    ss = {h: s for h, s in ss.items() if isinstance(s, dict) and not _expired(s, now)}
    ss[_tok_hash(token)] = {'uid': uid, 'created': now, 'seen': now, 'long': bool(long)}
    _write(SESSIONS, ss, indent=None)
    return token


def _expired(s, now):
    return now - float(s.get('seen') or 0) > (LONG_DAYS * 86400 if s.get('long') else SHORT_HOURS * 3600)


def register(name, password, long=True):
    """Новый кабинет → (профиль, токен входа). UserError — имя занято, короткий пароль…"""
    name = clean_name(name)
    _check_name(name)
    _check_pw(password)
    with _LOCK:
        if find(name):
            raise UserError(f'Имя «{name}» уже занято. Если это ваш кабинет — войдите; если нет — добавьте, '
                            'например, первую букву отчества.')
        users = _users()
        uid = secrets.token_hex(6)
        while uid in users:
            uid = secrets.token_hex(6)
        now = _now()
        users[uid] = {'name': name, 'key': name_key(name), 'pw': generate_password_hash(password, PW_METHOD),
                      'created': now, 'seen': now, 'full': '', 'phone': '', 'onboarded': False, 'cur': '', 'prefs': {}}
        _write(INDEX, users)
        return _public(uid, users[uid]), _new_session(uid, long)


def _fail_wait(key):
    n, t = _FAILS.get(key, (0, 0))
    left = FAIL_LOCK - (time.time() - t)
    return int(left) + 1 if n >= FAIL_MAX and left > 0 else 0


def login(name, password, long=True):
    """Вход → (профиль, токен). UserError — неверное имя или пароль, пауза после 5 ошибок подряд."""
    key = name_key(name)
    wait = _fail_wait(key)
    if wait:
        raise UserError(f'Слишком много неверных попыток. Подождите {wait} с и попробуйте снова.')
    with _LOCK:
        users = _users()
        uid = next((i for i, u in users.items() if u.get('key') == key and i != LOCAL_UID), None)
        ok = bool(uid) and check_password_hash(users[uid].get('pw') or '', str(password or ''))
        if not ok:
            n = _FAILS.get(key, (0, 0))[0]
            n = 1 if n >= FAIL_MAX else n + 1             # пауза прошла — считаем заново
            _FAILS[key] = (n, time.time())
            if n >= FAIL_MAX:
                raise UserError(f'Неверное имя или пароль. Слишком много попыток — подождите {FAIL_LOCK} с.')
            raise UserError('Неверное имя пользователя или пароль.')
        _FAILS.pop(key, None)
        users[uid]['seen'] = _now()
        _write(INDEX, users)
        return _public(uid, users[uid]), _new_session(uid, long)


def logout(token):
    with _LOCK:
        ss = _read(SESSIONS, {})
        if ss.pop(_tok_hash(token), None) is not None:
            _write(SESSIONS, ss, indent=None)


def by_token(token):
    """Профиль по токену входа из cookie (None — не вошёл или вход истёк)."""
    if not token or len(str(token)) > 200:
        return None
    h = _tok_hash(token)
    with _LOCK:
        ss = _read(SESSIONS, {})
        s = ss.get(h)
        now = _now()
        if not isinstance(s, dict):
            return None
        if _expired(s, now):
            ss.pop(h, None)
            _write(SESSIONS, ss, indent=None)
            return None
        users = _users()
        u = users.get(s.get('uid'))
        if not u:
            return None
        if now - float(s.get('seen') or 0) > 300:          # отметка визита — не чаще раза в 5 минут
            s['seen'] = now
            _write(SESSIONS, ss, indent=None)
        return _public(s['uid'], u)


def session_long(token):
    s = _read(SESSIONS, {}).get(_tok_hash(token or ''))
    return bool(isinstance(s, dict) and s.get('long'))


def local_user():
    """Кабинет «Этот компьютер» — когда администратор выключил вход ("require_login": false)."""
    with _LOCK:
        users = _users()
        if LOCAL_UID not in users:
            users[LOCAL_UID] = {'name': 'Этот компьютер', 'key': '', 'pw': '', 'created': _now(), 'seen': _now(),
                                'full': '', 'phone': '', 'onboarded': False, 'cur': '', 'prefs': {}}
            _write(INDEX, users)
        return _public(LOCAL_UID, users[LOCAL_UID])


def get(uid):
    u = _users().get(uid)
    return _public(uid, u) if u else None


def update(uid, fields):
    """Профиль: ФИО и телефон (для справки Word), «обучение пройдено», вид (тема, размер текста, шрифт)."""
    with _LOCK:
        users = _users()
        u = users.get(uid)
        if not u:
            raise UserError('Кабинет не найден.')
        f = fields or {}
        if 'full' in f:
            u['full'] = clean_name(f['full'])[:80]
        if 'phone' in f:
            u['phone'] = clean_name(f['phone'])[:40]
        if 'onboarded' in f:
            u['onboarded'] = bool(f['onboarded'])
        if isinstance(f.get('prefs'), dict):
            p = dict(u.get('prefs') or {})
            for k, rx in PREF_KEYS.items():
                v = f['prefs'].get(k)
                if isinstance(v, str) and re.fullmatch(rx, v):
                    if v:
                        p[k] = v
                    else:
                        p.pop(k, None)
            u['prefs'] = p
        if 'cur' in f and (f['cur'] == '' or WID_RX.match(str(f['cur']))):
            u['cur'] = f['cur']
        _write(INDEX, users)
        return _public(uid, u)


def change_password(uid, old, new):
    _check_pw(new)
    with _LOCK:
        users = _users()
        u = users.get(uid)
        if not u or uid == LOCAL_UID:
            raise UserError('Кабинет не найден.')
        if not check_password_hash(u.get('pw') or '', str(old or '')):
            raise UserError('Текущий пароль неверный.')
        u['pw'] = generate_password_hash(new, PW_METHOD)
        _write(INDEX, users)


def reset_password(name, new):
    """Новый пароль без старого — только с компьютера, где запущен конструктор (проверяет app.py).
    Все прежние входы этого пользователя закрываются."""
    _check_pw(new)
    with _LOCK:
        users = _users()
        uid = next((i for i, u in users.items() if u.get('key') == name_key(name) and i != LOCAL_UID), None)
        if not uid:
            raise UserError(f'Пользователя «{clean_name(name)}» нет.')
        users[uid]['pw'] = generate_password_hash(new, PW_METHOD)
        _write(INDEX, users)
        ss = {h: s for h, s in _read(SESSIONS, {}).items() if isinstance(s, dict) and s.get('uid') != uid}
        _write(SESSIONS, ss, indent=None)
        _FAILS.pop(name_key(name), None)
        return uid


def names():
    """Имена пользователей (для подсказки при сбросе пароля на этом компьютере)."""
    return sorted((u.get('name') or '' for i, u in _users().items() if i != LOCAL_UID), key=str.casefold)


# --------------------------------------------------------------------------------------
# Работы: текущая и «Мои презентации»
# --------------------------------------------------------------------------------------
def _wdir(uid):
    if not UID_RX.match(str(uid)):
        raise UserError('Кабинет не найден.')
    return USERS_DIR / uid / 'works'


def _wpath(uid, wid):
    if not WID_RX.match(str(wid or '')):
        raise UserError('Нет такой презентации.')
    return _wdir(uid) / f'{wid}.json'


def _title(d):
    spec = d.get('spec') if isinstance(d.get('spec'), dict) else {}
    meta = spec.get('meta') if isinstance(spec.get('meta'), dict) else {}
    opts = d.get('opts') if isinstance(d.get('opts'), dict) else {}
    for t in (d.get('title'), meta.get('title'), opts.get('optTitle'), *(d.get('files') or [])[:1]):
        t = clean_name(t)
        if t:
            return t[:120]
    return 'Без названия'


def _brief(d):
    spec = d.get('spec') if isinstance(d.get('spec'), dict) else {}
    return {'id': d.get('id'), 'title': d.get('title') or 'Без названия', 'created': d.get('created'),
            'saved': d.get('saved'), 'slides': len(spec.get('slides') or []), 'built': d.get('built') or None,
            'files': (d.get('files') or [])[:12]}


def works(uid):
    """Список работ пользователя, новые сверху: [{id, title, created, saved, slides, built, files}]."""
    out = []
    d = _wdir(uid)
    if d.exists():
        for p in d.glob('*.json'):
            if not WID_RX.match(p.stem):
                continue
            w = _read(p, {})
            if w.get('id') == p.stem:
                out.append(_brief(w))
    return sorted(out, key=lambda w: -(w.get('saved') or 0))


def work(uid, wid):
    w = _read(_wpath(uid, wid), {})
    if w.get('id') != wid:
        raise UserError('Нет такой презентации (возможно, её удалили).')
    return w


def save_work(uid, wid, data, size=0, create=False):
    """Сохранить работу (wid = None — новая). data: spec (план или null), opts (поля «Параметров»), ui (открытые
    слайды и т. п.), files (имена ещё не разобранных файлов), title, built. create — номер работы выбрала страница
    (автосохранение): такой работы ещё нет — она создаётся. Возвращает краткие сведения."""
    if size and size > MAX_WORK:
        raise UserError('План слишком большой для сохранения (больше 25 МБ).')
    data = data if isinstance(data, dict) else {}
    with _LOCK:
        old = {}
        if wid:
            p = _wpath(uid, wid)
            old = _read(p, {})
            if old.get('id') != wid and not create:
                raise UserError('Нет такой презентации (возможно, её удалили).')
        if old.get('id') != wid or not wid:
            if len(works(uid)) >= MAX_WORKS:
                raise UserError(f'В кабинете уже {MAX_WORKS} презентаций — удалите ненужные.')
            wid = wid or secrets.token_hex(6)
            p = _wpath(uid, wid)
            old = {'id': wid, 'created': _now()}
        w = dict(old)
        for k, typ in (('spec', (dict, type(None))), ('opts', dict), ('ui', dict), ('files', list)):
            if k in data and isinstance(data[k], typ):
                w[k] = data[k]
        if 'files' in w:
            w['files'] = [clean_name(f)[:200] for f in w['files'] if isinstance(f, str)][:100]
        if isinstance(data.get('built'), dict):
            w['built'] = {'at': _now(), 'name': clean_name(data['built'].get('name'))[:200]}
        if data.get('title'):
            w['title_set'] = True
            w['title'] = clean_name(data['title'])[:120]
        if not w.get('title_set'):
            w['title'] = _title(dict(w, title=''))
        w['saved'] = _now()
        _write(p, w, indent=None)
        users = _users()
        if uid in users and users[uid].get('cur') != wid and data.get('make_current', True):
            users[uid]['cur'] = wid
            _write(INDEX, users)
        return _brief(w)


def delete_work(uid, wid):
    with _LOCK:
        p = _wpath(uid, wid)
        if not p.exists():
            raise UserError('Нет такой презентации.')
        p.unlink()
        users = _users()
        if uid in users and users[uid].get('cur') == wid:
            users[uid]['cur'] = ''
            _write(INDEX, users)
