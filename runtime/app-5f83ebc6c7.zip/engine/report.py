# -*- coding: utf-8 -*-
"""
report.py — СПРАВКА В WORD (.docx) ПО ЗАГРУЖЕННЫМ МАТЕРИАЛАМ
==========================================================

Из тех же файлов, что и презентация (Word, Excel, CSV, текст), собирается деловая справка
для руководства в формате Word:

    шапка: логотип Компании (из корпоративного шаблона) и зелёная линия
    СПРАВКА
    о <теме> (заголовок к тексту), дата
    1. Краткое содержание      — 3–6 главных тезисов (выделенное автором — первым, жирным)
    2. Основные положения      — по разделам документа: сжатые абзацы без «речи докладчика»,
                                 списки, таблицы и рисунки разделов
    3. Ключевые показатели     — таблица чисел с единицами и источником (только числа из файлов)
    4. Табличные данные        — таблицы Excel/CSV (и не вошедшие в разделы), под ними —
                                 выводы, посчитанные из самих данных
    5. Выводы и предложения
    6. Источники               — имена файлов (и листов Excel)
    подвал: «Исполнитель: …» и номер страницы (поле PAGE)

Два режима (options['mode']):
  'rules' — по правилам, офлайн и мгновенно (тексты сжимаются функциями condense.py);
  'ai'    — тексты пишет модель ИИ — локальная или облачная (те же настройки, что у планировщика):
            ai_level 'fast' — краткое содержание, выводы, предложения и тема;
            ai_level 'full' — плюс тексты разделов.
            Числа в тексте модели сверяются с документом: предложение с числом, которого нет
            в исходных файлах, удаляется (с предупреждением). Таблицы и ключевые показатели
            всегда собирает код из документа. При любой ошибке модели справка строится по
            правилам — с предупреждением; отмена (llm_client.Cancelled) пробрасывается наверх.

Объём (options['pages'], 1–30 листов; 0 — без ограничения): число листов справки оценивается в коде
(ширины символов Arial, поля и стили страницы — без Word и LibreOffice), и, если справка не помещается,
в ней остаётся самое важное: шапка и краткое содержание, затем выводы и предложения, ключевые
показатели, главные мысли разделов (выделенное автором, числа, «цель», «результат», «эффект», «риск»…),
таблицы (длинные — первыми строками и строкой «…»), рисунки — в последнюю очередь. Предложения не
режутся на середине, пустых заголовков не бывает. Подробнее — раздел 5.

Оформление: А4, Arial (корпоративный TT Bluescreens Pro на компьютерах пользователей обычно
не установлен), заголовки в фирменных цветах (#00326E, #0078AE, #0A8F2D), шапки таблиц —
тёмно-синие с белым текстом, «зебра», текст 12 pt по ширине с переносами, интервал 1,15,
русская типографика (неразрывные пробелы textutil.typo).

Главная функция:
    make_report(files, out_path, options=None, llm=None, progress=None) → (путь | None, предупреждения, сведения)
"""
import copy
import datetime
import io
import re
import zipfile
from pathlib import Path
from types import SimpleNamespace

from docx import Document as WordDocument
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

from .condense import despeech, facts, params, pros_cons, sents
from .insights import choose_chart, kpi_from_table, kpi_scale_diverse, make_insights
from .llm_client import Cancelled, LLMError, chat, estimate_tokens, extract_json
from .planner_llm import _doc_numbers, _numbers, digest, digest_fast
from .planner_rules import RX, _kpi_item, same_text
from .prepare import prepare
from .readers import read_files
from .smart import clean_item
from .textutil import cap, clean, sentences, shorten, short_title, split_title_text, typo

ROOT = Path(__file__).resolve().parent.parent
TEMPLATE = ROOT / 'assets' / 'template' / 'base_deck.pptx'

# Палитра Компании (как в engine/nts/config.py) и оформление
NAVY, BLUE, GREEN, DGREEN = '00326E', '0078AE', '4BAF46', '0A8F2D'
TEXT, GRAY, LGRAY = '1E1E1E', '5A5A5A', 'BFC7D5'
ZEBRA, BOX, PALEG = 'F2F4F7', 'EEF2F6', 'EBF0D6'
FONT = 'Arial'

PAGE_W, PAGE_H = 21.0, 29.7                      # А4, см
MARGINS = {'top': 2.0, 'bottom': 2.0, 'left': 2.5, 'right': 1.5}
TEXT_W = PAGE_W - MARGINS['left'] - MARGINS['right']   # ширина текста: 17 см

PROSE_LIMIT = 1400        # символов прозы на раздел (выделенное автором — сверх лимита)
MAX_KEY_NUMBERS = 12      # строк в таблице ключевых показателей
MAX_TABLE_ROWS = 40       # строк таблицы данных в справке
MAX_TABLE_COLS = 10
MAX_SUMMARY = 6
MAX_PAGES = 30            # наибольшее число листов, которое можно задать (options['pages'])
WHOLE_TABLE = 15          # таблица до стольких строк не делится между страницами
WHOLE_TABLE_SHORT = 6     # то же в справке, сокращённой до заданного числа листов (меньше пустот внизу листа)


# ======================================================================================
# 1. ТЕКСТ: речь → деловой стиль, тема справки
# ======================================================================================
_FIRST_PERSON = [
    (re.compile(r'(?i)^(?:я|мы)\s+предлага\w*\s+'), 'Предлагается '),
    (re.compile(r'(?i)^предлагаю\s+'), 'Предлагается '),
    (re.compile(r'(?i)^(?:мной|нами)\s+(?:были\s+|был\s+|была\s+)?'), ''),
]
_INTRO_TAIL = re.compile(r':\s*$')
_CONJ_LEAD = re.compile(r'(?i)^(?:и|а|но|именно|поэтому|однако)\s+(?=\S)')


def _first_person(s):
    for rx, rep in _FIRST_PERSON:
        s2 = rx.sub(rep, s)
        if s2 != s:
            return cap(s2)
    return s


def _tidy(s):
    """Предложение целиком в скобках «(… .)» → без скобок; союз в начале («И важный момент…») — долой."""
    s = s.strip()
    m = re.fullmatch(r'\((.+?)\.?\)\.?', s)
    if m and '(' not in m.group(1):
        s = m.group(1).strip()
    s = _CONJ_LEAD.sub('', s)
    return cap(s)


def _condense(text):
    """Абзац (часто — текст выступления) → список предложений делового текста."""
    out = []
    for s in sents(text):
        t = despeech(_first_person(_tidy(s)))
        if t:
            out.append(_tidy(t))
    return out


def _end(s):
    s = (s or '').strip()
    return s if not s or s.endswith(('.', '!', '?', '…', ':', ';')) else s + '.'


def _lower_first(s):
    """«Энергоаудит» → «энергоаудит», но аббревиатуры («УЭЦН», «ESG») не трогаем."""
    w = s.split(' ', 1)[0] if s else ''
    if len(w) > 1 and (w.isupper() or any(ch.isupper() for ch in w[1:])):
        return s
    return s[:1].lower() + s[1:]


_KEEP_PREP = re.compile(r'(?i)^(о|об|обо|по|к|на|для)\s')
_PLURAL_IRREG = {'данные': 'данных', 'итоги': 'итогах', 'компания': 'компании', 'кампания': 'кампании'}


def _prepositional(w):
    """Первое слово темы в предложном падеже («программа» → «программе») или None, если не уверены."""
    if w in _PLURAL_IRREG:
        return _PLURAL_IRREG[w]
    if re.search(r'(ения|ания|ятия|ования)$', w):
        return w + 'х'                                   # «мероприятия» → «мероприятиях»
    if w.endswith('ия'):
        return w[:-1] + 'и'                              # «технология» → «технологии»
    if re.search(r'(ние|тие|вие|ствие)$', w):
        return w[:-1] + 'и'                              # «внедрение» → «внедрении»
    if re.search(r'(ый|ий|ой|ая|яя|ое|ее|ые|ие|ей|ай)$', w):
        return None                                      # прилагательное и т. п. — не склоняем
    if w.endswith(('ость', 'есть')):
        return w[:-1] + 'и'
    if w.endswith('тель'):
        return w[:-1] + 'е'
    if w.endswith('ь'):
        return w[:-1] + 'и'
    if w.endswith(('а', 'я')):
        return w[:-1] + 'е'                              # «программа» → «программе»
    if w.endswith('ы'):
        return w[:-1] + 'ах'                             # «результаты» → «результатах»
    if w.endswith('и'):
        return w[:-1] + ('ах' if w[-2:-1] in 'гкхжшчщ' else 'ях')
    if re.search(r'[бвгджзклмнпрстфхцчшщ]$', w):
        return w + 'е'                                   # «проект» → «проекте»
    return None


def about_phrase(topic):
    """Заголовок к тексту справки: «Программа повышения…» → «о программе повышения…».
    Если склонение не очевидно — «по теме «…»»."""
    t = clean(topic).strip(' .')
    t = re.sub(r'^[«"]+|[»"]+$', '', t).strip()
    if not t:
        return ''
    if _KEEP_PREP.match(t):
        return _lower_first(t)
    first, _, rest = t.partition(' ')
    if re.fullmatch(r'[А-ЯЁа-яё-]+', first) and not (len(first) > 1 and first.isupper()) \
            and not any(ch.isupper() for ch in first[1:]):
        new = _prepositional(first.lower())
        if new:
            prep = 'об' if new[:1] in 'аоэиуы' else 'о'
            return f'{prep} {new}' + (f' {rest}' if rest else '')
    return f'по теме «{t}»'


def _norm_words(t):
    return [w[:6] for w in re.findall(r'[0-9a-zа-яё]+', (t or '').lower()) if len(w) >= 4]


def _similar(a, b):
    """Одна и та же мысль (для проверки, что выделенное автором попало в текст модели)."""
    if same_text(a, b):
        return True
    wa, wb = set(_norm_words(a)), set(_norm_words(b))
    return bool(wa) and len(wa & wb) / len(wa) >= 0.6


# ======================================================================================
# 2. СОДЕРЖАНИЕ СПРАВКИ ПО ПРАВИЛАМ
# ======================================================================================
_PRO_RX = re.compile(r'(?i)^(достоинств\w*|преимуществ\w*|плюсы)\s*[:—–-]')
_CON_RX = re.compile(r'(?i)^(недостат\w*|минусы|ограничени\w*)\s*[:—–-]')
_PARAM_RX = re.compile(r'^\s*([^=:]{2,40}?)\s*(?:=|[-–—:])\s*([-−]?\d[\d  ]*(?:[.,]\d+)?)\s*([^\s\d][^,;]{0,14})?\s*$')
_KEYW = re.compile(r'(?i)проблем|цел[ьи]|задач|позволя|предлага|эффект|результат|вывод|итог|заключа|обеспеч|'
                   r'сниж|увелич|рост|экономи|прибыл|окупа')
_FINAL0 = re.compile(r'(?i)^(таким образом|в итоге|в результате|итак|следовательно)')
_PROPOSAL = re.compile(r'(?i)\b(предлагается|предлагаем|рекомендуется|рекомендуем|рекомендовано|целесообразно|'
                       r'необходимо|следует|планируется)\b')
_APPENDIX = re.compile(r'(?i)дополнительн\w* материал|приложени|справочн|резерв')


def _is_data_sheet(sec):
    """Раздел — лист Excel / CSV (в нём только данные)."""
    src = str(sec.source or '').split(' / ')[0]
    return Path(src).suffix.lower() in ('.xlsx', '.xlsm', '.csv')


def _is_concl(sec):
    return bool(sec.title and RX['concl'].search(sec.title))


def _place(sec):
    """Где в исходных файлах лежит раздел: (файл, «раздел …» / «лист …»)."""
    src = str(sec.source or '')
    if ' / ' in src:
        f, sheet = src.split(' / ', 1)
        return f, f'лист «{sheet}»'
    return src, (f'«{shorten(sec.title, 60)}»' if sec.title else '')


def _list_items(b):
    """Пункты списка Word → [{'title', 'text', 'mark', 'level'}]; «во-первых» и скобки убираются."""
    items = []
    for it in b.items:
        t = _first_person(clean_item(it.text))
        if not t:
            continue
        title, rest = split_title_text(t, it.bold)
        bold = title if title and rest and t.startswith(title) else ''
        items.append({'text': t, 'bold': bold, 'mark': bool(it.mark), 'level': min(1, it.level)})
    titled = sum(1 for i in items if i['bold'])
    if titled < 0.6 * max(1, len(items)):              # жирное начало — только если оно у большинства пунктов
        for i in items:
            i['bold'] = ''
    return items


def _section_body(doc, sec):
    """Раздел документа → {'title', 'blocks', 'children', 'sec'} для раздела «Основные положения»."""
    blocks = []
    paras = [b for b in sec.blocks if b.kind == 'para']
    texts = [clean(b.text) for b in paras]
    pc = pros_cons(texts)
    pr = params(texts)
    names = {g['name'] for g in pc} if pc else set()
    used = 0
    grid_done = params_done = False
    blist = list(sec.blocks)
    for k, b in enumerate(blist):
        if b.kind == 'para':
            t = clean(b.text)
            if not t:
                continue
            if pc and (_PRO_RX.match(t) or _CON_RX.match(t) or t.rstrip('.:') in names):
                if not grid_done:
                    rows = [[g['name'] or '—', '; '.join(g['pros']) or '—', '; '.join(g['cons']) or '—'] for g in pc]
                    blocks.append({'kind': 'grid', 'columns': ['Вид', 'Достоинства', 'Недостатки'], 'rows': rows,
                                   'caption': f'{sec.title}: достоинства и недостатки'})
                    grid_done = True
                continue
            if pr and _PARAM_RX.match(t):
                if not params_done:
                    blocks.append({'kind': 'list', 'ordered': False, 'items': [
                        {'text': f"{p['title']} = {p['value']} {p['unit']}".strip(), 'bold': '', 'mark': False,
                         'level': 0, 'raw': True} for p in pr]})
                    params_done = True
                continue
            nxt = blist[k + 1] if k + 1 < len(blist) else None
            if _INTRO_TAIL.search(t) and len(t) <= 200 and nxt is not None and nxt.kind in ('list', 'table'):
                blocks.append({'kind': 'para', 'text': _first_person(t), 'mark': bool(b.mark), 'bold_part': ''})
                continue                                # «Поставлены следующие задачи:» — перед списком
            ss = _condense(t)
            if not ss:
                continue
            if not (b.mark or b.mark_text) and used >= PROSE_LIMIT:
                continue
            if not (b.mark or b.mark_text):
                keep = []
                for s in ss:
                    if used + len(s) > PROSE_LIMIT and keep:
                        break
                    keep.append(s)
                    used += len(s) + 1
                ss = keep
            txt = ' '.join(ss)
            part = ''
            mark = bool(b.mark)
            if b.mark_text and not b.mark:
                mt = ' '.join(_condense(b.mark_text)) or clean(b.mark_text)
                cand = mt.rstrip('.')
                if cand and cand in txt:
                    part = cand
                elif clean(b.mark_text).rstrip('.') in txt:
                    part = clean(b.mark_text).rstrip('.')
                else:
                    mark = True                          # выделенную часть не нашли — выделяем абзац целиком
            blocks.append({'kind': 'para', 'text': txt, 'mark': mark, 'bold_part': part})
        elif b.kind == 'list':
            items = _list_items(b)
            if items:
                blocks.append({'kind': 'list', 'ordered': bool(b.ordered), 'items': items})
        elif b.kind == 'table' and b.table_id in doc.tables:
            blocks.append({'kind': 'table', 'tid': b.table_id})
        elif b.kind == 'image' and b.image_id in doc.images:
            blocks.append({'kind': 'image', 'fid': b.image_id, 'caption': clean(b.text)})
    children = []
    kids = [c for c in sec.children if not _is_concl(c)]
    simple = kids and len(kids) >= 2 and all(
        not c.children and all(b.kind == 'para' for b in c.blocks) and len(c.all_text(False)) <= 450 for c in kids)
    if simple:                                           # короткие подразделы («Технические риски…») — списком
        items = []
        for c in kids:
            body = ' '.join(' '.join(_condense(b.text)) for b in c.blocks if b.kind == 'para')
            if body:
                items.append({'text': f'{c.title}. {body}', 'bold': c.title, 'mark': c.marked(), 'level': 0})
        if items:
            blocks.append({'kind': 'list', 'ordered': False, 'items': items})
    else:
        for c in kids:
            ch = _section_body(doc, c)
            if ch['blocks'] or ch['children']:
                children.append(ch)
    return {'title': sec.title, 'blocks': blocks, 'children': children, 'sec': sec}


def _key_sentence(sec, with_score=False):
    """Главная мысль раздела для краткого содержания (with_score — вместе с «весом» мысли)."""
    cands = []
    pos = 0
    for b in sec.blocks:
        if b.kind != 'para':
            continue
        for s in sents(b.text):
            if s.rstrip().endswith(':'):
                continue
            t = despeech(_first_person(_tidy(s)))
            if not t or len(t) < 25 or re.search(r'[=*]', t):
                continue
            t = _tidy(t)
            score = 2 * bool(_KEYW.search(t)) + bool(re.search(r'\d', t)) + 2 * bool(_FINAL0.match(clean(s))) \
                + 2 * bool(re.search(r'(?i)составил|составит|составляет|руб', t)) \
                + (1 if pos == 0 else 0) - (1 if len(t) > 260 else 0)
            cands.append((score, -pos, t))
            pos += 1
    res, score = '', 0
    if cands:
        best = max(cands)
        res, score = shorten(best[2], 320), best[0]
    else:
        lst = next((b for b in sec.blocks if b.kind == 'list' and b.items), None)
        names = []
        if lst:
            for it in lst.items[:6]:
                t, _ = split_title_text(clean_item(it.text), it.bold)
                names.append(_lower_first(t or short_title(it.text, 6, 60)))
        elif sec.children:
            names = [_lower_first(c.title) for c in sec.children if c.title][:6]
        if names and sum(len(n) for n in names) <= 260:
            res, score = f'{sec.title}: {", ".join(names)}.', 1
    return (res, score) if with_score else res


def _marked_fragments(doc):
    """Выделенные автором фрагменты (абзацы, части абзацев, пункты) — в порядке документа."""
    out = []
    for s in doc.walk():
        for b in s.blocks:
            if b.kind == 'para' and (b.mark or b.mark_text):
                src = b.mark_text if (b.mark_text and not b.mark) else b.text
                t = ' '.join(_condense(src)[:2]) or clean(src)
                if t:
                    out.append(shorten(_end(t), 360))
            elif b.kind == 'list':
                for it in b.items:
                    if it.mark:
                        out.append(_end(_first_person(clean_item(it.text))))
        if s.mark and s.title and not any(b.mark or b.mark_text for b in s.blocks):
            k = _key_sentence(s)
            if k:
                out.append(_end(k))
    uniq = []
    for t in out:
        if not any(same_text(t, u) for u in uniq):
            uniq.append(t)
    return uniq


def _add_unique(lst, text, mark=False, limit=None):
    text = _end(clean(text))
    if not text or (limit and len(lst) >= limit):
        return False
    for x in lst:
        if same_text(x['text'], text):
            x['mark'] = x['mark'] or mark
            return False
    lst.append({'text': text, 'mark': mark})
    return True


def _summary_rules(doc, body_secs, concl_secs):
    out = []
    for t in _marked_fragments(doc):
        _add_unique(out, t, True, MAX_SUMMARY)
    cands = []
    for i, sec in enumerate(body_secs):
        if RX['intro'].match(sec.title or '') or _is_data_sheet(sec) or _APPENDIX.search(sec.title or ''):
            continue
        k, score = _key_sentence(sec, True)
        if k and not any(same_text(k, x['text']) for x in out):        # жирным — только выделенное автором
            cands.append((score + (3 if sec.marked() else 0), -i, k, bool(sec.mark)))
    best = sorted(cands, reverse=True)[:max(0, MAX_SUMMARY - len(out))]
    for _, _, k, mark in sorted(best, key=lambda x: -x[1]):      # самые весомые мысли — в порядке документа
        _add_unique(out, k, mark, MAX_SUMMARY)
    if len(out) < 3:
        for sec in concl_secs:
            for b in sec.blocks:
                if b.kind == 'list':
                    for it in b.items:
                        _add_unique(out, clean_item(it.text), bool(it.mark), MAX_SUMMARY)
    return out


def _conclusions_rules(doc, body_secs, concl_secs, summary):
    concl, props = [], []
    for sec in concl_secs:
        for b in sec.blocks:
            if b.kind == 'list':
                for it in b.items:
                    _add_unique(concl, _first_person(clean_item(it.text)), bool(it.mark))
            elif b.kind == 'para':
                t = clean(b.text)
                if not t or _INTRO_TAIL.search(t):
                    continue
                for s in _condense(t):
                    _add_unique(concl, s, bool(b.mark or b.mark_text))
        for c in sec.children:
            k = _key_sentence(c)
            if k:
                _add_unique(concl, k, c.marked())
    if not concl:                                    # раздела «Выводы» нет — итоговые фразы документа
        for sec in body_secs:
            for s0 in [x for s_ in [sec] + list(sec.children) for b in s_.blocks if b.kind == 'para'
                       for x in sents(b.text)]:
                if _FINAL0.match(clean(s0)):
                    t = despeech(s0)
                    if t and not re.search(r'[=*]', t):
                        _add_unique(concl, t)
    concl.sort(key=lambda x: not x['mark'])          # выделенное автором — первым
    for s in doc.walk():
        if _is_concl(s):
            continue
        for b in s.blocks:
            if b.kind != 'para':
                continue
            for s0 in sents(b.text):
                if _PROPOSAL.search(s0) and not re.search(r'[=*]', s0):
                    t = _tidy(despeech(_first_person(_tidy(s0))))
                    if t and not any(same_text(t, c['text']) for c in concl):
                        _add_unique(props, t, bool(b.mark), 4)
    return concl[:8], props


# ---------- Ключевые показатели ----------------------------------------------------------
_GEN_PL = re.compile(r'(?i)^(\S+(ов|ев|ей|ий|ин|ок|ек|ах)|число|количество|кол-во|доля|сумма)\b')
_VERB_FIRST = re.compile(r'^[А-ЯЁа-яё]+((?<!с)ть|ться|ает|яет|ует|еет|ется|ются|ают|яют|уют)\b')
_LEAD_QUAL = re.compile(r'(?i)[\s:—–-]*\b(более|менее|свыше|около|до|не менее|не более)\s*$')


_OBLIQUE_ONE = re.compile(r'(?i)^[а-яё]+((?<![иь])е|у|ю|ой|ом|ем|ами|ями|ах|ях)$')


def _good_label(t):
    if not t or len(t) < 4 or len(t) > 70 or '…' in t:
        return False
    if _OBLIQUE_ONE.match(t):                         # одно слово не в именительном падеже («Перегрузке»)
        return False
    if re.search(r'[=*/\\()<>\d]', t):
        return False
    if not re.search(r'[А-ЯЁа-яёA-Za-z]{4,}', t):
        return False
    low = [w.lower() for w in t.split()]
    return not any(a == b for a, b in zip(low, low[1:]))


def _fact_row(f):
    """Числовой факт из прозы (condense.facts) → строка таблицы показателей или None."""
    label = f['title']
    if ' — ' in label:
        left, right = label.split(' — ', 1)
        if len(left.split()) == 1 and len(right.split()) >= 2:
            label = cap(right)                         # «Программы — снизить …» → «Снизить …»
    if _VERB_FIRST.match(label):                       # «Снизить …», «Превышает затраты…» — не подпись показателя
        if re.match(r'^[А-ЯЁа-яё]+ть\b', label) and re.search(r'(?i)\bцел[ьи]\b', f.get('_sent') or ''):
            label = 'Цель: ' + _lower_first(label)
        else:
            return None
    if f.get('_count'):
        if not _GEN_PL.match(label):
            return None                                # «Секциями ЭЦН», «Случаях…» — не показатель
        if not re.match(r'(?i)(число|количество|кол-во|доля|сумма)\b', label):
            label = 'Число ' + _lower_first(label)
    elif not f.get('unit'):
        return None
    if not _good_label(label):
        return None
    return {'title': label, 'value': str(f['value']), 'unit': f.get('unit') or ''}


def _num_key(v):
    s = re.sub(r'(?i)^(до|от|более|менее|около)\s+', '', str(v)).replace(' ', '').replace(' ', '')
    return s.replace('−', '-').replace('—', '–').lower()


def _same_number(a, b):
    if _num_key(a['value']) != _num_key(b['value']):
        return False
    ua, ub = a['unit'].lower().split(), b['unit'].lower().split()
    if ua and ub and ua[0][:3] == ub[0][:3]:
        return True
    if not ua and not ub:
        return True
    return bool(set(_norm_words(a['title'])) & set(_norm_words(b['title'])))


def _key_numbers(doc):
    """Ключевые показатели: [{'title','value','unit','sources','mark'}] и таблицы, целиком вошедшие в них."""
    cands = []                        # (приоритет, порядок, строка)
    order = 0
    kpi_tables = {}

    def add(row, prio, mark, place):
        nonlocal order
        row = dict(row, sources=[place], mark=mark)
        cands.append((prio + (10 if mark else 0), -order, row))
        order += 1

    for sec in doc.walk():
        place = _place(sec)
        para_txt = [b for b in sec.blocks if b.kind == 'para' and not _PARAM_RX.match(clean(b.text))]
        for b in sec.blocks:
            if b.kind == 'list':
                for it in b.items:
                    k = _kpi_item(clean_item(it.text))
                    if not k:
                        continue
                    title, value = k['title'], k['value']
                    m = _LEAD_QUAL.search(title)            # «Износ …: более» + «40 %» → «Износ …» + «более 40 %»
                    if m:
                        title, value = title[:m.start()], f'{m.group(1).lower()} {value}'
                    title = title.rstrip(' :—–-')
                    if _good_label(title):
                        add({'title': title, 'value': value, 'unit': k['unit']}, 3, bool(it.mark), place)
            elif b.kind == 'table' and b.table_id in doc.tables:
                t = doc.tables[b.table_id]
                items = kpi_from_table(t)
                if items and (kpi_scale_diverse(t) or re.search(r'(?i)показател|kpi|результат|эффект',
                                                                 ' '.join([t.title, sec.title]))):
                    kpi_tables[t.id] = len(items)
                    for it in items:
                        add({'title': cap(clean(it['title'])), 'value': clean(str(it['value'])),
                             'unit': clean(it['unit'])}, 2, bool(b.mark), place)
        for b in para_txt:
            for f in facts(b.text, 8):
                r = _fact_row(f)
                if r:
                    mark = bool(b.mark) or bool(b.mark_text and str(f['value']).split('–')[0] in b.mark_text)
                    add(r, 1, mark, place)
    # объединение одинаковых чисел (одно и то же в Word и Excel); лучшая подпись — у списка/таблицы
    rows = []
    for prio, neg, r in sorted(cands, key=lambda x: (-x[0], -x[1])):
        dup = next((x for x in rows if _same_number(x, r)), None)
        if dup:
            for s in r['sources']:
                if s not in dup['sources']:
                    dup['sources'].append(s)
            dup['mark'] = dup['mark'] or r['mark']
            if dup['_q'] < (prio % 10):
                dup.update(title=r['title'], unit=r['unit'] or dup['unit'], _q=prio % 10)
            continue
        rows.append(dict(r, _q=prio % 10, _o=-neg))
    covered = set()
    rows = rows[:MAX_KEY_NUMBERS]
    for tid, n in kpi_tables.items():
        t = doc.tables[tid]
        vals = [_num_key(r[t.numeric_cols[0]]) for r in t.rows if t.numeric_cols]
        if vals and all(any(_num_key(x['value']) == v for x in rows) for v in vals):
            covered.add(tid)
    marked_nums = set()                              # число из выделенного автором фрагмента — тоже выделено
    for t in _marked_fragments(doc):
        marked_nums |= _numbers(t)
    for r in rows:
        v = _numbers(re.sub(r'[–—-].*$', '', _num_key(r['value'])).replace('.', ','))
        if v and v <= marked_nums:
            r['mark'] = True
    rows.sort(key=lambda x: (not x['mark'], x['_o']))
    for r in rows:
        r.pop('_q', None)
        r.pop('_o', None)
    return rows, covered


def _sources(doc):
    out = []
    sheets = {}
    for s in doc.walk():
        src = str(s.source or '')
        if ' / ' in src:
            f, sh = src.split(' / ', 1)
            sheets.setdefault(f, [])
            if sh not in sheets[f]:
                sheets[f].append(sh)
    kinds = {'.docx': 'документ Word', '.xlsx': 'книга Excel', '.xlsm': 'книга Excel', '.csv': 'таблица CSV',
             '.txt': 'текстовый файл', '.md': 'текстовый файл'}
    for f in doc.sources:
        k = kinds.get(Path(f).suffix.lower(), 'файл')
        sh = sheets.get(f)
        extra = f' (листы: {", ".join("«" + x + "»" for x in sh[:8])}{"…" if len(sh) > 8 else ""})' if sh else ''
        out.append(f'{f} — {k}{extra}')
    return out


def _today():
    return datetime.date.today().strftime('%d.%m.%Y')


def build_rules(doc, options):
    """Содержание справки по правилам (без модели) — словарь, который рисует _render()."""
    options = options or {}
    concl_secs = [s for s in doc.walk() if _is_concl(s)]
    concl_ids = {id(s) for s in concl_secs}
    body_secs = [s for s in doc.sections if id(s) not in concl_ids and not (_is_data_sheet(s) and not s.children
                 and all(b.kind == 'table' for b in s.blocks))]
    body = []
    for s in body_secs:
        sb = _section_body(doc, s)
        if sb['blocks'] or sb['children']:
            body.append(sb)
    summary = _summary_rules(doc, body_secs, concl_secs)
    concl, props = _conclusions_rules(doc, body_secs, concl_secs, summary)
    keys, covered = _key_numbers(doc)
    if not concl:                                    # нет ни выводов, ни итоговых фраз — выводы по данным
        for t in doc.tables.values():
            ch = choose_chart(t, t.title)
            ins = make_insights(ch) if ch else []
            if ins:
                _add_unique(concl, f'{t.title or "Данные"}: {_lower_first(ins[0])}', False, 3)
    topic = clean(options.get('title') or doc.title or 'Справка')
    return {
        'topic': topic,
        'about': clean(options.get('about') or '') or about_phrase(topic),
        'date': clean(options.get('date') or '') or _today(),
        'author': clean(options.get('author') or options.get('executor') or options.get('исполнитель') or ''),
        'phone': clean(options.get('phone') or ''),
        'summary': summary,
        'body': body,
        'key_numbers': keys,
        'covered': covered,
        'conclusions': concl,
        'proposals': props,
        'sources': _sources(doc),
        'mode': 'rules',
    }


# ======================================================================================
# 3. РЕЖИМ ИИ: модель пишет тексты, код проверяет числа
# ======================================================================================
_HEAD = """Ты — референт аппарата управления нефтегазовой компании. По выжимке документа готовишь
официальную СПРАВКУ для руководства.
Пиши по-русски официально-деловым стилем: безлично или в третьем лице, без разговорных оборотов
(«рассмотрим», «я предлагаю», «на слайде», «как видно из рисунка»), без Markdown и без нумерации пунктов.
Используй ТОЛЬКО факты из выжимки. Числа переписывай из документа точно, без пересчёта, округления и
смены единиц. Если числа нет в документе — не пиши его.
Фрагменты со знаком ★ автор выделил как главные: обязательно отрази их первыми в summary."""

SYSTEM_FULL = _HEAD + """

ФОРМАТ ОТВЕТА — только JSON-объект, без пояснений:
{"about": "о … — тема справки в предложном падеже, до 150 символов",
 "summary": ["3–6 главных тезисов, каждый — одно-два предложения"],
 "sections": [{"src": "S2", "heading": "заголовок раздела, до 80 символов",
               "paragraphs": ["1–3 абзаца связного делового текста"], "bullets": ["необязательные пункты"]}],
 "conclusions": ["2–5 выводов"],
 "proposals": ["0–4 предложения: что предлагается сделать (только если это следует из документа)"]}
Разделы sections — по смысловым разделам документа (обычно 3–8), src — метка раздела из выжимки (S1, S2…).
Раздел выводов в sections не включай — выводы пиши в conclusions. Таблицы данных, ключевые показатели и
список источников приложение добавит само — их не пиши."""

SYSTEM_FAST = _HEAD + """

ФОРМАТ ОТВЕТА — только JSON-объект, без пояснений:
{"about": "о … — тема справки в предложном падеже, до 150 символов",
 "summary": ["3–6 главных тезисов, каждый — одно-два предложения"],
 "conclusions": ["2–5 выводов"],
 "proposals": ["0–4 предложения: что предлагается сделать (только если это следует из документа)"]}
Тексты разделов, таблицы и показатели приложение возьмёт из документа само — их не пиши."""

MAX_TOKENS = {'fast': 1500, 'full': 4096}


def _strs(v, limit=12, max_len=1500):
    """Поле ответа модели → список чистых строк (терпимо к строке вместо списка и к объектам)."""
    if isinstance(v, str):
        v = [x for x in re.split(r'\n+', v) if x.strip()]
    if not isinstance(v, list):
        return []
    out = []
    for x in v:
        if isinstance(x, dict):
            x = x.get('text') or x.get('title') or ''
        if not isinstance(x, str):
            continue
        x = re.sub(r'\*\*|__|`', '', x)
        x = re.sub(r'^\s*(?:[-•*·–—]|\d{1,2}[.)])\s+', '', x)
        x = clean(x)[:max_len]
        if x:
            out.append(x)
    return out[:limit]


class _NumCheck:
    """Удаляет из текста модели предложения с числами, которых нет в документе."""

    def __init__(self, known, warnings):
        self.known, self.warnings, self.removed = known, warnings, 0

    def __call__(self, text):
        keep = []
        for s in sentences(text) or [text]:
            bad = sorted(n for n in _numbers(s) if n not in self.known)
            if bad:
                self.removed += 1
                if self.removed <= 5:
                    shown = ', '.join(('%g' % n).replace('.', ',') for n in bad[:3])
                    self.warnings.append(f'ИИ: число {shown} не найдено в документе — предложение «{shorten(s, 90)}» '
                                         'убрано из справки.')
                continue
            keep.append(s)
        return ' '.join(keep).strip()


def _merge_ai(raw, doc, rep, level):
    """Ответ модели → новая справка (rep не меняется). Неверный ответ → LLMError."""
    if not isinstance(raw, dict):
        raise LLMError('модель вернула не JSON-объект')
    warnings = []
    chk = _NumCheck(_doc_numbers(doc), warnings)
    summary_raw = _strs(raw.get('summary') or raw.get('резюме') or raw.get('краткое_содержание'), 8)
    concl_raw = _strs(raw.get('conclusions') or raw.get('выводы'), 8)
    props_raw = _strs(raw.get('proposals') or raw.get('предложения'), 5)
    if not summary_raw and not concl_raw:
        raise LLMError('в ответе модели нет полей справки (summary, conclusions)')
    summary = [x for x in (chk(t) for t in summary_raw) if x]
    concl = [x for x in (chk(t) for t in concl_raw) if x]
    props = [x for x in (chk(t) for t in props_raw) if x]
    if not summary:
        raise LLMError('в ответе модели нет краткого содержания (или все тезисы содержали непроверенные числа)')
    new = copy.copy(rep)
    new['mode'] = 'ai'
    marks = _marked_fragments(doc)

    def items(lst):
        out = []
        for t in lst:
            _add_unique(out, t, any(_similar(m, t) for m in marks))
        return out
    new['summary'] = items(summary)[:MAX_SUMMARY + 2]
    if concl:
        new['conclusions'] = items(concl)
    new['proposals'] = items(props) if props else ([] if concl else rep['proposals'])
    about = clean(str(raw.get('about') or ''))
    if about and len(about) <= 200 and re.match(r'(?i)^(о|об|обо|по)\s', about) and chk(about) == about:
        new['about'] = _lower_first(about.rstrip('.'))
    # разделы (уровень «полностью»)
    if level == 'full' and isinstance(raw.get('sections'), list):
        all_secs = list(doc.walk())
        body = []
        for s in raw['sections'][:14]:
            if not isinstance(s, dict):
                continue
            head = clean(re.sub(r'^\s*\d+(?:\.\d+)*[.)]?\s+', '', str(s.get('heading') or s.get('title') or '')))[:120]
            if head and chk(head) != head:
                head = ''
            m = re.fullmatch(r'\s*[Ss]\s*(\d+)\s*', str(s.get('src') or ''))
            sec = all_secs[int(m.group(1)) - 1] if m and 1 <= int(m.group(1)) <= len(all_secs) else None
            if (head and RX['concl'].search(head)) or (sec is not None and _is_concl(sec)):
                continue
            blocks = []
            for p in _strs(s.get('paragraphs') or s.get('text'), 6):
                p = chk(p)
                if p:
                    blocks.append({'kind': 'para', 'text': _end(p), 'mark': any(_similar(mk, p) for mk in marks),
                                   'bold_part': ''})
            bl = [chk(x) for x in _strs(s.get('bullets') or s.get('items'), 12)]
            bl = [x for x in bl if x]
            if bl:
                blocks.append({'kind': 'list', 'ordered': False, 'items': [
                    {'text': x, 'bold': '', 'mark': any(_similar(mk, x) for mk in marks), 'level': 0} for x in bl]})
            if sec is not None:                        # таблицы и рисунки раздела — из документа
                for b in sec.blocks:
                    if b.kind == 'table' and b.table_id in doc.tables:
                        blocks.append({'kind': 'table', 'tid': b.table_id})
                    elif b.kind == 'image' and b.image_id in doc.images:
                        blocks.append({'kind': 'image', 'fid': b.image_id, 'caption': clean(b.text)})
            if blocks and any(b['kind'] in ('para', 'list') for b in blocks):
                body.append({'title': head or (sec.title if sec is not None else 'Раздел'), 'blocks': blocks,
                             'children': [], 'sec': sec})
        if body:
            new['body'] = body
        else:
            warnings.append('ИИ: тексты разделов не получены — разделы составлены по документу.')
    # выделенное автором должно быть в справке, и в начале
    text_all = ' '.join([x['text'] for x in new['summary']] +
                        [b.get('text', '') for sec in new['body'] for b in sec['blocks']] +
                        [i['text'] for sec in new['body'] for b in sec['blocks'] for i in b.get('items', [])])
    missing = [m for m in marks if not _similar(m, text_all) and not any(_similar(m, x['text']) for x in new['summary'])]
    if missing:
        new['summary'] = [{'text': m, 'mark': True} for m in missing] + new['summary']
        warnings.append(f'ИИ: модель не отразила {len(missing)} выделенных автором фрагмента(ов) — они добавлены '
                        'в краткое содержание.')
    new['summary'].sort(key=lambda x: not x['mark'])
    new['summary'] = new['summary'][:MAX_SUMMARY + len(missing)]
    return new, warnings


def build_ai(doc, rep, options, llm, progress=None):
    """Тексты справки от модели ИИ → (новая справка, предупреждения, уровень). Ошибка → исключение."""
    notify = progress or (lambda e: None)
    level = 'full' if str(options.get('ai_level') or '').lower() == 'full' else 'fast'
    max_chars = int((llm or {}).get('max_chars') or 14000)
    if level == 'full':
        dg, system = digest(doc, max_chars), SYSTEM_FULL
    else:
        dg, system = digest_fast(doc, max(3000, max_chars // 2)), SYSTEM_FAST
    extra = []
    if options.get('focus'):
        extra.append(f'Акценты, которые просил автор: {options["focus"]}.')
    if options.get('title'):
        extra.append(f'Тема справки: {options["title"]}.')
    if options.get('pages'):
        n = int(options['pages'])
        extra.append(f'Объём справки — не больше {n} {_plural(n, "листа", "листов", "листов")} А4: пиши кратко, '
                     'только самое важное.')
    user = ('Подготовь справку по документу. ' + ' '.join(extra) +
            '\nОтветь только JSON-объектом по формату из инструкции.\n\nВЫЖИМКА ДОКУМЕНТА:\n' + dg)
    notify({'phase': 'prompt', 'kind': 'report', 'level': level, 'chars': len(system) + len(user),
            'tokens_est': estimate_tokens(system) + estimate_tokens(user)})

    def prog(e):
        if e.get('phase') == 'gen':
            txt = e.get('text') or ''
            e = dict(e, kind='report', sections=txt.count('"heading"'))
            e.pop('text', None)
        notify(e)

    text = chat(llm, system, user, progress=prog, max_tokens=MAX_TOKENS[level])
    try:
        raw = extract_json(text)
    except LLMError:
        notify({'phase': 'retry', 'kind': 'report'})
        text = chat(llm, system, user + '\n\nПредыдущий ответ был не JSON. Верни ТОЛЬКО корректный JSON-объект.',
                    progress=prog, max_tokens=MAX_TOKENS[level])
        raw = extract_json(text)
    new, warnings = _merge_ai(raw, doc, rep, level)
    return new, warnings, level


# ======================================================================================
# 4. ОФОРМЛЕНИЕ .docx
# ======================================================================================
_LOGO = None


def logo_png(max_w=1400):
    """Логотип Компании из корпоративного шаблона презентаций (PNG с прозрачным фоном) или None.
    Это картинка ppt/media/image2.png шаблона («шар + Зарубежнефть», пропорции ≈ 6,5 : 1);
    на случай другой версии шаблона ищется любая прозрачная PNG с такими пропорциями."""
    global _LOGO
    if _LOGO is not None:
        return _LOGO or None
    data = b''
    try:
        from PIL import Image
        with zipfile.ZipFile(TEMPLATE) as z:
            names = [n for n in z.namelist() if n.startswith('ppt/media/') and n.lower().endswith('.png')]
            names.sort(key=lambda n: n != 'ppt/media/image2.png')
            for n in names:
                if z.getinfo(n).file_size > 800_000:
                    continue
                im = Image.open(io.BytesIO(z.read(n)))
                w, h = im.size
                if im.mode in ('RGBA', 'LA', 'P') and h and 5.0 <= w / h <= 7.5:
                    im = im.convert('RGBA')
                    im.thumbnail((max_w, max_w))
                    buf = io.BytesIO()
                    im.save(buf, 'PNG', optimize=True)
                    data = buf.getvalue()
                    break
    except Exception:                                  # нет шаблона или Pillow — будет текстовая шапка
        data = b''
    _LOGO = data
    return data or None


# ---------- низкоуровневые помощники XML -------------------------------------------------
_PPR_ORDER = ['pStyle', 'keepNext', 'keepLines', 'pageBreakBefore', 'framePr', 'widowControl', 'numPr',
              'suppressLineNumbers', 'pBdr', 'shd', 'tabs', 'suppressAutoHyphens', 'kinsoku', 'wordWrap',
              'overflowPunct', 'topLinePunct', 'autoSpaceDE', 'autoSpaceDN', 'bidi', 'adjustRightInd', 'snapToGrid',
              'spacing', 'ind', 'contextualSpacing', 'mirrorIndents', 'suppressOverlap', 'jc', 'textDirection',
              'textAlignment', 'textboxTightWrap', 'outlineLvl', 'divId', 'cnfStyle', 'rPr', 'sectPr', 'pPrChange']
_RPR_ORDER = ['rStyle', 'rFonts', 'b', 'bCs', 'i', 'iCs', 'caps', 'smallCaps', 'strike', 'dstrike', 'outline',
              'shadow', 'emboss', 'imprint', 'noProof', 'snapToGrid', 'vanish', 'webHidden', 'color', 'spacing', 'w',
              'kern', 'position', 'sz', 'szCs', 'highlight', 'u', 'effect', 'bdr', 'shd', 'fitText', 'vertAlign', 'rtl',
              'cs', 'em', 'lang', 'eastAsianLayout', 'specVanish', 'oMath']
_TCPR_ORDER = ['cnfStyle', 'tcW', 'gridSpan', 'hMerge', 'vMerge', 'tcBorders', 'shd', 'noWrap', 'tcMar',
               'textDirection', 'tcFitText', 'vAlign', 'hideMark']
_TBLPR_ORDER = ['tblStyle', 'tblpPr', 'tblOverlap', 'bidiVisual', 'tblStyleRowBandSize', 'tblStyleColBandSize',
                'tblW', 'jc', 'tblCellSpacing', 'tblInd', 'tblBorders', 'shd', 'tblLayout', 'tblCellMar', 'tblLook',
                'tblCaption', 'tblDescription']


def _put(parent, child, order):
    """Вставляет child в parent на место по схеме OOXML (Word строг к порядку элементов)."""
    tag = child.tag.split('}')[1]
    for old in parent.findall(qn('w:' + tag)):
        parent.remove(old)
    idx = order.index(tag)
    for later in order[idx + 1:]:
        el = parent.find(qn('w:' + later))
        if el is not None:
            el.addprevious(child)
            return child
    parent.append(child)
    return child


def _el(tag, **attrs):
    e = OxmlElement(tag)
    for k, v in attrs.items():
        e.set(qn('w:' + k), str(v))
    return e


def _fonts(rpr, name=FONT):
    """Явный шрифт для всех письменностей (без ссылок на шрифты темы — они важнее явных)."""
    _put(rpr, _el('w:rFonts', ascii=name, hAnsi=name, cs=name, eastAsia=name), _RPR_ORDER)


def _borders(tag, **sides):
    """<w:pBdr>/<w:tblBorders>/<w:tcBorders>: sides — {'left': (sz, color, space)}."""
    b = OxmlElement(tag)
    for side in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        if side in sides:
            v = sides[side]
            if v is None:
                b.append(_el('w:' + side, val='nil'))
            else:
                sz, color, space = v
                b.append(_el('w:' + side, val='single', sz=sz, space=space, color=color))
    return b


def _shd(fill):
    return _el('w:shd', val='clear', color='auto', fill=fill)


def _cm_tw(cm):
    return int(round(cm / 2.54 * 1440))


# Стили абзацев справки (по ним же оценивается объём — раздел 5): кегль, начертание, цвет, выравнивание,
# интервалы до/после (пт), межстрочный множитель, отступ первой строки (см), «не отрывать от следующего»
_J, _C, _L = WD_ALIGN_PARAGRAPH.JUSTIFY, WD_ALIGN_PARAGRAPH.CENTER, WD_ALIGN_PARAGRAPH.LEFT
_PSTYLE_DEF = dict(size=12, bold=False, italic=False, color=TEXT, align=None, before=0, after=6, line=1.15,
                   indent=None, keep=False)
_PSTYLES = {
    'ZN Текст': dict(align=_J, indent=1.25, after=6),
    'ZN Список': dict(align=_L, after=3),
    'ZN Выделено': dict(align=_J, after=8, bold=True, color=NAVY),
    'ZN Таблица': dict(size=10, line=1.0, after=0, align=_L),
    'ZN Подпись таблицы': dict(size=11, bold=True, color=NAVY, before=10, after=4, keep=True, align=_L),
    'ZN Подпись рисунка': dict(size=10, italic=True, color=GRAY, before=2, after=10, align=_C),
    'ZN Источник': dict(size=9, italic=True, color=GRAY, before=3, after=8, align=_L),
    'ZN Вывод по данным': dict(size=10, color=TEXT, after=2, align=_L),
    'ZN Справка': dict(size=18, bold=True, color=NAVY, before=6, after=4, align=_C, line=1.0),
    'ZN Тема': dict(size=13, bold=True, color=NAVY, after=4, align=_C, line=1.1),
    'ZN Дата': dict(size=11, color=GRAY, after=14, align=_C, line=1.0),
    'ZN Колонтитул': dict(size=9, color=GRAY, after=0, line=1.0, align=_L),
}
# заголовки: кегль, цвет, интервал до и после (пт); жирные, интервал 1,1; у первого уровня — линия снизу
_HSTYLES = {'Heading 1': (13, NAVY, 16, 6), 'Heading 2': (12, BLUE, 12, 4), 'Heading 3': (12, DGREEN, 10, 3)}


def _image_cm(path, width_emu=0):
    """Размер рисунка в справке (ширина, высота в см): как в исходном Word, 6–15 см по ширине, не выше
    12 см. None — не картинка или файл не читается."""
    p = Path(path)
    if not p.exists() or p.suffix.lower() not in ('.png', '.jpg', '.jpeg', '.gif', '.bmp'):
        return None
    try:
        from PIL import Image
        with Image.open(p) as im:
            w, h = im.size
    except Exception:                                   # повреждённая картинка не роняет справку
        return None
    if not w:
        return None
    width = min(15.0, max(6.0, (width_emu / 360000) if width_emu else (w / 96 * 2.54)))
    if h and width * h / w > 12.0:
        width = max(4.0, 12.0 * w / h)
    return width, width * h / w


def _figure_caption(n, caption):
    cap_ = re.sub(r'(?i)^рис(унок|\.)?\s*\d*\s*[.:—–-]?\s*', '', caption or '').strip()
    return f'Рисунок {n}' + (f' — {cap_}' if cap_ else '')


# ---------- документ ---------------------------------------------------------------------
class _Writer:
    def __init__(self, author=''):
        self.d = WordDocument()
        self.n_table = 0
        self.n_image = 0
        self.whole_table = WHOLE_TABLE
        self._setup_page()
        self._setup_styles()
        self._setup_numbering()
        cp = self.d.core_properties
        cp.author = author or 'АО «Зарубежнефть»'
        cp.last_modified_by = cp.author
        cp.language = 'ru-RU'
        cp.comments = ''

    # --- страница и стили ---
    def _setup_page(self):
        sec = self.d.sections[0]
        sec.page_width, sec.page_height = Cm(PAGE_W), Cm(PAGE_H)
        sec.top_margin, sec.bottom_margin = Cm(MARGINS['top']), Cm(MARGINS['bottom'])
        sec.left_margin, sec.right_margin = Cm(MARGINS['left']), Cm(MARGINS['right'])
        sec.header_distance = sec.footer_distance = Cm(1.0)
        sec.different_first_page_header_footer = True
        st = self.d.settings.element
        zoom = st.find(qn('w:zoom'))
        if zoom is not None and zoom.get(qn('w:percent')) is None:
            zoom.set(qn('w:percent'), '100')              # обязательный атрибут (в шаблоне python-docx его нет)
        hyph = _el('w:autoHyphenation')
        anchor = st.find(qn('w:defaultTabStop'))
        if anchor is not None:
            anchor.addnext(hyph)
        else:
            st.insert(0, hyph)
        hyph.addnext(_el('w:hyphenationZone', val=357))   # перенос слов — для текста по ширине
        hyph.getnext().addnext(_el('w:doNotHyphenateCaps'))

    def _setup_styles(self):
        styles = self.d.styles
        dd = styles.element.find(qn('w:docDefaults'))
        rpr = dd.find(qn('w:rPrDefault')).find(qn('w:rPr'))
        _fonts(rpr)
        _put(rpr, _el('w:lang', val='ru-RU', eastAsia='ru-RU', bidi='ar-SA'), _RPR_ORDER)
        normal = styles['Normal']
        normal.font.name = FONT
        normal.font.size = Pt(12)
        normal.font.color.rgb = RGBColor.from_string(TEXT)
        _fonts(normal.element.get_or_add_rPr())
        pf = normal.paragraph_format
        pf.space_before, pf.space_after, pf.line_spacing = Pt(0), Pt(0), 1.15
        pf.widow_control = True

        def pstyle(name, size=12, bold=False, italic=False, color=TEXT, align=None, before=0, after=6,
                   line=1.15, indent=None, keep=False, base='Normal'):
            try:
                s = styles[name]
            except KeyError:
                s = styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
            s.base_style = styles[base]
            s.font.size = Pt(size)
            s.font.bold, s.font.italic = bold, italic
            s.font.color.rgb = RGBColor.from_string(color)
            _fonts(s.element.get_or_add_rPr())
            f = s.paragraph_format
            f.space_before, f.space_after, f.line_spacing = Pt(before), Pt(after), line
            if align is not None:
                f.alignment = align
            if indent is not None:
                f.first_line_indent = Cm(indent)
            f.keep_with_next = keep
            s.quick_style = True
            return s

        for name, kw in _PSTYLES.items():
            pstyle(name, **kw)
        for name, (size, color, before, after) in _HSTYLES.items():
            s = styles[name]
            s.font.size = Pt(size)
            s.font.bold = True
            s.font.italic = False
            s.font.color.rgb = RGBColor.from_string(color)
            _fonts(s.element.get_or_add_rPr())
            f = s.paragraph_format
            f.space_before, f.space_after, f.line_spacing = Pt(before), Pt(after), 1.1
            f.keep_with_next = True
            f.alignment = WD_ALIGN_PARAGRAPH.LEFT
        h1 = styles['Heading 1'].element.get_or_add_pPr()
        _put(h1, _borders('w:pBdr', bottom=(6, BLUE, 2)), _PPR_ORDER)
        for name in ('Header', 'Footer'):                # убрать табуляции шаблона (они — под формат Letter)
            ppr = styles[name].element.get_or_add_pPr()
            for t in ppr.findall(qn('w:tabs')):
                ppr.remove(t)

    def _setup_numbering(self):
        """Свои списки: маркер — зелёная точка, нумерация — «1.» тёмно-синим жирным."""
        numbering = self.d.part.numbering_part.element
        first_num = numbering.find(qn('w:num'))

        def abstract(aid, fmt, texts, color, bold):
            a = _el('w:abstractNum', abstractNumId=aid)
            a.append(_el('w:multiLevelType', val='hybridMultilevel'))
            for lvl, text in enumerate(texts):
                left = 567 + lvl * 454
                L = _el('w:lvl', ilvl=lvl)
                L.append(_el('w:start', val=1))
                L.append(_el('w:numFmt', val=fmt if lvl == 0 or fmt == 'bullet' else 'bullet'))
                L.append(_el('w:lvlText', val=text))
                L.append(_el('w:lvlJc', val='left'))
                ppr = OxmlElement('w:pPr')
                tabs = OxmlElement('w:tabs')
                tabs.append(_el('w:tab', val='num', pos=left))
                ppr.append(tabs)
                ppr.append(_el('w:ind', left=left, hanging=340 if fmt == 'decimal' and lvl == 0 else 284))
                L.append(ppr)
                rpr = OxmlElement('w:rPr')
                rpr.append(_el('w:rFonts', ascii=FONT, hAnsi=FONT, cs=FONT, eastAsia=FONT))
                if bold:
                    rpr.append(_el('w:b'))
                rpr.append(_el('w:color', val=color if lvl == 0 else GRAY))
                L.append(rpr)
                a.append(L)
            if first_num is not None:
                first_num.addprevious(a)
            else:
                numbering.append(a)

        abstract(9101, 'bullet', ['•', '–'], GREEN, False)
        abstract(9102, 'decimal', ['%1.', '–'], NAVY, True)
        self._num_id = 9100
        self.bullet_num = self._new_num(9101)

    def _new_num(self, abstract_id, restart=False):
        numbering = self.d.part.numbering_part.element
        self._num_id += 1
        n = _el('w:num', numId=self._num_id)
        n.append(_el('w:abstractNumId', val=abstract_id))
        if restart:
            o = _el('w:lvlOverride', ilvl=0)
            o.append(_el('w:startOverride', val=1))
            n.append(o)
        numbering.append(n)
        return self._num_id

    # --- текст ---
    def _runs(self, p, text, bold_part='', bold=False, color=None, size=None, italic=False):
        text = typo(text or '')
        parts = [(text, bold)]
        bp = typo(bold_part or '')
        if bp and bp in text and not bold:
            a, b = text.split(bp, 1)
            parts = [(a, False), (bp, True), (b, False)]
        for t, bb in parts:
            if not t:
                continue
            r = p.add_run(t)
            if bb:
                r.bold = True
            if italic:
                r.italic = True
            if color:
                r.font.color.rgb = RGBColor.from_string(color)
            if size:
                r.font.size = Pt(size)
        return p

    def para(self, text, style='ZN Текст', bold_part='', bold=False, color=None, keep=False):
        p = self.d.add_paragraph(style=style)
        self._runs(p, text, bold_part, bold, color)
        if keep:
            p.paragraph_format.keep_with_next = True
        return p

    def callout(self, text, bold_part=''):
        """Выделенный автором абзац: светло-зелёная плашка с фирменной полосой слева."""
        p = self.d.add_paragraph(style='ZN Текст')
        ppr = p._p.get_or_add_pPr()
        _put(ppr, _borders('w:pBdr', left=(24, GREEN, 6)), _PPR_ORDER)
        _put(ppr, _shd(PALEG), _PPR_ORDER)
        f = p.paragraph_format
        f.left_indent, f.right_indent, f.first_line_indent = Cm(0.35), Cm(0.1), Cm(0)
        f.space_before = Pt(4)
        f.space_after = Pt(8)
        self._runs(p, text, bold_part, bold=not bold_part)
        return p

    def heading(self, text, level):
        p = self.d.add_paragraph(style=f'Heading {level}')
        self._runs(p, text)
        return p

    def list(self, items, ordered=False, style='ZN Список', container=None):
        """items: [{'text', 'bold', 'mark', 'level'}]. container — ячейка таблицы (или документ)."""
        host = container or self.d
        num = self._new_num(9102, restart=True) if ordered else self.bullet_num
        out = []
        for it in items:
            p = host.add_paragraph(style=style)
            ppr = p._p.get_or_add_pPr()
            numpr = ppr.get_or_add_numPr()
            numpr.get_or_add_ilvl().val = int(it.get('level') or 0)
            numpr.get_or_add_numId().val = num
            text = it['text'] if it.get('raw') or it['text'].endswith((';', ',')) else _end(it['text'])
            if it.get('mark'):
                self._runs(p, text, bold=True, color=NAVY)
            else:
                self._runs(p, text, bold_part=it.get('bold') or '')
            out.append(p)
        return out

    # --- таблицы ---
    @staticmethod
    def _widths(columns, rows, numeric, size=10):
        """Ширины столбцов (см) по содержимому и ширина таблицы: маленькая таблица не растягивается
        на всю страницу (ставится по центру), большая — на всю ширину текста."""
        n = len(columns)
        k = 0.021 * size                                 # средняя ширина символа Arial, см
        lens, mins, nat = [], [], []
        for j in range(n):
            vals = [str(columns[j])] + [str(r[j]) if j < len(r) else '' for r in rows]
            lines = [x for v in vals for x in v.split('\n')]
            mx = max(len(v) for v in lines)
            avg = sum(len(v) for v in lines) / len(lines)
            L = min(60.0, max(4.0, 0.55 * mx + 0.45 * avg))
            if j in numeric:
                L = min(L, 14.0)
            lens.append(L)
            longest = max([len(w) for v in lines for w in v.split()] + [3])
            mins.append(min(4.2, k * longest + 0.45))      # длинное слово не должно рваться
            nat.append(max(mins[-1], min(7.0, k * mx + 0.5)))
        total = TEXT_W
        if sum(nat) * 1.5 < TEXT_W:
            total = max(0.6 * TEXT_W, sum(nat) * 1.5)
        w = [total * L / sum(lens) for L in lens]
        for _ in range(4):
            short = [j for j in range(n) if w[j] < mins[j]]
            if not short:
                break
            fixed = sum(mins[j] for j in short)
            rest = [j for j in range(n) if j not in short]
            rl = sum(lens[j] for j in rest) or 1
            for j in short:
                w[j] = mins[j]
            for j in rest:
                w[j] = max(0.8, (total - fixed) * lens[j] / rl)
        f = total / sum(w)
        return [x * f for x in w]

    def table(self, columns, rows, numeric=(), caption='', source='', widths=None, bold_cols=(), mark_rows=(),
              total_row=None, center_cols=(), small_cols=(), size=10, keep_after=False):
        """Таблица в фирменном стиле: шапка тёмно-синяя с белым текстом (повторяется на каждой странице),
        «зебра», числа — вправо. Возвращает (таблица, отступ слева в см — для подписи и выводов)."""
        ncol = len(columns)
        if not ncol:
            return None, 0
        self.n_table += 1
        widths = widths or self._widths(columns, rows, set(numeric), size)
        tw = sum(widths)
        indent = max(0.0, (TEXT_W - tw) / 2)
        if caption:
            p = self.d.add_paragraph(style='ZN Подпись таблицы')
            p.paragraph_format.left_indent = Cm(indent)
            self._runs(p, f'Таблица {self.n_table} — {caption}')
        t = self.d.add_table(rows=1 + len(rows), cols=ncol)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.autofit = False
        tblPr = t._tbl.tblPr
        _put(tblPr, _el('w:tblW', w=_cm_tw(tw), type='dxa'), _TBLPR_ORDER)
        _put(tblPr, _borders('w:tblBorders', top=(6, NAVY, 0), bottom=(6, NAVY, 0), left=(4, LGRAY, 0),
                             right=(4, LGRAY, 0), insideH=(4, LGRAY, 0), insideV=(4, LGRAY, 0)), _TBLPR_ORDER)
        _put(tblPr, _el('w:tblLayout', type='fixed'), _TBLPR_ORDER)
        mar = OxmlElement('w:tblCellMar')
        for side, v in (('top', 40), ('left', 85), ('bottom', 40), ('right', 85)):
            mar.append(_el('w:' + side, w=v, type='dxa'))
        _put(tblPr, mar, _TBLPR_ORDER)
        grid = t._tbl.tblGrid
        for j, gc in enumerate(grid.findall(qn('w:gridCol'))):
            gc.set(qn('w:w'), str(_cm_tw(widths[j])))
        for i, row in enumerate(t.rows):
            trpr = row._tr.get_or_add_trPr()
            trpr.append(_el('w:cantSplit'))
            if i == 0:
                trpr.append(_el('w:tblHeader'))          # шапка повторяется на каждой странице
            vals = columns if i == 0 else rows[i - 1]
            for j, cell in enumerate(row.cells):
                cell.width = Cm(widths[j])
                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                tcpr = cell._tc.get_or_add_tcPr()
                if i == 0:
                    _put(tcpr, _shd(NAVY), _TCPR_ORDER)
                elif (i - 1) in mark_rows:
                    _put(tcpr, _shd(PALEG), _TCPR_ORDER)
                elif i % 2 == 0:
                    _put(tcpr, _shd(ZEBRA), _TCPR_ORDER)
                v = vals[j] if j < len(vals) else ''
                lines = str(v if v is not None else '').split('\n')
                p = cell.paragraphs[0]
                p.style = self.d.styles['ZN Таблица']
                for li, line in enumerate(lines):
                    if li:
                        p = cell.add_paragraph(style='ZN Таблица')
                    if i == 0:
                        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                        self._runs(p, line, bold=True, color='FFFFFF', size=size)
                        continue
                    if j in numeric:
                        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
                    elif j in center_cols:
                        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    if j in small_cols:
                        self._runs(p, line, color=GRAY, size=size - 1)
                        continue
                    bold = j in bold_cols or (total_row is not None and i - 1 == total_row)
                    self._runs(p, line, bold=bold, color=NAVY if j in bold_cols else None, size=size)
        # небольшая таблица не разрывается между страницами и не отрывается от строки «Источник»
        keep_rows = t.rows if len(rows) <= self.whole_table else t.rows[-1:]
        for row in keep_rows:
            for cell in row.cells:
                for cp in cell.paragraphs:
                    cp.paragraph_format.keep_with_next = True
        if source:
            sp = self.para(source, style='ZN Источник', keep=keep_after)
            sp.paragraph_format.left_indent = Cm(indent)
        else:
            sp = self.d.add_paragraph(style='ZN Таблица')
            sp.paragraph_format.space_after = Pt(6)
        return t, indent

    def box(self, items):
        """Плашка «Краткое содержание»: светлый фон и фирменная зелёная полоса слева."""
        t = self.d.add_table(rows=1, cols=1)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        tblPr = t._tbl.tblPr
        _put(tblPr, _el('w:tblW', w=_cm_tw(TEXT_W), type='dxa'), _TBLPR_ORDER)
        _put(tblPr, _borders('w:tblBorders', top=None, left=None, bottom=None, right=None, insideH=None,
                             insideV=None), _TBLPR_ORDER)
        mar = OxmlElement('w:tblCellMar')
        for side, v in (('top', 110), ('left', 170), ('bottom', 90), ('right', 170)):
            mar.append(_el('w:' + side, w=v, type='dxa'))
        _put(tblPr, mar, _TBLPR_ORDER)
        t._tbl.tblGrid.findall(qn('w:gridCol'))[0].set(qn('w:w'), str(_cm_tw(TEXT_W)))
        cell = t.rows[0].cells[0]
        cell.width = Cm(TEXT_W)
        tcpr = cell._tc.get_or_add_tcPr()
        _put(tcpr, _borders('w:tcBorders', left=(36, GREEN, 0), top=None, bottom=None, right=None), _TCPR_ORDER)
        _put(tcpr, _shd(BOX), _TCPR_ORDER)
        first = cell.paragraphs[0]
        ps = self.list(items, container=cell)
        first._p.getparent().remove(first._p)
        if ps:
            ps[-1].paragraph_format.space_after = Pt(0)
        sp = self.d.add_paragraph(style='ZN Таблица')
        sp.paragraph_format.space_after = Pt(4)
        return t

    def image(self, path, caption='', width_emu=0):
        """Рисунок из документа: размер — как в исходном Word (6–15 см по ширине, не выше 12 см)."""
        size = _image_cm(path, width_emu)
        if not size:
            return False
        try:
            para = self.d.add_paragraph(style='ZN Таблица')
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            para.paragraph_format.keep_with_next = True
            para.paragraph_format.space_before = Pt(6)
            para.add_run().add_picture(str(path), width=Cm(size[0]))
        except Exception:                               # повреждённая картинка не роняет справку
            return False
        self.n_image += 1
        self.para(_figure_caption(self.n_image, caption), style='ZN Подпись рисунка')
        return True

    # --- колонтитулы ---
    def _field(self, p, instr, size=9, color=GRAY):
        def run():
            r = p.add_run()
            r.font.size = Pt(size)
            r.font.color.rgb = RGBColor.from_string(color)
            return r
        run()._r.append(_el('w:fldChar', fldCharType='begin'))
        it = OxmlElement('w:instrText')
        it.set(qn('xml:space'), 'preserve')
        it.text = f' {instr} '
        run()._r.append(it)
        run()._r.append(_el('w:fldChar', fldCharType='separate'))
        r = run()
        r.text = '1'
        run()._r.append(_el('w:fldChar', fldCharType='end'))

    def header_footer(self, about, author, phone):
        sec = self.d.sections[0]
        # первая страница: логотип и зелёная линия
        hp = sec.first_page_header.paragraphs[0]
        hp.style = self.d.styles['ZN Колонтитул']
        logo = logo_png()
        if logo:
            hp.add_run().add_picture(io.BytesIO(logo), width=Cm(5.6))
        else:
            self._runs(hp, 'АО «Зарубежнефть»', bold=True, color=NAVY, size=14)
        ppr = hp._p.get_or_add_pPr()
        _put(ppr, _borders('w:pBdr', bottom=(12, GREEN, 6)), _PPR_ORDER)
        # следующие страницы: короткая шапка справа
        h2 = sec.header.paragraphs[0]
        h2.style = self.d.styles['ZN Колонтитул']
        h2.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        self._runs(h2, shorten(f'АО «Зарубежнефть» · Справка {about}', 92))
        _put(h2._p.get_or_add_pPr(), _borders('w:pBdr', bottom=(4, LGRAY, 4)), _PPR_ORDER)
        # подвал: исполнитель слева, номер страницы справа
        who = 'Исполнитель: ' + author + (f', тел. {phone}' if phone else '') if author else ''
        for ft in (sec.first_page_footer, sec.footer):
            p = ft.paragraphs[0]
            p.style = self.d.styles['ZN Колонтитул']
            p.paragraph_format.tab_stops.add_tab_stop(Cm(TEXT_W), WD_TAB_ALIGNMENT.RIGHT)
            _put(p._p.get_or_add_pPr(), _borders('w:pBdr', top=(4, LGRAY, 4)), _PPR_ORDER)
            self._runs(p, who)
            self._runs(p, '\tСтр. ')
            self._field(p, 'PAGE')
            self._runs(p, ' из ')
            self._field(p, 'NUMPAGES')

    def save(self, path):
        self.d.save(str(path))


def _table_caption(doc, t, sec):
    return clean(t.title) or (clean(sec.title) if sec is not None else '') or f'Таблица {t.id}'


def _insights(t, cache=None):
    """Выводы по данным таблицы (до трёх); cache — словарь на время повторных оценок объёма справки."""
    if cache is not None and t.id in cache:
        return cache[t.id]
    ch = choose_chart(t, t.title)
    ins = make_insights(ch)[:3] if ch else []
    if cache is not None:
        cache[t.id] = ins
    return ins


def _plural(n, one, few, many):
    """Слово при числе: 1 лист, 2 листа, 5 листов."""
    n = abs(int(n)) % 100
    if 10 < n < 20:
        return many
    return one if n % 10 == 1 else (few if 2 <= n % 10 <= 4 else many)


def _doc_table(w, doc, t, sec, insights=True, max_rows=None):
    """Таблица документа в справку: шапка с единицами, «итого» жирным, выводы по данным.
    max_rows — короткая справка: первые строки, строка «…» и «итого» (если она ниже), с пометкой."""
    cols = [clean(str(c)) for c in t.columns][:MAX_TABLE_COLS]
    for j in range(len(cols)):
        u = t.units[j] if j < len(t.units) else ''
        if u and u not in cols[j]:
            cols[j] = f'{cols[j]}, {u}' if cols[j] else u

    def row(r):
        return [clean(str(c)) for c in r[:len(cols)]] + [''] * (len(cols) - len(r))
    limit = min(MAX_TABLE_ROWS, max_rows or MAX_TABLE_ROWS)
    rows = [row(r) for r in t.rows[:limit]]
    total = t.total_row if t.total_row is not None and t.total_row < len(rows) else None
    if max_rows and len(t.rows) > limit:
        rows.append(['…'] + [''] * (len(cols) - 1))
        if t.total_row is not None and t.total_row >= limit:
            rows.append(row(t.rows[t.total_row]))
            total = len(rows) - 1
    note = []
    if len(t.rows) > limit:
        note.append(f'показаны первые {limit} {_plural(limit, "строка", "строки", "строк")} из {len(t.rows)}')
    if len(t.columns) > MAX_TABLE_COLS:
        note.append(f'показаны первые {MAX_TABLE_COLS} столбцов из {len(t.columns)}')
    src_file = str(t.source or (sec.source if sec is not None else '') or '')
    if ' / ' in src_file:
        f, sh = src_file.split(' / ', 1)
        src = f'Источник: {f}, лист «{sh}».'
    else:
        src = f'Источник: {src_file}.' if src_file else ''
    if note:
        src = (src + ' ' if src else '') + cap('; '.join(note)) + '.'
    numeric = {j for j in t.numeric_cols if j < len(cols)}
    ins = _insights(t, getattr(w, 'cache', None)) if insights else []
    _, indent = w.table(cols, rows, numeric=numeric, caption=_table_caption(doc, t, sec), source=src,
                        total_row=total, keep_after=bool(ins))
    if insights:
        if ins:
            p = w.para('Что показывают данные:', style='ZN Вывод по данным', bold=True, color=NAVY, keep=True)
            p.paragraph_format.left_indent = Cm(indent)
            ps = w.list([{'text': cap(x), 'bold': '', 'mark': False, 'level': 0} for x in ins],
                        style='ZN Вывод по данным')
            for q in ps:                                 # маркеры — под левым краем таблицы
                q.paragraph_format.left_indent = Cm(indent + 0.75)
                q.paragraph_format.first_line_indent = Cm(-0.45)
            if ps:
                ps[0].paragraph_format.keep_with_next = len(ps) > 1
            if ps:
                ps[-1].paragraph_format.space_after = Pt(10)


def _render_blocks(w, doc, blocks, inline, limits=None):
    """Блоки раздела в справку; limits — {id таблицы: строк} для короткой справки."""
    for b in blocks:
        k = b['kind']
        if k == 'para':
            if b.get('mark'):
                w.callout(b['text'], b.get('bold_part') or '')
            else:
                w.para(b['text'], bold_part=b.get('bold_part') or '')
        elif k == 'list':
            w.list(b['items'], ordered=b.get('ordered'))
        elif k == 'table':
            t = doc.tables.get(b['tid'])
            if t is not None and t.id not in inline:
                inline.add(t.id)
                sec = next((s for s in doc.walk() for x in s.blocks if x.kind == 'table' and x.table_id == t.id), None)
                _doc_table(w, doc, t, sec, max_rows=(limits or {}).get(t.id))
        elif k == 'grid':
            w.table(b['columns'], b['rows'], caption=b.get('caption') or '', source='')
        elif k == 'image':
            img = doc.images.get(b['fid'])
            if img:
                w.image(img['path'], b.get('caption') or img.get('caption') or '', int(img.get('width') or 0))


_KN_COLS = ['№', 'Показатель', 'Значение', 'Источник']
_KN_WIDTHS = [1.0, 6.3, 3.7, TEXT_W - 11.0]


def _kn_row(i, r):
    """Строка таблицы ключевых показателей: №, подпись, значение с единицей, где в файлах."""
    by_file = {}
    for f, place in r['sources']:
        by_file.setdefault(f, [])
        if place and place not in by_file[f]:
            by_file[f].append(place)
    src = '\n'.join(f + (': ' + '; '.join(ps[:3]) if ps else '') for f, ps in list(by_file.items())[:3])
    return [str(i + 1), r['title'], f"{r['value']} {r['unit']}".strip(), src]


def _render(rep, doc, out_path, w=None):
    """Справка → .docx. w — «писатель» (по умолчанию _Writer; _Meter — оценка объёма без файла)."""
    w = w or _Writer(rep.get('author'))
    limits = rep.get('table_rows') or {}
    w.whole_table = rep.get('whole_table') or WHOLE_TABLE
    w.header_footer(rep['about'], rep.get('author') or '', rep.get('phone') or '')
    title = w.para('СПРАВКА', style='ZN Справка')
    for r in title.runs:                                 # разрядка букв «С П Р А В К А»
        _put(r._r.get_or_add_rPr(), _el('w:spacing', val=80), _RPR_ORDER)
    w.para(rep['about'], style='ZN Тема')
    w.para(rep['date'], style='ZN Дата')
    n = 0
    inline = set()
    counts = {'summary': len(rep['summary']), 'sections': len(rep['body']), 'key_numbers': len(rep['key_numbers'])}
    if rep['summary']:
        n += 1
        w.heading(f'{n}. Краткое содержание', 1)
        w.box([{'text': x['text'], 'bold': '', 'mark': x['mark'], 'level': 0} for x in rep['summary']])
    if rep['body']:
        n += 1
        w.heading(f'{n}. Основные положения', 1)
        for i, sec in enumerate(rep['body'], 1):
            w.heading(f'{n}.{i}. {sec["title"]}', 2)
            _render_blocks(w, doc, sec['blocks'], inline, limits)
            for j, ch in enumerate(sec['children'], 1):
                w.heading(f'{n}.{i}.{j}. {ch["title"]}', 3)
                _render_blocks(w, doc, ch['blocks'], inline, limits)
                for gch in ch['children']:                # глубже третьего уровня — без номера
                    w.para(gch['title'], style='ZN Текст', bold=True, color=DGREEN, keep=True)
                    _render_blocks(w, doc, gch['blocks'], inline, limits)
    if rep['key_numbers']:
        n += 1
        w.heading(f'{n}. Ключевые показатели', 1)
        rows = [_kn_row(i, r) for i, r in enumerate(rep['key_numbers'])]
        marks = {i for i, r in enumerate(rep['key_numbers']) if r['mark']}
        w.table(_KN_COLS, rows, caption='Ключевые показатели (по исходным материалам)', widths=_KN_WIDTHS,
                bold_cols={2}, center_cols={0, 2}, small_cols={3},
                mark_rows=marks, source='Числа приведены по исходным документам без пересчёта.' +
                (' Выделенные автором показатели отмечены цветом.' if marks else ''))
    skip = rep.get('skip_tables') or set()
    rest = [t for t in doc.tables.values() if t.id not in inline and t.id not in rep.get('covered', set())
            and t.id not in skip]
    counts['tables'] = len(inline) + len(rest)
    if rest:
        n += 1
        w.heading(f'{n}. Табличные данные', 1)
        for t in rest:
            sec = next((s for s in doc.walk() for x in s.blocks if x.kind == 'table' and x.table_id == t.id), None)
            _doc_table(w, doc, t, sec, max_rows=limits.get(t.id))
    if rep['conclusions'] or rep['proposals']:
        n += 1
        w.heading(f'{n}. Выводы и предложения' if rep['proposals'] and rep['conclusions'] else
                  (f'{n}. Выводы' if rep['conclusions'] else f'{n}. Предложения'), 1)
        if rep['conclusions']:
            w.list([{'text': x['text'], 'bold': '', 'mark': x['mark'], 'level': 0} for x in rep['conclusions']],
                   ordered=True)
        if rep['proposals']:
            if rep['conclusions']:
                w.para('Предложения:', style='ZN Текст', bold=True, color=NAVY, keep=True).paragraph_format \
                    .first_line_indent = Cm(0)
            w.list([{'text': x['text'], 'bold': '', 'mark': x['mark'], 'level': 0} for x in rep['proposals']])
    if rep.get('sources_line'):                          # короткая справка: источники одной строкой
        w.para(rep['sources_line'], style='ZN Источник')
    elif rep['sources']:
        n += 1
        w.heading(f'{n}. Источники', 1)
        ps = w.list([{'text': s, 'bold': '', 'mark': False, 'level': 0} for s in rep['sources']], ordered=True)
        if len(ps) <= 8:                                 # короткий перечень не разрывается между страницами
            for p in ps[:-1]:
                p.paragraph_format.keep_with_next = True
    w.d.core_properties.title = shorten(f'Справка {rep["about"]}', 250)
    w.d.core_properties.subject = 'Справка'
    w.save(out_path)
    counts['images'] = w.n_image
    counts['word_tables'] = w.n_table
    return counts


# ======================================================================================
# 5. ОБЪЁМ СПРАВКИ: ОЦЕНКА ЧИСЛА ЛИСТОВ И ОТБОР САМОГО ВАЖНОГО (options['pages'])
# ======================================================================================
# Оценка — без Word и LibreOffice (приложение работает офлайн): справка «рисуется» в _Meter теми же
# вызовами _render, что и в .docx, но вместо файла считаются высоты абзацев и строк таблиц по ширинам
# символов Arial и реальным полям страницы; затем блоки раскладываются по листам (_layout) с учётом
# «не отрывать от следующего», неразрывных таблиц, висячих строк и повтора шапки таблицы.
# Оценка с запасом: без переносов по слогам (Word их делает — строк у него не больше), интервалы до и
# после абзацев складываются (LibreOffice берёт больший из двух), жирный — на 10 % шире, высота листа —
# с запасом 2 %. Высоты строк сверены с LibreOffice (Arial там подменяется метрически совместимым
# Liberation Sans): 12 pt при интервале 1,15 — 15,9 пт, строка таблицы 10 pt — 16 пт.

# Ширины символов Arial в тысячных долях кегля (сняты с метрически совместимого Liberation Sans):
# ASCII 32…126, затем А…Я, а…я; несколько знаков — отдельно; неизвестные символы — 600.
_AW = dict(zip(map(chr, range(32, 127)), (
    278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556,
    556, 556, 556, 556, 278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667,
    556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333, 556,
    556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722,
    500, 500, 500, 334, 260, 334, 584)))
_AW.update(zip(map(chr, range(0x410, 0x450)), (
    667, 656, 667, 542, 677, 667, 923, 604, 719, 719, 583, 656, 833, 722, 778, 719, 667, 722, 611, 635, 760, 667,
    740, 667, 917, 938, 792, 885, 656, 719, 1010, 722, 556, 573, 531, 365, 583, 556, 669, 458, 559, 559, 438, 583,
    688, 552, 556, 542, 556, 500, 458, 500, 823, 500, 573, 521, 802, 823, 625, 719, 521, 510, 750, 542)))
_AW.update({'ё': 556, 'Ё': 667, '«': 556, '»': 556, '—': 1000, '–': 556, '…': 1000, '№': 1073, '°': 400, '±': 549,
            '×': 584, '−': 584, '•': 350, '\u00a0': 278})
_LINE_EM = 1.15               # высота строки Arial при одинарном интервале, доли кегля (как в Word)
_BOLD = 1.1                   # жирный Arial шире обычного (в русском тексте — на 7 %; берём с запасом)
_PT = 72 / 2.54               # пунктов в сантиметре
_TEXT_PT = TEXT_W * _PT                                            # ширина текста, пт
_PAGE_PT = (PAGE_H - MARGINS['top'] - MARGINS['bottom']) * _PT     # высота текста на листе, пт
_SAFETY = 0.98                # запас высоты листа на расхождения Word, LibreOffice и оценки
_CELL_PAD = 85 / 20           # поле ячейки таблицы слева и справа (85 twip), пт
_ROW_PAD = 80 / 20 + 0.5      # поля ячейки сверху и снизу (по 40 twip) и линия сетки, пт
_BOX_PAD = (170 / 20, 110 / 20, 90 / 20)    # плашка краткого содержания: поле сбоку, сверху, снизу, пт
_NUM_LEFT = (1.0, 1.8)        # отступ текста пунктов списка (уровни 1 и 2), см — как в _setup_numbering
_CORE_ROWS = 5                # длинная таблица в короткой справке: первые строки, затем «…»


def _text_w(s, size, k=1.0):
    """Ширина строки текста в пунктах (Arial; k — поправка на жирный)."""
    return sum(_AW.get(ch, 600) for ch in s) * size * k / 1000


def _bold_k(text, bold=False, bold_part=''):
    """Поправка ширины на жирный: весь абзац или выделенная часть."""
    if bold:
        return _BOLD
    if bold_part and text:
        return 1 + (_BOLD - 1) * min(1.0, len(bold_part) / len(text))
    return 1.0


def _n_lines(text, width, size=12, k=1.0, first=0.0):
    """Строк в абзаце шириной width пт (first — отступ первой строки, пт; «\\n» — новый абзац ячейки):
    перенос по словам, слово длиннее строки рвётся; неразрывные пробелы typo() склеивают слова, как в Word."""
    n = 0
    sp = _AW[' '] * size * k / 1000
    for part in str(text or '').split('\n'):
        n += 1
        x, room = 0.0, width - first
        for word in typo(part).split(' '):
            if not word:
                continue
            ww = _text_w(word, size, k)
            if x and x + sp + ww <= room:
                x += sp + ww
                continue
            if x:
                n += 1
                room = width
            while ww > room > 0:
                n += 1
                ww -= room
                room = width
            x = ww
    return max(1, n)


def _row_h(vals, widths, size=10, bold_cols=(), small_cols=(), header=False, bold_all=False):
    """Высота строки таблицы, пт: самая высокая ячейка (с переносом по ширине столбца) и поля."""
    h = 0.0
    for j, wd in enumerate(widths):
        v = vals[j] if j < len(vals) else ''
        sz = size - 1 if (j in small_cols and not header) else size
        k = _BOLD if (header or bold_all or j in bold_cols) else 1.0
        n = _n_lines(str(v if v is not None else ''), wd * _PT - 2 * _CELL_PAD, sz, k)
        h = max(h, n * size * _LINE_EM)
    return h + _ROW_PAD


class _Blk:
    """Блок раскладки: высоты строк (абзаца или строк таблицы), интервалы до и после, «не отрывать от
    следующего», можно ли делить между листами, шапка таблицы (повторяется на новом листе), висячие строки."""
    __slots__ = ('lines', 'before', 'after', 'keep', 'split', 'head', 'widow')

    def __init__(self, lines, before=0.0, after=0.0, keep=False, split=True, head=0.0, widow=True):
        self.lines, self.before, self.after, self.keep = lines, before, after, keep
        self.split, self.head, self.widow = split, head, widow

    def total(self):
        return self.before + sum(self.lines) + self.after


class _MP:
    """Абзац для оценки объёма: стиль, текст и формат. paragraph_format — он сам (как у абзаца python-docx:
    _render и _doc_table меняют отступы и интервалы уже после создания абзаца), высоты — в blk()."""
    runs = ()

    def __init__(self, style, text, k=None, left=None, first=None, is_list=False):
        if style in _HSTYLES:
            size, _, before, after = _HSTYLES[style]
            st = dict(_PSTYLE_DEF, size=size, bold=True, before=before, after=after, line=1.1, keep=True)
        else:
            st = dict(_PSTYLE_DEF, **_PSTYLES.get(style, {}))
        self.text, self.size, self.line, self.is_list = text or '', st['size'], st['line'], is_list
        self.k = k if k is not None else (_BOLD if st['bold'] else 1.0)
        self.border = 2.75 if style == 'Heading 1' else 0.0          # линия под заголовком: 0,75 пт и отступ 2 пт
        self.space_before, self.space_after = Pt(st['before']), Pt(st['after'])
        self.left_indent, self.right_indent = left, None
        self.first_line_indent = first if first is not None else (Cm(st['indent']) if st['indent'] else None)
        self.keep_with_next, self.alignment = st['keep'], None
        self.paragraph_format = self

    def blk(self, width=_TEXT_PT):
        def pt(v):
            return (v or 0) / 12700                    # EMU → пт
        first = 0.0 if self.is_list else pt(self.first_line_indent)  # у пункта текст — от отступа, маркер — левее
        n = _n_lines(self.text, width - pt(self.left_indent) - pt(self.right_indent), self.size, self.k, first)
        lines = [self.size * _LINE_EM * self.line] * n
        lines[-1] += self.border
        return _Blk(lines, pt(self.space_before), pt(self.space_after), bool(self.keep_with_next))


class _Meter:
    """«Писатель» для оценки объёма: те же вызовы, что у _Writer, но вместо .docx — блоки с высотами (пт)
    по порядку. pages() раскладывает их по листам, height() — высота одной лентой (цена фрагмента)."""

    def __init__(self):
        self.flow = []
        self.n_table = self.n_image = 0
        self.whole_table = WHOLE_TABLE
        self.cache = {}                                  # выводы по данным таблиц (_insights)
        self.d = SimpleNamespace(core_properties=SimpleNamespace())

    def _add(self, p):
        self.flow.append(p)
        return p

    def para(self, text, style='ZN Текст', bold_part='', bold=False, color=None, keep=False):
        p = self._add(_MP(style, text, k=_bold_k(text, bold, bold_part) if (bold or bold_part) else None))
        if keep:
            p.keep_with_next = True
        return p

    def callout(self, text, bold_part=''):
        p = self._add(_MP('ZN Текст', text, k=_bold_k(text, not bold_part, bold_part), left=Cm(0.35), first=Cm(0)))
        p.right_indent, p.space_before, p.space_after = Cm(0.1), Pt(4), Pt(8)
        return p

    def heading(self, text, level):
        return self._add(_MP(f'Heading {level}', text))

    def list(self, items, ordered=False, style='ZN Список', container=None):
        out = []
        for it in items:
            text = it['text'] if it.get('raw') or it['text'].endswith((';', ',')) else _end(it['text'])
            p = _MP(style, text, k=_bold_k(text, bool(it.get('mark')), it.get('bold') or ''),
                    left=Cm(_NUM_LEFT[min(1, int(it.get('level') or 0))]), is_list=True)
            out.append(p if container else self._add(p))
        return out

    def table(self, columns, rows, numeric=(), caption='', source='', widths=None, bold_cols=(), mark_rows=(),
              total_row=None, center_cols=(), small_cols=(), size=10, keep_after=False):
        if not columns:
            return None, 0
        self.n_table += 1
        widths = widths or _Writer._widths(columns, rows, set(numeric), size)
        indent = max(0.0, (TEXT_W - sum(widths)) / 2)
        if caption:
            self._add(_MP('ZN Подпись таблицы', f'Таблица {self.n_table} — {caption}', left=Cm(indent)))
        hs = [_row_h(columns, widths, size, header=True)] + [
            _row_h(r, widths, size, bold_cols, small_cols, bold_all=(total_row is not None and i == total_row))
            for i, r in enumerate(rows)]
        # небольшая таблица не делится (строки «не отрывать от следующего»), длиннее — делится по строкам
        self.flow.append(_Blk(hs, keep=True, split=len(rows) > self.whole_table, head=hs[0], widow=False))
        if source:
            p = self.para(source, style='ZN Источник', keep=keep_after)
            p.left_indent = Cm(indent)
        else:
            p = self._add(_MP('ZN Таблица', ''))
            p.space_after = Pt(6)
        return None, indent

    def box(self, items):
        side, top, bottom = _BOX_PAD
        ps = self.list(items, container=True)
        lines = []
        for i, p in enumerate(ps):
            b = p.blk(_TEXT_PT - 2 * side)
            b.lines[-1] += b.after if i < len(ps) - 1 else 0
            lines += b.lines
        if lines:
            lines[0] += top
            lines[-1] += bottom
            self.flow.append(_Blk(lines, widow=False))     # строка плашки может перейти на следующий лист
        self._add(_MP('ZN Таблица', '')).space_after = Pt(4)

    def image(self, path, caption='', width_emu=0):
        size = _image_cm(path, width_emu)
        if not size:
            return False
        self.flow.append(_Blk([size[1] * _PT + 3], before=6, keep=True, split=False))
        self.n_image += 1
        self.para(_figure_caption(self.n_image, caption), style='ZN Подпись рисунка')
        return True

    def header_footer(self, about, author, phone):
        pass

    def save(self, path):
        pass

    def blocks(self):
        return [x.blk() if isinstance(x, _MP) else x for x in self.flow]

    def height(self):
        return sum(b.total() for b in self.blocks())

    def pages(self):
        """Раскладка по листам → (листов, доля занятого на последнем листе)."""
        return _layout(self.blocks(), _PAGE_PT * _SAFETY - _first_page_loss(), _PAGE_PT * _SAFETY)


def _first_page_loss():
    """На первом листе шапка с логотипом выше верхнего поля — текст начинается ниже (пт)."""
    h = 14 * _LINE_EM                                    # текстовая шапка «АО «Зарубежнефть»»
    logo = logo_png()
    if logo:
        try:
            from PIL import Image
            with Image.open(io.BytesIO(logo)) as im:
                lw, lh = im.size
            h = 5.6 * lh / lw * _PT + 9 * 0.25           # рисунок 5,6 см и нижний вынос строки
        except Exception:
            pass
    return max(0.0, h + 7.5 - (MARGINS['top'] - 1.0) * _PT)  # 7,5 — зелёная линия с отступом


def _layout(blocks, first_h, page_h):
    """Раскладка блоков по листам, как в Word: «не отрывать от следующего» — вместе с началом следующего
    блока, неделимое (рисунок, таблица до 15 строк, абзац до 3 строк) — целиком, у абзаца на листе не
    меньше двух строк, у таблицы на новом листе повторяется шапка. → (листов, доля последнего листа)."""
    def whole(b):
        return not b.split or (b.widow and len(b.lines) <= 3)
    need = [0.0] * (len(blocks) + 1)                     # что должно поместиться, чтобы начать блок на листе
    for i in range(len(blocks) - 1, -1, -1):
        b = blocks[i]
        if b.keep and not (b.split and b.head):          # у длинной таблицы «прицеп» — только последняя строка
            need[i] = b.before + sum(b.lines) + need[i + 1]
        else:
            need[i] = b.before + (sum(b.lines) if whole(b) else sum(b.lines[:2]))
    page, y, room = 1, 0.0, first_h
    for i, b in enumerate(blocks):
        req = need[i] if need[i] <= page_h else b.before + sum(b.lines[:2])
        if y > 0 and y + req > room:
            page, y, room = page + 1, 0.0, page_h
        y += b.before
        if whole(b):
            y += sum(b.lines)
            while y > room:                              # выше листа (огромная таблица) — переливается
                page, y, room = page + 1, y - room, page_h
        else:
            for k, h in enumerate(b.lines):
                if y + h > room and y > 0:
                    page, room = page + 1, page_h
                    y = b.lines[k - 1] if (b.widow and k >= 3 and k == len(b.lines) - 1) else b.head
                y += h
        y += b.after
    return page, min(1.0, y / room)


def estimate_pages(rep, doc):
    """Оценка объёма справки без Word и LibreOffice → (листов, доля занятого на последнем листе)."""
    m = _Meter()
    _render(rep, doc, None, m)
    return m.pages()


# ---------- отбор самого важного ---------------------------------------------------------
_IMPORTANT = re.compile(r'(?i)цел[ьиея]\b|результат|эффект|риск|предлож|предлага|вывод|итог|задач|проблем|экономи|'
                        r'сниж|увелич|рост|прибыл|окупа|позволя|обеспеч|рекоменд|необходим')
_ANAPHOR = re.compile(r'(?i)^(?:это|эт[аои]|он[аио]?|они|их|его|её|такж\w*|так(?:ой|ая|ое|ие)|данн\w+|при этом|'
                      r'кроме того|поэтому|однако|для этого|в связи с этим)\b')


def _weight(text, mark=False, first=False):
    """«Вес» мысли для короткой справки: выделенное автором, числа, ключевые слова («цель», «результат»,
    «эффект», «риск», «предлагается», «вывод»…), итоговая фраза, первое предложение раздела. Очень короткое,
    очень длинное и «не текст» (псевдографика, перечни путей и формул — мало букв) — легче."""
    t = clean(text)
    letters = sum(ch.isalpha() for ch in t) / max(1, len(t))
    return (20 + 30 * bool(mark) + 8 * bool(re.search(r'\d', t)) + 8 * bool(_IMPORTANT.search(t))
            + 6 * bool(_FINAL0.match(t)) + 10 * bool(first) - 4 * (len(t) > 300) - 12 * (len(t) > 600)
            - 6 * (len(t) < 40) - 15 * (letters < 0.6))


class _Unit:
    """Часть справки для отбора: ключ, вес, цена (пт), «общие» части (заголовки, вводная фраза списка —
    их цена платится один раз), обязательна ли, от какой части зависит (без неё — не берётся)."""
    __slots__ = ('key', 'score', 'cost', 'groups', 'must', 'dep')

    def __init__(self, key, score, cost, groups=(), must=False, dep=None):
        self.key, self.score, self.cost, self.groups, self.must, self.dep = key, score, cost, tuple(groups), must, dep


def _is_intro(blocks, i):
    """«Поставлены следующие задачи:» — вводная фраза перед списком или таблицей (без них не нужна)."""
    b = blocks[i]
    return (b['kind'] == 'para' and not b.get('mark') and bool(_INTRO_TAIL.search(b['text'])) and i + 1 < len(blocks)
            and blocks[i + 1]['kind'] in ('list', 'table', 'grid'))


def _sources_line(doc):
    return ('Источники: ' + ', '.join(doc.sources) + '.') if doc.sources else ''


def _rest_tables(rep, doc, seen):
    return [t for t in doc.tables.values() if t.id not in seen and t.id not in rep.get('covered', set())]


def _table_sec(doc, t):
    return next((s for s in doc.walk() for x in s.blocks if x.kind == 'table' and x.table_id == t.id), None)


def _units(rep, doc):
    """Части справки с весами и ценами → ([_Unit], {группа: цена}). Обязательны шапка (её рисует _render
    всегда), первые тезисы краткого содержания (и выделенные автором) и строка источников."""
    units, over = [], {}
    lh = 12 * _LINE_EM * 1.15

    def add(*a, **kw):
        units.append(_Unit(*a, **kw))

    def measure(fn):
        m = _Meter()
        fn(m)
        return m.height()

    def item_cost(it, width=_TEXT_PT):
        return _Meter().list([dict(it, level=it.get('level') or 0)], container=True)[0].blk(width).total()

    side, top, bottom = _BOX_PAD
    over['sum'] = measure(lambda m: (m.heading('1. Краткое содержание', 1), m.box([]))) + top + bottom
    for i, x in enumerate(rep['summary']):
        must = i < 3 or (x['mark'] and i < 5)
        add(('sum', i), 1000 - i if must else 75 - 3 * i, item_cost(x, _TEXT_PT - 2 * side), ['sum'], must)
    sumtxt = [x['text'] for x in rep['summary']] + [x['text'] for x in rep['conclusions']]

    def said(text, lst=sumtxt):                          # уже сказано в кратком содержании (или выводах)
        return any(_similar(text, x) for x in lst)
    seen = set()
    n_tab = [0]

    def table_units(key, t, tsec, score, groups):
        core = min(len(t.rows), _CORE_ROWS)
        c_core = measure(lambda m: _doc_table(m, doc, t, tsec, max_rows=core if len(t.rows) > core else None))
        add(('t', key), score - 2 * n_tab[0], c_core, groups)
        if len(t.rows) > core:
            c_full = measure(lambda m: _doc_table(m, doc, t, tsec))
            add(('tx', key), 10 - n_tab[0], max(0.0, c_full - c_core), groups, dep=('t', key))
        n_tab[0] += 1

    def walk(nd, path, groups, pen):
        title = nd.get('title') or ''
        sec = nd.get('sec')
        style = ('Heading 2', 'Heading 3', 'ZN Текст')[len(path) - 1]
        over[('h', path)] = _MP(style, '2.' + '.'.join(map(str, path)) + '. ' + title,
                                k=_BOLD if len(path) == 3 else None).blk().total()
        groups = groups + (('h', path),)
        bonus = (6 if sec is not None and sec.marked() else 0) - (15 if _APPENDIX.search(title) else 0) \
            - (6 if RX['intro'].match(title) else 0) - pen
        blocks, pos = nd['blocks'], 0
        for bi, b in enumerate(blocks):
            kind = b['kind']
            g = groups + ((('i', path, bi - 1),) if bi and _is_intro(blocks, bi - 1) else ())
            if kind == 'para' and _is_intro(blocks, bi):
                over[('i', path, bi)] = _MP('ZN Текст', b['text']).blk().total()
            elif kind == 'para':
                callout, bp = bool(b.get('mark')), b.get('bold_part') or ''
                width = _TEXT_PT - (0.45 * _PT if callout else 0)
                over[('p', path, bi)] = (12 if callout else 6) + 0.6 * lh      # интервалы и неполная строка
                prev = None
                for si, s in enumerate(sentences(b['text']) or [b['text']]):
                    mark = callout or bool(bp and (bp in s or s.rstrip('.') in bp))
                    sc = _weight(s, mark, pos == 0) + bonus - min(10, 0.7 * pos) + (3 if si == 0 else 0)
                    # повтор краткого содержания и «…следующим образом:» (без своего списка не нужно) — ниже
                    sc -= 40 * said(s) + 30 * s.rstrip().endswith(':')
                    cost = _text_w(typo(s) + ' ', 12, _BOLD if mark else 1.0) / width * lh
                    key = ('s', path, bi, si)
                    add(key, sc, cost, g + (('p', path, bi),), dep=prev if (prev and _ANAPHOR.match(s)) else None)
                    prev, pos = key, pos + 1
            elif kind == 'list':
                for ii, it in enumerate(b['items']):
                    sc = _weight(it['text'], it.get('mark'), pos == 0) + 2 + (4 if ii == 0 else 0) \
                        - min(8, 0.8 * ii) + bonus - min(10, 0.7 * pos)
                    sc -= 40 * said(it['text'])
                    add(('li', path, bi, ii), sc, item_cost(it), g)
                pos += 1
            elif kind == 'table':
                t = doc.tables.get(b['tid'])
                if t is not None and t.id not in seen:
                    seen.add(t.id)
                    kpi = re.search(r'(?i)показател|эффект|результат|бюджет|затрат|стоимост', f'{title} {t.title}')
                    table_units((path, bi), t, _table_sec(doc, t), 30 + 6 * bool(kpi) + bonus, g)
            elif kind == 'grid':
                add(('g', path, bi), 30 + bonus, measure(
                    lambda m: m.table(b['columns'], b['rows'], caption=b.get('caption') or '', source='')), g)
            elif kind == 'image':
                img = doc.images.get(b['fid'])
                if img:
                    add(('im', path, bi), 6 + min(0, bonus), measure(lambda m: m.image(
                        img['path'], b.get('caption') or img.get('caption') or '', int(img.get('width') or 0))), g)
        if len(path) < 3:
            for j, ch in enumerate(nd['children'], 1):
                walk(ch, path + (j,), groups, pen + 3)

    over['body'] = _MP('Heading 1', '2. Основные положения').blk().total()
    for i, s in enumerate(rep['body'], 1):
        walk(s, (i,), ('body',), 0)
    kn = rep['key_numbers']
    if kn:
        over['kn'] = measure(lambda m: (m.heading('3. Ключевые показатели', 1), m.table(
            _KN_COLS, [], caption='Ключевые показатели (по исходным материалам)', widths=_KN_WIDTHS,
            source='Числа приведены по исходным документам без пересчёта. Выделенные автором показатели '
                   'отмечены цветом.')))
        for i, r in enumerate(kn):
            add(('kn', i), 66 - 5 * i + 12 * bool(r['mark']), _row_h(_kn_row(i, r), _KN_WIDTHS, 10, {2}, {3}), ['kn'])
    rest = _rest_tables(rep, doc, seen)
    if rest:
        over['tabs'] = _MP('Heading 1', '4. Табличные данные').blk().total()
    for t in rest:
        table_units(t.id, t, _table_sec(doc, t), 26, ['tabs'])
    if rep['conclusions'] or rep['proposals']:
        over['con'] = _MP('Heading 1', '5. Выводы и предложения').blk().total()
    summ = [x['text'] for x in rep['summary']]

    def item_score(base, i, x):
        """Пункт выводов и предложений: по порядку, выделенное автором — выше, короткое и повтор резюме — ниже."""
        return base - 3 * i + 10 * bool(x['mark']) - 12 * (len(x['text']) < 40) - 40 * said(x['text'], summ)
    for i, x in enumerate(rep['conclusions']):
        add(('c', i), item_score(76, i, x), item_cost(x), ['con'])
    if rep['conclusions'] and rep['proposals']:
        over['plab'] = _MP('ZN Текст', 'Предложения:', k=_BOLD, first=Cm(0)).blk().total()
    for i, x in enumerate(rep['proposals']):
        add(('pr', i), item_score(72, i, x), item_cost(x), ['con', 'plab'] if rep['conclusions'] else ['con'])
    if rep['sources']:
        short = measure(lambda m: m.para(_sources_line(doc), style='ZN Источник'))
        full = measure(lambda m: (m.heading('6. Источники', 1), m.list(
            [{'text': s, 'bold': '', 'mark': False, 'level': 0} for s in rep['sources']], ordered=True)))
        add(('srcline',), 1000, short, must=True)
        add(('src',), 16, max(0.0, full - short), dep=('srcline',))
    for u in units:                                      # из равных по весу — что короче
        u.score -= 0 if u.must else u.cost / 20
    units.sort(key=lambda u: (not u.must, -u.score))      # при равном весе — в порядке документа
    return units, over


def _select(units, over, budget):
    """Жадный отбор по весу: обязательное — всегда, остальное — пока хватает места (budget, пт)."""
    chosen, active, used = set(), set(), 0.0
    for u in units:
        if u.dep and u.dep not in chosen:
            continue
        extra = u.cost + sum(over.get(g, 0.0) for g in u.groups if g not in active)
        if not u.must and used + extra > budget:
            continue
        chosen.add(u.key)
        active.update(u.groups)
        used += 0.0 if u.must else extra
    return chosen


def _trim(rep, doc, chosen):
    """Справка из выбранных частей: порядок документа сохраняется, абзацы — из целых предложений,
    вводная фраза — только со своим списком, разделы без содержания убираются."""
    new = copy.copy(rep)
    skip, limits, seen = set(), {}, set()

    def table_ok(key, t):
        if ('t', key) not in chosen:
            skip.add(t.id)
            return False
        if len(t.rows) > _CORE_ROWS and ('tx', key) not in chosen:
            limits[t.id] = _CORE_ROWS
        return True

    def shown(path, bi):                                 # от блока что-то осталось (пункт, таблица…)
        return any(k[0] in ('li', 'g', 'im') and k[1:3] == (path, bi) or k[0] == 't' and k[1] == (path, bi)
                   for k in chosen)

    def node(nd, path):
        blocks, src = [], nd['blocks']
        for bi, b in enumerate(src):
            kind, keep = b['kind'], None
            if kind == 'para' and _is_intro(src, bi):
                continue
            if kind == 'para':
                ss = sentences(b['text']) or [b['text']]
                kept = [s for si, s in enumerate(ss) if ('s', path, bi, si) in chosen and not (
                    s.rstrip().endswith(':') and not (si == len(ss) - 1 and shown(path, bi + 1)))]
                if len(kept) == len(ss):
                    keep = b
                elif kept:
                    txt = ' '.join(kept)
                    bp = b.get('bold_part') or ''
                    keep = dict(b, text=txt, bold_part=bp if bp and bp in txt else '')
            elif kind == 'list':
                items = [it for ii, it in enumerate(b['items']) if ('li', path, bi, ii) in chosen]
                keep = dict(b, items=items) if items else None
            elif kind == 'table':
                t = doc.tables.get(b['tid'])
                if t is not None and t.id not in seen:
                    seen.add(t.id)
                    keep = b if table_ok((path, bi), t) else None
            elif kind == 'grid':
                keep = b if ('g', path, bi) in chosen else None
            elif kind == 'image':
                keep = b if ('im', path, bi) in chosen else None
            if keep is not None:
                if bi and _is_intro(src, bi - 1):
                    blocks.append(src[bi - 1])
                blocks.append(keep)
        children = [c for c in (node(ch, path + (j,)) for j, ch in enumerate(nd['children'], 1)) if c] \
            if len(path) < 3 else []
        return dict(nd, blocks=blocks, children=children) if (blocks or children) else None

    new['summary'] = [x for i, x in enumerate(rep['summary']) if ('sum', i) in chosen]
    new['body'] = [c for c in (node(s, (i,)) for i, s in enumerate(rep['body'], 1)) if c]
    new['key_numbers'] = [r for i, r in enumerate(rep['key_numbers']) if ('kn', i) in chosen]
    for t in _rest_tables(rep, doc, seen):
        table_ok(t.id, t)
    new['conclusions'] = [x for i, x in enumerate(rep['conclusions']) if ('c', i) in chosen]
    new['proposals'] = [x for i, x in enumerate(rep['proposals']) if ('pr', i) in chosen]
    if rep['sources'] and ('src',) not in chosen:
        new['sources_line'] = _sources_line(doc)
    new['skip_tables'], new['table_rows'], new['whole_table'] = skip, limits, WHOLE_TABLE_SHORT
    return new


def _omitted(units, chosen, new):
    """Что опущено и что сокращено — для сообщения пользователю: «12 фрагментов текста, 2 таблицы; …»."""
    keys = {u.key for u in units} - chosen
    count = {'text': 0, 'kn': 0, 'tab': 0, 'img': 0}
    for k in keys:
        kind = {'s': 'text', 'li': 'text', 'sum': 'text', 'c': 'text', 'pr': 'text', 'kn': 'kn', 't': 'tab', 'g': 'tab',
                'im': 'img'}.get(k[0])
        if kind:
            count[kind] += 1
    words = {'text': ('фрагмент текста', 'фрагмента текста', 'фрагментов текста'),
             'kn': ('показатель', 'показателя', 'показателей'), 'tab': ('таблица', 'таблицы', 'таблиц'),
             'img': ('рисунок', 'рисунка', 'рисунков')}
    gone = [f'{n} {_plural(n, *words[k])}' for k, n in count.items() if n]
    out = ['опущено: ' + ', '.join(gone)] if gone else []
    n_short = len(new.get('table_rows') or {})
    if n_short:
        out.append(f'{n_short} {_plural(n_short, "таблица показана", "таблицы показаны", "таблиц показаны")} '
                   'первыми строками')
    if new.get('sources_line'):
        out.append('источники — одной строкой')
    return out


def fit_pages(rep, doc, pages):
    """Справка не длиннее pages листов: если не помещается — остаётся самое важное (см. начало раздела).
    Бюджет места подбирается делением пополам по оценке estimate_pages(), затем в оставшееся место
    добираются следующие по весу части. → (справка, предупреждения, оценка числа листов)."""
    est = estimate_pages(rep, doc)[0]
    if est <= pages:
        return rep, [], est
    loose = dict(rep, whole_table=WHOLE_TABLE_SHORT)  # сначала — без сокращения, таблицы делятся между листами
    est = estimate_pages(loose, doc)[0]
    if est <= pages:
        return loose, [], est
    warnings, notes = [], []
    units, over = _units(rep, doc)
    chosen = _select(units, over, 0.0)
    best = _trim(rep, doc, chosen)
    n, fill = estimate_pages(best, doc)
    if n > pages:                        # даже главное не помещается: краткое содержание — короче
        notes.append('краткое содержание — три тезиса по одному предложению')
        rep = dict(rep, summary=[dict(x, text=_end(shorten((sentences(x['text']) or [x['text']])[0], 220)))
                                 for x in rep['summary'][:3]])
        units, over = _units(rep, doc)
        chosen = _select(units, over, 0.0)
        best = _trim(rep, doc, chosen)
        n, fill = estimate_pages(best, doc)
    if n > pages:
        warnings.append(f'Даже самое важное не помещается в {pages} {_plural(pages, "лист", "листа", "листов")}: '
                        f'справка займёт около {n} {_plural(n, "листа", "листов", "листов")}. '
                        'Увеличьте число листов справки.')
    else:
        lo, hi = 0.0, sum(u.cost for u in units if not u.must) + sum(over.values())
        for _ in range(16):              # 1) бюджет места — делением пополам
            if hi - lo < 10:
                break
            mid = (lo + hi) / 2
            sel = _select(units, over, mid)
            cand = _trim(rep, doc, sel)
            k, f = estimate_pages(cand, doc)
            if k <= pages:
                lo, best, chosen, n, fill = mid, cand, sel, k, f
            else:
                hi = mid
        # 2) добор: следующие по весу части — если справка от них не становится длиннее
        active = {g for u in units if u.key in chosen for g in u.groups}
        free, tries = (pages - n + 1 - fill) * _PAGE_PT * _SAFETY, 0
        for u in units:
            if tries >= 40 or free < 8:
                break
            if u.key in chosen or (u.dep and u.dep not in chosen):
                continue
            if u.cost + sum(over.get(g, 0.0) for g in u.groups if g not in active) > free + 30:
                continue
            sel = chosen | {u.key}
            cand = _trim(rep, doc, sel)
            k, f = estimate_pages(cand, doc)
            tries += 1
            if k <= pages:
                best, chosen, n, fill = cand, sel, k, f
                active.update(u.groups)
                free = (pages - n + 1 - fill) * _PAGE_PT * _SAFETY
    parts = notes + _omitted(units, chosen, best)
    warnings.insert(0, f'Справка сокращена до {pages} {_plural(pages, "листа", "листов", "листов")}: оставлено '
                       'самое важное' + (f' ({"; ".join(parts)})' if parts else '') + '.')
    return best, warnings, n


def pages_option(v):
    """Число листов справки из настроек: целое 1–30, 0 / пусто / неверное — без ограничения."""
    try:
        return max(0, min(MAX_PAGES, int(float(v or 0))))
    except (TypeError, ValueError, OverflowError):
        return 0


# ======================================================================================
# 6. ГЛАВНАЯ ФУНКЦИЯ
# ======================================================================================
def make_report(files, out_path, options=None, llm=None, progress=None):
    """Справка в Word по загруженным файлам.

    files    — [(путь, исходное_имя)], как у engine.analyze;
    out_path — куда сохранить .docx;
    options  — title (тема), about («о …» — заголовок к тексту, необязательно), date, author (исполнитель),
               phone, mode ('rules' | 'ai'), ai_level ('fast' | 'full'), focus, marks (priority | only | ignore),
               pages (листов справки: 1–30; 0 — без ограничения, см. раздел 5);
    llm      — настройки модели ИИ (как у планировщика) или None;
    progress — обратный вызов хода: {'phase': 'read' | 'prompt' | 'wait' | 'gen' | 'retry' | 'done' | 'write',
               'kind': 'report', …}. Если он бросает llm_client.Cancelled — отмена пробрасывается наверх.

    Возвращает (путь | None, предупреждения, сведения). None — если в файлах нет текста и таблиц."""
    options = dict(options or {})
    options['pages'] = pages = pages_option(options.get('pages'))
    notify = progress or (lambda e: None)
    notify({'phase': 'read', 'kind': 'report'})
    doc = read_files(files, lambda e: notify(dict(e, kind='report')))
    pinfo = prepare(doc, options)
    warnings = list(doc.warnings)
    info = {'kind': 'report', 'stats': doc.stats(), 'title': clean(options.get('title') or doc.title),
            'sources': list(doc.sources), 'mode_used': 'rules', 'script': pinfo['script'], 'marks': pinfo['marks']}
    if not doc.sections:
        return None, warnings + ['В файлах не найдено текста или таблиц.'], info
    rep = build_rules(doc, options)
    if options.get('mode') == 'ai' and llm:
        stats = {}

        def prog(e):
            if e.get('phase') == 'done':
                stats.update(e.get('stats') or {})
            notify(e)
        try:
            rep2, w2, level = build_ai(doc, rep, options, llm, progress=prog)
            rep = rep2
            warnings += w2
            info.update(mode_used='ai', ai_level=level, llm=stats)
        except Cancelled:
            raise
        except Exception as e:                       # noqa: BLE001 — любая ошибка модели → справка по правилам
            info['llm'] = stats
            from .llm_client import is_cloud
            src = 'облачной модели' if is_cloud(llm) else 'локальной ИИ'
            warnings.append(f'Не удалось получить текст справки от {src}: {e} Справка составлена по правилам.')
    notify({'phase': 'write', 'kind': 'report'})
    if pages:                                        # заданное число листов: остаётся самое важное
        rep, w3, est = fit_pages(rep, doc, pages)
        warnings += w3
        info.update(pages=pages, pages_est=est, trimmed=bool(w3))
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    info.update(_render(rep, doc, out_path))
    info.update(title=rep['topic'], about=rep['about'], date=rep['date'])
    return out_path, warnings, info


if __name__ == '__main__':          # python -m engine.report [--pages N] out.docx файл1.docx файл2.xlsx …
    import sys
    a = sys.argv[1:]
    opts = {}
    if '--pages' in a and a.index('--pages') + 1 < len(a):
        k = a.index('--pages')
        opts['pages'] = a[k + 1]
        del a[k:k + 2]
    path, w, inf = make_report([(p, Path(p).name) for p in a[1:]], a[0], opts)
    print(path, w, inf)
