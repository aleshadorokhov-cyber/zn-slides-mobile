# -*- coding: utf-8 -*-
"""
render.py — ОТРИСОВКА СПЕЦИФИКАЦИИ В ФАЙЛ .pptx
==============================================

build_pptx(spec, out_path) :
  1. нормализует спецификацию (spec.normalize);
  2. открывает базовую презентацию корпоративного шаблона (Deck) — остаётся только
     её титульный слайд; берётся облегчённая копия с фонами 4K (nts/compact.py);
  3. для каждого слайда вызывает функцию своего макета (layouts.RENDERERS);
     ошибка в одном слайде не роняет сборку — вместо него ставится слайд-заглушка
     с текстом ошибки, а сама ошибка попадает в список предупреждений;
  4. записывает переходы и анимации, сохраняет файл.
Возвращает (путь, предупреждения, число слайдов).

build_preview_deck(slides, out_path) — те же слайды без титула и финала, для миниатюр вариантов:
возвращает номера первых страниц каждого исходного слайда (слайд может разделиться на
продолжения или пропасть, если в нём нет данных).
"""
import traceback
from pathlib import Path

from pptx.oxml.ns import qn

from .layouts import RENDERERS, Ctx
from .layouts.base import content_slide
from .nts import config as C
from .nts.compact import compact_template
from .nts.deck import Deck
from .nts.shapes import icon_shape
from .nts.theme import use as use_theme
from .spec import normalize
from .templates import BUILTIN, theme_for


def _theme(meta, warnings=None):
    """Свой шаблон из meta.template (None — корпоративный; неизвестный — корпоративный с предупреждением)."""
    tid = (meta or {}).get('template') or ''
    th = theme_for(tid) if tid and tid != BUILTIN else None
    if tid and tid != BUILTIN and th is None and warnings is not None:
        warnings.append('Выбранный шаблон не найден (его удалили?) — презентация собрана на корпоративном шаблоне.')
    return th


def _open(template, theme):
    return Deck(template or (theme.path if theme else compact_template()), keep_first_slide=theme is None, theme=theme)


def build_pptx(spec, out_path, template=None):
    spec, warnings = normalize(spec)
    from .dictionary import for_build
    spec, _ = for_build(spec)                        # словарь Компании, правописание, типографика (1.7)
    theme = _theme(spec['meta'], warnings)
    from .model3d import collect
    with use_theme(theme), icon_shape(spec['meta'].get('icon_shape'), spec['meta'].get('icon_3d')), collect() as live3d:
        return _build(spec, out_path, template, theme, warnings, live3d)


def _build(spec, out_path, template, theme, warnings, live3d=()):
    deck = _open(template, theme)
    ctx = Ctx(deck, spec['meta'])
    title_done = False
    fidx = None
    if spec['meta'].get('facts') and spec['meta'].get('number_notes', True) is not False:
        from .factcheck import index_for                 # источники чисел — в заметки докладчика (1.7)
        fidx = index_for(spec['meta'])
    for i, s in enumerate(spec['slides'], start=1):
        lay = s['layout']
        if fidx is not None and lay not in ('title', 'end', 'agenda', 'section', 'own'):
            s = _with_number_notes(s, fidx)
        if lay == 'title':
            if title_done:
                continue                    # второй титульный слайд не нужен
            title_done = True
        if lay == 'image' and s.get('images'):
            s = _with_credits(s)
        n0 = len(deck.prs.slides)
        try:
            RENDERERS[lay](ctx, s)
            _mark(deck.prs, n0, lay)
        except Exception as e:                       # noqa: BLE001
            warnings.append(f'Слайд {i} («{s.get("title") or lay}»): ошибка отрисовки — {type(e).__name__}: {e}')
            traceback.print_exc()
            sl, top, _ = content_slide(ctx, {'title': s.get('title') or 'Слайд', 'notes': s.get('notes', '')})
            from .nts.shapes import text
            text(sl, C.L, top + 0.2, C.CW, 1.0, f'Не удалось построить макет «{lay}». Измените макет слайда в плане.',
                 size=16, color=C.GRAY)
    if not title_done and theme is None:
        # титульный слайд базовой презентации есть всегда — удаляем его, если он не нужен
        sldIdLst = deck.prs.slides._sldIdLst
        first = list(sldIdLst)[0]
        deck.prs.part.drop_rel(first.rId)
        sldIdLst.remove(first)
    ctx.finalize()
    if live3d:                                       # 3D-модели с галочкой «вращаемая» — объектом PowerPoint 365 (1.7)
        from .model3d import apply_live
        apply_live(live3d, warnings)
    out_path = Path(out_path)
    deck.save(out_path)
    return out_path, warnings, len(deck.prs.slides)


def _mark(prs, n0, lay):
    """Слайды, которые нарисовал макет, помнят его имя (<p:cSld name="zn:process">, PowerPoint его не показывает):
    по нему «План по образцу» точно узнаёт вид слайда, когда эта презентация станет образцом (1.7)."""
    from .readers.pptx_reader import ZN_MARK
    for sl in list(prs.slides)[n0:]:
        sl._element.find(qn('p:cSld')).set('name', ZN_MARK + lay)


def _with_number_notes(s, fidx):
    """«Источники чисел» (engine/factcheck) — в конец заметок докладчика."""
    from .factcheck import notes_block
    try:
        block = notes_block(s, fidx)
    except Exception:                                    # noqa: BLE001 — сверка не мешает сборке
        return s
    if not block:
        return s
    return dict(s, notes=((s.get('notes') or '').rstrip() + '\n\n' if s.get('notes') else '') + block)


def _with_credits(s):
    """Авторство фотографий слайда (автор, лицензия, источник) — в конец заметок докладчика, если его там нет."""
    from .pictures import image_credits
    add = [c for c in image_credits(s) if c not in (s.get('notes') or '')]
    if not add:
        return s
    return dict(s, notes=((s.get('notes') or '').rstrip() + '\n\n' if s.get('notes') else '') + '\n'.join(add))


def _number_from(prs, number, pad_hidden):
    """Номер в колонтитуле — как в готовой презентации, а не «1». PowerPoint берёт его из
    firstSlideNum; LibreOffice этот атрибут не читает, поэтому перед слайдами ставятся пустые
    скрытые слайды: номер они сдвигают, а в PDF не попадают (номера страниц PDF не меняются)."""
    if not pad_hidden:
        prs.part._element.set('firstSlideNum', str(number))
        return
    lst = prs.slides._sldIdLst
    lay = prs.slide_layouts[len(prs.slide_layouts) - 1]
    for _ in range(min(number, 300) - 1):
        s = prs.slides.add_slide(lay)
        for ph in list(s.placeholders):
            ph._element.getparent().remove(ph._element)
        s._element.set('show', '0')
        el = lst[-1]
        lst.remove(el)
        lst.insert(0, el)
    prs.part.rename_slide_parts([sid.rId for sid in lst])    # add_slide нумерует части по числу слайдов — без повторов


def build_preview_deck(slides, out_path, meta=None, template=None, number=None, pad_hidden=True):
    """Колода для миниатюр: каждый слайд нормализуется отдельно, чтобы знать, с какой
    страницы он начинается. Возвращает (путь, [номер первой страницы или None для каждого]).
    number — номер первого слайда в готовой презентации (для просмотра крупно): см. _number_from."""
    theme = _theme(meta)
    with use_theme(theme), icon_shape((meta or {}).get('icon_shape'), (meta or {}).get('icon_3d')):
        return _preview(slides, out_path, meta, template, number, pad_hidden, theme)


def _preview(slides, out_path, meta, template, number, pad_hidden, theme):
    deck = _open(template, theme)
    m = dict(meta or {}, animations=False)
    ctx = Ctx(deck, m)
    starts = []
    title_done = False
    for s in slides:
        sp, _ = normalize({'meta': m, 'slides': [s]}, add_title_end=False)
        if not sp['slides']:
            starts.append(None)
            continue
        if sp['slides'][0]['layout'] == 'title':        # титульный — это первый слайд базовой презентации
            if title_done:
                starts.append(None)
                continue
            title_done = True
            starts.append(0 if theme is None else len(deck.prs.slides))
        else:
            starts.append(len(deck.prs.slides))
        for s2 in sp['slides']:
            try:
                RENDERERS[s2['layout']](ctx, s2)
            except Exception:                            # noqa: BLE001
                traceback.print_exc()
                content_slide(ctx, {'title': s2.get('title') or 'Слайд'})
    if not title_done and theme is None:                 # титульный не нужен — убираем, номера страниц сдвигаются
        sldIdLst = deck.prs.slides._sldIdLst
        first = list(sldIdLst)[0]
        deck.prs.part.drop_rel(first.rId)
        sldIdLst.remove(first)
        starts = [st - 1 if st is not None else None for st in starts]
    if theme is not None:                                # свой шаблон: перенос в его поля, цвета и шрифт
        theme.finish(ctx)
    if number and number > 1 and (not title_done or theme is not None):
        _number_from(deck.prs, number, pad_hidden)
    out_path = Path(out_path)
    deck.save(out_path)
    return out_path, starts
