# -*- coding: utf-8 -*-
"""
dictionary.py — КОРПОРАТИВНЫЙ СЛОВАРЬ, ПРАВОПИСАНИЕ И ТИПОГРАФИКА (1.7)
=====================================================================
Три уровня правки текста слайдов:
  1. Словарь Компании (output/dictionary.json, окно «📖 Словарь»): как правильно пишутся названия обществ,
     месторождений, должностей и терминов и как их пишут неправильно. Встроено только название самой Компании;
     остальное вносит автор или загружает из Excel/CSV (столбцы: «правильно», «как ещё пишут», «вид»).
  2. Правописание: частые ошибки деловых текстов («в течении года», «согласно приказа», «по окончанию») и
     сокращения («млн. руб.» → «млн руб.», «т.е.» → «т. е.», «м3» → «м³», «CO2» → «CO₂», «2026 г» → «2026 г.»).
  3. Типографика: кавычки «ёлочки» (внутри — „лапки“), тире «—» между словами, «–» в диапазонах
     («2026–2028», «8–10 %»), многоточие «…», лишние и неразрывные пробелы (после предлогов, между
     числом и единицей).
Сборка применяет всё это сама (если в словаре не выключено «Исправлять при сборке»; типографика — всегда).
Окно «✔ Проверить» → «Текст» показывает, что будет исправлено; «Оставить как есть» запоминает исключение
в плане (meta.text_skip), и сборка его не трогает. Числа не меняются: правки касаются только написания.
Свои слайды из PowerPoint не правятся.
"""
import copy
import csv
import io
import json
import re

from .nts import config as C
from .textutil import typo

DICT_FILE = C.OUTPUT_DIR / 'dictionary.json'
CATS = ('общество', 'месторождение', 'должность', 'термин')
KINDS = ('словарь', 'правописание', 'типографика')
COMPANY = [('АО «Зарубежнефть»', ['АО Зарубежнефть'], 'общество')]
NBSP = ' '
_W = r'[0-9A-Za-zА-Яа-яЁё]'

_END = {'окончанию': 'окончании', 'завершению': 'завершении', 'истечению': 'истечении', 'прибытию': 'прибытии',
        'приезду': 'приезде', 'возвращению': 'возвращении', 'приходу': 'приходе'}


def _po(m):
    w = m.group(2)
    new = _END[w.lower()]
    return f'{m.group(1)} {new[0].upper() + new[1:] if w[0].isupper() else new}'


def _soglasno(m):
    return f'{m.group(1)} {m.group(2)}{"у" if m.group(3) == "а" else "ю"}'


# (шаблон, замена, пояснение) — правописание и сокращения
RULES = [
    (r'(?i)\b(в) течении\b(?!\s+(?:рек|ручь|вод|поток|болезн|процесс))', r'\1 течение', '«в течение» — о времени'),
    (r'(?i)\b(в)следствии\b', r'\1следствие', '«вследствие» — пишется слитно, на конце «е»'),
    (r'(?i)\b(в) последствии\b', r'\1последствии', '«впоследствии» — слитно'),
    (r'(?i)\b(в) виду того(?=,? что)', r'\1виду того', '«ввиду того что» — слитно'),
    (r'(?i)\b(н)е смотря на\b', r'\1есмотря на', '«несмотря на» — слитно'),
    (r'(?i)\b(н)е взирая на\b', r'\1евзирая на', '«невзирая на» — слитно'),
    (r'(?i)\b(по) (' + '|'.join(_END) + r')\b', _po, '«по окончании», «по завершении», «по приезде»'),
    (r'(?i)\b(согласно) (приказ|договор|план|график|регламент|протокол|решени|распоряжени|положени|требовани)(а|я)\b',
     _soglasno, '«согласно приказу» — дательный падеж'),
    (r'\b(млн|млрд|трлн)\.[  ]*(?=[а-яё$€₽])', r'\1 ', '«млн», «млрд» — без точки'),
    (r'\bтыс\.(?=[а-яё])', 'тыс. ', 'пробел после «тыс.»'),
    (r'\bруб(?![.А-Яа-яЁё])', 'руб.', '«руб.» — с точкой'),
    (r'\bт\.\s?(е|к|д|п|ч)\.', r'т. \1.', 'сокращения с пробелом: «т. е.», «т. д.»'),
    (r'\bг\.\s?г\.', 'гг.', '«гг.»'),
    (r'\b((?:19|20)\d{2})\s?(гг|г)(?![А-Яа-яЁё])\.?', r'\1 \2.', '«2026 г.», «2026–2028 гг.» — с пробелом и точкой'),
    (r'\bкв\.\s?м\b\.?', 'м²', '«м²»'),
    (r'\bкуб\.\s?м\b\.?', 'м³', '«м³»'),
    (r'\b(к?м)([23])\b', lambda m: m.group(1) + ('²' if m.group(2) == '2' else '³'), '«м²», «м³»'),
    (r'\b[CС][OО]2\b', 'CO₂', '«CO₂»'),
    (r'№(?=\d)', '№' + NBSP, 'пробел после «№»'),
]
_RULES = [(re.compile(p), r, why) for p, r, why in RULES]


def _norm(s):
    return re.sub(r'[\s ]+', ' ', s).strip().lower()


# ---------------------------------------------------------------------------------------------
# Типографика
# ---------------------------------------------------------------------------------------------
def _quotes(t):
    """Прямые и “английские” кавычки → «ёлочки», вложенные — „лапки“. Непарная закрывающая остаётся как была."""
    if not re.search(r'["“”«]', t):
        return t
    out, depth = [], 0
    for i, ch in enumerate(t):
        prev = t[i - 1] if i else ' '
        nxt = t[i + 1] if i + 1 < len(t) else ' '
        if ch == '«' or (ch in '"“' and (prev.isspace() or prev in '([{—–-/«„' or ch == '“') and not nxt.isspace()):
            out.append('«' if depth == 0 else '„')
            depth += 1
        elif ch in '"”»':
            if depth == 0:
                out.append(ch)                               # 5" — дюймы, а не кавычка
                continue
            depth -= 1
            out.append('»' if depth == 0 else '“')
        else:
            out.append(ch)
    return ''.join(out)


def typography(t):
    """Кавычки, тире, диапазоны, многоточие, лишние и неразрывные пробелы. Тексты с адресами и кодом не трогаются."""
    if not isinstance(t, str) or not t.strip() or re.search(r'://|www\.|[{}<>]|\\', t):
        return t
    t = _quotes(t)
    t = re.sub(r'(?<=[^\s:(])[  ]+[-–—][  ]+(?=\S)', NBSP + '— ', t)      # тире между словами
    t = re.sub(r'(?<![\d/:\-–])(?<!\d[.,])(\d+(?:[.,]\d+)?)\s?[-–—]\s?(\d+(?:[.,]\d+)?)(?![\d/:\-–]|[.,]\d)',
               r'\1–\2', t)                                                          # диапазон: 2026–2028, 8–10
    t = t.replace('...', '…')
    t = re.sub(r'(?<=\S) {2,}', ' ', t)
    t = re.sub(r' +([,;!?»“)])', r'\1', t)
    t = re.sub(r' +\.(?=\s|$)', '.', t)
    t = re.sub(r'([«„(]) +', r'\1', t)
    return typo(t)


def _snip(before, after, ctx=18):
    """Короткий показ правки: общее начало и конец срезаются, вокруг изменения — немного контекста."""
    a, b = before.replace(NBSP, ' '), after.replace(NBSP, ' ')
    p = 0
    while p < min(len(a), len(b)) and a[p] == b[p]:
        p += 1
    s = 0
    while s < min(len(a), len(b)) - p and a[-1 - s] == b[-1 - s]:
        s += 1
    lo = max(0, p - ctx)
    lo = a.rfind(' ', 0, lo + 1) + 1 if lo else 0
    ha, hb = len(a) - s, len(b) - s

    def cut(x, h):
        hi = min(len(x), h + ctx)
        sp = x.find(' ', hi)
        hi = len(x) if sp < 0 else sp
        return ('…' if lo else '') + x[lo:hi] + ('…' if hi < len(x) else '')
    return cut(a, ha), cut(b, hb)


def _around(m, ctx=16):
    """Немного текста слева и справа от найденного — чтобы правку было видно в окне проверки."""
    s, a, b = m.string, m.start(), m.end()
    left, right = s[max(0, a - ctx):a], s[b:b + ctx]
    if a > ctx and ' ' in left:
        left = '…' + left[left.find(' ') + 1:]
    if b + ctx < len(s) and ' ' in right:
        right = right[:right.rfind(' ')] + '…'
    return left.replace(NBSP, ' '), right.replace(NBSP, ' ')


# ---------------------------------------------------------------------------------------------
# Словарь
# ---------------------------------------------------------------------------------------------
def _variants(right):
    """Варианты, которые узнаются сами: прямые и английские кавычки, без кавычек (если есть «АО», «ООО»…), «е» вместо «ё»."""
    out = set()
    m = re.match(r'^(.*?)«(.+)»$', right)
    if m:
        pre, name = m.group(1), m.group(2)
        out |= {f'{pre}"{name}"', f'{pre}“{name}”', f'{pre}„{name}“'}
        if pre.strip():
            out.add(f'{pre}{name}')
    if 'ё' in right or 'Ё' in right:
        out.add(right.replace('ё', 'е').replace('Ё', 'Е'))
    return {v for v in out if v and v != right}


def _clean_entry(e):
    right = str((e or {}).get('right') or '').strip()[:200]
    wrong = e.get('wrong') or []
    if isinstance(wrong, str):
        wrong = re.split(r'[;\n]', wrong)
    wrong = list(dict.fromkeys(str(w).strip()[:200] for w in wrong if str(w).strip() and str(w).strip() != right))[:30]
    return {'right': right, 'wrong': wrong, 'cat': e.get('cat') if e.get('cat') in CATS else 'термин'}


def load():
    """{'entries': [{'right', 'wrong': [...], 'cat'}], 'auto': bool} — словарь автора (встроенные записи — в builtin())."""
    try:
        d = json.loads(DICT_FILE.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        d = {}
    entries = [_clean_entry(e) for e in d.get('entries') or [] if isinstance(e, dict)]
    return {'entries': [e for e in entries if e['right']], 'auto': d.get('auto', True) is not False}


def save(d):
    out, seen = [], set()
    for e in d.get('entries') or []:
        if not isinstance(e, dict):
            continue
        e = _clean_entry(e)
        if e['right'] and e['right'].lower() not in seen:
            seen.add(e['right'].lower())
            out.append(e)
    DICT_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = DICT_FILE.with_suffix('.tmp')
    tmp.write_text(json.dumps({'v': 1, 'auto': d.get('auto', True) is not False, 'entries': out[:2000]},
                              ensure_ascii=False, indent=1), encoding='utf-8')
    tmp.replace(DICT_FILE)
    return load()


def builtin():
    return [{'right': r, 'wrong': w, 'cat': c, 'builtin': True} for r, w, c in COMPANY]


class Fixer:
    """Правка одного текста: словарь → правописание → типографика.
    fix(t) → (новый текст, [{'kind', 'before', 'after', 'why', 'key'}]). skip — ключи правок «оставить как есть»."""

    def __init__(self, entries=(), kinds=KINDS, skip=()):
        self.kinds, self.skip = set(kinds), set(skip or ())
        self.lookup = {}
        if 'словарь' in self.kinds:
            for e in builtin() + list(entries or []):
                right = e['right']
                for w in [right] + list(e.get('wrong') or []) + sorted(_variants(right)):
                    if w and (_norm(w) not in self.lookup or w == right):
                        self.lookup[_norm(w)] = right
        alts = sorted(self.lookup, key=len, reverse=True)
        self.rx = re.compile(r'(?<!' + _W + r')(?:' + '|'.join(re.escape(a).replace(r'\ ', r'[\s ]+') for a in alts)
                             + r')(?!' + _W + r')', re.IGNORECASE) if alts else None

    def fix(self, t):
        if not isinstance(t, str) or not t.strip():
            return t, []
        changes = []

        def note(kind, m, after, why):
            before = m.group(0)
            if re.sub(r'[\s\u00a0]+', ' ', after) == re.sub(r'[\s\u00a0]+', ' ', before):
                return before                            # разница только в неразрывном пробеле — не правка
            key = f'{kind}|{_norm(before)}'
            if key in self.skip:
                return before
            left, right = _around(m)
            changes.append({'kind': kind, 'before': left + before + right, 'after': left + after + right, 'why': why,
                            'key': key, 'word': before, 'fixed': after})
            return after

        cur = t
        if self.rx is not None:
            def dict_sub(m):
                right = self.lookup.get(_norm(m.group(0)), m.group(0))
                if m.group(0)[:1].isupper() and right[:1].islower():
                    right = right[0].upper() + right[1:]
                return note('словарь', m, right, 'написание из словаря Компании')
            cur = self.rx.sub(dict_sub, cur)
        if 'правописание' in self.kinds:
            for rx, rep, why in _RULES:
                cur = rx.sub(lambda m, rep=rep, why=why: note('правописание', m,
                                                              m.expand(rep) if isinstance(rep, str) else rep(m), why), cur)
        if 'типографика' in self.kinds:
            new = typography(cur)
            if new.replace(NBSP, ' ') != cur.replace(NBSP, ' '):
                b, a = _snip(cur, new)
                changes.append({'kind': 'типографика', 'before': b, 'after': a, 'key': '', 'word': '', 'fixed': '',
                                'why': 'кавычки «ёлочки», тире, диапазоны, многоточие, пробелы'})
            cur = new
        return cur, changes


# ---------------------------------------------------------------------------------------------
# План
# ---------------------------------------------------------------------------------------------
TEXT_KEYS = ('title', 'subtitle', 'lead', 'conclusion', 'center', 'text', 'caption', 'label', 'unit', 'unit2', 'name',
             'section', 'x', 'y')
STR_LISTS = ('insights', 'paragraphs', 'categories', 'columns', 'items')
NESTED = ('items', 'left', 'right', 'chart', 'series', 'images', 'axes')
SKIP_LAYOUTS = ('own',)


def _walk(obj, path, fn):
    """Тексты слайда: fn(путь, текст) → новый текст. Числа, значки, картинки, заметки не трогаются."""
    for k in list(obj):
        v = obj[k]
        if isinstance(v, str) and k in TEXT_KEYS:
            obj[k] = fn(path + [k], v)
        elif isinstance(v, list) and (k in STR_LISTS or k in NESTED):
            for j, x in enumerate(v):
                if isinstance(x, str) and k in STR_LISTS:
                    v[j] = fn(path + [k, j], x)
                elif isinstance(x, dict) and k in NESTED:
                    _walk(x, path + [k, j], fn)
        elif k == 'rows' and isinstance(v, list):
            for a, r in enumerate(v):
                if isinstance(r, list):
                    for b, c in enumerate(r):
                        if isinstance(c, str):
                            r[b] = fn(path + [k, a, b], c)
        elif isinstance(v, dict) and k in NESTED:
            _walk(v, path + [k], fn)


class _Pair:
    """Две правки: обычная и для подписей данных диаграммы (категории, имена рядов — это данные: без типографики,
    чтобы в «Изменить данные» PowerPoint не появлялись неразрывные пробелы)."""

    def __init__(self, entries, kinds, skip):
        self.text = Fixer(entries, kinds, skip)
        self.data = Fixer(entries, [k for k in kinds if k != 'типографика'], skip)

    def fix(self, path, t):
        data = bool(path) and path[0] == 'chart' and ('categories' in path or path[-1] == 'name')
        return (self.data if data else self.text).fix(t)


def _skip_of(spec):
    return [str(x) for x in ((spec or {}).get('meta') or {}).get('text_skip') or [] if isinstance(x, str)][:500]


def _slides(spec):
    for i, s in enumerate((spec or {}).get('slides') or []):
        if isinstance(s, dict) and s.get('layout') not in SKIP_LAYOUTS:
            yield i, s


def check(spec, entries=(), kinds=KINDS):
    """Что исправится → {'findings': [{'id', 'i', 'title', 'path', 'kind', 'before', 'after', 'why', 'key'}], 'counts'}."""
    fx = _Pair(entries, kinds, _skip_of(spec))
    out = []
    for i, s in _slides(copy.deepcopy(spec)):
        title = re.sub(r'\s+', ' ', str(s.get('title') or '')) or f'Слайд {i + 1}'

        def fn(path, t, i=i, title=title):
            new, ch = fx.fix(path, t)
            for c in ch:
                out.append(dict(c, id=len(out), i=i, title=title, path=path))
            return new
        _walk(s, [], fn)
    counts = {k: sum(1 for f in out if f['kind'] == k) for k in KINDS}
    return {'findings': out, 'counts': counts}


def apply(spec, entries=(), kinds=KINDS, where=None, skip=None, out=None):
    """Исправить план (копия) → (план, число правок). where — [(номер слайда, путь)] или None (везде);
    skip — дополнительные ключи «оставить как есть» (к meta.text_skip плана); out — список, куда сложить
    изменённые места {'i', 'path', 'old', 'text'} (окно проверки меняет только их)."""
    sp = copy.deepcopy(spec)
    fx = _Pair(entries, kinds, _skip_of(sp) + list(skip or ()))
    n = [0]
    want = None if where is None else {(int(i), tuple(p)) for i, p in where}
    for i, s in _slides(sp):
        def fn(path, t, i=i):
            if want is not None and (i, tuple(path)) not in want:
                return t
            new, ch = fx.fix(path, t)
            n[0] += len(ch)
            if out is not None and new != t:
                out.append({'i': i, 'path': path, 'old': t, 'text': new})
            return new
        _walk(s, [], fn)
    return sp, n[0]


def settings_kinds(d):
    return KINDS if d['auto'] else ('типографика',)


def fix_plan(spec):
    """Автопилот: исправить план так же, как при сборке → (план, {'findings', 'counts'}) — для отчёта."""
    d = load()
    r = check(spec, d['entries'], settings_kinds(d))
    sp, _ = apply(spec, d['entries'], settings_kinds(d))
    return sp, r


def for_build(spec):
    """Перед сборкой: словарь и правописание (если «Исправлять при сборке» включено) и типографика → (план, число правок)."""
    try:
        d = load()
        return apply(spec, d['entries'], settings_kinds(d))
    except Exception:                                    # noqa: BLE001 — правка текста не должна мешать сборке
        return spec, 0


# ---------------------------------------------------------------------------------------------
# Загрузка и выгрузка словаря
# ---------------------------------------------------------------------------------------------
HEADERS = ('правильно', 'как правильно', 'правильное написание', 'название', 'верно')


def _text(data):
    """Текст CSV/TXT в любой кодировке, в которой его сохраняет Windows: UTF-8 (с BOM или без),
    «Текст Юникод» Excel (UTF-16) или Windows-1251 («CSV (разделители — точка с запятой)» в Excel)."""
    if data[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return data.decode('utf-16', 'replace')
    try:
        return data.decode('utf-8-sig')
    except UnicodeDecodeError:
        return data.decode('cp1251', 'replace')


def _rows_from(data, name):
    ext = name.lower().rsplit('.', 1)[-1]
    if ext in ('xlsx', 'xlsm'):
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        rows = [[('' if c is None else str(c)).strip() for c in r] for r in wb.worksheets[0].iter_rows(values_only=True)]
        wb.close()
        return rows
    text = _text(data)
    if not text.strip():
        return []
    if ext == 'txt' and '\t' not in text and ';' not in text:
        out = []
        for line in text.splitlines():
            parts = re.split(r'\s*(?:→|->|=>|=)\s*', line.strip(), maxsplit=1)
            if len(parts) == 2:
                out.append([parts[1], parts[0]])                  # «неправильно → правильно»
            elif parts[0]:
                out.append([parts[0], ''])
        return out
    first = text.lstrip().split('\n', 1)[0]
    delim = max(';\t,', key=first.count) if any(d in first for d in ';\t,') else ';'   # Excel в России пишет CSV через «;»
    return [[c.strip() for c in r] for r in csv.reader(io.StringIO(text), delimiter=delim)]


def parse_file(data, name):
    """Строки «правильно | как ещё пишут (через «;») | вид» → записи словаря. TXT — «неправильно → правильно»."""
    entries = {}
    for r in _rows_from(data, name):
        r = list(r) + ['', '', '']
        right, wrong, cat = r[0].strip()[:200], r[1].strip(), r[2].strip().lower()
        if not right or right.lower() in HEADERS:
            continue
        e = entries.setdefault(right.lower(), {'right': right, 'wrong': [], 'cat': 'термин'})
        e['wrong'] += [w.strip() for w in re.split(r'[;\n]', wrong) if w.strip()]
        for c in CATS:
            if cat and (cat.startswith(c[:5]) or c.startswith(cat[:5])):
                e['cat'] = c
    return [_clean_entry(e) for e in entries.values()]


def merge(old, new):
    by = {e['right'].lower(): dict(e, wrong=list(e.get('wrong') or [])) for e in old}
    for e in new:
        cur = by.setdefault(e['right'].lower(), {'right': e['right'], 'wrong': [], 'cat': e.get('cat') or 'термин'})
        cur['wrong'] = list(dict.fromkeys(cur['wrong'] + list(e.get('wrong') or [])))
        if e.get('cat') and e['cat'] != 'термин':
            cur['cat'] = e['cat']
    return list(by.values())


def to_csv(entries):
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=';', lineterminator='\r\n')
    w.writerow(['Правильно', 'Как ещё пишут (через «;»)', 'Вид'])
    for e in entries:
        w.writerow([e['right'], '; '.join(e.get('wrong') or []), e.get('cat') or 'термин'])
    return '﻿' + buf.getvalue()
