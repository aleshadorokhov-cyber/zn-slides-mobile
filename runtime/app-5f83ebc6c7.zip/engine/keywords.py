# -*- coding: utf-8 -*-
"""
keywords.py — БАЗА КЛЮЧЕВЫХ СЛОВ ПО ТЕМАТИКАМ (1.8)
===================================================
Темы докладов Компании (геологоразведка, бурение, добыча, энергоэффективность, экология, финансы…) и их
ключевые слова. База одна на всех пользователей конструктора: output/keywords.json (встроенные темы — SEED,
дальше её пополняют люди и модель ИИ).

Для чего:
  • тема доклада — по материалам при анализе (meta.topics, meta.keywords): видна над планом;
  • ключевые слова материалов — подсказки у слайда в «🔎 Подходящих фразах» (щелчок — поиск фраз);
  • темы записей «📚 Библиотеки материалов».

Пополнение:
  • вручную — окно «🏷 Ключевые слова»;
  • моделью ИИ (llm_enrich) — после каждого анализа, если включено «Пополнять автоматически», и по кнопке.
    Модель только выписывает термины из текста материалов; термин, которого в тексте нет, отбрасывается.
    Автоматически — только локальная модель (документы не уходят наружу); облачная — по кнопке и только с
    согласием в «⚙ Модель ИИ» (проверяет llm_client.chat);
  • без модели (candidates) — частые слова и сочетания материалов, которых ещё нет в базе: предлагаются, сами
    в базу не попадают.
Числа и факты на слайды база не добавляет.
"""
import csv
import io
import json
import re
import threading
import time
from collections import Counter

from .nts import config as C

KW_FILE = C.OUTPUT_DIR / 'keywords.json'
MAX_TOPICS = 80
MAX_WORDS = 400                         # слов в одной теме
MAX_NEW_TOPICS = 2                      # новых тем от модели за один раз
SRC = ('seed', 'user', 'llm')

SEED = [
    ('geology', 'Геологоразведка и запасы', 'геологоразведка; ГРР; сейсморазведка; запасы нефти; ресурсная база; прирост '
     'запасов; лицензионный участок; разведочное бурение; поисковая скважина; пласт; коллектор; керн; геологическая '
     'модель; месторождение; подсчёт запасов; категория запасов; перспективная структура; нефтенасыщенность'),
    ('drilling', 'Бурение и строительство скважин', 'бурение; буровая установка; скважина; горизонтальная скважина; '
     'боковой ствол; ЗБС; буровой раствор; долото; обсадная колонна; цементирование; проходка; наклонно-направленное '
     'бурение; многозабойная скважина; конструкция скважины; освоение скважины; капитальный ремонт скважин; КРС'),
    ('production', 'Добыча и разработка месторождений', 'добыча нефти; добыча газа; разработка месторождения; фонд '
     'скважин; дебит; обводнённость; пластовое давление; заводнение; нагнетательная скважина; коэффициент извлечения '
     'нефти; КИН; нефтеотдача; методы увеличения нефтеотдачи; МУН; гидроразрыв пласта; ГРП; интенсификация добычи; '
     'механизированная добыча; УЭЦН; ШГН; газлифт; газовый фактор; попутный нефтяной газ; ПНГ; трудноизвлекаемые '
     'запасы; ТРИЗ'),
    ('offshore', 'Шельф и морские проекты', 'шельф; морская платформа; морское месторождение; шельфовый проект; подводный '
     'добычной комплекс; буровое судно; плавучая установка; ледовая обстановка; морская сейсморазведка; акватория; '
     'береговая база; СПБУ'),
    ('refining', 'Переработка и нефтехимия', 'нефтепереработка; НПЗ; глубина переработки; нефтехимия; нефтепродукты; '
     'газопереработка; ГПЗ; каталитический крекинг; гидроочистка; выход светлых нефтепродуктов; моторное топливо; '
     'бензин; дизельное топливо; мазут; сжиженный природный газ; СПГ'),
    ('transport', 'Транспорт и хранение', 'трубопровод; нефтепровод; газопровод; нефтесборная сеть; перекачка нефти; '
     'насосная станция; резервуарный парк; хранение нефти; отгрузка; нефтеналивной терминал; танкер; логистика; '
     'сдача нефти; коммерческий учёт'),
    ('energy', 'Энергоэффективность и энергетика', 'энергоэффективность; энергосбережение; энергопотребление; '
     'электроэнергия; энергоресурсы; удельный расход; тариф; собственная генерация; газотурбинная электростанция; ГТЭС; '
     'частотное регулирование; частотный преобразователь; энергоаудит; учёт энергопотребления; компрессорная станция; '
     'КПД; потери электроэнергии; возобновляемые источники энергии; ВИЭ; солнечная электростанция'),
    ('ecology', 'Экология и ESG', 'экология; охрана окружающей среды; выбросы; парниковые газы; углеродный след; '
     'декарбонизация; ESG; устойчивое развитие; рекультивация; утилизация попутного газа; факельная установка; '
     'сжигание газа; отходы; нефтешлам; разлив нефти; экологический мониторинг; углеродная нейтральность; '
     'водопользование; биоразнообразие'),
    ('safety', 'Промышленная безопасность и охрана труда', 'промышленная безопасность; охрана труда; ОТиПБ; травматизм; '
     'несчастный случай; происшествие; авария; инцидент; оценка рисков; средства индивидуальной защиты; СИЗ; пожарная '
     'безопасность; чрезвычайная ситуация; культура безопасности; LTIF; наряд-допуск; предупреждение аварий'),
    ('digital', 'Цифровизация и ИТ', 'цифровизация; цифровая трансформация; цифровой двойник; искусственный интеллект; '
     'машинное обучение; нейросеть; большие данные; автоматизация; АСУ ТП; информационная система; интеллектуальное '
     'месторождение; датчик; телеметрия; кибербезопасность; платформа данных; роботизация; предиктивная аналитика'),
    ('finance', 'Финансы и экономика', 'выручка; EBITDA; прибыль; чистая прибыль; затраты; себестоимость; капитальные '
     'вложения; CAPEX; операционные затраты; OPEX; инвестиции; инвестиционный проект; NPV; IRR; срок окупаемости; '
     'экономический эффект; бюджет; рентабельность; налог; НДПИ; денежный поток; финансирование; дивиденды'),
    ('hr', 'Персонал и обучение', 'персонал; кадры; численность персонала; обучение; повышение квалификации; кадровый '
     'резерв; молодой специалист; наставничество; компетенции; производительность труда; мотивация; оплата труда; '
     'социальная политика; вахта; корпоративная культура; подготовка кадров; аттестация'),
    ('science', 'Наука и инновации', 'НИОКР; научные исследования; инновации; технология; пилотный проект; '
     'опытно-промышленные испытания; ОПИ; внедрение; патент; научно-технический совет; НТС; исследовательский центр; '
     'лабораторные исследования; моделирование; новая технология; грант; тиражирование'),
    ('international', 'Зарубежные проекты и сотрудничество', 'зарубежный проект; международное сотрудничество; '
     'совместное предприятие; партнёр; соглашение; контракт; соглашение о разделе продукции; СРП; межправительственное '
     'соглашение; доля участия; оператор проекта; зарубежные активы; экспорт; страна присутствия'),
    ('supply', 'Закупки, оборудование и сервис', 'закупки; тендер; поставщик; подрядчик; импортозамещение; локализация; '
     'оборудование; ремонт; техническое обслуживание; ТОиР; сервис; запасные части; насосное оборудование; износ '
     'оборудования; модернизация; отечественное оборудование; склад; договор поставки'),
    ('strategy', 'Стратегия и управление', 'стратегия; стратегическая цель; ключевые показатели эффективности; КПЭ; KPI; '
     'целевые показатели; бизнес-план; программа развития; приоритеты; управление проектами; портфель проектов; '
     'эффективность; дорожная карта; совет директоров; правление; корпоративное управление; риск-менеджмент; '
     'контроль исполнения'),
]

_LOCK = threading.RLock()
_JOB = {'running': False}
_WORD = re.compile(r'[0-9A-Za-zА-Яа-яЁё]+(?:[-‐][0-9A-Za-zА-Яа-яЁё]+)*')
_ENDS = sorted('''иями ями ами ого его ому ему ыми ими иях ях ах ией ие ые ое ая яя ой ей ий ый ую юю ам ям ом ем ов ев
ия ья ию ью ии ьи ым им ых их ы и а я о е у ю ь й'''.split(), key=len, reverse=True)
STOP = set('''это этот эта эти того также которые который которая которых которой является являются год года году
годы годах лет работа работы работ результат результаты результатов вопрос вопросы часть части данные данных
случае рамках целях основе связи счет счёт числе виде период периода время время мера меры ряд ряда план плана
планы этап этапа этапы итог итоги весь всего всех свой своих более менее очень может могут должен должны нужно
можно также при для или как что чтобы если когда между после перед через около против кроме среди вместо
the and for with that this from are was'''.split())


def stem(w):
    """Основа слова: нижний регистр, ё → е, без частых окончаний, не длиннее 7 букв."""
    w = str(w or '').lower().replace('ё', 'е')
    if len(w) >= 4:
        for e in _ENDS:
            if w.endswith(e) and len(w) - len(e) >= 3:
                w = w[:-len(e)]
                break
    return w[:7]


def _abbr(term):
    """Аббревиатура (ГРП, ESG, CAPEX, ТОиР): ищется целым словом с учётом регистра."""
    t = term.replace(' ', '')
    return len(term.split()) == 1 and 2 <= len(t) <= 8 and sum(ch.isupper() for ch in t) >= max(2, len(t) - 2)


def _term_stems(term):
    return tuple(stem(w) for w in _WORD.findall(term) if len(w) >= 2)


def clean_term(term):
    t = re.sub(r'\s+', ' ', str(term or '')).strip(' .,;:«»"\'()[]—–-')
    return t[:60]


def _key(term):
    return ' '.join(_term_stems(term)) or term.lower()


# --------------------------------------------------------------------------------------
# Хранение
# --------------------------------------------------------------------------------------
def _seed_base():
    now = 0
    return {'v': 1, 'auto': True, 'removed': [], 'last': None,
            'topics': [{'id': tid, 'name': name, 'words': [{'w': w.strip(), 'src': 'seed', 'at': now}
                                                           for w in words.split(';') if w.strip()]}
                       for tid, name, words in SEED]}


def load():
    """База: {'auto', 'topics': [{'id', 'name', 'words': [{'w', 'src', 'by', 'at', 'doc', 'model'}]}], 'last'}.
    Новые встроенные слова будущих версий добавляются сами (кроме удалённых пользователем — 'removed')."""
    with _LOCK:
        try:
            d = json.loads(KW_FILE.read_text(encoding='utf-8'))
            if not isinstance(d, dict) or not isinstance(d.get('topics'), list):
                raise ValueError
        except (OSError, ValueError):
            return _seed_base()
        removed = set(d.get('removed') or [])
        have = {t.get('id'): t for t in d['topics'] if isinstance(t, dict)}
        for tid, name, words in SEED:
            if f'{tid}|*' in removed:
                continue
            t = have.get(tid)
            if t is None:
                t = {'id': tid, 'name': name, 'words': []}
                d['topics'].append(t)
            keys = {_key(x.get('w', '')) for x in t.get('words') or []}
            for w in words.split(';'):
                w = w.strip()
                if w and _key(w) not in keys and f'{tid}|{_key(w)}' not in removed:
                    t.setdefault('words', []).append({'w': w, 'src': 'seed', 'at': 0})
        d.setdefault('auto', True)
        return d


def save(d):
    with _LOCK:
        KW_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = KW_FILE.with_suffix('.tmp')
        tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding='utf-8')
        tmp.replace(KW_FILE)


def _topic(d, ref):
    """Тема по id или по названию (без регистра)."""
    ref = str(ref or '').strip()
    low = ref.casefold().replace('ё', 'е')
    for t in d['topics']:
        if t.get('id') == ref or str(t.get('name') or '').casefold().replace('ё', 'е') == low:
            return t
    return None


def _new_id(d, name):
    base = re.sub(r'[^0-9a-z]+', '', name.lower())[:12] or 't'
    ids = {t.get('id') for t in d['topics']}
    i, tid = 1, f'u{base}' if base != 't' else 'u1'
    while tid in ids or not re.match(r'^[a-z0-9]+$', tid):
        i += 1
        tid = f'u{i}'
    return tid


def public(d=None):
    d = d or load()
    tops = [{'id': t['id'], 'name': t['name'], 'words': t.get('words') or [], 'n': len(t.get('words') or []),
             'seed': any(t['id'] == s[0] for s in SEED)} for t in d['topics']]
    return {'topics': tops, 'auto': d.get('auto', True) is not False, 'last': d.get('last'),
            'running': _JOB['running'], 'counts': {'topics': len(tops), 'words': sum(t['n'] for t in tops),
                                                   'llm': sum(1 for t in tops for w in t['words'] if w.get('src') == 'llm')}}


def _all_keys(d):
    return {_key(w.get('w', '')) for t in d['topics'] for w in t.get('words') or []}


def add_word(d, topic, word, src='user', by='', doc='', model=''):
    """Добавить слово в тему (по id или названию; новая тема создаётся). True — добавлено."""
    word = clean_term(word)
    if len(word) < 2 or not _WORD.search(word) or word.replace(' ', '').isdigit():
        return False
    t = _topic(d, topic)
    if t is None:
        name = clean_term(topic)[:40]
        if len(name) < 3 or len(d['topics']) >= MAX_TOPICS:
            return False
        t = {'id': _new_id(d, name), 'name': name[:1].upper() + name[1:], 'words': []}
        d['topics'].append(t)
    k = _key(word)
    if any(_key(w.get('w', '')) == k for w in t['words']) or len(t['words']) >= MAX_WORDS:
        return False
    rec = {'w': word, 'src': src if src in SRC else 'user', 'at': round(time.time())}
    for f, v in (('by', by), ('doc', doc), ('model', model)):
        if v:
            rec[f] = str(v)[:120]
    t['words'].append(rec)
    d['removed'] = [r for r in d.get('removed') or [] if r != f"{t['id']}|{k}"]
    return True


def edit(op):
    """Правка из окна «🏷 Ключевые слова»: op = {action: add | remove | move | add_topic | rename | delete_topic | auto,
    topic, word, name, to, on, by}. Возвращает базу для окна; ValueError — понятная причина отказа."""
    a = str(op.get('action') or '')
    with _LOCK:
        d = load()
        t = _topic(d, op.get('topic')) if op.get('topic') else None
        if a == 'add':
            if not add_word(d, op.get('topic') or op.get('name'), op.get('word'), 'user', op.get('by') or ''):
                raise ValueError('Слово уже есть в этой теме или слишком короткое.')
        elif a in ('remove', 'move'):
            if t is None:
                raise ValueError('Нет такой темы.')
            k = _key(clean_term(op.get('word')))
            rec = next((w for w in t['words'] if _key(w.get('w', '')) == k), None)
            if rec is None:
                raise ValueError('Нет такого слова в теме.')
            t['words'].remove(rec)
            if rec.get('src') == 'seed':
                d.setdefault('removed', []).append(f"{t['id']}|{k}")
            if a == 'move':
                dst = _topic(d, op.get('to'))
                if dst is None:
                    raise ValueError('Нет темы, куда перенести слово.')
                if not any(_key(w.get('w', '')) == k for w in dst['words']):
                    dst['words'].append(dict(rec, src='user' if rec.get('src') == 'seed' else rec.get('src')))
        elif a == 'add_topic':
            name = clean_term(op.get('name'))[:40]
            if len(name) < 3:
                raise ValueError('Название темы — не короче 3 знаков.')
            if _topic(d, name):
                raise ValueError('Такая тема уже есть.')
            if len(d['topics']) >= MAX_TOPICS:
                raise ValueError(f'Тем уже {MAX_TOPICS}.')
            t = {'id': _new_id(d, name), 'name': name[:1].upper() + name[1:], 'words': []}
            d['topics'].append(t)
        elif a == 'rename':
            name = clean_term(op.get('name'))[:40]
            if t is None or len(name) < 3:
                raise ValueError('Нет такой темы или короткое название.')
            other = _topic(d, name)
            if other is not None and other is not t:
                raise ValueError('Такая тема уже есть.')
            t['name'] = name
        elif a == 'delete_topic':
            if t is None:
                raise ValueError('Нет такой темы.')
            d['topics'].remove(t)
            if any(t['id'] == s[0] for s in SEED):
                d.setdefault('removed', []).append(f"{t['id']}|*")
        elif a == 'auto':
            d['auto'] = bool(op.get('on'))
        elif a == 'restore':                          # вернуть встроенные темы и слова
            d['removed'] = []
        else:
            raise ValueError('Неизвестное действие.')
        save(d)
        return public(load())


# --------------------------------------------------------------------------------------
# Тема текста
# --------------------------------------------------------------------------------------
class _Text:
    def __init__(self, texts):
        self.raw = '\n'.join(str(t or '') for t in texts)
        self.words = _WORD.findall(self.raw)
        self.stems = [stem(w) for w in self.words]
        self.idx = {}
        for i, s in enumerate(self.stems):
            self.idx.setdefault(s, []).append(i)
        self.set = set(self.stems)

    def count(self, term):
        if _abbr(term):
            return len(re.findall(r'(?<![0-9A-Za-zА-Яа-яЁё])' + re.escape(term) + r'(?![0-9A-Za-zА-Яа-яЁё])', self.raw))
        st = _term_stems(term)
        if not st or st[0] not in self.idx:
            return 0
        if len(st) == 1:
            return len(self.idx[st[0]])
        n = 0
        for i in self.idx[st[0]]:
            if tuple(self.stems[i:i + len(st)]) == st:
                n += 1
        return n

    def has(self, term):
        """Все слова термина есть в тексте (для проверки ответа модели)."""
        if _abbr(term):
            return self.count(term) > 0
        st = _term_stems(term)
        return bool(st) and all(s in self.set for s in st)


def detect(texts, d=None, top=3):
    """Тема материалов: {'topics': [{id, name, score, words: [...]}], 'keywords': [{w, n, topic}]} —
    до top тем и до 24 ключевых слов, найденных в тексте (чаще встречающиеся — первыми)."""
    d = d or load()
    tx = _Text(texts)
    if not tx.words:
        return {'topics': [], 'keywords': []}
    scored, found = [], []
    for t in d['topics']:
        score, words = 0.0, []
        for w in t.get('words') or []:
            n = tx.count(w.get('w', ''))
            if n:
                multi = len(_term_stems(w['w'])) > 1 or _abbr(w['w'])
                score += min(n, 6) * (2 if multi else 1)
                words.append((n, w['w']))
                found.append({'w': w['w'], 'n': n, 'topic': t['name']})
        if score:
            words.sort(key=lambda x: -x[0])
            scored.append({'id': t['id'], 'name': t['name'], 'score': round(score, 1), 'words': [w for _, w in words[:8]]})
    scored.sort(key=lambda x: -x['score'])
    best = scored[0]['score'] if scored else 0
    need = min(4.0, 1 + len(tx.words) / 150)          # у короткого текста (запись библиотеки, поиск) порог ниже
    topics = [s for s in scored if s['score'] >= max(need, best * 0.3)][:top]
    names = {s['name'] for s in topics}
    seen, kws = set(), []
    for f in sorted(found, key=lambda f: (f['topic'] not in names, -f['n'])):
        k = _key(f['w'])
        if k not in seen:
            seen.add(k)
            kws.append(f)
    return {'topics': topics, 'keywords': kws[:24]}


def texts_of_pool(pool_id):
    from .phrases import load_pool
    return [p.get('t') or '' for p in load_pool(pool_id) or [] if isinstance(p, dict)]


# --------------------------------------------------------------------------------------
# Пополнение без модели: частые слова и сочетания материалов, которых нет в базе
# --------------------------------------------------------------------------------------
_ADJ = re.compile(r'(ый|ий|ой|ая|яя|ое|ее|ые|ие|ого|его|ому|ему|ых|их|ым|им|ыми|ими|ую|юю)$')
_VERB = re.compile(r'(ать|ять|ить|еть|уть|ться|тся|ет|ют|ут|ит|ят|ал|ала|али|ило|ует|уют|ировать|ируют)$')
GENERIC = set('''программа программы программе программу система системы систем объект объекты объектов
снижение снижения снижению повышение повышения рост роста увеличение увеличения уменьшение показатель показатели
показателей направление направления задача задачи задач цель цели целей мероприятие мероприятия мероприятий
компания компании общество общества проект проекта проекты проектов документ документа решение решения пример
примера условие условия уровень уровня процесс процесса средства средств срок сроки вариант варианта'''.split())


def candidates(texts, limit=30, d=None):
    """Частые сочетания «прилагательное + существительное» и частые существительные материалов, которых нет в
    базе, с предполагаемой темой: [{w, n, topic}]. Только предложение — сами в базу не попадают."""
    d = d or load()
    have = _all_keys(d)
    tx = _Text(texts)
    ws, ss = tx.words, tx.stems
    low = [w.lower().replace('ё', 'е') for w in ws]

    def ok(i, n):
        w = low[i]
        return len(w) >= n and w not in STOP and not any(ch.isdigit() for ch in w) and not _VERB.search(w)
    pairs, singles, surf = Counter(), Counter(), {}
    for i in range(len(ws)):
        if not ok(i, 4):
            continue
        if i + 1 < len(ws) and ok(i + 1, 4) and _ADJ.search(low[i]) and not _ADJ.search(low[i + 1]):
            k = (ss[i], ss[i + 1])
            pairs[k] += 1
            surf.setdefault(k, Counter())[ws[i].lower() + ' ' + ws[i + 1].lower()] += 1
        if len(low[i]) >= 6 and not _ADJ.search(low[i]) and low[i] not in GENERIC:
            k = (ss[i],)
            singles[k] += 1
            surf.setdefault(k, Counter())[ws[i] if ws[i].isupper() else ws[i].lower()] += 1
    out = []
    for cnt, need in ((pairs, 2), (singles, 3)):
        for k, n in cnt.most_common(200):
            if n < need or ' '.join(k) in have:
                continue
            out.append({'w': surf[k].most_common(1)[0][0], 'n': n, 'topic': _guess_topic(d, tx, k)})
            if len(out) >= limit:
                return out
    return out


def _guess_topic(d, tx, k):
    """Тема для нового слова — та, чьи слова чаще стоят рядом с ним (в пределах 12 слов)."""
    pos = [i for i in tx.idx.get(k[0], [])]
    best, name = 0, ''
    for t in d['topics']:
        near = 0
        for w in t.get('words') or []:
            st = _term_stems(w.get('w', ''))
            for i in tx.idx.get(st[0] if st else '', [])[:200]:
                near += sum(1 for p in pos[:200] if abs(p - i) <= 12 and p != i)
        if near > best:
            best, name = near, t['name']
    return name


# --------------------------------------------------------------------------------------
# Пополнение моделью ИИ
# --------------------------------------------------------------------------------------
LLM_SYSTEM = """Ты пополняешь базу ключевых слов по тематикам для презентаций нефтегазовой компании.
Выписывай только термины, которые есть в присланном тексте. Ничего не придумывай. Ответ — только JSON."""

LLM_USER = """Темы базы: {topics}.

Текст материалов (фрагменты):
\"\"\"
{text}
\"\"\"

Выпиши до 25 ключевых терминов из этого текста: существительные или устойчивые словосочетания из 1–4 слов в
начальной форме; аббревиатуры — как в тексте. Не бери числа, даты, имена людей, названия организаций и общие
слова (работа, год, результат, вопрос). Для каждого термина укажи тему из списка; если ни одна не подходит —
новую тему из 2–4 слов.
Ответ строго в JSON: {{"terms": [{{"term": "...", "topic": "..."}}]}}"""


def _sample(texts, limit=7000):
    """Фрагменты материалов для модели: предложения подряд, пока не наберётся limit знаков."""
    out, n = [], 0
    for t in texts:
        t = re.sub(r'\s+', ' ', str(t or '')).strip()
        if len(t) < 25:
            continue
        out.append(t)
        n += len(t) + 1
        if n >= limit:
            break
    return '\n'.join(out)[:limit]


def llm_enrich(texts, llm, by='', doc='', progress=None):
    """Модель выписывает термины из материалов → новые слова базы (src 'llm'). Возвращает
    {'added': [{w, topic}], 'rejected': n, 'model'}. Термины, которых нет в тексте, отбрасываются."""
    from .llm_client import chat, extract_json
    d = load()
    text = _sample(texts)
    if len(text) < 80:
        raise ValueError('в материалах слишком мало текста')
    names = [t['name'] for t in d['topics']]
    raw = extract_json(chat(llm, LLM_SYSTEM, LLM_USER.format(topics='; '.join(names), text=text),
                            progress=progress, max_tokens=1500))
    terms = raw.get('terms') if isinstance(raw, dict) else raw
    if not isinstance(terms, list):
        raise ValueError('модель ответила не в том виде')
    tx = _Text(texts)
    added, rejected, new_topics = [], 0, 0
    model = str((llm or {}).get('model') or '')
    with _LOCK:
        d = load()
        have = _all_keys(d)
        for it in terms[:40]:
            if not isinstance(it, dict):
                rejected += 1
                continue
            term, topic = clean_term(it.get('term')), clean_term(it.get('topic'))[:40]
            words = term.split()
            if not (3 <= len(term) <= 60) or len(words) > 4 or not tx.has(term) or _key(term) in have \
                    or any(ch.isdigit() for ch in term) or term.lower() in STOP:
                rejected += 1
                continue
            if _topic(d, topic) is None:
                if new_topics >= MAX_NEW_TOPICS or len(topic) < 3:
                    topic = _guess_topic(d, tx, _term_stems(term)) or ''
                    if not topic:
                        rejected += 1
                        continue
                else:
                    new_topics += 1
            if add_word(d, topic, term, 'llm', by, doc, model):
                have.add(_key(term))
                added.append({'w': term, 'topic': (_topic(d, topic) or {}).get('name', topic)})
            else:
                rejected += 1
        d['last'] = {'at': round(time.time()), 'added': added[:60], 'rejected': rejected, 'model': model,
                     'by': str(by)[:80], 'doc': str(doc)[:120], 'error': ''}
        save(d)
    return {'added': added, 'rejected': rejected, 'model': model}


def run_background(texts, llm, by='', doc=''):
    """Пополнение моделью в фоне (после анализа или по кнопке). Не больше одного сразу; False — уже идёт."""
    with _LOCK:
        if _JOB['running']:
            return False
        _JOB['running'] = True

    def work():
        try:
            llm_enrich(texts, llm, by, doc)
        except Exception as e:                          # noqa: BLE001 — записываем причину, окно её покажет
            with _LOCK:
                d = load()
                d['last'] = {'at': round(time.time()), 'added': [], 'rejected': 0, 'model': str((llm or {}).get('model') or ''),
                             'by': str(by)[:80], 'doc': str(doc)[:120], 'error': str(e)[:300]}
                save(d)
        finally:
            _JOB['running'] = False
    threading.Thread(target=work, daemon=True).start()
    return True


# --------------------------------------------------------------------------------------
# Выгрузка и загрузка (CSV «тема;слово»)
# --------------------------------------------------------------------------------------
def export_csv():
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=';')
    w.writerow(['тема', 'ключевое слово', 'откуда'])
    names = {'seed': 'встроено', 'user': 'вручную', 'llm': 'модель ИИ'}
    for t in load()['topics']:
        for x in t.get('words') or []:
            w.writerow([t['name'], x.get('w', ''), names.get(x.get('src'), '')])
    return '﻿' + buf.getvalue()


def import_rows(data, by=''):
    """CSV или TXT «тема;слово» (разделитель ; , или табуляция) → число добавленных слов."""
    text = data.decode('utf-8-sig', errors='replace') if isinstance(data, bytes) else str(data)
    if '�' in text and isinstance(data, bytes):
        text = data.decode('cp1251', errors='replace')
    sample = text[:2000]
    delim = ';' if sample.count(';') >= sample.count('\t') and sample.count(';') >= sample.count(',') else \
        ('\t' if sample.count('\t') >= sample.count(',') else ',')
    n = 0
    with _LOCK:
        d = load()
        for row in csv.reader(io.StringIO(text), delimiter=delim):
            if len(row) < 2 or row[0].strip().lower() in ('тема', 'topic'):
                continue
            if add_word(d, row[0], row[1], 'user', by):
                n += 1
        save(d)
    return n
