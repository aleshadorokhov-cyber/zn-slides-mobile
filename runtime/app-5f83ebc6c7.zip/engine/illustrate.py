# -*- coding: utf-8 -*-
"""
illustrate.py — ИЛЛЮСТРАЦИИ, КОТОРЫЕ РИСУЕТ МОДЕЛЬ ИИ
====================================================

Все иллюстрации к слайдам рисует та же локальная модель ИИ, что строит план (Ollama, LM Studio,
vLLM). Отдельного генератора изображений нет.

Текстовая модель рисует ВЕКТОРНУЮ картинку — код SVG (плоская корпоративная иллюстрация в
фирменных цветах, без надписей). svgdraw.py очищает код и при сборке переводит его в обычные
фигуры PowerPoint: их можно править в презентации, они не размываются при увеличении.

  draw_prompt(slide)          — системный и пользовательский запрос к модели;
  model_drawing(slide, llm)   — запрос → очищенный SVG (одна повторная попытка при ошибке формата);
  illustrated_slide(...)      — вариант слайда «иллюстрация + тезисы»;
  auto_illustrate(spec, …)    — при ИИ-анализе модель рисует иллюстрации к N ключевым слайдам.
"""
from .svgdraw import SvgError, extract_svg, sanitize
from .textutil import clean

PALETTE = '#00326E (тёмно-синий), #0078AE (синий), #4BAF46 (зелёный), #0A8F2D (тёмно-зелёный), ' \
          '#9AC854 (салатовый), #E5EAF0 (светло-серый), #FFFFFF (белый)'

DRAW_SYSTEM = f"""Ты — иллюстратор корпоративных презентаций АО «Зарубежнефть». Ты рисуешь простую плоскую векторную иллюстрацию к слайду в формате SVG.

Правила:
1. Ответ — только код SVG, без пояснений: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600"> … </svg>.
2. Разрешены только элементы: g, rect, circle, ellipse, line, polyline, polygon, path, defs, linearGradient, radialGradient, stop. Запрещены: text, image, use, filter, mask, clipPath, pattern, style, script, анимации.
3. От 12 до 40 фигур. Координаты — целые числа: x от 0 до 800, y от 0 до 600. Главный предмет — по центру, крупно.
4. Цвета только из палитры: {PALETTE}. Можно fill-opacity и градиенты из этих цветов.
5. Стиль: плоская корпоративная инфографика — крупные простые формы, мягкие градиенты, без мелких деталей. Без надписей, букв и цифр. Без людей и лиц. Фон прозрачный; можно светлый круг-подложку #E5EAF0.
6. Рисуй узнаваемые предметы темы слайда: оборудование, скважину, насос, трубы, шестерёнки, графики, диаграммы, щит, документы, здания, деньги, стрелки роста и т. п.

Пример оформления (другая тема, не копируй):
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600"><defs><linearGradient id="g1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0078AE"/><stop offset="1" stop-color="#00326E"/></linearGradient></defs><circle cx="400" cy="300" r="250" fill="#E5EAF0"/><rect x="250" y="330" width="80" height="140" rx="8" fill="#9AC854"/><rect x="360" y="260" width="80" height="210" rx="8" fill="#4BAF46"/><rect x="470" y="180" width="80" height="290" rx="8" fill="url(#g1)"/><path d="M230 300 L360 220 L450 250 L580 140" fill="none" stroke="#00326E" stroke-width="12" stroke-linecap="round"/><polygon points="580,140 545,150 570,175" fill="#00326E"/><line x1="220" y1="480" x2="590" y2="480" stroke="#00326E" stroke-width="6"/></svg>"""

MIN_SHAPES = 3


def slide_subject(s):
    """Короткое описание содержания слайда для запроса к модели."""
    parts = [s.get('title') or '']
    if s.get('lead'):
        parts.append(s['lead'])
    for it in (s.get('items') or [])[:4]:
        if isinstance(it, dict):
            parts.append(it.get('title') or it.get('text') or '')
    if s.get('center'):
        parts.append(s['center'])
    for p in (s.get('paragraphs') or [])[:1]:
        parts.append(p)
    txt = '. '.join(p for p in parts if p)
    return clean(txt)[:500]


def draw_prompt(s):
    return DRAW_SYSTEM, (f'Слайд: «{clean(s.get("title") or "")}».\nСодержание: {slide_subject(s)}\n\n'
                         'Нарисуй иллюстрацию к этому слайду по правилам. Ответ — только SVG.')


def model_drawing(s, llm_cfg, progress=None):
    """Модель рисует иллюстрацию к слайду → очищенный текст SVG. Ошибка → LLMError или SvgError."""
    from .llm_client import chat
    if not llm_cfg or not llm_cfg.get('model'):
        raise SvgError('модель ИИ не настроена (окно «⚙ Модель ИИ»)')
    cfg = dict(llm_cfg, json_mode=False, temperature=max(0.3, float(llm_cfg.get('temperature') or 0.2)))
    system, user = draw_prompt(s)
    last = None
    for attempt in range(2):
        text = chat(cfg, system, user if attempt == 0 else
                    user + f'\n\nПредыдущий ответ не подошёл ({last}). Ответь ТОЛЬКО кодом SVG по правилам.',
                    progress=progress, max_tokens=3000)
        try:
            svg = sanitize(extract_svg(text))
            if _count(svg) < MIN_SHAPES:
                raise SvgError('в рисунке меньше трёх фигур')
            return svg
        except SvgError as e:
            last = str(e)
    raise SvgError(last or 'модель не нарисовала иллюстрацию')


def _count(svg):
    from .svgdraw import DRAWABLE, _parse, _strip
    return sum(1 for el in _strip(_parse(svg)).iter() if el.tag in DRAWABLE)


def illustrated_slide(s, svg, label='Иллюстрация модели ИИ'):
    """Вариант слайда «иллюстрация + тезисы» на основе текущего слайда (svg — рисунок модели)."""
    pts = []
    if s.get('lead'):
        pts.append(s['lead'])
    pts += [p for p in (s.get('paragraphs') or []) if p]
    for it in s.get('items') or []:
        if not isinstance(it, dict):
            continue
        t = it.get('title') or ''
        x = it.get('text') or ''
        v = f"{it.get('value') or ''} {it.get('unit') or ''}".strip()
        if v and t and str(it.get('value') or '') in t:
            v = ''                                         # число уже есть в подписи («236 отказов…»)
        pts.append(' — '.join(p for p in (t, v or x) if p) if (t and (v or x)) else (t or x or v))
    if s.get('layout') == 'compare':
        for side in ('left', 'right'):
            pts += (s.get(side) or {}).get('items') or []
    if s.get('center'):
        pts.insert(0, s['center'])
    pts = [p for p in pts if p][:4]
    return {'layout': 'image', 'title': s.get('title') or '', 'subtitle': s.get('subtitle') or '',
            'section': s.get('section') or '', 'images': [{'svg': svg, 'caption': '', 'ai': True}] if svg else [],
            'items': [{'title': '', 'text': p} for p in pts], 'illustration': True,
            'conclusion': s.get('conclusion') or '', 'alt_label': label}


def add_illustration(s, svg):
    """Добавляет иллюстрацию в варианты слайда (заменяет прежнюю). Возвращает индекс варианта."""
    alt = illustrated_slide(s, svg)
    alts = s.get('alts') or [dict({k: v for k, v in s.items() if k not in ('alts', 'notes')},
                                  alt_label=s.get('alt_label') or 'Текущий')]
    alts = [a for a in alts if not (a.get('layout') == 'image' and a.get('illustration'))][:3] + [alt]
    s['alts'] = alts
    return len(alts) - 1


# --------------------------------------------------------------------------------------
# Автоматические иллюстрации при ИИ-анализе
# --------------------------------------------------------------------------------------
AUTO_LAYOUTS = ('text', 'list', 'cards', 'conclusions', 'process', 'target', 'honeycomb')


def auto_illustrate(spec, llm_cfg, limit=0, progress=None):
    """Модель рисует иллюстрации к первым `limit` подходящим слайдам (текстовым, без таблиц и чисел).
    Иллюстрация добавляется в варианты слайда; слайдам «одна мысль» (text) она сразу ставится основной.
    Возвращает список предупреждений."""
    from .llm_client import Cancelled, LLMError
    notify = progress or (lambda e: None)
    warnings = []
    order = {lay: i for i, lay in enumerate(AUTO_LAYOUTS)}
    cands = sorted([s for s in spec.get('slides') or [] if s.get('layout') in AUTO_LAYOUTS],
                   key=lambda s: (0 if s.get('layout') == 'text' else 1, order.get(s.get('layout'), 9)))
    cands = cands[:max(0, int(limit or 0))]
    for i, s in enumerate(cands, 1):
        title = s.get('title') or ''

        def prog(e, i=i, title=title):
            ev = {'phase': 'draw', 'i': i, 'n': len(cands), 'title': title}
            if e.get('phase') == 'gen':
                ev['tokens'] = e.get('tokens', 0)
            notify(ev)
        prog({})
        try:
            svg = model_drawing(s, llm_cfg, progress=prog)
        except Cancelled:
            raise
        except (LLMError, SvgError) as e:
            warnings.append(f'Модель не нарисовала иллюстрацию к слайду «{title}»: {e}')
            if isinstance(e, LLMError):
                break                                        # модель недоступна — дальше не пытаемся
            continue
        idx = add_illustration(s, svg)
        if s.get('layout') == 'text':                        # одна мысль — с картинкой нагляднее
            from .variety import apply_alt
            new = apply_alt(s, idx)
            s.clear()
            s.update(new)
    return warnings
