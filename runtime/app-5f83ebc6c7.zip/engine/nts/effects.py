# -*- coding: utf-8 -*-
"""
effects.py — ВИЗУАЛЬНЫЕ ЭФФЕКТЫ ФИГУР (тени, свечение, прозрачность, градиенты)
==============================================================================

python-pptx «из коробки» умеет только заливку и контур. Тени, свечение, прозрачность
и тонкие настройки геометрии он не поддерживает, поэтому здесь мы напрямую дописываем
XML-разметку DrawingML (формат, в котором PowerPoint хранит фигуры).

Как это устроено внутри файла .pptx (упрощённо):
    <p:sp>                      ← фигура
      <p:spPr>                  ← свойства фигуры
        <a:prstGeom prst="rect">  ← геометрия (тип фигуры + настройки avLst)
        <a:solidFill>…</a:solidFill>   ← заливка
        <a:ln>…</a:ln>                 ← контур
        <a:effectLst>                  ← СПИСОК ЭФФЕКТОВ (порядок важен!)
          <a:glow …/>                  ← 1) свечение
          <a:outerShdw …/>             ← 2) внешняя тень
        </a:effectLst>
      </p:spPr>
    </p:sp>

ВАЖНО: в <a:effectLst> PowerPoint требует строгий порядок: glow раньше outerShdw.
Если порядок нарушить, PowerPoint сочтёт файл повреждённым. Функции ниже это учитывают.

Единицы внутри XML:
  * расстояния — EMU (1 пт = 12 700 EMU; функция Pt() переводит пункты в EMU);
  * прозрачность (alpha) — в тысячных долях процента: 20 % → 20000;
  * углы — в 60 000-х долях градуса: 90° → 5 400 000.
"""
import copy
import re

from lxml import etree
from pptx.oxml.ns import qn
from pptx.util import Pt

from .config import rgb


def no_shadow(shape):
    """Отключает тень темы у фигуры.

    Корпоративная тема задаёт фигурам тень «по умолчанию». Пустой <a:effectLst/>
    означает «эффектов нет» — так фигуры выглядят плоскими и чистыми.
    Вызывается автоматически в rect() и freeform().
    """
    spPr = shape._element.spPr
    if spPr.find(qn('a:effectLst')) is None:
        spPr.append(etree.SubElement(spPr, qn('a:effectLst')))


def shadow(shape, blur=12, dist=3, alpha=20, color='1F2A44', dir_=5400000):
    """Мягкая внешняя тень — «приподнимает» карточку над фоном.

    Параметры:
        blur  — размытие, пт (8–14 — мягкая «воздушная» тень; больше — расплывчатее);
        dist  — смещение тени от фигуры, пт (2–4 — едва заметный подъём);
        alpha — непрозрачность тени, % (14–25 — деликатно; 35 — для тёмного фона);
        color — цвет тени 'RRGGBB' (по умолчанию тёмно-синий, а не чёрный — мягче);
        dir_  — направление тени в 60000-х долях градуса (5400000 = 90° = вниз).

    Правило дизайна: тень одинакового «характера» на всём слайде, иначе карточки
    будут выглядеть как из разных презентаций.
    Возвращает ту же фигуру (удобно писать shadow(rect(...), ...)).
    """
    spPr = shape._element.spPr
    eff = spPr.find(qn('a:effectLst'))
    if eff is None:
        eff = etree.SubElement(spPr, qn('a:effectLst'))
    for c in list(eff):          # убираем прежние эффекты, чтобы не дублировать
        eff.remove(c)
    sh = etree.SubElement(eff, qn('a:outerShdw'))
    sh.set('blurRad', str(int(Pt(blur))))
    sh.set('dist', str(int(Pt(dist))))
    sh.set('dir', str(dir_))
    sh.set('algn', 't')               # тень «привязана» к верху фигуры
    sh.set('rotWithShape', '0')       # не поворачивать тень вместе с фигурой
    c = etree.SubElement(sh, qn('a:srgbClr'))
    c.set('val', color)
    etree.SubElement(c, qn('a:alpha')).set('val', str(alpha * 1000))
    return shape


def glow(shape, color='9AC854', rad=8, alpha=55):
    """Свечение вокруг фигуры — выделяет главный элемент слайда (центр мишени,
    плашку «Робот — мост через разрыв», ядро цикла).

    Параметры: color — цвет свечения, rad — радиус в пт, alpha — непрозрачность в %.
    Правило дизайна: свечение — максимум у 1–2 элементов на слайде, иначе пропадает акцент.
    Свечение вставляется ПЕРВЫМ в список эффектов (требование формата, см. выше),
    поэтому glow() можно вызывать и до, и после shadow().
    """
    spPr = shape._element.spPr
    eff = spPr.find(qn('a:effectLst'))
    if eff is None:
        eff = etree.SubElement(spPr, qn('a:effectLst'))
    g_ = etree.Element(qn('a:glow'))
    g_.set('rad', str(int(Pt(rad))))
    c = etree.SubElement(g_, qn('a:srgbClr'))
    c.set('val', color)
    etree.SubElement(c, qn('a:alpha')).set('val', str(alpha * 1000))
    eff.insert(0, g_)   # glow обязан стоять раньше outerShdw
    return shape


def alpha_fill(shape, hexcol, alpha):
    """Полупрозрачная заливка фигуры (alpha — непрозрачность в %, 0…100).

    В текущих слайдах не используется — оставлена для новых слайдов
    (например, полупрозрачная плашка поверх картинки).
    """
    shape.fill.solid()
    shape.fill.fore_color.rgb = rgb(hexcol)
    clr = shape._element.spPr.find(qn('a:solidFill')).find(qn('a:srgbClr'))
    etree.SubElement(clr, qn('a:alpha')).set('val', str(alpha * 1000))


def text_alpha(tb, alpha):
    """Делает ТЕКСТ полупрозрачным (alpha — непрозрачность в %).

    Используется для больших «фоновых» цифр 1…6 на плитках слайда «Выводы»:
    цифра 64 пт с непрозрачностью ~20 % — декоративный элемент, не спорящий с текстом.
    Работает для всех фрагментов текста, у которых задан цвет.
    """
    for r in tb._element.iter(qn('a:rPr')):
        sf = r.find(qn('a:solidFill'))
        if sf is not None:
            c = sf.find(qn('a:srgbClr'))
            if c is not None:
                etree.SubElement(c, qn('a:alpha')).set('val', str(alpha * 1000))


def grad(shape, c1, c2, angle=0):
    """Линейный градиент заливки из цвета c1 в цвет c2.

    angle — направление в градусах: 0 — слева направо, 90 — сверху вниз,
    45 — по диагонали. Правило дизайна: градиент только между «соседними» цветами
    палитры (NAVY→BLUE, DGREEN→GREEN) — так он выглядит объёмно, а не пёстро.
    """
    f = shape.fill
    f.gradient()
    f.gradient_angle = angle
    st = f.gradient_stops
    st[0].color.rgb = c1
    st[0].position = 0.0
    st[1].color.rgb = c2
    st[1].position = 1.0
    return shape


def _lum(hexv):
    def ch(x):
        x /= 255
        return x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4
    r, g, b = (int(hexv[i:i + 2], 16) for i in (0, 2, 4))
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)


def _flat_colour(stops):
    """Цвет вместо градиента: у соседних цветов палитры (NAVY→BLUE, DGREEN→GREEN) — первый, основной цвет пары;
    у далёких (WHITE→SKY, NAVY→GREEN) — середина, чтобы фигура не слилась с фоном и не стала чужого цвета."""
    stops = sorted(stops, key=lambda g_: int(g_.get('pos', '0') or 0))
    first, last = stops[0][0] if len(stops[0]) else None, stops[-1][0] if len(stops[-1]) else None
    if first is None:
        return None
    plain = all(c is not None and c.tag == qn('a:srgbClr') and not len(c) and re.fullmatch(r'[0-9A-Fa-f]{6}', c.get('val') or '')
                for c in (first, last))
    if plain and abs(_lum(first.get('val')) - _lum(last.get('val'))) > 0.25:
        a, b = first.get('val'), last.get('val')
        mid = ''.join(f'{(int(a[i:i + 2], 16) + int(b[i:i + 2], 16)) // 2:02X}' for i in (0, 2, 4))
        el = etree.Element(qn('a:srgbClr'))
        el.set('val', mid)
        return el
    return copy.deepcopy(first)


def flatten_gradients(sl, skip=('zn-tpl-decor',)):
    """Галочка «Градиент в фигурах» снята (1.9): градиентная заливка фигур, линий, текста и ячеек таблиц на слайде →
    сплошная (_flat_colour). Не трогаются: градиенты с прозрачностью — это эффекты (затухание фото, блик), а не цвет
    фигуры; оформление, перенесённое со слайдов своего шаблона (имя «zn-tpl-decor…»); фон слайда. → сколько заменено."""
    tree = sl.shapes._spTree
    n = 0
    for top in list(tree)[2:]:
        nv = top.find('.//' + qn('p:cNvPr'))
        if nv is not None and (nv.get('name') or '').startswith(skip):
            continue
        for gf in list(top.iter(qn('a:gradFill'))):
            stops = gf.findall(qn('a:gsLst') + '/' + qn('a:gs'))
            if not stops or any(g_.find('.//' + qn('a:alpha')) is not None for g_ in stops):
                continue
            col = _flat_colour(stops)
            if col is None:
                continue
            solid = etree.Element(qn('a:solidFill'))
            solid.append(col)
            gf.getparent().replace(gf, solid)
            n += 1
    return n


def set_av(shape, vals):
    """Задаёт «регуляторы» (adjust values) стандартной фигуры PowerPoint.

    У многих фигур есть жёлтые «ромбики»-регуляторы (скругление, угол дуги, глубина
    шеврона). В XML это <a:avLst><a:gd name="adj1" fmla="val 123"/></a:avLst>.
    vals — словарь {'adj1': число, 'adj2': число}.

    Пример — дуга (MSO_SHAPE.ARC): adj1 / adj2 — начальный и конечный угол
    в 60000-х долях градуса, отсчёт от направления «вправо» (3 часа) по часовой стрелке.
    Так на слайде 2 рисуется арка «моста» (верхняя полуокружность, 180°→0°).
    """
    av = shape._element.spPr.find(qn('a:prstGeom')).find(qn('a:avLst'))
    for g in list(av):
        av.remove(g)
    for k, v in vals.items():
        gd = etree.SubElement(av, qn('a:gd'))
        gd.set('name', k)
        gd.set('fmla', f'val {int(v)}')
