# -*- coding: utf-8 -*-
"""
tables.py — ОФОРМЛЕНИЕ ТАБЛИЦ PowerPoint
======================================

Таблица создаётся стандартно: slide.shapes.add_table(строк, столбцов, x, y, w, h).
Здесь — две функции, которые делают таблицу «корпоративной»:
  set_borders() — тонкие линии только там, где нужно (обычно только снизу ячейки);
  cell_set()    — заливка, поля, выравнивание и текст ячейки за один вызов.

Приём: стиль таблицы по умолчанию заменяется на «No Style, No Grid»
(id {2D5ABB26-0587-4C30-8999-92F81FD0307C}), а оформление задаётся вручную —
так PowerPoint не добавляет свою «зебру» и рамки поверх наших.
"""
from lxml import etree
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches as I
from pptx.util import Pt

from .config import GRAY, WHITE
from .shapes import _fill_tf

NO_STYLE_TABLE_ID = '{2D5ABB26-0587-4C30-8999-92F81FD0307C}'   # «Без стиля, без сетки»


def set_borders(cell, color='D0D7E2', w=0.75, sides='B'):
    """Границы ячейки: sides — какие стороны рисовать ('L', 'R', 'T', 'B' в любой
    комбинации; '' — без границ). Остальные стороны явно делаются невидимыми.
    color — 'RRGGBB', w — толщина, пт.
    """
    tcPr = cell._tc.get_or_add_tcPr()
    for tag in ('a:lnL', 'a:lnR', 'a:lnT', 'a:lnB'):
        for e in tcPr.findall(qn(tag)):
            tcPr.remove(e)
    els = []
    for sd in 'LRTB':
        ln = etree.Element(qn(f'a:ln{sd}'))
        if sd in sides:
            ln.set('w', str(int(Pt(w))))
            sf = etree.SubElement(ln, qn('a:solidFill'))
            etree.SubElement(sf, qn('a:srgbClr')).set('val', color)
        else:
            ln.set('w', '0')
            etree.SubElement(ln, qn('a:noFill'))
        els.append(ln)
    # линии границ должны стоять в начале tcPr, в порядке L, R, T, B
    for k, e in enumerate(els):
        tcPr.insert(k, e)


def cell_set(cell, content, size=12, color=GRAY, font='mn', fill=WHITE, align=PP_ALIGN.LEFT, sides='B', bcolor='D0D7E2'):
    """Полностью оформляет ячейку: заливка fill, поля 0,1"/0,02", вертикально по центру,
    текст content (формат — как в text()), границы sides цвета bcolor."""
    cell.fill.solid()
    cell.fill.fore_color.rgb = fill
    cell.margin_left = cell.margin_right = I(0.1)
    cell.margin_top = cell.margin_bottom = I(0.02)
    cell.vertical_anchor = MSO_ANCHOR.MIDDLE
    tf = cell.text_frame
    tf.word_wrap = True
    _fill_tf(tf, content, size, color, font, False, align, 0, None)
    set_borders(cell, color=bcolor, sides=sides)
