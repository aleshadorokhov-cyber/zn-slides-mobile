# -*- coding: utf-8 -*-
"""
theme.py — СБОРКА НА СВОЁМ ШАБЛОНЕ: цвета, шрифты и поля шаблона пользователя
============================================================================

Все макеты рисуют слайды в «корпоративной» системе координат (слайд 13,333 × 7,5″,
рабочая область от 0,41″) и корпоративными цветами. Когда пользователь выбрал свой
шаблон (engine/templates.py), сборка идёт так:

  1) слайды создаются по макетам ЕГО шаблона (титул, контент, раздел, финал), заголовки
     пишутся в заполнители шаблона — их шрифт, цвет и место задаёт шаблон;
  2) ширина рабочей области макетов подбирается под пропорции рабочей области шаблона
     (C.L / C.R / C.CW на время сборки), текст подгоняется по ширинам ЕГО шрифтов;
  3) в конце (finish) нарисованное на каждом контентном слайде переносится в рабочую
     область шаблона: сдвиг и общий масштаб (кегли, линии, тени — тоже), чтобы не задеть
     логотип, подвал или полосы оформления шаблона;
  4) цвета перекрашиваются: синие оттенки корпоративной палитры → основной цвет шаблона,
     зелёные → акцентный, с сохранением светлоты (тёмная плашка остаётся тёмной, подложка —
     светлой). С 1.9 основных и акцентных цветов может быть до трёх: тогда заливки фигур по
     порядку (NAVY, DBLUE, BLUE; DGREEN, 2FA046, GREEN — как идут элементы слайда) получают
     каждая свой цвет шаблона, градиент остаётся оттенками одного цвета, а под белым текстом
     заливка темнеет до читаемой. Красный, оранжевый, жёлтый (риски, предупреждения) и серые не меняются.
     Иконки перекрашиваются так же; фирменная «волна» Зарубежнефти заменяется плашкой;
  5) шрифт TT Bluescreens Pro (цифры, акценты) заменяется шрифтом заголовков темы шаблона.

Встроенный шаблон Зарубежнефти через этот модуль не проходит — его сборка не меняется.
Одновременно может идти несколько сборок (разные пользователи), поэтому активная тема —
переменная контекста, а изменение полей C.L / C.R / C.CW защищено замком RENDER_LOCK.
"""
import colorsys
import contextvars
import threading
from contextlib import contextmanager

from lxml import etree
from pptx.oxml.ns import qn

from . import config as C

ACTIVE = contextvars.ContextVar('zn_template_theme', default=None)
RENDER_LOCK = threading.RLock()
EMU = 914400

REF_BLUE, REF_GREEN = '0078AE', '4BAF46'       # опорные цвета корпоративной палитры
ICON_HEX = {'n': '00326E', 'b': '0078AE', 'g': '4BAF46', 'd': '0A8F2D', 'w': 'FFFFFF'}
ICON_CACHE = C.OUTPUT_DIR / 'icon_cache'
SKIP = 'zn-tpl'                                 # фигуры с таким началом имени уже в координатах шаблона
BAND_BOTTOM = 6.85                              # низ рабочей области корпоративных макетов


def active():
    """Тема текущей сборки (None — встроенный корпоративный шаблон)."""
    return ACTIVE.get()


# --------------------------------------------------------------------------------------
# Перекраска
# --------------------------------------------------------------------------------------
def hls(hexv):
    r, g, b = (int(hexv[i:i + 2], 16) / 255 for i in (0, 2, 4))
    return colorsys.rgb_to_hls(r, g, b)


def _lum(hexv):
    r, g, b = (int(hexv[i:i + 2], 16) / 255 for i in (0, 2, 4))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def hexof(h, l, s):
    r, g, b = colorsys.hls_to_rgb(h % 1.0, min(1, max(0, l)), min(1, max(0, s)))
    return '%02X%02X%02X' % (round(r * 255), round(g * 255), round(b * 255))


# заливки элементов слайда по порядку (layouts/base.py PALETTE): основные — вместо синих, акцентные — вместо зелёных
FILL_BLUES, FILL_GREENS = ('00326E', '005491', '0078AE'), ('0A8F2D', '2FA046', '4BAF46')


def rel_lum(hexv):
    """Относительная яркость по WCAG (для контраста с белым текстом)."""
    def ch(x):
        x /= 255
        return x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4
    r, g, b = (int(hexv[i:i + 2], 16) for i in (0, 2, 4))
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)


class Recolor:
    """Корпоративный цвет → цвет шаблона. primary — вместо синих, accent — вместо зелёных; списки (до трёх цветов) —
    заливки элементов по порядку получают каждая свой цвет шаблона (fill=True)."""

    def __init__(self, primary, accent):
        ps = [c.upper() for c in (primary if isinstance(primary, (list, tuple)) else [primary]) if c][:3] or ['0078AE']
        acs = [c.upper() for c in (accent if isinstance(accent, (list, tuple)) else [accent]) if c][:3] or ['4BAF46']
        primary, accent = ps[0], acs[0]
        self.p, self.a = hls(primary), hls(accent)
        self.rb, self.rg = hls(REF_BLUE), hls(REF_GREEN)
        # у светлых и жёлтых цветов (янтарь, золото) тёмные оттенки выходят «болотными» — темним мягче
        self.kp, self.ka = (0.7 if _lum(c) > 0.5 else 1.0 for c in (primary, accent))
        self.fills = {}
        for src, lst in ((FILL_BLUES, ps), (FILL_GREENS, acs)):
            if len(lst) > 1:
                for i, c in enumerate(src):
                    self.fills[c] = self._readable(c, lst[min(i, len(lst) - 1)])
        self.cache = {}

    @staticmethod
    def _readable(src, tgt):
        """Тёмная корпоративная заливка несёт белый текст: цвет шаблона темнеет, пока контраст с белым не станет ≥ 3."""
        if rel_lum(src) >= 0.3 or rel_lum(tgt) <= 0.3:
            return tgt
        h, l, s = hls(tgt)
        while l > 0.05 and rel_lum(tgt) > 0.3:
            l -= 0.02
            tgt = hexof(h, l, s)
        return tgt

    def __call__(self, hexv, fill=False):
        hexv = (hexv or '').upper()
        if len(hexv) != 6:
            return hexv
        if fill and hexv in self.fills:
            return self.fills[hexv]
        got = self.cache.get(hexv)
        if got:
            return got
        h, l, s = hls(hexv)
        deg = h * 360
        out = hexv
        if s >= 0.08 and 0.03 < l < 0.985:
            fam = ((self.rb, self.p, self.kp) if 165 <= deg <= 260 else (self.rg, self.a, self.ka) if 60 <= deg < 165
                   else None)
            if fam:
                ref, tgt, k = fam
                dh = (h - ref[0] + 0.5) % 1.0 - 0.5
                nh = tgt[0] + 0.3 * dh
                if l <= ref[1]:
                    nl = l * tgt[1] / ref[1]
                    nl = tgt[1] - (tgt[1] - nl) * k
                else:
                    nl = tgt[1] + (l - ref[1]) * (1 - tgt[1]) / (1 - ref[1])
                if l < 0.3:
                    nl = min(nl, 0.3)                # тёмная плашка под белым текстом остаётся тёмной
                ns = min(1.0, s * tgt[2] / max(ref[2], 0.05))
                out = hexof(nh, nl, ns)
        self.cache[hexv] = out
        return out


def icon_file(path, letter):
    """Иконка assets/icons/<имя>_<буква>.png в цвете шаблона (кэш output/icon_cache)."""
    th = active()
    src = ICON_HEX.get(letter)
    if th is None or not src:
        return path
    tgt = th.recolor(src)
    if tgt == src:
        return path
    out = ICON_CACHE / f'{path.stem}_{tgt}.png'
    if not out.exists():
        from PIL import Image
        ICON_CACHE.mkdir(parents=True, exist_ok=True)
        with Image.open(path) as im:
            a = im.convert('RGBA').getchannel('A')
        new = Image.new('RGBA', a.size, tuple(int(tgt[i:i + 2], 16) for i in (0, 2, 4)) + (255,))
        new.putalpha(a)
        tmp = out.with_suffix(f'.{threading.get_ident()}.tmp')
        new.save(tmp, 'PNG', optimize=True)
        tmp.replace(out)
    return out


# --------------------------------------------------------------------------------------
# Тема сборки
# --------------------------------------------------------------------------------------
class Theme:
    """Оформление своего шаблона для одной сборки (создаёт engine/templates.py по meta.json)."""

    def __init__(self, info, path, metrics=None):
        self.info = info
        self.id = info['id']
        self.path = path
        self.w, self.h = info['size']
        self.roles = info['roles']
        self.frame = info['frame']
        self.title_size = info.get('title_size') or 32
        self.panel = bool(info.get('dark_content'))
        self.colors = info.get('colors') or {}
        self.recolor = Recolor(info.get('primaries') or [info.get('primary') or '0078AE'],
                               info.get('accents') or [info.get('accent') or '4BAF46'])
        self.metrics = metrics
        self.metrics_key = f"{self.id}:{info.get('rev', '')}" if metrics else ''
        f = self.frame
        # ширина рабочей области макетов — под пропорции рабочей области шаблона (высота полосы ≈ 5,5″)
        aspect = (f['R'] - f['L']) / max(0.5, f['bottom'] - f['top'])
        self.canon_w = max(7.0, min(C.CW, (BAND_BOTTOM - 1.35) * aspect))

    # --- макеты шаблона ---------------------------------------------------------------
    def layout(self, prs, role):
        mi, li = self.roles.get(role) or self.roles['content']
        try:
            return prs.slide_masters[mi].slide_layouts[li]
        except IndexError:
            return prs.slide_masters[0].slide_layouts[0]

    # --- перенос нарисованного в рабочую область шаблона ----------------------------------
    def box(self, sub):
        f = self.frame
        return f['L'], (f['top_sub'] if sub else f['top']), f['R'], f['bottom']

    def finish(self, ctx):
        """Перенос, перекраска и шрифты на всех слайдах, которые нарисовали макеты."""
        prs = ctx.d.prs
        for sl in prs.slides:
            mark = ctx.tpl_marks.get(sl.slide_id)
            if mark is None:
                continue
            top_c, sub = mark
            bl, bt, br, bb = self.box(sub)
            cw, ch = self.canon_w, BAND_BOTTOM - top_c
            s = min((br - bl) / cw, (bb - bt) / ch)
            x0 = bl + ((br - bl) - cw * s) / 2
            y0 = bt + ((bb - bt) - ch * s) / 2
            for shp in list(sl.shapes):
                if shp.is_placeholder or (shp.name or '').startswith(SKIP):
                    continue
                self._move(shp._element, s, x0 - C.L * s, y0 - top_c * s)
                _scale_tree(shp._element, s)
                self._paint(shp._element)
                if getattr(shp, 'has_chart', False):
                    cx = shp.chart.part._element
                    _scale_tree(cx, s)
                    self._paint(cx)

    @staticmethod
    def _move(el, s, dx, dy):
        """Сдвиг и масштаб фигуры верхнего уровня: x' = x·s + dx (дюймы)."""
        tag = etree.QName(el).localname
        if tag == 'graphicFrame':
            xfrm = el.find(qn('p:xfrm'))
        elif tag == 'grpSp':
            xfrm = el.find(qn('p:grpSpPr') + '/' + qn('a:xfrm'))
        else:
            xfrm = el.find(qn('p:spPr') + '/' + qn('a:xfrm'))
        if xfrm is None:
            return
        off, ext = xfrm.find(qn('a:off')), xfrm.find(qn('a:ext'))
        if off is not None:
            off.set('x', str(int(round(int(off.get('x', 0)) * s + dx * EMU))))
            off.set('y', str(int(round(int(off.get('y', 0)) * s + dy * EMU))))
        if ext is not None:
            ext.set('cx', str(max(0, int(round(int(ext.get('cx', 0)) * s)))))
            ext.set('cy', str(max(0, int(round(int(ext.get('cy', 0)) * s)))))

    def _paint(self, el):
        done = set()
        for gf in el.iter(qn('a:gradFill')):                # градиент — оттенками цвета первой точки (1.9)
            stops = [g_ for g_ in gf.iter(qn('a:gs')) if g_.find(qn('a:srgbClr')) is not None]
            if not stops:
                continue
            stops.sort(key=lambda g_: int(g_.get('pos', '0') or 0))
            c0 = stops[0].find(qn('a:srgbClr'))
            v0 = (c0.get('val') or '').upper()
            if len(v0) != 6:
                continue
            m0 = self.recolor(v0, fill=_is_fill(gf))
            h0, l0, s0 = hls(m0)
            for g_ in stops:
                c = g_.find(qn('a:srgbClr'))
                v = (c.get('val') or '').upper()
                if len(v) != 6:
                    continue
                if g_ is stops[0]:
                    c.set('val', m0)
                else:
                    hv, lv, sv = hls(v)
                    ho = hls(v0)
                    if abs((hv - ho[0] + 0.5) % 1.0 - 0.5) * 360 < 30 or sv < 0.08 or ho[2] < 0.08:
                        c.set('val', hexof(h0, l0 + (lv - ho[1]), s0))    # соседний цвет палитры — оттенок того же
                    else:
                        c.set('val', self.recolor(v, fill=True))
                done.add(c)
        for c in el.iter(qn('a:srgbClr')):
            v = c.get('val')
            if v and c not in done:
                c.set('val', self.recolor(v, fill=_is_fill(c)))
        for tag in ('a:latin', 'a:ea', 'a:cs'):
            for f in el.iter(qn(tag)):
                if (f.get('typeface') or '').startswith('TT Bluescreens'):
                    f.set('typeface', '+mj-lt')


_NOT_FILL = {qn('a:rPr'), qn('a:defRPr'), qn('a:endParaRPr'), qn('a:ln'), qn('c:txPr'), qn('a:effectLst')}


def _is_fill(el):
    """Цвет заливки фигуры, ячейки или ряда диаграммы (не текста, не линии, не тени)."""
    p = el.getparent()
    while p is not None:
        if p.tag in _NOT_FILL:
            return False
        if etree.QName(p).localname in ('spPr', 'tcPr', 'grpSpPr', 'bg', 'bgPr'):
            return True
        p = p.getparent()
    return False


_SZ_TAGS = {qn('a:rPr'), qn('a:defRPr'), qn('a:endParaRPr')}
_EFFECT = {qn('a:outerShdw'): ('blurRad', 'dist'), qn('a:innerShdw'): ('blurRad', 'dist'),
           qn('a:prstShdw'): ('dist',), qn('a:glow'): ('rad',), qn('a:softEdge'): ('rad',)}
_INS = ('lIns', 'tIns', 'rIns', 'bIns')
_MAR = ('marL', 'marR', 'marT', 'marB')


def _sc(el, attr, s, lo=0):
    v = el.get(attr)
    if v is not None:
        try:
            el.set(attr, str(max(lo, int(round(int(v) * s)))))
        except ValueError:
            pass


def _scale_tree(root, s):
    """Кегли, отступы текста, толщины линий, тени, размеры таблиц — умножить на s."""
    if abs(s - 1) < 1e-3:
        return
    for el in root.iter():
        tag = el.tag
        if tag in _SZ_TAGS:
            _sc(el, 'sz', s, 100)
        elif tag == qn('a:bodyPr'):
            for a in _INS:
                _sc(el, a, s)
        elif tag == qn('a:ln'):
            _sc(el, 'w', s)
        elif tag in _EFFECT:
            for a in _EFFECT[tag]:
                _sc(el, a, s)
        elif tag in (qn('a:spcPts'), qn('a:buSzPts')):
            _sc(el, 'val', s)
        elif tag == qn('a:gridCol'):
            _sc(el, 'w', s)
        elif tag == qn('a:tr'):
            _sc(el, 'h', s)
        elif tag == qn('a:tcPr'):
            for a in _MAR:
                _sc(el, a, s)


@contextmanager
def use(theme):
    """На время сборки: активная тема и ширина рабочей области макетов под шаблон."""
    with RENDER_LOCK:
        token = ACTIVE.set(theme)
        saved = C.L, C.R, C.CW
        if theme is not None:
            C.R = C.L + theme.canon_w
            C.CW = theme.canon_w
        try:
            yield theme
        finally:
            C.L, C.R, C.CW = saved
            ACTIVE.reset(token)
