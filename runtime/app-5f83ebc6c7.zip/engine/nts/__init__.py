# -*- coding: utf-8 -*-
"""
nts — БИБЛИОТЕКА СБОРКИ ПРЕЗЕНТАЦИЙ в корпоративном стиле (поверх python-pptx)
============================================================================

Состав пакета (читать в этом порядке):
    config.py     — пути, палитра, шрифты, сетка, номера макетов шаблона;
    deck.py       — класс Deck: открыть шаблон, добавить слайд, сохранить;
    shapes.py     — фигуры, текст, иконки, линии, баннеры, группы;
    effects.py    — тени, свечение, прозрачность, градиенты, регуляторы фигур;
    animation.py  — анимации появления и переходы (запись в XML слайда);
    charts.py     — доработка нативных диаграмм (подписи, «дырка», полукруглая шкала);
    tables.py     — оформление таблиц.

Модули слайдов (папка slides/) подключают всё одной строкой:
    from nts import *
и получают доступ ко всем константам и функциям ниже.
"""
import math  # noqa: F401  (тригонометрия для круговых схем — нужна слайдам)

from pptx.chart.data import CategoryChartData  # noqa: F401
from pptx.enum.chart import XL_CHART_TYPE  # noqa: F401
from pptx.enum.shapes import MSO_SHAPE  # noqa: F401
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN  # noqa: F401
from pptx.oxml.ns import qn  # noqa: F401
from pptx.util import Inches as I  # noqa: F401
from pptx.util import Pt  # noqa: F401
from lxml import etree  # noqa: F401

from .config import (  # noqa: F401
    BLUE, CARD, CONTENT_DIR, CW, DBLUE, DGREEN, GRAY, GREEN, L, LGRAY, LGREEN, NAVY,
    PALEG, PALEG2, PH_TITLE, PH_TITLE_SUB, R, SEQ, SOFT, WHITE, rgb,
)
from .shapes import (  # noqa: F401
    badge, banner, bottom_banner, circ_icon, freeform, grect, group, icon, line, rect,
    shape_text, text,
)
from .effects import alpha_fill, glow, grad, no_shadow, set_av, shadow, text_alpha  # noqa: F401
from .animation import anim  # noqa: F401
from .charts import doughnut_hole, half_gauge, ring_labels  # noqa: F401
from .tables import NO_STYLE_TABLE_ID, cell_set, set_borders  # noqa: F401
