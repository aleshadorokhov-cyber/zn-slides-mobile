# -*- coding: utf-8 -*-
"""
animation.py — АНИМАЦИИ ПОЯВЛЕНИЯ И ПЕРЕХОДЫ МЕЖДУ СЛАЙДАМИ
==========================================================

python-pptx не умеет создавать анимации, поэтому мы пишем XML-блок <p:timing>
(временную шкалу слайда) вручную. Работа идёт в два этапа:

  1) Во время сборки слайда вызывается  anim(slide, shape, kind, delay, dur)  —
     анимация лишь ЗАПОМИНАЕТСЯ в реестре ANIMS (ничего в файл ещё не пишется).
  2) В самом конце сборки вызывается  finalize_all(prs)  — для каждого слайда
     записываются переход (<p:transition>) и вся временная шкала (<p:timing>).

СЦЕНАРИЙ ПОКАЗА (так задумано для доклада):
  * Все анимации слайда запускаются ОДНИМ щелчком, который PowerPoint «нажимает сам»
    при открытии слайда (авто-старт). Докладчику не нужно щёлкать по каждому элементу.
  * Элементы появляются КАСКАДОМ: у каждого своя задержка delay (мс) от начала показа.
    Типовой шаг каскада — 150–280 мс; длительность одного эффекта — 400–900 мс.
  * Переход между слайдами — «Выцветание» (fade), средняя скорость.

ДОСТУПНЫЕ ЭФФЕКТЫ (kind) — это стандартные эффекты входа PowerPoint:
  'fade'   — «Выцветание»        (presetID 10)  — спокойное появление подписей, легенд;
  'rise'   — «Всплывание вверх»  (presetID 42)  — карточки, панели: выезжают снизу и проявляются;
  'wipe_l' — «Появление слева»   (presetID 22, вариант 8) — линии, шкалы, баннеры, строки «стало»;
  'wipe_b' — «Появление снизу»   (presetID 22, вариант 4) — таблицы (открываются сверху вниз);
  'zoom'   — «Масштабирование»   (presetID 53, вариант 16) — круги, узлы, плитки «из точки».

Правило: на одном слайде 2–3 разных эффекта, не больше; порядок появления повторяет
логику рассказа (сначала причина — потом следствие, слева направо, от центра к краям).
Посмотреть/поправить анимации готового файла: PowerPoint → «Анимация» → «Область анимации».
"""
from lxml import etree
from pptx.oxml.ns import qn

P_NS = 'http://schemas.openxmlformats.org/presentationml/2006/main'
A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main'

# Реестр анимаций: { slide_id: (slide, [(shape_id, kind, delay, dur), ...]) }
ANIMS = {}


def anim(sl, shp, kind='fade', delay=0, dur=500):
    """Запоминает анимацию появления фигуры/группы shp на слайде sl.

    sl    — именно СЛАЙД (не группа!);
    shp   — фигура или группа, которая должна появиться;
    kind  — тип эффекта (см. список выше);
    delay — задержка от начала показа слайда, мс;
    dur   — длительность эффекта, мс.
    """
    ANIMS.setdefault(sl.slide_id, (sl, []))[1].append((shp.shape_id, kind, delay, dur))


def _eff_xml(kind, spid, delay, dur, nid):
    """Внутренняя функция: XML одного эффекта появления для фигуры с id = spid.

    Каждый эффект = «сделать видимой» (style.visibility → visible) + собственно
    анимация (проявление / сдвиг / растяжение). nid — генератор уникальных номеров
    узлов временной шкалы (PowerPoint требует, чтобы id не повторялись на слайде).
    """
    tgt = f'<p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl>'

    def cid():
        return str(next(nid))

    # «Сделать видимой» — обязательная часть любого эффекта входа
    vis = (f'<p:set><p:cBhvr><p:cTn id="{cid()}" dur="1" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst></p:cTn>'
           f'{tgt}<p:attrNameLst><p:attrName>style.visibility</p:attrName></p:attrNameLst></p:cBhvr><p:to><p:strVal val="visible"/></p:to></p:set>')

    def fx(filt):
        # Фильтр перехода: 'fade' — проявление, 'wipe(left)' — шторка слева и т. п.
        return f'<p:animEffect transition="in" filter="{filt}"><p:cBhvr><p:cTn id="{cid()}" dur="{dur}"/>{tgt}</p:cBhvr></p:animEffect>'

    def an(attr, v0, v1, num0=False):
        # Плавное изменение свойства (ppt_x, ppt_y — положение; ppt_w, ppt_h — размер)
        a0 = f'<p:fltVal val="{v0}"/>' if num0 else f'<p:strVal val="{v0}"/>'
        return (f'<p:anim calcmode="lin" valueType="num"><p:cBhvr><p:cTn id="{cid()}" dur="{dur}" fill="hold"/>{tgt}'
                f'<p:attrNameLst><p:attrName>{attr}</p:attrName></p:attrNameLst></p:cBhvr><p:tavLst>'
                f'<p:tav tm="0"><p:val>{a0}</p:val></p:tav><p:tav tm="100000"><p:val><p:strVal val="{v1}"/></p:val></p:tav></p:tavLst></p:anim>')

    if kind == 'fade':
        pid, sub, body = 10, 0, lambda: vis + fx('fade')
    elif kind == 'rise':
        # проявление + сдвиг снизу (#ppt_y+.1 — на 10 % высоты слайда ниже итоговой позиции)
        pid, sub, body = 42, 0, lambda: vis + fx('fade') + an('ppt_x', '#ppt_x', '#ppt_x') + an('ppt_y', '#ppt_y+.1', '#ppt_y')
    elif kind == 'wipe_l':
        pid, sub, body = 22, 8, lambda: vis + fx('wipe(left)')
    elif kind == 'wipe_b':
        pid, sub, body = 22, 4, lambda: vis + fx('wipe(up)')
    elif kind == 'zoom':
        # растяжение из нулевого размера до полного + проявление
        pid, sub, body = 53, 16, lambda: vis + an('ppt_w', '0', '#ppt_w', True) + an('ppt_h', '0', '#ppt_h', True) + fx('fade')
    else:
        raise ValueError(f'Неизвестный тип анимации: {kind}')
    # nodeType="withEffect" — «вместе с предыдущим»: все эффекты стартуют одновременно,
    # а разнесены во времени только своими задержками delay.
    head = f'<p:par><p:cTn id="{cid()}" presetID="{pid}" presetClass="entr" presetSubtype="{sub}" fill="hold" nodeType="withEffect">'
    return head + f'<p:stCondLst><p:cond delay="{delay}"/></p:stCondLst><p:childTnLst>' + body() + '</p:childTnLst></p:cTn></p:par>'


def finalize_slide_fx(slide, items, transition='fade'):
    """Записывает в слайд переход и временную шкалу со всеми эффектами items.

    Старые <p:transition>/<p:timing> (например, унаследованные от исходного слайда)
    удаляются. Переход вставляется сразу после <p:clrMapOvr> — так требует формат.
    """
    sld = slide._element
    for tag in ('p:transition', 'p:timing'):
        for e in sld.findall(qn(tag)):
            sld.remove(e)
    clr = sld.find(qn('p:clrMapOvr'))
    tr = etree.fromstring(f'<p:transition xmlns:p="{P_NS}" spd="med"><p:{transition}/></p:transition>')
    clr.addnext(tr)
    if not items:
        return
    nid = iter(range(1, 100000))
    root_id, seq_id, click_id, grp_id = next(nid), next(nid), next(nid), next(nid)
    effs = ''.join(_eff_xml(k, spid, d, du, nid) for spid, k, d, du in items)
    # Структура шкалы:  корень → главная последовательность → «щелчок» (авто-старт
    # по событию onBegin) → группа эффектов «вместе с предыдущим».
    xml = (f'<p:timing xmlns:p="{P_NS}" xmlns:a="{A_NS}"><p:tnLst><p:par><p:cTn id="{root_id}" dur="indefinite" restart="never" nodeType="tmRoot"><p:childTnLst>'
           f'<p:seq concurrent="1" nextAc="seek"><p:cTn id="{seq_id}" dur="indefinite" nodeType="mainSeq"><p:childTnLst>'
           f'<p:par><p:cTn id="{click_id}" fill="hold"><p:stCondLst><p:cond delay="indefinite"/><p:cond evt="onBegin" delay="0"><p:tn val="{seq_id}"/></p:cond></p:stCondLst><p:childTnLst>'
           f'<p:par><p:cTn id="{grp_id}" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst>{effs}</p:childTnLst></p:cTn></p:par>'
           f'</p:childTnLst></p:cTn></p:par>'
           f'</p:childTnLst></p:cTn><p:prevCondLst><p:cond evt="onPrev" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:prevCondLst>'
           f'<p:nextCondLst><p:cond evt="onNext" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:nextCondLst></p:seq>'
           f'</p:childTnLst></p:cTn></p:par></p:tnLst></p:timing>')
    tr.addnext(etree.fromstring(xml))


def finalize_all(prs, transition='fade'):
    """Финальный шаг сборки: переход + анимации для КАЖДОГО слайда презентации.

    Слайды без анимаций получают только переход.
    """
    for sl in prs.slides:
        items = ANIMS.get(sl.slide_id, (sl, []))[1]
        finalize_slide_fx(sl, items, transition)
