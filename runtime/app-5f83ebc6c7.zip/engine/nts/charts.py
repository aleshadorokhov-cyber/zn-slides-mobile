# -*- coding: utf-8 -*-
"""
charts.py — ДОРАБОТКА НАТИВНЫХ ДИАГРАММ POWERPOINT
=================================================

Диаграммы в презентации — «живые» (нативные) диаграммы PowerPoint, а не картинки:
по щелчку правой кнопкой → «Изменить данные» их можно поправить в Excel.
Создаются они стандартно через python-pptx (slide.shapes.add_chart), а здесь лежат
функции тонкой настройки, которых нет в python-pptx:

  ring_labels()     — подписи значений только у нужных секторов, свой шрифт и цвет;
  doughnut_hole()   — размер «дырки» кольцевой диаграммы;
  half_gauge()      — превращает кольцевую диаграмму в полукруглую шкалу-«спидометр».

ДВА ПРИЁМА, КОТОРЫЕ ИСПОЛЬЗОВАНЫ В ПРЕЗЕНТАЦИИ
  1) «Вложенное кольцо» (слайд 6). Кольцевая диаграмма с ДВУМЯ рядами данных рисует
     два концентрических кольца. Внутреннее — веса блоков (40/30/30), внешнее — веса
     9 показателей. Чтобы сектора колец совпадали по углам, внутренний ряд содержит
     вес блока в первой категории блока и нули в остальных его категориях.
  2) «Полукруглая шкала» (слайд 8). Кольцевая диаграмма, в которой последняя точка
     равна сумме всех остальных (100 из 200) и сделана невидимой, а начальный угол
     повёрнут на 270°. Видимые сектора образуют верхнюю половину кольца.
"""
from lxml import etree
from pptx.oxml.ns import qn


def ring_labels(ser, values, size, color_fn):
    """Подписи данных для ряда кольцевой диаграммы.

    ser      — ряд (plot.series[i]);
    values   — значения ряда; у нулевых значений подпись УДАЛЯЕТСЯ (c:delete);
    size     — кегль подписи, пт;
    color_fn — функция i → 'RRGGBB' (цвет подписи i-й точки: белый на тёмном
               секторе, тёмно-синий на светлом).
    Формат числа '0"%"' — значение с символом процента (15 → «15%»).
    """
    dLbls = ser._element.get_or_add_dLbls()
    for ch_ in list(dLbls):
        dLbls.remove(ch_)
    for i, v in enumerate(values):
        d = etree.SubElement(dLbls, qn('c:dLbl'))
        etree.SubElement(d, qn('c:idx')).set('val', str(i))
        if not v:
            etree.SubElement(d, qn('c:delete')).set('val', '1')
            continue
        nf = etree.SubElement(d, qn('c:numFmt'))
        nf.set('formatCode', '0"%"')
        nf.set('sourceLinked', '0')
        etree.SubElement(d, qn('c:spPr'))
        tx = etree.SubElement(d, qn('c:txPr'))
        etree.SubElement(tx, qn('a:bodyPr'))
        etree.SubElement(tx, qn('a:lstStyle'))
        p_ = etree.SubElement(tx, qn('a:p'))
        ppr = etree.SubElement(p_, qn('a:pPr'))
        dr = etree.SubElement(ppr, qn('a:defRPr'))
        dr.set('sz', str(int(size * 100)))     # размер в сотых долях пункта
        dr.set('b', '1')                       # жирный
        sf = etree.SubElement(dr, qn('a:solidFill'))
        etree.SubElement(sf, qn('a:srgbClr')).set('val', color_fn(i))
        etree.SubElement(dr, qn('a:latin')).set('typeface', 'TT Bluescreens Pro Normal')
        etree.SubElement(p_, qn('a:endParaRPr')).set('lang', 'ru-RU')
        # Показать только значение (без имени ряда, категории, процента от суммы)
        for tag, val in (('c:showLegendKey', '0'), ('c:showVal', '1'), ('c:showCatName', '0'),
                         ('c:showSerName', '0'), ('c:showPercent', '0'), ('c:showBubbleSize', '0')):
            etree.SubElement(d, qn(tag)).set('val', val)
    # Общие настройки ряда: по умолчанию подписи выключены (включены только выше)
    for tag, val in (('c:showLegendKey', '0'), ('c:showVal', '0'), ('c:showCatName', '0'),
                     ('c:showSerName', '0'), ('c:showPercent', '0'), ('c:showBubbleSize', '0')):
        etree.SubElement(dLbls, qn(tag)).set('val', val)


def doughnut_hole(chart, pct):
    """Размер центрального отверстия кольцевой диаграммы, % от диаметра (10…90).

    Меньше — кольца толще (удобно для подписей внутри секторов).
    """
    dn = chart._chartSpace.find('.//' + qn('c:doughnutChart'))
    hs = dn.find(qn('c:holeSize'))
    if hs is None:
        hs = etree.SubElement(dn, qn('c:holeSize'))
    hs.set('val', str(pct))


def half_gauge(chart, hole=55, first_angle=270):
    """Превращает кольцевую диаграмму в полукруглую шкалу (дугу сверху).

    Требования к данным: последняя точка ряда = сумма остальных и сделана невидимой
    (заливка и контур — «нет»). Тогда:
      * first_angle=270 — первый сектор начинается слева (на «9 часах»);
      * видимые сектора занимают верхние 180°, невидимый — нижние 180°;
      * hole — толщина дуги (55 — средняя).
    Дополнительно область построения растягивается почти на всю рамку (manualLayout),
    чтобы дуга была максимально крупной.
    """
    dn = chart._chartSpace.find('.//' + qn('c:doughnutChart'))
    fsa = dn.find(qn('c:firstSliceAng'))
    if fsa is None:
        fsa = etree.SubElement(dn, qn('c:firstSliceAng'))
    fsa.set('val', str(first_angle))
    hs = dn.find(qn('c:holeSize'))
    if hs is None:
        hs = etree.SubElement(dn, qn('c:holeSize'))
    hs.set('val', str(hole))
    # Формат требует порядок: ... firstSliceAng, holeSize — в конце элемента
    for tag in ('c:firstSliceAng', 'c:holeSize'):
        e = dn.find(qn(tag))
        dn.remove(e)
        dn.append(e)
    # Ручная разметка области построения: 2 % отступ от краёв рамки диаграммы
    pa = chart._chartSpace.find('.//' + qn('c:plotArea'))
    lay = pa.find(qn('c:layout'))
    if lay is None:
        lay = etree.Element(qn('c:layout'))
        pa.insert(0, lay)
    for ch_ in list(lay):
        lay.remove(ch_)
    ml = etree.SubElement(lay, qn('c:manualLayout'))
    for tag, val in (('c:layoutTarget', 'inner'), ('c:xMode', 'edge'), ('c:yMode', 'edge'),
                     ('c:x', '0.02'), ('c:y', '0.02'), ('c:w', '0.96'), ('c:h', '0.96')):
        etree.SubElement(ml, qn(tag)).set('val', val)
