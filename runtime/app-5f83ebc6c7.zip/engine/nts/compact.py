# -*- coding: utf-8 -*-
"""
compact.py — ОБЛЕГЧЁННАЯ КОПИЯ ШАБЛОНА (меньше размер готовой презентации)
=========================================================================

Фоны макетов в шаблоне — картинки 8000×4500 точек (по 1–1,2 МБ). Это вдвое больше
разрешения 4K, поэтому готовая презентация весит около 12 МБ даже на 10 слайдов.

compact_template(path) один раз делает копию шаблона, в которой такие картинки уменьшены
до 3840 точек по ширине (4K — на любом экране и проекторе выглядят так же), и возвращает
путь к копии. Сам шаблон assets/template/base_deck.pptx не меняется. Копия лежит в
output/template/ и пересоздаётся, если шаблон изменился. Если сжать не удалось —
возвращается исходный шаблон.
"""
import hashlib
import io
import os
import threading
import zipfile
from pathlib import Path

from . import config as C

MAX_W = 3840                                   # наибольшая ширина картинки (4K)
CACHE_DIR = C.OUTPUT_DIR / 'template'


def _shrink(data):
    """Картинка PNG/JPEG шире MAX_W → уменьшенная того же формата (или None, если не нужно)."""
    from PIL import Image
    try:
        im = Image.open(io.BytesIO(data))
        if im.width <= MAX_W or im.format not in ('PNG', 'JPEG'):
            return None
        fmt = im.format
        im = im.resize((MAX_W, max(1, round(im.height * MAX_W / im.width))), Image.LANCZOS)
        out = io.BytesIO()
        if fmt == 'PNG':
            im.save(out, 'PNG', optimize=True)
        else:
            im.save(out, 'JPEG', quality=90, optimize=True)
        b = out.getvalue()
        return b if len(b) < len(data) else None
    except Exception:                                    # noqa: BLE001
        return None


def compact_template(path=C.TEMPLATE):
    path = Path(path)
    try:
        st = path.stat()
        key = hashlib.sha1(f'{path.resolve()}|{st.st_size}|{st.st_mtime_ns}|{MAX_W}'.encode()).hexdigest()[:12]
        stem = path.stem if path.parent == C.TEMPLATE.parent else f'{path.parent.name}_{path.stem}'
        out = CACHE_DIR / f'{stem}_{key}.pptx'
        if out.exists():
            return out
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        tmp = out.with_suffix(f'.{os.getpid()}_{threading.get_ident()}.tmp')     # несколько заданий сразу
        with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as zout:
            for info in zin.infolist():
                data = zin.read(info.filename)
                if info.filename.startswith('ppt/media/'):
                    data = _shrink(data) or data
                zout.writestr(info, data, compress_type=info.compress_type)
        os.replace(tmp, out)
        for old in CACHE_DIR.glob(f'{stem}_*.pptx'):            # прежние копии (шаблон менялся)
            if old != out and old.stem.count('_') == stem.count('_') + 1:
                old.unlink(missing_ok=True)
        return out
    except Exception:                                    # noqa: BLE001
        return path
