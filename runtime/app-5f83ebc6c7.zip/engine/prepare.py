# -*- coding: utf-8 -*-
"""
prepare.py — ПОДГОТОВКА МОДЕЛИ ДОКУМЕНТА ПЕРЕД ПЛАНИРОВАНИЕМ
==========================================================

1. ДОКУМЕНТ-СЦЕНАРИЙ. Если в документе разделы озаглавлены «Слайд 1», «Слайд 2»… (так часто
   пишут текст выступления), то:
     * заголовок раздела заменяется на смысловой: «Слайд 3. Цель проекта» → «Цель проекта»;
       «Слайд 3» + короткая первая строка → эта строка; иначе — тема по ключевым словам
       («Актуальность проблемы», «Цель и задачи», «Экономический эффект»…);
     * «Слайд 1» в начале документа — титульный: его первая строка — название презентации,
       следующая — подзаголовок;
     * раздел «Спасибо за внимание» убирается (финальный слайд добавляется всегда);
     * раздел помечается marker=True — планировщик сохраняет авторскую разбивку на слайды.
2. ПОМЕТКИ АВТОРА (выделенные фрагменты). Режим opts['marks']:
     'priority' (по умолчанию) — выделенное идёт на слайды в первую очередь;
     'only'     — в презентацию попадают только разделы с выделенными фрагментами;
     'ignore'   — пометки не учитываются.
3. НАЗВАНИЕ. Если название документа не найдено или это «Слайд 1» — берётся имя файла.
"""
import re
from pathlib import Path

from .condense import is_slide_marker, topic_title
from .textutil import cap, clean


def _title_like(text):
    t = clean(text)
    return bool(t) and len(t) <= 90 and len(t.split()) <= 12 and not t.endswith(('.', ':', ';', ',', '?')) \
        and not re.search(r'[=]', t)


def _walk_with_parent(secs, parent=None):
    for s in secs:
        yield s, parent
        yield from _walk_with_parent(s.children, s)


def prepare(doc, opts=None):
    """Подготавливает модель документа (меняет её на месте). Возвращает словарь сведений."""
    opts = opts or {}
    info = {'script': False, 'marks': doc.marks_count()}
    _merge_marker_children(doc)
    _title_page(doc)
    all_secs = list(doc.walk())
    markers = [s for s in all_secs if is_slide_marker(s.title)]
    if len(markers) >= 3 and len(markers) >= 0.5 * len(all_secs):
        info['script'] = True
        _prepare_script(doc, markers)
    if not doc.title or is_slide_marker(doc.title):
        src = doc.sources[0] if doc.sources else ''
        doc.title = cap(clean(Path(str(src)).stem.replace('_', ' '))) if src else 'Презентация'
    mode = str(opts.get('marks') or 'priority')
    if mode == 'ignore':
        _clear_marks(doc)
        info['marks'] = 0
    elif mode == 'only' and info['marks']:
        _keep_marked(doc)
    return info


def _merge_marker_children(doc):
    """«Слайд 3» (пустой) → единственный подраздел «Цель проекта» с текстом: склеиваются в
    «Слайд 3. Цель проекта» (так бывает, когда название слайда набрано жирным под номером)."""
    for sec in list(doc.walk()):
        m = is_slide_marker(sec.title)
        if m and not m[1] and not [b for b in sec.blocks if b.kind != 'image'] and len(sec.children) == 1:
            ch = sec.children[0]
            sec.title = f'Слайд {m[0]}. {ch.title}'
            sec.blocks = sec.blocks + ch.blocks
            sec.children = ch.children
            sec.mark = sec.mark or ch.mark


_SUBTITLE_RX = re.compile(r'(?i)^\(.{6,140}\)$|по состоянию на|заседани|совещани|^доклад|^отч[её]т|^для |'
                          r'опытно-промышленн|^о ходе|^об? ')
_ORG_RX = re.compile(r'(?i)^(ао|ооо|пао|оао|зао| гк|группа компаний|научно-проектн|управлени|департамент|'
                     r'москва|санкт-петербург|самара)\b|^\w+,\s*(19|20)\d\d\s*(г\.|год)?$|^(19|20)\d\d$|'
                     r'^цифры условные|^(утверждаю|согласовано)\b')


def _title_like_sec(sec):
    """Раздел — часть титульной страницы: только короткие строки (название, организация, город и год,
    «по состоянию на…»), без списков, таблиц и подразделов с текстом."""
    if is_slide_marker(sec.title):
        return False                              # «Слайд 1» документа-сценария разбирается отдельно
    if any(b.kind != 'para' for b in sec.blocks) or any(c.blocks or c.children for c in sec.children):
        return False
    paras = [b.text for b in sec.blocks]
    if len(paras) > 5 or any(len(t) > 140 for t in paras) or sum(len(t) for t in paras) > 420:
        return False
    if len(sec.title) > 140:
        return False
    return all(_ORG_RX.search(t) or _SUBTITLE_RX.search(t) or len(t) <= 70 for t in paras)


def _title_page(doc):
    """Титульная страница документа (строки до первого раздела с текстом: «АО «Зарубежнефть»», «СПРАВКА»,
    «о ходе реализации…», «(по состоянию на 30.09.2026)», «Москва, 2026») — не слайды: из неё берутся
    название и подзаголовок, остальное отбрасывается."""
    secs = doc.sections
    k = 0
    lines = []
    while k < len(secs) - 1 and _title_like_sec(secs[k]):
        lines.append(secs[k].title)
        lines.extend(b.text for b in secs[k].blocks)
        for c in secs[k].children:
            lines.append(c.title)
        k += 1
    if not k:
        return
    lines = [clean(t) for t in lines if clean(t)]
    title_parts = [t for t in lines if not _ORG_RX.search(t) and not re.match(r'^\(.*\)$', t)]
    if not doc.title and title_parts:
        doc.title = cap(title_parts[0])
    for t in lines:
        if _SUBTITLE_RX.search(t) and not _ORG_RX.search(t) and doc.title and t.lower() not in doc.title.lower():
            if not doc.subtitle:
                doc.subtitle = cap(t.strip('()'))
            break
    doc.sections = secs[k:]


_END_RX = re.compile(r'(?i)спасибо за внимание|благодар\w* за внимание|готов\w* ответить на вопросы|^вопросы$')


def _prepare_script(doc, markers):
    first_done = False
    for sec in markers:
        num, rest = is_slide_marker(sec.title)
        paras = [b for b in sec.blocks if b.kind == 'para']
        # титульный «Слайд 1» в самом начале документа
        is_first = bool(doc.sections) and sec is doc.sections[0]
        if not first_done and num == 1 and is_first:
            first_done = True
            texts = [p.text for p in paras]
            title = rest or (texts[0] if texts and _title_like(texts[0]) else '')
            if title and (not doc.title or is_slide_marker(doc.title)):
                doc.title = cap(title)
            rest_texts = texts[1:] if (not rest and texts and title == texts[0]) else texts
            if rest_texts and not doc.subtitle and len(rest_texts[0]) <= 160:
                doc.subtitle = rest_texts[0]
            sec.title = ''
            sec.blocks = [b for b in sec.blocks if b.kind != 'para']
            sec.marker = True
            continue
        first_done = True
        if _END_RX.search(rest) or (_END_RX.search(sec.all_text(False)) and len(sec.all_text(False)) < 120):
            sec.title = '__end__'
            continue
        title = rest
        if not title and paras and _title_like(paras[0].text) and len(sec.blocks) > 1:
            title = paras[0].text
            sec.blocks.remove(paras[0])
        if not title:
            title = topic_title(sec.all_text(False))
        sec.title = title or f'Слайд {num}'
        sec.marker = True
    # удалить пустой титульный и «Спасибо за внимание»
    def keep(s):
        if s.title == '__end__':
            return False
        if s.marker and not s.title and not s.blocks and not s.children:
            return False
        return True

    def prune(secs):
        out = []
        for s in secs:
            s.children = prune(s.children)
            if keep(s):
                out.append(s)
        return out
    doc.sections = prune(doc.sections)


def _clear_marks(doc):
    for s in doc.walk():
        s.mark = False
        for b in s.blocks:
            b.mark, b.mark_text = False, ''
            for i in b.items:
                i.mark = False


def _keep_marked(doc):
    """Режим «только выделенное»: остаются разделы с пометками (и их родители); внутри раздела —
    только выделенные абзацы, пункты и таблицы (если выделен весь раздел — всё его содержимое)."""
    from .model import Block

    def strip_blocks(s):
        if s.mark:
            return
        keep = []
        for b in s.blocks:
            if b.kind == 'para' and (b.mark or b.mark_text):
                keep.append(Block('para', text=b.mark_text or b.text, bold=b.bold, mark=True))
            elif b.kind == 'list':
                items = [i for i in b.items if i.mark]
                if items:
                    keep.append(Block('list', items=items, ordered=b.ordered))
            elif b.kind in ('table', 'image') and b.mark:
                keep.append(b)
        s.blocks = keep

    def prune(secs):
        out = []
        for s in secs:
            s.children = prune(s.children)
            if s.marked() or s.children:
                strip_blocks(s)
                out.append(s)
        return out
    doc.sections = prune(doc.sections)
