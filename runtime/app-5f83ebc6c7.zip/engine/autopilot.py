# -*- coding: utf-8 -*-
"""
autopilot.py — АВТОПИЛОТ: ПАПКА «ВХОДЯЩИЕ» → ГОТОВЫЕ ПРОВЕРЕННЫЕ ПРЕЗЕНТАЦИИ (1.7)
================================================================================
Документ кладётся в папку «Входящие» — рядом, в папке «Готово», появляются:
  * «Имя.pptx» — презентация в фирменном шаблоне;
  * «Имя — проверка.txt» — отчёт: замечания рецензента, сверка чисел с документом, готовый файл глазами зрителя
    (текст за рамкой и краем слайда, наезды, мелкий шрифт), что исправлено в тексте, предупреждения сборки;
  * «Имя — план.json» — план: перетащите его в окно конструктора, чтобы поправить и собрать заново.
Папка внутри «Входящих» — одна презентация из всех её файлов. Сохранённый план (.json) — сборка по нему.
Файл изменился — презентация собирается заново; исходные файлы не трогаются и не перемещаются.
Файл, который ещё копируется (менялся последние секунды), и временные файлы (~$…, .tmp, .part) ждут.

Сам план строит analyze(files) — его передаёт приложение (те же режимы и модели, что в окне конструктора).
"""
import datetime as dt
import hashlib
import json
import os
import re
import threading
import time
from pathlib import Path

from .nts import config as C

INBOX_NAME = 'Входящие'
DONE = 'Готово'
STATE = '.автопилот.json'
HELP = 'Как пользоваться автопилотом.txt'
SETTLE = 5.0                                         # секунд без изменений — файл докопирован
MAX_FILES = 30                                       # файлов в одной папке-презентации
SKIP = re.compile(r'(?i)^(~\$|\.|thumbs\.db$|desktop\.ini$)|\.(tmp|part|crdownload|download|partial)$')
MODE_NAMES = {'rules': 'по правилам', 'search': 'по правилам + поиск фраз', 'ai': 'локальная ИИ'}
LOCK = threading.Lock()                              # одна обработка за раз (фон и кнопка «Обработать сейчас»)
STATUS = {'running': False, 'current': '', 'last': 0.0, 'error': ''}


def default_folder():
    return C.OUTPUT_DIR / INBOX_NAME


def folder_of(path):
    """Папка «Входящие» из настроек ('' — output/Входящие)."""
    return Path(os.path.expandvars(os.path.expanduser(str(path)))) if str(path or '').strip() else default_folder()


HELP_TEXT = """Автопилот конструктора презентаций

1. Положите документ (Word, PDF, Excel, PowerPoint, текст) в папку «Входящие».
2. Через несколько секунд здесь, в папке «Готово», появятся:
   • «Имя.pptx» — презентация в фирменном шаблоне;
   • «Имя — проверка.txt» — замечания рецензента и сверка чисел с документом;
   • «Имя — план.json» — план презентации.
3. Чтобы что-то поправить, перетащите «Имя — план.json» в окно конструктора, исправьте и соберите заново
   (или сохраните исправленный план в «Входящие» — автопилот соберёт по нему).

Несколько файлов для одной презентации положите в отдельную папку внутри «Входящих».
Изменили документ — презентация соберётся заново. Исходные файлы автопилот не трогает.
Автопилот работает, пока запущен конструктор: при включённом автопилоте он не выключается сам
после закрытия вкладки. Включается и выключается в окне «🤖 Автопилот».
"""


def ensure(folder):
    """Папки «Входящие» и «Готово» (и подсказка в «Готово»)."""
    folder = Path(folder)
    (folder / DONE).mkdir(parents=True, exist_ok=True)
    h = folder / DONE / HELP
    if not h.exists():
        h.write_text(HELP_TEXT.replace('\n', '\r\n'), encoding='utf-8-sig')
    return folder


def _supported():
    from .readers import SUPPORTED
    return SUPPORTED


def is_plan(path):
    """Сохранённый план конструктора («Сохранить план» или «… — план.json»)."""
    try:
        sp = json.loads(Path(path).read_text(encoding='utf-8-sig'))
    except (OSError, ValueError):
        return False
    return isinstance(sp, dict) and isinstance(sp.get('slides'), list) and \
        any(isinstance(s, dict) and isinstance(s.get('layout'), str) for s in sp['slides'])


def jobs(folder):
    """Что собрать: [(ключ, имя результата, [файлы])]. Файл — своя презентация; папка — одна из всех её файлов."""
    folder, ok = Path(folder), _supported()
    out = []
    try:
        items = sorted(folder.iterdir(), key=lambda p: p.name.lower())
    except OSError:
        return []
    for p in items:
        if SKIP.search(p.name) or p.name == DONE:
            continue
        try:
            if p.is_file() and p.suffix.lower() in ok:
                out.append((p.name, p.stem, [p]))
            elif p.is_dir():
                files = sorted((f for f in p.rglob('*') if f.is_file() and f.suffix.lower() in ok
                                and not any(SKIP.search(x) for x in f.relative_to(p).parts)),
                               key=lambda f: str(f).lower())[:MAX_FILES]
                if files:
                    out.append((p.name + '/', p.name, files))
        except OSError:
            continue
    stems = [name.lower() for _, name, _ in out]                 # «Справка.docx» и «Справка.pdf» — разные имена
    return [(k, (k if stems.count(name.lower()) > 1 and not k.endswith('/') else name), fs) for k, name, fs in out]


def signature(files):
    h = hashlib.sha1()
    for f in files:
        st = f.stat()
        h.update(f'{f.name}|{st.st_size}|{st.st_mtime_ns};'.encode('utf-8', 'replace'))
    return h.hexdigest()[:16]


def settled(files, now=None, settle=SETTLE):
    now = time.time() if now is None else now
    try:
        return all(now - f.stat().st_mtime >= settle for f in files)
    except OSError:
        return False


def _load_state(folder):
    try:
        st = json.loads((Path(folder) / DONE / STATE).read_text(encoding='utf-8'))
        return st if isinstance(st, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_state(folder, st):
    p = Path(folder) / DONE / STATE
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding='utf-8')
    os.replace(tmp, p)


def _safe(name):
    name = re.sub(r'[\\/:*?"<>|\n\r\t]+', ' ', str(name or 'Презентация')).strip(' .')
    return name[:100] or 'Презентация'


# ---------------------------------------------------------------------------------------------
# Одна презентация
# ---------------------------------------------------------------------------------------------
def _checks(spec):
    """Рецензент (правила) и сверка чисел с документом. Ошибка проверки не мешает результату."""
    from .factcheck import verify
    from .review import review
    try:
        rv = review(spec)
    except Exception as e:                               # noqa: BLE001
        rv = {'counts': {'warn': 0, 'tip': 0}, 'deck': [], 'slides': [], 'error': str(e)}
    try:
        vf = verify(spec)
    except Exception as e:                               # noqa: BLE001
        vf = {'error': str(e)}
    return rv, vf


def _file_check(path, spec):
    """Проверка готового файла (deckcheck): по файлу и, если есть программа просмотра, по картинке слайдов."""
    import shutil
    import tempfile

    from . import deckcheck as DC
    tmp = Path(tempfile.mkdtemp(prefix='zn_auto_'))
    try:
        p = tmp / 'проверка.pptx'
        shutil.copy(path, p)
        pdf = None
        if DC.TO_PDF is not None:
            try:
                pdf = DC.TO_PDF(p)
            except Exception:                            # noqa: BLE001 — без картинки проверка идёт по файлу
                pdf = None
        return DC.check(p, spec, pdf, images=False)
    except Exception as e:                               # noqa: BLE001
        return {'error': f'{type(e).__name__}: {e}'}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def report_text(rec, rv, vf, sources, tx=None, fc=None):
    """Отчёт «— проверка.txt»."""
    when = dt.datetime.fromtimestamp(rec['when']).strftime('%d.%m.%Y %H:%M')
    L = [f'Автопилот конструктора презентаций · {when}', f'Источник: {", ".join(sources)}',
         f'Презентация: {rec["pptx"]} · слайдов: {rec["slides"]} · {MODE_NAMES.get(rec.get("mode"), rec.get("mode") or "")}'
         f' · {str(rec["seconds"]).replace(".", ",")} с', '']
    c = rv.get('counts') or {}
    L.append('Проверка (рецензент)')
    if rv.get('error'):
        L.append(f'  Не выполнена: {rv["error"]}')
    else:
        L.append(f'  Замечаний: {c.get("warn", 0)}, советов: {c.get("tip", 0)}.')
        for f in rv.get('deck') or []:
            L.append(f'  {"⚠" if f["level"] == "warn" else "•"} Вся презентация: {f["text"]}')
        for s in rv.get('slides') or []:
            for f in s['items']:
                L.append(f'  {"⚠" if f["level"] == "warn" else "•"} Слайд {s["i"] + 1} «{s["title"]}»: {f["text"]}')
    L.append('')
    L.append('Сверка чисел с документом')
    if vf.get('error'):
        L.append(f'  Не выполнена: {vf["error"]}')
    else:
        n = vf.get('counts') or {}
        L.append(f'  Совпадают: {n.get("ok", 0)}, округлены: {n.get("rounded", 0)}, расчётные: {n.get("derived", 0)}, '
                 f'только в библиотеке: {n.get("library", 0)}, не найдены в документе: {n.get("missing", 0)}.')
        for s in vf.get('slides') or []:
            for x in s['numbers']:
                if x['status'] in ('missing', 'library'):
                    why = 'не найдено в документе' if x['status'] == 'missing' else 'есть только в библиотеке, не в документе'
                    L.append(f'  ⚠ Слайд {s["i"] + 1} «{s["title"]}»: {x["raw"]} — {why}.')
    if fc:
        L += ['', 'Готовый файл (как его увидят на экране)']
        if fc.get('error'):
            L.append(f'  Не выполнена: {fc["error"]}')
        else:
            n = fc.get('counts') or {}
            L.append(f'  Важных: {n.get("warn", 0)}, советов: {n.get("tip", 0)}.' if n.get('warn') or n.get('tip') else
                     '  Всё на своих местах: текст в рамках и в пределах слайда, надписи не наезжают, шрифт читаемый.')
            L += [f'  {x}' for x in fc.get('notes') or []]
            for f in fc.get('deck') or []:
                L.append(f'  {"⚠" if f["level"] == "warn" else "•"} {f["text"]}')
            for s in fc.get('slides') or []:
                for f in s['items']:
                    L.append(f'  {"⚠" if f["level"] == "warn" else "•"} Слайд {f["page"]} «{s["title"]}»: {f["text"]}')
    if tx and tx.get('findings'):
        n = tx.get('counts') or {}
        L += ['', 'Текст: исправлено при сборке',
              f'  Названия по словарю: {n.get("словарь", 0)}, правописание: {n.get("правописание", 0)}, '
              f'типографика (кавычки, тире, пробелы): {n.get("типографика", 0)}.']
        shown = [f for f in tx['findings'] if f['kind'] != 'типографика']
        for f in shown[:30]:
            L.append(f'  • Слайд {f["i"] + 1} «{f["title"]}»: {f["word"]} → {f["fixed"]}'.replace('\u00a0', ' '))
        if len(shown) > 30:
            L.append(f'  … и ещё {len(shown) - 30}.')
    if rec.get('warnings'):
        L += ['', 'Предупреждения сборки'] + [f'  • {w}' for w in rec['warnings']]
    L += ['', f'Поправить: перетащите «{rec["plan"]}» в окно конструктора, исправьте и соберите заново.']
    return '\r\n'.join(L) + '\r\n'


def run_one(folder, key, name, files, analyze, mode='rules'):
    """Собрать одну презентацию → запись для списка и состояния."""
    from . import build
    t0 = time.time()
    done = Path(folder) / DONE
    base = _safe(name)
    rec = {'key': key, 'name': name, 'files': [f.name for f in files], 'sig': signature(files), 'mode': mode,
           'pptx': base + '.pptx', 'report': base + ' — проверка.txt', 'plan': base + ' — план.json'}
    try:
        if len(files) == 1 and files[0].suffix.lower() == '.json' and is_plan(files[0]):
            spec = json.loads(files[0].read_text(encoding='utf-8-sig'))
            warnings, rec['mode'] = [], 'plan'
        else:
            spec, warnings, info = analyze([(str(f), f.name) for f in files])
            if spec is None:
                raise ValueError('; '.join(warnings) or 'в файлах не найдено текста или таблиц')
            rec['mode'] = info.get('mode_used') or mode
        from .dictionary import fix_plan
        spec, tx = fix_plan(spec)                        # словарь, правописание, типографика — в план и отчёт
        tmp = done / f'.{base}.tmp.pptx'
        _, bwarn, n = build(spec, tmp)
        os.replace(tmp, done / rec['pptx'])              # готовый файл появляется сразу целиком
        (done / rec['plan']).write_text(json.dumps(spec, ensure_ascii=False, indent=1), encoding='utf-8')
        rv, vf = _checks(spec)
        fc = _file_check(done / rec['pptx'], spec)
        rec.update(state='done', slides=n, file=(fc.get('counts') or {}), warnings=list(dict.fromkeys(warnings + bwarn))[:12],
                   warn=(rv.get('counts') or {}).get('warn', 0), tip=(rv.get('counts') or {}).get('tip', 0),
                   numbers=vf.get('counts') or {}, text=tx.get('counts') or {}, error='')
    except Exception as e:                               # noqa: BLE001 — сбой одного файла не останавливает остальные
        rec.update(state='error', error=f'{type(e).__name__}: {e}' if not isinstance(e, ValueError) else str(e))
        rv, vf, tx, fc = {}, {}, {}, {}
    rec['when'], rec['seconds'] = time.time(), round(time.time() - t0, 1)
    if rec['state'] == 'done':
        (done / rec['report']).write_text(report_text(rec, rv, vf, rec['files'], tx, fc), encoding='utf-8-sig')
    for junk in done.glob('.*.tmp.pptx'):
        try:
            junk.unlink()
        except OSError:
            pass
    return rec


def process(folder, analyze, mode='rules', progress=None, now=None):
    """Один проход по «Входящим»: собрать новое и изменённое. → список записей (что сделано в этот раз)."""
    folder = ensure(folder)
    if not LOCK.acquire(blocking=False):
        return []
    STATUS.update(running=True, error='')
    made = []
    try:
        st = _load_state(folder)
        todo = jobs(folder)
        keys = {k for k, _, _ in todo}
        for k in [k for k in st if k not in keys]:       # исходник убрали — запись не нужна (готовые файлы остаются)
            st.pop(k)
        for key, name, files in todo:
            try:
                sig = signature(files)
            except OSError:
                continue
            old = st.get(key) or {}
            if old.get('sig') == sig and (old.get('state') == 'error' or (Path(folder) / DONE / old.get('pptx', '')).exists()):
                continue
            if not settled(files, now):
                st[key] = dict(old, key=key, name=name, state='waiting')
                continue
            STATUS['current'] = name
            if progress:
                progress({'phase': 'start', 'name': name})
            rec = run_one(folder, key, name, files, analyze, mode)
            st[key] = rec
            made.append(rec)
            _save_state(folder, st)
        _save_state(folder, st)
    except OSError as e:
        STATUS['error'] = f'Папка «{folder}» недоступна: {e}'
    finally:
        STATUS.update(running=False, current='', last=time.time())
        LOCK.release()
    return made


def listing(folder):
    """Записи для окна «Автопилот»: всё, что лежит во «Входящих», с состоянием (новые — «в очереди»)."""
    folder = Path(folder)
    st = _load_state(folder) if (folder / DONE).exists() else {}
    out = []
    for key, name, files in jobs(folder):
        r = dict(st.get(key) or {'key': key, 'name': name, 'state': 'queued'})
        try:
            if r.get('state') != 'waiting' and r.get('sig') and r['sig'] != signature(files):
                r['state'] = 'queued'                    # документ изменили — соберётся заново
        except OSError:
            pass
        if r.get('state') == 'done' and not (folder / DONE / r.get('pptx', '')).exists():
            r['state'] = 'queued'
        if STATUS['running'] and STATUS['current'] == name:
            r['state'] = 'working'
        r['files'] = [f.name for f in files]
        out.append(r)
    return out


def file_of(folder, key, kind):
    """Готовый файл записи (pptx | report | plan) — только из папки «Готово»."""
    rec = _load_state(folder).get(key) or {}
    name = rec.get({'pptx': 'pptx', 'report': 'report', 'plan': 'plan'}.get(kind, ''), '')
    if not name:
        return None
    p = (Path(folder) / DONE / name)
    try:
        p.resolve().relative_to((Path(folder) / DONE).resolve())
    except (ValueError, OSError):
        return None
    return p if p.is_file() else None
