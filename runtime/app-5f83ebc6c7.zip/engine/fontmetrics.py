# -*- coding: utf-8 -*-
"""
fontmetrics.py — ШИРИНЫ СИМВОЛОВ ШРИФТОВ СВОЕГО ШАБЛОНА (для подгонки текста)
============================================================================

Подгонка кегля (textfit.py) считает ширину текста по заранее снятым ширинам символов.
Для корпоративных шрифтов TT Bluescreens Pro они лежат в font_metrics.json. У своего
шаблона PowerPoint шрифты другие (Arial, Calibri, Montserrat …) — их ширины снимаются
здесь, один раз при загрузке шаблона:

  1) шрифт ищется среди установленных на этом компьютере (Windows: C:\\Windows\\Fonts и
     шрифты пользователя; Linux и macOS — стандартные папки шрифтов);
  2) если его нет — среди шрифтов, встроенных в сам шаблон (только несжатые);
  3) если и там нет — берётся близкий по ширине: Calibri → Carlito, Arial → Liberation Sans …;
  4) в крайнем случае — Arial с запасом 5 % (и предупреждение: подгонка примерная).
Если в шрифте нет каких-то символов (часто — русских букв), их ширины берутся у запасного
шрифта: PowerPoint тоже покажет такие символы другим шрифтом.

Результат — словарь как в font_metrics.json: {'mn': …, 'mj': …, 'b': …}, где
'mj' — шрифт заголовков темы, 'mn' — основного текста, 'b' — жирный шрифт заголовков.
"""
import io
import json
import os
import struct
import sys
import threading
from pathlib import Path

from .nts import config as C

_BUILTIN = json.loads(Path(__file__).with_name('font_metrics.json').read_text(encoding='utf8'))
CHARS = sorted(_BUILTIN['mn']['widths'])          # символы, ширины которых нужны подгонке
INDEX_FILE = C.OUTPUT_DIR / 'font_index.json'
_LOCK = threading.Lock()
_INDEX = None

# Близкие по ширине замены (метрически совместимые шрифты — у них те же ширины символов)
SUBST = {
    'calibri': ['carlito'], 'calibri light': ['carlito'], 'cambria': ['caladea'],
    'arial': ['liberation sans', 'arimo'], 'helvetica': ['liberation sans', 'arial', 'arimo'],
    'arial narrow': ['liberation sans narrow'], 'times new roman': ['liberation serif', 'tinos'],
    'courier new': ['liberation mono', 'cousine'], 'segoe ui': ['open sans', 'noto sans', 'dejavu sans'],
}
FALLBACK = ['arial', 'liberation sans', 'arimo', 'dejavu sans', 'freesans']


def font_dirs():
    """Папки со шрифтами этого компьютера."""
    home = Path.home()
    if os.name == 'nt':
        dirs = [Path(os.environ.get('WINDIR', r'C:\Windows')) / 'Fonts']
        if os.environ.get('LOCALAPPDATA'):
            dirs.append(Path(os.environ['LOCALAPPDATA']) / 'Microsoft' / 'Windows' / 'Fonts')
    elif sys.platform == 'darwin':
        dirs = [Path('/System/Library/Fonts'), Path('/Library/Fonts'), home / 'Library' / 'Fonts']
    else:
        dirs = [Path('/usr/share/fonts'), Path('/usr/local/share/fonts'), home / '.fonts',
                home / '.local' / 'share' / 'fonts']
    return [d for d in dirs if d.is_dir()]


def _scan(dirs):
    """{семейство (строчными): {начертание (строчными): [путь, номер в .ttc]}}."""
    from PIL import ImageFont
    idx = {}
    for d in dirs:
        for p in d.rglob('*'):
            if p.suffix.lower() not in ('.ttf', '.otf', '.ttc'):
                continue
            for i in range(8 if p.suffix.lower() == '.ttc' else 1):
                try:
                    fam, style = ImageFont.truetype(str(p), 20, index=i).getname()
                except Exception:                            # noqa: BLE001
                    break
                if fam:
                    idx.setdefault(fam.strip().lower(), {}).setdefault((style or 'regular').strip().lower(), [str(p), i])
    return idx


def font_index():
    """Список шрифтов компьютера (кэш output/font_index.json; пересоздаётся, если папки шрифтов менялись)."""
    global _INDEX
    with _LOCK:
        dirs = font_dirs()
        sig = [[str(d), int(d.stat().st_mtime)] for d in dirs]
        if _INDEX and _INDEX.get('sig') == sig:
            return _INDEX['fonts']
        try:
            saved = json.loads(INDEX_FILE.read_text(encoding='utf-8'))
            if saved.get('sig') == sig:
                _INDEX = saved
                return saved['fonts']
        except (OSError, ValueError):
            pass
        _INDEX = {'sig': sig, 'fonts': _scan(dirs)}
        try:
            INDEX_FILE.parent.mkdir(parents=True, exist_ok=True)
            INDEX_FILE.write_text(json.dumps(_INDEX, ensure_ascii=False), encoding='utf-8')
        except OSError:
            pass
        return _INDEX['fonts']


def _pick(styles, bold):
    want = ('bold', 'semibold', 'demibold', 'heavy', 'black') if bold else ('regular', 'normal', 'book', 'roman', 'medium')
    for w in want:
        for st, v in styles.items():
            if st == w:
                return v
    for st, v in styles.items():
        if bold == ('bold' in st) and 'italic' not in st and 'oblique' not in st:
            return v
    return None if bold else next(iter(styles.values()))


def find_font(family, bold=False, index=None):
    """Файл шрифта по имени семейства → (путь, номер) или None. Имена во встроенных шрифтах
    PowerPoint обрезаны до 31 символа, а начертание бывает частью имени («Montserrat Medium»)."""
    if not family:
        return None
    idx = font_index() if index is None else index
    name = family.strip().lower()
    if name in idx:
        return _pick(idx[name], bold)
    if len(name) >= 28:                                     # обрезанное имя
        for fam, styles in idx.items():
            if fam.startswith(name):
                return _pick(styles, bold)
    words = name.split()
    for k in range(len(words) - 1, 0, -1):                  # «Montserrat SemiBold» → семейство Montserrat
        fam, style = ' '.join(words[:k]), ' '.join(words[k:])
        if fam in idx:
            styles = idx[fam]
            for st, v in styles.items():
                if st.replace(' ', '') == style.replace(' ', ''):
                    return v
            return _pick(styles, bold)
    return None


def eot_font(data):
    """Шрифт, встроенный в .pptx (часть ppt/fonts/*.fntdata): обычный TrueType или несжатый
    Embedded OpenType → байты TrueType; сжатый MicroType Express → None."""
    if data[:4] in (b'\x00\x01\x00\x00', b'OTTO', b'true', b'ttcf'):
        return data
    try:
        eot_size, font_size, version, flags = struct.unpack('<IIII', data[:16])
    except struct.error:
        return None
    if eot_size != len(data) or font_size > len(data) or version not in (0x10000, 0x20001, 0x20002):
        return None
    if flags & 0x4:                                          # TTEMBED_TTCOMPRESSED — MicroType Express
        return None
    font = data[-font_size:]
    if flags & 0x10000000:                                   # TTEMBED_XORENCRYPTDATA
        font = bytes(b ^ 0x50 for b in font)
    return font


CYR = 'абвгдеёжзийклмнопрстуфхцчшщъыьэюяАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'


def measure(src, index=0):
    """Ширины символов шрифта (src — путь или байты) в долях кегля, как в font_metrics.json.
    'missing' — символы, которых в шрифте нет (вместо них «пустой квадрат» .notdef)."""
    from PIL import ImageFont
    size = 1000
    f = ImageFont.truetype(io.BytesIO(src) if isinstance(src, (bytes, bytearray)) else str(src), size, index=index)
    notdef = (f.getlength('\U0010FFFD'), f.getbbox('\U0010FFFD'))
    widths, missing = {}, []
    for ch in CHARS:
        w = f.getlength(ch)
        if ch.strip() and (w, f.getbbox(ch)) == notdef:
            missing.append(ch)
        widths[ch] = round(w / size, 4)
    asc, desc = f.getmetrics()
    vals = [w for ch, w in widths.items() if w > 0 and ch not in missing]
    return {'widths': widths, 'line': round((asc + desc) / size, 3),
            'default': round(sum(vals) / max(1, len(vals)), 4), 'missing': ''.join(missing)}


def _fill(m, idx, bold=False):
    """Символов нет в шрифте (часто — русских букв: PowerPoint покажет их другим шрифтом) —
    их ширины берутся у запасного шрифта с запасом 5 %."""
    miss = m.pop('missing', '')
    if not miss:
        return m, False
    alt = None
    for name in FALLBACK:
        hit = find_font(name, bold, idx) or find_font(name, False, idx)
        if hit:
            try:
                alt = measure(hit[0], hit[1])
                break
            except Exception:                                # noqa: BLE001
                pass
    src = alt['widths'] if alt else _BUILTIN['mn']['widths']
    for ch in miss:
        m['widths'][ch] = round(src.get(ch, m['default']) * 1.05, 4)
    return m, sum(ch in miss for ch in CYR) > len(CYR) // 3


def _scaled(m, k):
    return {'widths': {ch: round(w * k, 4) for ch, w in m['widths'].items()}, 'line': m.get('line', 1.22),
            'default': round(m['default'] * k, 4)}


def _one(family, bold, embedded, idx):
    """Ширины одного шрифта → (метрики, откуда взяты: 'system' | 'embedded' | 'builtin' | 'similar' |
    'approx' | 'nocyr' — в самом шрифте нет русских букв)."""
    name = (family or '').strip()
    hit = find_font(name, bold, idx)
    if hit:
        try:
            m, nocyr = _fill(measure(hit[0], hit[1]), idx, bold)
            return m, 'nocyr' if nocyr else 'system'
        except Exception:                                    # noqa: BLE001
            pass
    for emb_name, emb_bold, data in embedded or ():
        if emb_name.lower() == name.lower() and emb_bold == bold:
            font = eot_font(data)
            if font:
                try:
                    m, nocyr = _fill(measure(font), idx, bold)
                    return m, 'nocyr' if nocyr else 'embedded'
                except Exception:                            # noqa: BLE001
                    pass
    if name.lower().startswith('tt bluescreens'):
        return _BUILTIN['b' if bold else 'mn'], 'builtin'
    for alt in SUBST.get(name.lower(), []):
        hit = find_font(alt, bold, idx)
        if hit:
            try:
                m, nocyr = _fill(measure(hit[0], hit[1]), idx, bold)  # у замены нет русских букв — ширины примерные
                return m, 'approx' if nocyr else 'similar'
            except Exception:                                # noqa: BLE001
                pass
    for alt in FALLBACK:
        hit = find_font(alt, bold, idx)
        if hit:
            try:
                return _scaled(_fill(measure(hit[0], hit[1]), idx, bold)[0], 1.05), 'approx'
            except Exception:                                # noqa: BLE001
                pass
    return _scaled(_BUILTIN['b' if bold else 'mn'], 1.1), 'approx'


def metrics_for(major, minor, embedded=None):
    """Метрики шаблона {'mj', 'mn', 'b'} и шрифты, ширины которых взяты приблизительно.
    embedded — [(имя, жирный, байты)] шрифтов, встроенных в шаблон."""
    try:
        idx = font_index()
    except Exception:                                        # noqa: BLE001
        idx = {}
    mj, how_mj = _one(major, False, embedded, idx)
    mn, how_mn = _one(minor, False, embedded, idx)
    b, how_b = _one(major, True, embedded, idx)
    if how_b == 'approx' and how_mj != 'approx':            # жирного начертания нет — обычное шире на 6 %
        b = _scaled(mj, 1.06)
    approx = sorted({f for f, how in ((major, how_mj), (minor, how_mn)) if how == 'approx' and f})
    return {'mj': mj, 'mn': mn, 'b': b}, approx, {'major': how_mj, 'minor': how_mn}


def no_cyrillic(how, fonts):
    """Шрифты шаблона без русских букв (по сведениям metrics_for)."""
    return sorted({fonts.get(k) for k in ('major', 'minor') if (how or {}).get(k) == 'nocyr' and fonts.get(k)})
