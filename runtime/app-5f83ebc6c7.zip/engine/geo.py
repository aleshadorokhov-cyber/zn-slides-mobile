# -*- coding: utf-8 -*-
"""
geo.py — КАРТА МИРА: КОНТУРЫ СТРАН, ПОИСК СТРАН В ТЕКСТЕ, РИСОВАНИЕ ФИГУРАМИ POWERPOINT
=====================================================================================

Контуры стран — assets/maps/world.json (Natural Earth 1:50 млн, общественное достояние;
готовит tools/dev/make_maps.py). Проекция Миллера, ширина карты 1000 единиц.

  countries()                 — {код: страна} (код ISO-3 по Natural Earth: RUS, VNM, CUB…);
  find_countries(text)        — коды стран, названных в тексте («во Вьетнаме», «на Кубе», «ОАЭ»);
  item_countries(items)       — страна каждого пункта (по заголовку, затем по тексту) или None;
  map_view(ids, aspect)       — область карты вокруг стран (с соседями), с нужными пропорциями;
  draw_map(container, …)      — карта фигурами PowerPoint: страны — полилиниями, выделенные — цветом;
  picture_svg(ids)            — та же карта в виде SVG (картинки библиотеки world_map / russia_map).
"""
import json
import re
from functools import lru_cache

from .nts import config as C

MAP_FILE = C.ASSETS / 'maps' / 'world.json'

ENDINGS = r'(?:а|е|ы|у|ой|ою|и|ю|я|ей|ии|ию|ией|ия|ом|ах|ам|ами)?'
ADJ = r'(?:ая|ой|ую|ою|ое|ого|ому|ом|ые|ых|ым|ыми|ий|ый|ие|их|им|ими|ая|яя|ей|юю|ее)'   # «Российская Федерация» → «в Российской Федерации»
VOWELS = 'аеёиоуыэюяй'


@lru_cache(maxsize=1)
def _data():
    try:
        doc = json.loads(MAP_FILE.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {'width': 1000.0, 'height': 560.0, 'countries': {}}
    sc = float(doc.get('scale') or 10)
    out = {}
    for c in doc.get('countries') or []:
        rings = [[(r[i] / sc, r[i + 1] / sc) for i in range(0, len(r) - 1, 2)] for r in c['rings']]
        out[c['id']] = {'id': c['id'], 'name': c['name'], 'en': c.get('en', ''), 'alias': c.get('alias') or [],
                        'label': (c['label'][0] / sc, c['label'][1] / sc), 'rings': rings}
    return {'width': float(doc.get('width') or 1000), 'height': float(doc.get('height') or 560), 'countries': out}


def countries():
    return _data()['countries']


def size():
    d = _data()
    return d['width'], d['height']


def _name_rx(name):
    """Название → регулярное выражение со склонениями: «Куба» → Куб(а|е|ы|у|ой…), «Вьетнам» → Вьетнам(е|а…)."""
    words = name.split()
    parts = []
    for w in words:
        if len(w) <= 2 and w.islower():                     # «и», «о» в «Босния и Герцеговина»
            parts.append(re.escape(w))
            continue
        lw = w.lower()
        if len(w) > 4 and lw[-2:] in ('ая', 'ое', 'ые', 'ий', 'ый', 'ой', 'ие'):        # прилагательное
            parts.append(re.escape(w[:-2]) + ADJ)
            continue
        stem = w[:-1] if len(w) > 3 and lw[-1] in 'аяеоыийь' else w
        rx = re.escape(stem) + (r'\w{0,3}' if lw[-1] in 'йь' else ENDINGS)
        if len(w) > 4 and lw[-1] not in VOWELS + 'ь' and lw[-2] in 'ео' and lw[-3] not in VOWELS:
            rx = f'(?:{rx}|{re.escape(w[:-2] + w[-1])}(?:а|е|у|ом))'                  # беглая гласная: Египет → в Египте
        parts.append(rx)
    return r'(?<![\w-])' + r'\s+'.join(parts) + r'(?![\w-])'


@lru_cache(maxsize=1)
def _patterns():
    pats = []
    for c in countries().values():
        names = [c['name']] + list(c['alias'])
        for nm in names:
            if not nm:
                continue
            if nm.isupper() and len(nm) <= 4:                # аббревиатуры: США, ОАЭ, РФ, КНР
                rx = r'(?<![\w-])' + re.escape(nm) + r'(?![\w-])'
            else:
                rx = _name_rx(nm)
            pats.append((len(nm), c['id'], re.compile(rx)))
    pats.sort(key=lambda p: -p[0])                           # длинные названия раньше («Южная Корея» до «Корея»)
    return pats


def find_countries(text):
    """Коды стран в порядке упоминания (без повторов). Названия — с заглавной буквы, как в тексте."""
    if not text:
        return []
    found = []
    taken = []
    for _, cid, rx in _patterns():
        for m in rx.finditer(text):
            if any(a < m.end() and m.start() < b for a, b in taken):
                continue
            taken.append((m.start(), m.end()))
            found.append((m.start(), cid))
    seen, out = set(), []
    for _, cid in sorted(found):
        if cid not in seen:
            seen.add(cid)
            out.append(cid)
    return out


def item_countries(items):
    """Страна каждого пункта: сначала по заголовку, затем по тексту; None — страны нет."""
    out = []
    for it in items or []:
        ids = find_countries(it.get('title') or '') if isinstance(it, dict) else []
        if not ids and isinstance(it, dict):
            ids = find_countries(it.get('text') or '')[:1]
        out.append(ids[0] if ids else None)
    return out


# --------------------------------------------------------------------------------------
# Геометрия
# --------------------------------------------------------------------------------------
def _bbox(pts):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def _area(pts):
    return abs(sum(x1 * y2 - x2 * y1 for (x1, y1), (x2, y2) in zip(pts, pts[1:] + pts[:1]))) / 2


def main_rings(cid):
    """Контуры страны, задающие её область: главный и крупные/близкие к нему (без заморских
    территорий и кусков за 180-м меридианом — иначе Россия «растянулась» бы на всю карту)."""
    c = countries().get(cid)
    if not c:
        return []
    rings = c['rings']
    main = rings[0]
    a0 = _area(main)
    bx = _bbox(main)
    out = [main]
    for r in rings[1:]:
        b = _bbox(r)
        near = b[0] < bx[2] + 60 and b[2] > bx[0] - 60 and b[1] < bx[3] + 60 and b[3] > bx[1] - 60
        if near and (_area(r) > a0 * 0.002 or near):
            out.append(r)
    return out


def map_view(ids, aspect, pad=0.35, min_w=170.0):
    """Область карты (x0, y0, w, h) вокруг стран ids с полями и пропорцией ровно aspect = w/h (иначе
    карта исказится). Поля pad — доля размера стран; у крупных стран поля меньше. Страны по всему
    свету — вся карта по ширине; область может выходить за край карты (там пустой «океан»)."""
    W, H = size()
    pts = [p for cid in ids for r in main_rings(cid) for p in r]
    if not pts:
        return 0.0, (H - W / aspect) / 2, W, W / aspect
    x0, y0, x1, y1 = _bbox(pts)
    w, h = x1 - x0, y1 - y0
    k = max(0.08, pad * min(1.0, 220.0 / max(w, h, 1)))
    w, h = max(min_w, w * (1 + 2 * k)), max(min_w / aspect, h * (1 + 2 * k))
    if w / h < aspect:
        w = h * aspect
    else:
        h = w / aspect
    if w >= W * 0.85:                                         # почти весь мир — вся карта по ширине
        w, h = W, W / aspect
        cy = (y0 + y1) / 2
        return 0.0, (min(max(0.0, cy - h / 2), H - h) if h < H else (H - h) / 2), w, h
    if h > H:                                                 # выше карты — «океан» сверху и снизу
        return min(max(0.0, (x0 + x1) / 2 - w / 2), W - w), (H - h) / 2, w, h
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    return min(max(0.0, cx - w / 2), W - w), min(max(0.0, cy - h / 2), H - h), w, h


def _clip(pts, x0, y0, x1, y1):
    """Отсечение многоугольника прямоугольником (Сазерленд — Ходжмен)."""
    def cut(poly, inside, inter):
        out = []
        for i, p in enumerate(poly):
            q = poly[i - 1]
            if inside(p):
                if not inside(q):
                    out.append(inter(q, p))
                out.append(p)
            elif inside(q):
                out.append(inter(q, p))
        return out

    def ix(xv):
        return lambda a, b: (xv, a[1] + (b[1] - a[1]) * (xv - a[0]) / ((b[0] - a[0]) or 1e-9))

    def iy(yv):
        return lambda a, b: (a[0] + (b[0] - a[0]) * (yv - a[1]) / ((b[1] - a[1]) or 1e-9), yv)
    poly = list(pts)
    for inside, inter in ((lambda p: p[0] >= x0, ix(x0)), (lambda p: p[0] <= x1, ix(x1)),
                          (lambda p: p[1] >= y0, iy(y0)), (lambda p: p[1] <= y1, iy(y1))):
        if not poly:
            break
        poly = cut(poly, inside, inter)
    return poly


def _thin(pts, step):
    """Убирает точки ближе step друг к другу (на мелком масштабе они не видны)."""
    out = [pts[0]]
    for p in pts[1:]:
        if abs(p[0] - out[-1][0]) + abs(p[1] - out[-1][1]) >= step:
            out.append(p)
    return out if len(out) >= 3 else []


def shapes_in_view(view, min_px=0.0015):
    """[(код, [контуры в долях области 0..1])] — страны, попавшие в область, уже отсечённые."""
    vx, vy, vw, vh = view
    x1, y1 = vx + vw, vy + vh
    out = []
    step = vw * min_px
    for cid, c in countries().items():
        rings = []
        for r in c['rings']:
            b = _bbox(r)
            if b[2] < vx or b[0] > x1 or b[3] < vy or b[1] > y1:
                continue
            if (b[2] - b[0]) < step * 2 and (b[3] - b[1]) < step * 2:
                continue                                     # остров меньше точки
            pts = r if (b[0] >= vx and b[2] <= x1 and b[1] >= vy and b[3] <= y1) else _clip(r, vx, vy, x1, y1)
            pts = _thin(pts, step) if len(pts) >= 3 else []
            if len(pts) >= 3:
                rings.append([((x - vx) / vw, (y - vy) / vh) for x, y in pts])
        if rings:
            out.append((cid, rings))
    return out


def country_box(cid):
    """Рамка главного контура страны (x0, y0, x1, y1) в единицах карты или None."""
    c = countries().get(cid)
    return _bbox(c['rings'][0]) if c else None


def label_point(cid, view):
    """Точка для метки страны (доли области) или None, если страна вне области."""
    c = countries().get(cid)
    if not c:
        return None
    vx, vy, vw, vh = view
    lx, ly = c['label']
    main = c['rings'][0]
    b = _bbox(main)
    if not (b[0] - 5 <= lx <= b[2] + 5 and b[1] - 5 <= ly <= b[3] + 5):     # метка не на главном контуре
        lx, ly = (b[0] + b[2]) / 2, (b[1] + b[3]) / 2
    fx, fy = (lx - vx) / vw, (ly - vy) / vh
    if -0.02 <= fx <= 1.02 and -0.02 <= fy <= 1.02:
        return max(0.02, min(0.98, fx)), max(0.03, min(0.97, fy))
    return None


# --------------------------------------------------------------------------------------
# Рисование фигурами PowerPoint
# --------------------------------------------------------------------------------------
def draw_map(container, x, y, w, h, view, colors=None, land=None, border=None, border_w=0.5):
    """Карта в прямоугольнике (дюймы). colors = {код: (c1, c2)} — выделенные страны (градиент).
    Возвращает {код: фигура} выделенных стран."""
    from pptx.dml.color import RGBColor
    from pptx.util import Pt
    from .nts.effects import grad, no_shadow
    land = land or C.LGRAY
    border = border or C.WHITE
    colors = colors or {}
    emu = 914400
    shapes = {}
    items = shapes_in_view(view)
    items.sort(key=lambda t: t[0] in colors)                  # выделенные — поверх остальных
    for cid, rings in items:
        def P(p):
            return int(round((x + p[0] * w) * emu)), int(round((y + p[1] * h) * emu))
        first = [P(p) for p in rings[0]]
        fb = container.shapes.build_freeform(first[0][0], first[0][1], scale=1.0)
        fb.add_line_segments(first[1:], close=True)
        for r in rings[1:]:
            pts = [P(p) for p in r]
            fb.move_to(*pts[0])
            fb.add_line_segments(pts[1:], close=True)
        try:
            shp = fb.convert_to_shape()
        except Exception:                                    # noqa: BLE001 — вырожденный контур
            continue
        shp.name = f'Страна {countries()[cid]["name"]}'
        if cid in colors:
            c1, c2 = colors[cid]
            grad(shp, c1, c2, 45)
        else:
            shp.fill.solid()
            shp.fill.fore_color.rgb = land
        shp.line.color.rgb = border if isinstance(border, RGBColor) else RGBColor.from_string(str(border))
        shp.line.width = Pt(border_w)
        no_shadow(shp)
        if cid in colors:
            shapes[cid] = shp
    return shapes


# --------------------------------------------------------------------------------------
# Картинки библиотеки (SVG)
# --------------------------------------------------------------------------------------
def picture_svg(ids=None, tol=2.2, min_area=6.0):
    """SVG карты для библиотеки картинок: ids=None — весь мир (суша градиентом), иначе — область вокруг
    стран ids, они выделены зелёным, соседи — серым. Мелкие страны и острова отбрасываются, чтобы
    рисунок оставался лёгким (не больше 220 фигур)."""
    W, H = size()
    if ids:
        view = map_view(ids, 16 / 10, pad=0.08)
    else:
        view = (0.0, 0.0, W, H)
    vx, vy, vw, vh = view
    k = 800.0 / vw
    vb_h = round(vh * k)
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 %d">' % vb_h,
             '<defs><linearGradient id="land" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2E95C4"/>'
             '<stop offset="1" stop-color="#005491"/></linearGradient>'
             '<linearGradient id="hl" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#9AC854"/>'
             '<stop offset="1" stop-color="#0A8F2D"/></linearGradient></defs>']
    cand = []
    for cid, rings in shapes_in_view(view, min_px=tol / 800):
        rings = [r for r in rings if _area([(px * 800, py * vb_h) for px, py in r]) >= min_area]
        if rings:
            cand.append((cid, rings))
    hl = set(ids or [])
    cand.sort(key=lambda t: (t[0] in hl, ))
    if len(cand) > 210:                                       # самые мелкие страны — долой
        cand.sort(key=lambda t: -_area([(px * 800, py * vb_h) for px, py in t[1][0]]))
        cand = sorted(cand[:210], key=lambda t: t[0] in hl)
    for cid, rings in cand:
        d = ' '.join('M' + ' '.join('%d %d' % (round(px * 800), round(py * vb_h)) for px, py in r) + 'Z' for r in rings)
        fill = 'url(#hl)' if cid in hl else ('#D9DEE6' if ids else 'url(#land)')
        parts.append(f'<path d="{d}" fill="{fill}" stroke="#FFFFFF" stroke-width="{0.8 if ids else 0.5}"/>')
    parts.append('</svg>')
    return ''.join(parts)
