# -*- coding: utf-8 -*-
"""
discover.py — ПОИСК ЛОКАЛЬНОЙ МОДЕЛИ ИИ («🔎 Найти ИИ», 1.7)
===========================================================
Находит программы с моделями ИИ, которые уже работают на этом компьютере, на другом компьютере или на
телефоне в той же сети, и предлагает лучшую модель для каждой задачи конструктора:
  * модель для анализа документов (пишет план и тексты);
  * модель поиска по смыслу (эмбеддинги: только сравнивает фразы);
  * модель, которая распознаёт картинки (даёт названия своим фото).

Что узнаётся (по стандартному порту и ответу сервера, а не по одному порту):
  Ollama (11434), LM Studio (1234), Jan (1337), GPT4All (4891), llama.cpp / LocalAI (8080), KoboldCpp (5001),
  text-generation-webui (5000), vLLM (8000), Msty и другие серверы с протоколом Ollama (10000).
Программа установлена, но не запущена — подсказка, как её включить; Ollama и LM Studio можно запустить
кнопкой (`ollama serve`, `lms server start`). В Ollama без моделей — кнопка «Скачать» (/api/pull).

Только локально: проверяются этот компьютер и частная сеть (10.*, 172.16–31.*, 192.168.*), только порты
программ ИИ, без прокси. Документы при поиске никуда не отправляются: запрашивается только список моделей.
Облачные модели Ollama (имя с «cloud») отмечаются отдельно и сами не предлагаются: они работают на ollama.com.
Поиск в сети администратор может запретить: "allow_lan_scan": false в settings.json.
"""
import concurrent.futures as cf
import http.client
import ipaddress
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

# (порт, вид, название) — в таком порядке показываются найденные программы
PORTS = [
    (11434, 'ollama', 'Ollama'),
    (1234, 'lmstudio', 'LM Studio'),
    (1337, 'jan', 'Jan'),
    (4891, 'gpt4all', 'GPT4All'),
    (8080, 'llamacpp', 'llama.cpp или LocalAI'),
    (5001, 'kobold', 'KoboldCpp'),
    (5000, 'tgw', 'text-generation-webui'),
    (8000, 'vllm', 'vLLM'),
    (10000, 'ollama_api', 'Msty или другой сервер Ollama'),
]
PORT_NAME = {p: (k, n) for p, k, n in PORTS}
THIS_PC = 'этот компьютер'
LOCAL = '127.0.0.1'
_NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))

# Как включить программу, если она установлена, но сервер не отвечает
HOW_TO = {
    'ollama': 'Ollama установлена, но не запущена. Нажмите «Запустить» или откройте Ollama из меню «Пуск».',
    'lmstudio': 'LM Studio установлена, но её сервер выключен. Нажмите «Запустить» или в LM Studio откройте '
                'вкладку Developer и включите Status: Running.',
    'jan': 'Jan установлена, но её сервер выключен: в Jan откройте Settings → Local API Server и нажмите Start Server.',
    'gpt4all': 'GPT4All установлена, но её сервер выключен: в GPT4All откройте Settings и отметьте '
               '«Enable Local API Server».',
}
# Телефон и другой компьютер: сервер должен принимать запросы из сети, а не только со своего устройства
LAN_HOW = ('Телефон или другой компьютер должен быть в той же сети Wi-Fi или в сети Компании, а программа с моделью — '
           'принимать запросы из сети: в LM Studio — «Serve on Local Network», в Ollama — переменная OLLAMA_HOST=0.0.0.0, '
           'в llama.cpp — llama-server --host 0.0.0.0, в приложении на телефоне — «сервер» или «API в локальной сети». '
           'Адрес устройства показан в программе или в настройках Wi-Fi.')

# ---- модели: для чего годится ----
RX_EMBED = re.compile(r'(?i)embed|(^|[/:_-])(bge|e5|gte|minilm|mxbai|arctic|jina|sbert|labse)([:_.-]|$)|bge-|e5-|gte-')
RX_OTHER = re.compile(r'(?i)whisper|tts|kokoro|rerank|stable-diffusion|sdxl|flux|(^|[/:_-])sd[-_]?\d|bark|piper|audio')
RX_VISION = re.compile(r'(?i)(^|[/:_.-])vl([:_.-]|$)|-vl\b|\dvl\b|vision|llava|minicpm-?v|moondream|pixtral|internvl|'
                       r'smolvlm|gemma-?3(?!n)(?![:_-]?1b)|mistral-small-?3\.[12]|llama-?4|multimodal|janus')
RX_CLOUD = re.compile(r'(?i)(^|[:\-])cloud$')
CHAT_FAMILY = [  # семейство → насколько хорошо пишет деловой русский текст и выдаёт JSON (выше — лучше)
    (r'qwen-?3(?!.*coder)', 10), (r't-?(lite|pro)|vikhr|saiga|yandexgpt|gigachat', 9), (r'qwen-?2\.5(?!.*coder)', 9),
    (r'gemma-?3', 8), (r'mistral-?(small|nemo|medium)|ministral', 7), (r'gpt-?oss', 7), (r'llama-?3\.?[13]|llama-?4', 6),
    (r'command-?r|aya', 6), (r'deepseek', 5), (r'phi-?[34]', 4), (r'llama', 4), (r'mistral', 4),
]
EMBED_FAMILY = [(r'bge-?m3', 10), (r'qwen-?3-?embed', 9), (r'multilingual-?e5|e5-', 8), (r'arctic-?embed-?2|jina-?embeddings-?v3', 7),
                (r'embeddinggemma|granite-?embed', 7), (r'labse|paraphrase-?multilingual', 6), (r'nomic|mxbai|gte', 5), (r'minilm', 3)]
VISION_FAMILY = [(r'qwen-?(2\.5|3)-?vl', 10), (r'gemma-?3', 8), (r'minicpm-?v', 7), (r'mistral-small|pixtral', 7),
                 (r'llama-?3\.2-?vision|llama-?4', 6), (r'internvl', 6), (r'granite.*vision', 5), (r'llava', 4), (r'moondream|smolvlm', 3)]
# что скачать в Ollama, если в ней нет подходящих моделей (размер — для подсказки)
PULL = {
    'chat': [('qwen3:14b', '9,3 ГБ', 24), ('qwen3:8b', '5,2 ГБ', 12), ('qwen3:4b', '2,5 ГБ', 0)],   # ГБ памяти компьютера
    'embed': [('bge-m3', '1,2 ГБ', 0)],
    'vision': [('qwen2.5vl:7b', '6 ГБ', 16), ('gemma3:4b', '3,3 ГБ', 0)],
}


def _score(name, table):
    n = name.lower()
    for rx, w in table:
        if re.search(rx, n):
            return w
    return 1


def params_b(name, size=''):
    """Число параметров модели в миллиардах: из сведений сервера («14.8B») или из имени («qwen3:14b», «7B-Instruct»)."""
    for s in (str(size or ''), str(name or '')):
        m = re.search(r'(?i)(?<![\d.])(\d+(?:\.\d+)?)\s*b(?![a-z])', s)
        if m:
            return float(m.group(1))
        m = re.search(r'(?i)(?<![\d.])(\d+(?:\.\d+)?)\s*m(?![a-z])', s)
        if m:
            return float(m.group(1)) / 1000
    return 0.0


def kind_of(name, caps=None):
    """'chat' | 'embed' | 'other' и признак «видит картинки». caps — возможности из Ollama (/api/show)."""
    caps = [str(c).lower() for c in (caps or [])]
    if caps:
        if 'embedding' in caps and 'completion' not in caps:
            return 'embed', False
        if 'completion' not in caps:
            return 'other', False
        return 'chat', 'vision' in caps
    if RX_OTHER.search(name):
        return 'other', False
    if RX_EMBED.search(name):
        return 'embed', False
    return 'chat', bool(RX_VISION.search(name))


def chat_score(m):
    """Чем выше, тем лучше модель для анализа документов: семейство, размер (лучше всего 7–16 млрд параметров —
    быстро и толково на обычном компьютере), уже загружена в память, не «базовая» и не для программирования."""
    n, p = m['name'].lower(), m.get('params') or 0
    s = _score(n, CHAT_FAMILY)
    if 7 <= p <= 16:
        s += 3 + (0.5 if p >= 12 else 0)
    elif 16 < p <= 35:
        s += 2
    elif 3.5 <= p < 7:
        s += 1
    elif 0 < p < 3.5:
        s -= 3
    elif p > 35:
        s -= 1
    if m.get('loaded'):
        s += 2
    if re.search(r'coder|code|math|guard|base\b|-base', n):
        s -= 4
    if m.get('vision'):
        s -= 0.5
    return s


def best(models, kind):
    """Лучшая модель для задачи kind ('chat' | 'embed' | 'vision') или ''."""
    if kind == 'chat':
        c = [m for m in models if m['kind'] == 'chat' and not m.get('cloud')]
        return max(c, key=chat_score)['name'] if c else ''
    if kind == 'embed':
        c = [m for m in models if m['kind'] == 'embed' and not m.get('cloud')]
        return max(c, key=lambda m: (_score(m['name'], EMBED_FAMILY), bool(m.get('loaded'))))['name'] if c else ''
    c = [m for m in models if m.get('vision') and not m.get('cloud')]
    return max(c, key=lambda m: (_score(m['name'], VISION_FAMILY) + (1 if 3.5 <= (m.get('params') or 0) <= 12 else 0),
                                 bool(m.get('loaded'))))['name'] if c else ''


# ---------------------------------------------------------------------------------------------
# Сеть
# ---------------------------------------------------------------------------------------------
def _http(url, payload=None, timeout=2.0):
    """(код ответа, JSON или None). Без прокси: адреса только локальные. 0 — сервер не ответил."""
    data = json.dumps(payload).encode('utf-8') if payload is not None else None
    req = urllib.request.Request(url, data=data, headers={'Accept': 'application/json',
                                                          **({'Content-Type': 'application/json'} if data else {})})
    try:
        with _NOPROXY.open(req, timeout=timeout) as r:
            raw = r.read(4_000_000)
            try:
                return r.status, json.loads(raw.decode('utf-8', 'replace') or 'null')
            except ValueError:
                return r.status, None
    except urllib.error.HTTPError as e:
        return e.code, None
    except (OSError, ValueError, http.client.HTTPException):
        return 0, None


def port_open(host, port, timeout=0.6):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _url_host(host):
    return 'localhost' if host == LOCAL else (f'[{host}]' if ':' in host else host)


def is_private(host):
    """Адрес этого компьютера или частной сети (только такие проверяются)."""
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return False
    return ip.is_loopback or (ip.version == 4 and ip.is_private and not ip.is_link_local)


def my_addresses():
    """IPv4-адреса этого компьютера в частных сетях (без 127.*, 169.254.*)."""
    found = set()
    for probe in ('192.168.0.1', '10.0.0.1', '172.16.0.1'):          # пакеты не отправляются: только выбор интерфейса
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect((probe, 9))
                found.add(s.getsockname()[0])
        except OSError:
            pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            found.add(info[4][0])
    except OSError:
        pass
    return sorted(a for a in found if is_private(a) and not a.startswith('127.'))


def networks(limit=3):
    """Сети /24 этого компьютера, где искать телефон и другие компьютеры (не больше limit)."""
    nets = []
    for a in my_addresses():
        n = ipaddress.ip_network(a + '/24', strict=False)
        if n not in nets:
            nets.append(n)
    return nets[:limit]


# ---------------------------------------------------------------------------------------------
# Проверка одного сервера
# ---------------------------------------------------------------------------------------------
def _model(name, size='', caps=None, loaded=False, cloud=False, family=''):
    kind, vision = kind_of(name + ' ' + family, caps)
    return {'name': name, 'kind': kind, 'vision': vision, 'params': params_b(name, size),
            'size': str(size or ''), 'loaded': bool(loaded), 'cloud': bool(cloud or RX_CLOUD.search(name))}


def _ollama(host, port, t):
    code, ver = _http(f'http://{_url_host(host)}:{port}/api/version', timeout=t)
    if code != 200 or not isinstance(ver, dict) or 'version' not in ver:
        return None
    base = f'http://{_url_host(host)}:{port}'
    _, tags = _http(base + '/api/tags', timeout=max(t, 3))
    _, ps = _http(base + '/api/ps', timeout=t)
    loaded = {m.get('name') for m in (ps or {}).get('models') or [] if isinstance(m, dict)}
    items = [m for m in (tags or {}).get('models') or [] if isinstance(m, dict) and m.get('name')][:40]

    def show(m):
        code, js = _http(base + '/api/show', {'model': m['name']}, timeout=max(t, 3))
        return (js or {}).get('capabilities') if code == 200 and isinstance(js, dict) else None
    with cf.ThreadPoolExecutor(8) as ex:
        caps = list(ex.map(show, items))
    models = [_model(m['name'], (m.get('details') or {}).get('parameter_size') or '', c, m['name'] in loaded,
                     bool(m.get('remote_host') or m.get('remote_model')), (m.get('details') or {}).get('family') or '')
              for m, c in zip(items, caps)]
    kind, name = ('ollama', 'Ollama') if port == 11434 else PORT_NAME.get(port, ('ollama_api', 'Сервер Ollama'))
    return {'kind': kind, 'name': name, 'provider': 'ollama', 'base_url': base, 'version': str(ver.get('version')),
            'models': models, 'can_pull': True}


def _lmstudio(host, port, t):
    code, js = _http(f'http://{_url_host(host)}:{port}/api/v0/models', timeout=t)
    data = (js or {}).get('data') if isinstance(js, dict) else None
    if code != 200 or not isinstance(data, list) or not all(isinstance(m, dict) and 'type' in m for m in data):
        return None
    models = []
    for m in data:
        tp = str(m.get('type') or '')
        caps = ['embedding'] if tp == 'embeddings' else (['completion', 'vision'] if tp == 'vlm' else ['completion'])
        models.append(_model(str(m.get('id') or ''), '', caps, m.get('state') == 'loaded'))
    return {'kind': 'lmstudio', 'name': 'LM Studio', 'provider': 'openai',
            'base_url': f'http://{_url_host(host)}:{port}/v1', 'models': [m for m in models if m['name']]}


def _flavor(host, port, models_js, t):
    """Какая программа отвечает по протоколу OpenAI: по её собственным адресам и полю owned_by."""
    if port in (1337, 4891):                             # Jan и GPT4All — по своему порту (внутри у них llama.cpp)
        return PORT_NAME[port]
    base = f'http://{_url_host(host)}:{port}'
    owners = {str(m.get('owned_by') or '').lower() for m in (models_js or {}).get('data') or [] if isinstance(m, dict)}
    code, js = _http(base + '/api/extra/version', timeout=t)
    if code == 200 and isinstance(js, dict) and 'kobold' in str(js.get('result') or '').lower():
        return 'kobold', 'KoboldCpp'
    if 'vllm' in owners:
        return 'vllm', 'vLLM'
    code, js = _http(base + '/props', timeout=t)
    if code == 200 and isinstance(js, dict) and ({'default_generation_settings', 'model_path', 'build_info'} & set(js)):
        return 'llamacpp', 'llama.cpp'
    code, js = _http(base + '/v1/internal/model/info', timeout=t)
    if code == 200 and isinstance(js, dict) and 'model_name' in js:
        return 'tgw', 'text-generation-webui'
    if 'llamacpp' in owners:
        return 'llamacpp', 'llama.cpp'
    if port == 8080:
        return 'localai', 'LocalAI или другой сервер'
    return PORT_NAME.get(port, ('openai', 'Сервер с протоколом OpenAI'))


def _openai(host, port, t):
    base = f'http://{_url_host(host)}:{port}'
    code, js = _http(base + '/v1/models', timeout=max(t, 2.5))
    if code in (401, 403):
        kind, name = PORT_NAME.get(port, ('openai', 'Сервер с протоколом OpenAI'))
        return {'kind': kind, 'name': name, 'provider': 'openai', 'base_url': base + '/v1', 'models': [],
                'needs_key': True}
    data = (js or {}).get('data') if isinstance(js, dict) else (js if isinstance(js, list) else None)
    if code != 200 or not isinstance(data, list):
        return None
    kind, name = _flavor(host, port, js if isinstance(js, dict) else {}, t)
    models = [_model(str(m.get('id') or m.get('name') or '') if isinstance(m, dict) else str(m)) for m in data]
    return {'kind': kind, 'name': name, 'provider': 'openai', 'base_url': base + '/v1', 'models': [m for m in models if m['name']]}


def probe(host, port, t=1.5):
    """Сервер модели ИИ по адресу host:port → сведения о нём и его моделях или None."""
    if not port_open(host, port, min(t, 0.8)):
        return None
    info = None
    for fn in ((_ollama, _lmstudio, _openai) if port != 1234 else (_lmstudio, _openai, _ollama)):
        info = fn(host, port, t)
        if info:
            break
    if not info:
        return None
    ms = info['models']
    info.update(host=host, port=port, id=f'{host}:{port}', where=THIS_PC if host == LOCAL else host,
                chat=best(ms, 'chat'), embed=best(ms, 'embed'), vision=best(ms, 'vision'),
                cloud_models=[m['name'] for m in ms if m['cloud']],
                counts={k: sum(1 for m in ms if m['kind'] == k and not m['cloud']) for k in ('chat', 'embed')})
    info.setdefault('needs_key', False)
    info.setdefault('can_pull', False)
    return info


# ---------------------------------------------------------------------------------------------
# Установленные программы (сервер не запущен)
# ---------------------------------------------------------------------------------------------
def _env_path(var, *parts):
    v = os.environ.get(var)
    return Path(v, *parts) if v else None


def _first(paths):
    for p in paths:
        try:
            if p and Path(p).exists():
                return str(p)
        except OSError:
            pass
    return ''


def ollama_exe():
    return _first([shutil.which('ollama'), _env_path('LOCALAPPDATA', 'Programs', 'Ollama', 'ollama.exe'),
                   _env_path('ProgramFiles', 'Ollama', 'ollama.exe'), '/usr/local/bin/ollama',
                   '/Applications/Ollama.app/Contents/Resources/ollama'])


def lms_exe():
    home = Path.home()
    return _first([shutil.which('lms'), home / '.lmstudio' / 'bin' / ('lms.exe' if os.name == 'nt' else 'lms'),
                   home / '.cache' / 'lm-studio' / 'bin' / ('lms.exe' if os.name == 'nt' else 'lms')])


def installed():
    """Программы с моделями ИИ, установленные на этом компьютере: {вид: путь}. Только известные пути установки."""
    home = Path.home()
    out = {}
    if ollama_exe():
        out['ollama'] = ollama_exe()
    lm = lms_exe() or _first([_env_path('LOCALAPPDATA', 'Programs', 'LM Studio', 'LM Studio.exe'),
                              _env_path('LOCALAPPDATA', 'Programs', 'lm-studio', 'LM Studio.exe'),
                              '/Applications/LM Studio.app'])
    if lm:
        out['lmstudio'] = lm
    jan = _first([_env_path('LOCALAPPDATA', 'Programs', 'jan', 'Jan.exe'), _env_path('LOCALAPPDATA', 'Programs', 'Jan', 'Jan.exe'),
                  '/Applications/Jan.app'])
    if jan:
        out['jan'] = jan
    g4a = _first([home / 'gpt4all' / 'bin' / 'chat.exe', _env_path('LOCALAPPDATA', 'Programs', 'nomic.ai', 'GPT4All'),
                  '/Applications/gpt4all/bin/gpt4all.app'])
    if g4a:
        out['gpt4all'] = g4a
    return out


def _detached():
    if os.name == 'nt':
        return {'creationflags': 0x00000008 | 0x00000200 | 0x08000000}   # DETACHED | NEW_PROCESS_GROUP | NO_WINDOW
    return {'start_new_session': True}


def start(kind, wait=20.0):
    """Запустить сервер программы kind ('ollama' | 'lmstudio') на этом компьютере. → (ok, сообщение)."""
    if kind == 'ollama':
        exe, port, args = ollama_exe(), 11434, ['serve']
    elif kind == 'lmstudio':
        exe, port, args = lms_exe(), 1234, ['server', 'start']
    else:
        return False, 'Эту программу конструктор запустить не может: включите её сервер в самой программе.'
    if not exe:
        return False, 'Программа не найдена на этом компьютере.'
    if port_open(LOCAL, port, 0.4):
        return True, 'Сервер уже работает.'
    try:
        subprocess.Popen([exe] + args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         close_fds=True, **_detached())
    except OSError as e:
        return False, f'Не удалось запустить: {e}'
    t0 = time.time()
    while time.time() - t0 < wait:
        if port_open(LOCAL, port, 0.4):
            return True, 'Сервер запущен.'
        time.sleep(0.5)
    return False, ('Программа запускается дольше обычного. Подождите немного и нажмите «Найти ИИ» ещё раз.'
                   if kind == 'ollama' else 'LM Studio не включила сервер: откройте её и включите сервер на вкладке Developer.')


# ---------------------------------------------------------------------------------------------
# Поиск
# ---------------------------------------------------------------------------------------------
def memory_gb():
    """Оперативная память компьютера, ГБ (для совета, какую модель скачать); 0 — неизвестно."""
    try:
        if os.name == 'nt':
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [('dwLength', ctypes.c_ulong), ('dwMemoryLoad', ctypes.c_ulong),
                            ('ullTotalPhys', ctypes.c_ulonglong), ('ullAvailPhys', ctypes.c_ulonglong),
                            ('ullTotalPageFile', ctypes.c_ulonglong), ('ullAvailPageFile', ctypes.c_ulonglong),
                            ('ullTotalVirtual', ctypes.c_ulonglong), ('ullAvailVirtual', ctypes.c_ulonglong),
                            ('ullAvailExtendedVirtual', ctypes.c_ulonglong)]
            ms = MS()
            ms.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms))
            return round(ms.ullTotalPhys / 2 ** 30)
        return round(os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES') / 2 ** 30)
    except (OSError, ValueError, AttributeError):
        return 0


def suggest_pull(found, ram=None):
    """Что скачать в Ollama, если в ней нет модели для задачи: {задача: (модель, размер)}."""
    ram = memory_gb() if ram is None else ram
    out = {}
    for task, opts in PULL.items():
        if found.get(task):
            continue
        for name, size, need in opts:
            if not ram or ram >= need:
                out[task] = {'model': name, 'size': size}
                break
    return out


def find_local(t=1.5, ports=None):
    """Серверы моделей на этом компьютере."""
    ports = ports or [p for p, _, _ in PORTS]
    with cf.ThreadPoolExecutor(max(1, len(ports))) as ex:
        res = list(ex.map(lambda p: probe(LOCAL, p, t), ports))
    return [r for r in res if r]


def find_host(host, port=None, t=2.0):
    """Серверы на устройстве по адресу (телефон, другой компьютер). Адрес — только из частной сети."""
    host = str(host or '').strip()
    if not is_private(host):
        try:
            host = socket.gethostbyname(host)
        except OSError:
            raise ValueError('Адрес не найден. Впишите адрес устройства цифрами, например 192.168.1.23.')
        if not is_private(host):
            raise ValueError('Это адрес в интернете, а не в вашей сети. Облачные сервисы выбираются в списке '
                             '«Где работает модель» и включаются только с согласия.')
    ports = [port] if port else [p for p, _, _ in PORTS]
    with cf.ThreadPoolExecutor(max(1, len(ports))) as ex:
        res = list(ex.map(lambda p: probe(host, p, t), ports))
    return [r for r in res if r]


def scan_lan(deadline=20.0, nets=None, ports=None, skip=()):
    """Телефоны и компьютеры в сетях /24 этого компьютера, где работает программа с моделью ИИ.
    Сначала быстрая проверка портов (0,35 с), потом — запрос списка моделей у открытых портов."""
    nets = networks() if nets is None else nets
    ports = ports or [p for p, _, _ in PORTS]
    mine = set(my_addresses()) | set(skip)
    targets = [(str(h), p) for n in nets for h in n.hosts() if str(h) not in mine for p in ports]
    t_end = time.time() + deadline
    hits = []
    lock = threading.Lock()

    def knock(hp):
        if time.time() < t_end and port_open(hp[0], hp[1], 0.35):
            with lock:
                hits.append(hp)
    with cf.ThreadPoolExecutor(min(256, max(1, len(targets)))) as ex:
        list(ex.map(knock, targets))
    with cf.ThreadPoolExecutor(min(16, max(1, len(hits)))) as ex:
        res = list(ex.map(lambda hp: probe(hp[0], hp[1], 2.0), hits))
    return [r for r in res if r], [str(n) for n in nets], len(targets)


def find(lan=False, host=None, allow_lan=True):
    """Поиск: этот компьютер; host — устройство по адресу; lan=True — вся сеть /24 (если не запрещено).
    → {'found': [...], 'installed': [{kind, name, how, can_start}], 'nets': [...], 'pull': {...}, 'ram_gb', 'seconds'}"""
    t0 = time.time()
    found = find_local()
    out = {'nets': [], 'lan_checked': 0, 'lan_off': False}
    if host:
        m = re.fullmatch(r'\s*(?:https?://)?([^\s/:]+|\[[0-9a-fA-F:]+\])(?::(\d{2,5}))?/?.*', str(host))
        if not m:
            raise ValueError('Впишите адрес устройства, например 192.168.1.23 или 192.168.1.23:8080.')
        found += find_host(m.group(1).strip('[]'), int(m.group(2)) if m.group(2) else None)
    if lan:
        if allow_lan:
            got, out['nets'], out['lan_checked'] = scan_lan(skip={f['host'] for f in found})
            found += [g for g in got if g['id'] not in {f['id'] for f in found}]
        else:
            out['lan_off'] = True
    running = {f['kind'] for f in found if f['host'] == LOCAL}
    inst = []
    for kind, path in installed().items():
        if kind in running:
            continue
        inst.append({'kind': kind, 'name': dict((k, n) for _, k, n in PORTS)[kind], 'how': HOW_TO.get(kind, ''),
                     'can_start': kind in ('ollama', 'lmstudio') and bool(ollama_exe() if kind == 'ollama' else lms_exe())})
    ram = memory_gb()
    for f in found:
        f['pull'] = suggest_pull(f, ram) if f.get('can_pull') else {}
    out.update(found=found, installed=inst, ram_gb=ram, seconds=round(time.time() - t0, 1), lan_how=LAN_HOW)
    return out


# ---------------------------------------------------------------------------------------------
# Скачивание модели в Ollama
# ---------------------------------------------------------------------------------------------
PULLS = {}
_PULL_LOCK = threading.Lock()


def pull(base_url, model):
    """Скачать модель в Ollama по адресу base_url (в фоне). Ход — pull_state(base_url, model)."""
    key = f'{base_url}|{model}'
    with _PULL_LOCK:
        st = PULLS.get(key)
        if st and st['state'] == 'running':
            return st
        st = PULLS[key] = {'state': 'running', 'model': model, 'status': 'начинаю', 'done': 0, 'total': 0, 'error': ''}

    def run():
        req = urllib.request.Request(base_url.rstrip('/') + '/api/pull', data=json.dumps({'model': model, 'stream': True}).encode(),
                                     headers={'Content-Type': 'application/json'})
        try:
            with _NOPROXY.open(req, timeout=60) as r:
                for line in r:
                    try:
                        ev = json.loads(line.decode('utf-8', 'replace'))
                    except ValueError:
                        continue
                    if ev.get('error'):
                        raise RuntimeError(ev['error'])
                    st['status'] = str(ev.get('status') or '')
                    if ev.get('total'):
                        st['total'], st['done'] = int(ev['total']), int(ev.get('completed') or 0)
            st['state'] = 'done' if st['status'] == 'success' else 'error'
            if st['state'] == 'error':
                st['error'] = 'Ollama не закончила скачивание: ' + (st['status'] or 'нет ответа')
        except (OSError, RuntimeError, http.client.HTTPException) as e:
            st.update(state='error', error=f'Модель не скачалась: {e}. Нужен доступ Ollama в интернет '
                                            '(или скачайте модель на другом компьютере и перенесите).')
    threading.Thread(target=run, daemon=True).start()
    return st


def pull_state(base_url, model):
    return PULLS.get(f'{base_url}|{model}') or {'state': 'none'}


if __name__ == '__main__':                              # python -m engine.discover [--lan] [адрес]
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:                                    # noqa: BLE001
        pass
    args = sys.argv[1:]
    r = find(lan='--lan' in args, host=next((a for a in args if not a.startswith('--')), None))
    for f in r['found']:
        print(f"{f['name']} · {f['where']} · {f['base_url']} · моделей {len(f['models'])} · "
              f"анализ: {f['chat'] or '—'} · поиск: {f['embed'] or '—'} · картинки: {f['vision'] or '—'}")
    for i in r['installed']:
        print(f"{i['name']}: {i['how']}")
    if not r['found']:
        print('Локальная модель ИИ не найдена.')
