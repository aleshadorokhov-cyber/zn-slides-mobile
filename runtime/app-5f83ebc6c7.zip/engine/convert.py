# -*- coding: utf-8 -*-
"""
convert.py — СМЕНА МАКЕТА СЛАЙДА С ПЕРЕНОСОМ СОДЕРЖИМОГО
======================================================

convert_slide(slide, 'honeycomb') переводит слайд плана в другой макет: элементы ↔ абзацы ↔
колонки сравнения ↔ таблица ↔ диаграмма. Если для нового макета не хватает данных
(показатели без чисел, диаграмма без таблицы), слайд остаётся прежним.

Используется планировщиком ИИ (модель выбрала макет, а содержимое пришло из правил) и
модулем разнообразия (variety.py), который чередует схемы на соседних слайдах.
"""
from .insights import choose_chart, make_insights
from .model import Table
from .planner_rules import _kpi_item
from .spec import CENTERED, LAYOUTS  # noqa: F401  (CENTERED — макеты с центральной фразой)
from .textutil import parse_number

NUMERIC = ('kpi', 'gauge', 'bars', 'bubbles', 'hero')    # макеты, которым нужны числа (value)
KEEP = ('label', 'icon', 'prob', 'impact', 'picture')    # поля элемента, которые переносятся в новый макет


def _kind(lay):
    return (LAYOUTS.get(lay) or {}).get('kind')


def _to_items(sl):
    """Любой слайд → список элементов {'title','text', …} (как convert() в интерфейсе)."""
    k = _kind(sl.get('layout'))
    if k == 'items':
        return [dict(x) for x in sl.get('items') or []]
    if k == 'text':
        return [{'title': '', 'text': t} for t in [sl.get('lead')] + list(sl.get('paragraphs') or []) if t]
    if k == 'compare':
        return [{'title': '', 'text': t} for side in ('left', 'right')
                for t in ((sl.get(side) or {}).get('items') or [])]
    if k == 'table':
        out = []
        for r in sl.get('rows') or []:
            cells = [str(c or '').strip() for c in r]
            j = next((i for i, c in enumerate(cells) if c), None)
            if j is not None:
                out.append({'title': cells[j], 'text': ', '.join(c for c in cells[j + 1:] if c)})
        return out
    if k == 'chart':
        ch = sl.get('chart') or {}
        ser = (ch.get('series') or [{}])[0]
        return [{'title': c, 'text': '', 'value': '' if v is None else str(v), 'unit': ch.get('unit') or ''}
                for c, v in zip(ch.get('categories') or [], ser.get('values') or [])]
    return []


def convert_slide(sl, to):
    """Переводит слайд в макет to, перенося содержимое. Если для макета нет нужных данных
    (kpi/chart без чисел), слайд остаётся в исходном макете."""
    src_lay = sl.get('layout')
    if src_lay == to or to not in LAYOUTS:
        return sl
    kf, kt = _kind(src_lay), _kind(to)
    out = {k: v for k, v in sl.items() if k not in ('items', 'lead', 'paragraphs', 'left', 'right',
                                                     'columns', 'rows', 'chart', 'insights', 'center', 'style',
                                                     'variant', 'aside', 'axes', 'images', 'alt_label', 'alt_index')}
    items = _to_items(sl)
    out['layout'] = to
    if kf == 'chart':
        ch = sl.get('chart') or {}
        multi = len(ch.get('series') or []) > 1
        # диаграмма с несколькими рядами (или в текст/сравнение) содержательнее любых карточек —
        # остаётся диаграммой; с одним рядом → показатели или карточки «категория — значение»
        if (multi and kt != 'table') or kt in ('text', 'compare') or (to in NUMERIC and len(items) > 6):
            return sl                             # несколько рядов — только диаграмма или таблица
        if str(out.get('subtitle') or '').startswith('Единицы:'):
            out['subtitle'] = ''                  # подпись единиц относится только к диаграмме
        unit = ch.get('unit') or ''
        if kt == 'items' and to not in NUMERIC:
            items = [{'title': it['title'], 'text': f'{it["value"]} {unit}'.strip()} for it in items if it.get('value')]
    joined = lambda it: ((it.get('title') + '. ') if it.get('title') else '') + (it.get('text') or '')
    if kt == 'items':
        if to in NUMERIC:
            ks = []
            for it in items:
                if it.get('value') and parse_number(str(it['value'])) is not None:
                    ks.append({'value': str(it['value']), 'unit': it.get('unit') or '', 'title': it.get('title') or '',
                               'text': it.get('text') or ''})
                else:
                    k = _kpi_item(it.get('_raw') or joined(it))
                    if k:
                        ks.append(k)
            if not ks:
                return sl
            out['items'] = ks
        else:
            out['items'] = [dict({k: it[k] for k in KEEP if it.get(k)}, title=it.get('title') or '',
                                 text=it.get('text') or '', label=it.get('label') or '') for it in items]
            if kf == 'items' and src_lay in NUMERIC:
                out['items'] = [{'title': it.get('title') or '', 'text': f'{it.get("value") or ""} {it.get("unit") or ""}'
                                 .strip() + (f' — {it["text"]}' if it.get('text') else '')} for it in items]
        if to in CENTERED:
            out['center'] = sl.get('center') or sl.get('lead') or sl.get('subtitle') or sl.get('title') or ''
            if out['center'] == sl.get('subtitle'):
                out['subtitle'] = ''                  # фраза ушла в центр схемы — не дублировать
        if not out['items']:
            return sl
    elif kt == 'text':
        if not items:
            return sl
        out['lead'] = joined(items[0])
        out['paragraphs'] = [joined(it) for it in items[1:4]]
    elif kt == 'compare':
        if kf == 'compare':                        # сравнение ↔ весы ↔ «было → стало»: колонки те же
            out['left'], out['right'] = sl.get('left') or {}, sl.get('right') or {}
            out['style'] = sl.get('style') or 'before_after'
            return out
        if kf == 'table' and len(sl.get('columns') or []) >= 2:
            cols, rows = sl['columns'], sl.get('rows') or []
            out['left'] = {'title': cols[-2], 'items': [f'{r[0]}: {r[-2]}' if len(cols) > 2 and r[0] else r[-2] for r in rows]}
            out['right'] = {'title': cols[-1], 'items': [r[-1] for r in rows]}
        else:
            half = (len(items) + 1) // 2
            out['left'] = {'title': 'Было', 'items': [joined(it) for it in items[:half]]}
            out['right'] = {'title': 'Стало', 'items': [joined(it) for it in items[half:]]}
        out['style'] = 'before_after'
        if not out['left']['items'] and not out['right']['items']:
            return sl
    elif kt == 'table':
        if kf == 'chart' and sl.get('chart'):
            ch = sl['chart']
            out['columns'] = ['Категория'] + [s['name'] for s in ch['series']]
            out['rows'] = [[c] + ['' if s['values'][i] is None else s['values'][i] for s in ch['series']]
                           for i, c in enumerate(ch['categories'])]
        elif kf == 'compare':
            L, R = sl.get('left') or {}, sl.get('right') or {}
            n = max(len(L.get('items') or []), len(R.get('items') or []))
            out['columns'] = [L.get('title') or 'Было', R.get('title') or 'Стало']
            out['rows'] = [[(L.get('items') or [''] * n)[i] if i < len(L.get('items') or []) else '',
                            (R.get('items') or [''] * n)[i] if i < len(R.get('items') or []) else ''] for i in range(n)]
        elif kf == 'items' and src_lay in NUMERIC + ('funnel',) and any(it.get('value') for it in items):
            out['columns'] = ['Показатель', 'Значение'] + (['Пояснение'] if any(it.get('text') for it in items) else [])
            out['rows'] = [[it.get('title') or '', f"{it.get('value') or ''} {it.get('unit') or ''}".strip()] +
                           ([it.get('text') or ''] if len(out['columns']) > 2 else []) for it in items]
        else:
            out['columns'] = ['Пункт', 'Описание']
            out['rows'] = [[it.get('title') or '', it.get('text') or ''] for it in items]
        if not out['rows']:
            return sl
    elif kt == 'chart':
        if kf == 'table' and sl.get('columns'):
            t = Table('tmp', list(sl['columns']), [list(r) for r in sl.get('rows') or []]).analyze()
            ch = choose_chart(t, sl.get('title', ''))
        else:
            vals = [parse_number(str(it.get('value') or '')) if it.get('value') else
                    (lambda k: parse_number(k['value']) if k else None)(_kpi_item(it.get('_raw') or joined(it)))
                    for it in items]
            ok = [(it.get('title') or it.get('text') or '', v) for it, v in zip(items, vals) if v is not None]
            ch = ({'type': 'column', 'categories': [c for c, _ in ok], 'unit': items[0].get('unit', '') if items else '',
                   'series': [{'name': 'Значение', 'values': [v for _, v in ok]}]} if len(ok) >= 2 else None)
        if not ch:
            return sl
        ch.pop('note', None)
        out['chart'] = ch
        out['insights'] = make_insights(ch)
    else:
        return sl
    return out



_convert = convert_slide
