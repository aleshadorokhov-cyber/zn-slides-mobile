# -*- coding: utf-8 -*-
"""
model3d.py — 3D-МОДЕЛИ НА СЛАЙДЕ (1.7)
=====================================

Модель оборудования, платформы, установки (.stl, .obj, .glb, .gltf, .ply, .off) встаёт на слайд картинкой —
видом с выбранного ракурса. Модель читает библиотека trimesh, рисует matplotlib без видеокарты: грани
закрашиваются по освещению (свет сверху-слева), цвет — фирменный или собственный цвет модели.

  is_model(имя)                       — 3D-модель ли это по расширению;
  load(байты, имя)                    — модель trimesh (сцена склеивается в одну сетку) или Model3DError;
  render_png(сетка, ракурс, w, h)     — PNG с прозрачным фоном;
  save(байты, имя, ракурс)            — PNG в output/uploads (как своя картинка) + модель .glb рядом
                                        (output/uploads/models/<имя>.glb) для смены ракурса и вращаемой модели;
  rerender(имя картинки, ракурс)      — новый вид той же модели (новое имя файла);
  VIEWS                               — ракурсы: изометрия, спереди, сбоку, сверху, снизу-сбоку.

Вращаемая модель PowerPoint 365 (проба, по галочке автора images[i].live3d): при сборке картинка модели
заменяется объектом «3D-модель» (am3d:model3d, MS-ODRAWXML 2.31) с файлом .glb внутри презентации; в
mc:Fallback остаётся та же картинка — её показывают PowerPoint 2016 и старше, LibreOffice и просмотрщики.
Тип связи и тип содержимого .glb в открытой спецификации не описаны (взяты по файлам PowerPoint) — поэтому
функция проверяется в PowerPoint 365 у автора и по умолчанию выключена.

Оси: в glTF (.glb, .gltf) и большинстве .obj «вверх» — ось Y, в .stl/.ply/.off (САПР) — ось Z. Внутри
модель всегда «вверх по Z» (так рисует matplotlib), в .glb записывается «вверх по Y», как требует glTF.

Нет trimesh или matplotlib — понятная ошибка (модель не загружается, остальное работает).
"""
import contextvars
import io
import json
import math
from contextlib import contextmanager
from pathlib import Path
from xml.sax.saxutils import escape

EXTS = ('.stl', '.obj', '.glb', '.gltf', '.ply', '.off')
MAX_FACES = 40000                       # больше граней matplotlib рисует слишком долго — берётся часть
VIEWS = {'iso': ('Изометрия', 24, -58), 'front': ('Спереди', 8, -90), 'side': ('Сбоку', 8, 0),
         'top': ('Сверху', 88, -90), 'low': ('Снизу сбоку', -18, -40)}
BASE_RGB = (0.0, 0.47, 0.68)            # фирменный синий 0078AE — если у модели нет своих цветов
Y_UP = ('.glb', '.gltf', '.obj')        # «вверх по Y»; остальные форматы — «вверх по Z»


class Model3DError(Exception):
    pass


def is_model(filename):
    return Path(str(filename or '')).suffix.lower() in EXTS


def available():
    try:
        import trimesh  # noqa: F401
        import matplotlib  # noqa: F401
        return True
    except ImportError:
        return False


def load(data, filename):
    """Байты файла → trimesh.Trimesh (все части сцены вместе, с их цветами, если они есть)."""
    try:
        import trimesh
    except ImportError:
        raise Model3DError('для 3D-моделей нужна библиотека trimesh — она входит в полный пакет для Windows')
    ext = Path(str(filename or '')).suffix.lower().lstrip('.')
    if not data:
        raise Model3DError('файл пустой')
    try:
        obj = trimesh.load(io.BytesIO(data), file_type=ext, force=None, process=False)
    except Exception as e:                                  # noqa: BLE001 — повреждённый или чужой формат
        raise Model3DError(f'модель не прочитана ({type(e).__name__})')
    if isinstance(obj, trimesh.Scene):
        geoms = []
        for name in obj.graph.nodes_geometry:
            tf, gname = obj.graph[name]
            g = obj.geometry.get(gname)
            if isinstance(g, trimesh.Trimesh) and len(g.faces):
                g = g.copy()
                g.apply_transform(tf)
                geoms.append(g)
        if not geoms:
            raise Model3DError('в файле нет поверхностей (только точки или линии)')
        mesh = trimesh.util.concatenate(geoms)
    elif isinstance(obj, trimesh.Trimesh):
        mesh = obj
    else:
        raise Model3DError('в файле нет поверхностей (только точки или линии)')
    if not len(mesh.faces):
        raise Model3DError('в модели нет граней')
    if '.' + ext in Y_UP:                                   # Y вверх → Z вверх (поворот на 90° вокруг X)
        mesh.apply_transform(_rx(90))
    return mesh


def _rx(deg):
    import trimesh
    return trimesh.transformations.rotation_matrix(math.radians(deg), (1, 0, 0))


def _face_colors(mesh):
    """Цвета граней модели (0–1) или None, если цветов нет / все одинаковые серые по умолчанию."""
    try:
        vis = mesh.visual
        if getattr(vis, 'kind', None) == 'texture':
            vis = vis.to_color()
        fc = vis.face_colors[:, :3] / 255.0
        if len(fc) and (fc.std(axis=0).max() > 0.02 or abs(fc[0] - [102 / 255, 102 / 255, 102 / 255]).max() > 0.05):
            return fc
    except Exception:                                       # noqa: BLE001
        pass
    return None


def render_png(mesh, view='iso', w=8.0, h=6.0, dpi=200):
    """Вид модели с ракурса view (ключ VIEWS или (подъём, поворот) в градусах) → PNG с прозрачным фоном."""
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection
    elev, azim = (VIEWS.get(view) or VIEWS['iso'])[1:] if not isinstance(view, (tuple, list)) else view
    faces = np.asarray(mesh.faces)
    verts = np.asarray(mesh.vertices, dtype=float)
    normals = np.asarray(mesh.face_normals, dtype=float)
    colors = _face_colors(mesh)
    if len(faces) > MAX_FACES:                              # самые крупные грани — силуэт и форма сохраняются
        area = np.asarray(mesh.area_faces)
        keep = np.sort(np.argsort(-area)[:MAX_FACES])
        faces, normals = faces[keep], normals[keep]
        colors = colors[keep] if colors is not None else None
    # свет «сверху-слева-спереди» в системе координат камеры
    e, a = math.radians(elev), math.radians(azim)
    cam = np.array([math.cos(e) * math.cos(a), math.cos(e) * math.sin(a), math.sin(e)])
    up = np.array([0.0, 0.0, 1.0])
    right = np.cross(up, cam)
    right = right / (np.linalg.norm(right) or 1)
    light = cam * 0.7 + up * 0.55 - right * 0.45
    light = light / np.linalg.norm(light)
    lam = np.clip(normals @ light, -1, 1)
    shade = 0.38 + 0.62 * np.abs(lam)                       # обе стороны граней (у многих моделей нормали внутрь)
    base = colors if colors is not None else np.tile(BASE_RGB, (len(faces), 1))
    rgb = np.clip(base * shade[:, None] + 0.06, 0, 1)
    fig = plt.figure(figsize=(w, h), dpi=dpi)
    try:
        ax = fig.add_subplot(111, projection='3d')
        ax.set_axis_off()
        fig.patch.set_alpha(0)
        ax.patch.set_alpha(0)
        poly = Poly3DCollection(verts[faces], facecolors=rgb, edgecolors=rgb, linewidths=0.15)
        ax.add_collection3d(poly)
        lo, hi = verts.min(axis=0), verts.max(axis=0)
        ctr, span = (lo + hi) / 2, (hi - lo).max() / 2 or 1
        ax.set_xlim(ctr[0] - span, ctr[0] + span)
        ax.set_ylim(ctr[1] - span, ctr[1] + span)
        ax.set_zlim(ctr[2] - span, ctr[2] + span)
        ax.set_box_aspect((1, 1, 1))
        ax.view_init(elev=elev, azim=azim)
        fig.subplots_adjust(0, 0, 1, 1)
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=dpi, transparent=True)
    finally:
        plt.close(fig)
    return _crop_alpha(buf.getvalue())


def _crop_alpha(png, pad=12):
    """Срезает прозрачные поля вокруг модели."""
    from PIL import Image
    im = Image.open(io.BytesIO(png)).convert('RGBA')
    box = im.getchannel('A').point(lambda v: 255 if v > 8 else 0).getbbox()
    if box:
        l, t, r, b = box
        im = im.crop((max(0, l - pad), max(0, t - pad), min(im.width, r + pad), min(im.height, b + pad)))
    out = io.BytesIO()
    im.save(out, 'PNG', optimize=True)
    return out.getvalue()


def _models_dir():
    from .pictures import UPLOAD_DIR
    return UPLOAD_DIR / 'models'


def model_path(upload):
    """Модель .glb, из которой нарисована своя картинка upload, или None."""
    from .pictures import UPLOAD_RX
    if not UPLOAD_RX.fullmatch(str(upload or '')):
        return None
    meta = _models_dir() / (Path(upload).stem + '.json')
    try:
        info = json.loads(meta.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None
    p = _models_dir() / str(info.get('glb') or '')
    return p if p.suffix == '.glb' and p.is_file() else None


def model_info(upload):
    from .pictures import UPLOAD_RX
    if not UPLOAD_RX.fullmatch(str(upload or '')):
        return None
    try:
        return json.loads((_models_dir() / (Path(upload).stem + '.json')).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None


def save(data, filename, view='iso', folder=''):
    """Файл модели → своя картинка (вид с ракурса) {'upload', 'caption', 'model3d': ракурс}. Ошибка → Model3DError."""
    import hashlib
    from .pictures import _naming, _store
    mesh = load(data, filename)
    try:
        png = render_png(mesh, view)
    except ImportError:
        raise Model3DError('для 3D-моделей нужна библиотека matplotlib — она входит в полный пакет для Windows')
    d = _models_dir()
    d.mkdir(parents=True, exist_ok=True)
    glb_name = hashlib.sha1(data).hexdigest()[:20] + '.glb'
    glb = d / glb_name
    if not glb.exists():
        glb_name = _write_glb(data, filename, mesh, glb)
    name = _store(png, '.png', filename, _naming('', [], filename, folder))
    (d / (Path(name).stem + '.json')).write_text(json.dumps(
        {'glb': glb_name, 'view': view if isinstance(view, str) else list(view), 'source': Path(str(filename)).name[:120],
         'faces': int(len(mesh.faces)), 'size': [round(float(x), 4) for x in mesh.extents]}, ensure_ascii=False), encoding='utf-8')
    return {'upload': name, 'caption': '', 'model3d': view if isinstance(view, str) else 'custom'}


def _write_glb(data, filename, mesh, dst):
    """Модель в формате .glb рядом с картинкой: .glb — как есть, остальное — переводом trimesh. → имя файла или ''."""
    if Path(str(filename)).suffix.lower() == '.glb' and data[:4] == b'glTF':
        dst.write_bytes(data)
        return dst.name
    for strip in (False, True):
        try:
            m = mesh.copy()
            if strip:                                       # цвета граней требуют scipy — без цветов
                import trimesh
                m = trimesh.Trimesh(vertices=mesh.vertices, faces=mesh.faces, process=False)
            m.apply_transform(_rx(-90))                     # Z вверх → Y вверх, как в glTF
            dst.write_bytes(m.export(file_type='glb'))
            return dst.name
        except Exception:                                   # noqa: BLE001 — без .glb модель всё равно на слайде
            continue
    return ''


def rerender(upload, view):
    """Тот же файл модели с другого ракурса → новая своя картинка (прежняя остаётся)."""
    info = model_info(upload)
    p = model_path(upload)
    if not info or not p:
        raise Model3DError('модель этой картинки не найдена — загрузите файл модели ещё раз')
    from .pictures import _load_index
    title = (_load_index().get(upload) or {}).get('title') or ''
    data = p.read_bytes()
    mesh = load(data, 'model.glb')
    png = render_png(mesh, view)
    from .pictures import _store
    name = _store(png, '.png', info.get('source') or 'model', {'title': title, 'how': 'user' if title else '', 'tags': []})
    d = _models_dir()
    (d / (Path(name).stem + '.json')).write_text(json.dumps(dict(info, view=view), ensure_ascii=False), encoding='utf-8')
    return {'upload': name, 'caption': '', 'model3d': view}


# --------------------------------------------------------------------------------------
# Вращаемая 3D-модель PowerPoint 365 (проба)
# --------------------------------------------------------------------------------------
NS_AM3D = 'http://schemas.microsoft.com/office/drawing/2017/model3d'
NS_MC = 'http://schemas.openxmlformats.org/markup-compatibility/2006'
RT_MODEL3D = 'http://schemas.microsoft.com/office/2017/06/relationships/model3d'
CT_GLB = 'model/gltf.binary'
EMU_M = 36000000                        # 1 м сцены в EMU: модель приводится к размеру 1 м по большей стороне
FOV = 45                                # угол обзора камеры, градусы
# свет как у модели, вставленной в PowerPoint: рассеянный и три точечных (тёплый, холодный, контровой)
LIGHTS = ('<am3d:ambientLight><am3d:clr><a:scrgbClr r="50000" g="50000" b="50000"/></am3d:clr>'
          '<am3d:illuminance n="500000" d="1000000"/></am3d:ambientLight>'
          '<am3d:ptLight rad="0"><am3d:clr><a:scrgbClr r="100000" g="75000" b="50000"/></am3d:clr>'
          '<am3d:intensity n="9765625" d="1000000"/><am3d:pos x="21959998" y="70920001" z="16344003"/></am3d:ptLight>'
          '<am3d:ptLight rad="0"><am3d:clr><a:scrgbClr r="40000" g="60000" b="95000"/></am3d:clr>'
          '<am3d:intensity n="12250000" d="1000000"/><am3d:pos x="-37964106" y="51130435" z="57631972"/></am3d:ptLight>'
          '<am3d:ptLight rad="0"><am3d:clr><a:scrgbClr r="86837" g="72700" b="100000"/></am3d:clr>'
          '<am3d:intensity n="3125000" d="1000000"/><am3d:pos x="-37739122" y="58056624" z="-34769649"/></am3d:ptLight>')

_LIVE = contextvars.ContextVar('zn_live3d', default=None)


@contextmanager
def collect():
    """На время сборки: картинки моделей с галочкой «вращаемая» собираются, замена — apply_live()."""
    items = []
    tok = _LIVE.set(items)
    try:
        yield items
    finally:
        _LIVE.reset(tok)


def register(pic, im):
    """Картинка pic нарисована из 3D-модели и автор отметил «вращаемая» → запомнить для замены. → True/False."""
    items = _LIVE.get()
    if items is None or not isinstance(im, dict) or not im.get('live3d') or not im.get('upload'):
        return False
    p = model_path(im['upload'])
    if not p:
        return False
    items.append((pic, p, (model_info(im['upload']) or {}).get('view') or 'iso'))
    return True


def _bounds_yup(glb_path, cache):
    """Габариты модели в осях glTF (Y вверх): (lo, hi)."""
    key = str(glb_path)
    if key not in cache:
        m = load(Path(glb_path).read_bytes(), 'model.glb')      # внутри — Z вверх
        (x0, y0, z0), (x1, y1, z1) = m.bounds
        cache[key] = ((x0, z0, -y1), (x1, z1, -y0))
    return cache[key]


def camera(lo, hi, view, w, h):
    """Камера и перенос модели для ракурса view: модель приводится к 1 м по большей стороне и ставится в центр
    сцены, камера смотрит на центр с направления ракурса (как у картинки). w, h — размер рамки на слайде, EMU.
    → {'mpu': (n, d), 'pre': (dx, dy, dz), 'pos': (x, y, z), 'up': (dx, dy, dz), 'vp': размер окна сцены, EMU}."""
    import numpy as np
    lo, hi = np.asarray(lo, float), np.asarray(hi, float)
    ext = hi - lo
    size = float(ext.max()) or 1.0
    mpu = 1.0 / size                                         # метров в единице модели
    half = ext * mpu / 2
    r = float(np.linalg.norm(half)) or 0.5
    t = math.tan(math.radians(FOV / 2))
    dist = r / t * 1.05
    elev, azim = (VIEWS.get(view) or VIEWS['iso'])[1:]
    e, a = math.radians(elev), math.radians(azim)
    d = np.array([math.cos(e) * math.cos(a), math.sin(e), -math.cos(e) * math.sin(a)])   # к камере (Y вверх)
    up = np.array([0.0, 1.0, 0.0]) - math.sin(e) * d
    up /= np.linalg.norm(up)
    right = np.cross(-d, up)
    xs, ys = [], []
    for sx in (-1, 1):
        for sy in (-1, 1):
            for sz in (-1, 1):
                p = half * (sx, sy, sz)
                depth = max(dist - float(p @ d), 1e-6)
                xs.append(float(p @ right) / (depth * t))
                ys.append(float(p @ up) / (depth * t))
    fx, fy = max((max(xs) - min(xs)) / 2, 0.05), max((max(ys) - min(ys)) / 2, 0.05)
    big = max(w, h)
    vp = int(min(max(max(w / fx, h / fy), big), big * 4))
    n = max(1, round(mpu * 1e6))
    return {'mpu': (n, 1000000),
            'pre': tuple(int(round(-c * mpu * EMU_M)) for c in (lo + hi) / 2),
            'pos': tuple(int(round(c * dist * EMU_M)) for c in d),
            'up': tuple(int(round(c * EMU_M)) for c in up),
            'vp': vp}


def _glb_part(slide_part, glb_path, parts):
    """Часть .glb в пакете (одна на файл модели, даже если модель на нескольких слайдах) → rId на слайде."""
    from pptx.opc.package import Part
    key = str(glb_path)
    gp = parts.get(key)
    if gp is None:
        pkg = slide_part.package
        gp = Part(pkg.next_partname('/ppt/media/model3d%d.glb'), CT_GLB, pkg, Path(glb_path).read_bytes())
        parts[key] = gp
    return slide_part.relate_to(gp, RT_MODEL3D)


def live_xml(pic_el, model_rid, cam):
    """mc:AlternateContent: вращаемая модель (Requires="am3d") + та же картинка для остальных программ."""
    from pptx.oxml.ns import nsdecls, qn
    nv = pic_el.find(qn('p:nvPicPr')).find(qn('p:cNvPr'))
    off = pic_el.find(qn('p:spPr')).find(qn('a:xfrm'))
    o, ex = off.find(qn('a:off')), off.find(qn('a:ext'))
    x, y, cx, cy = o.get('x'), o.get('y'), ex.get('cx'), ex.get('cy')
    img_rid = pic_el.find(qn('p:blipFill')).find(qn('a:blip')).get(qn('r:embed'))
    attr = lambda v: escape(str(v or ''), {'"': '&quot;'})  # noqa: E731
    name = attr(nv.get('name') or '3D-модель')
    descr = f' descr="{attr(nv.get("descr"))}"' if nv.get('descr') else ''
    xfrm = f'<a:off x="{x}" y="{y}"/><a:ext cx="{cx}" cy="{cy}"/>'
    (px, py, pz), (ux, uy, uz), (tx, ty, tz) = cam['pos'], cam['up'], cam['pre']
    one = 'n="1000000" d="1000000"'
    return (
        f'<mc:AlternateContent xmlns:mc="{NS_MC}">'
        f'<mc:Choice xmlns:am3d="{NS_AM3D}" Requires="am3d">'
        f'<p:graphicFrame {nsdecls("p", "a", "r")}>'
        f'<p:nvGraphicFramePr><p:cNvPr id="{nv.get("id")}" name="{name}"{descr}/>'
        '<p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1" noChangeAspect="1"/></p:cNvGraphicFramePr><p:nvPr/>'
        f'</p:nvGraphicFramePr><p:xfrm>{xfrm}</p:xfrm>'
        f'<a:graphic><a:graphicData uri="{NS_AM3D}"><am3d:model3d r:embed="{model_rid}">'
        f'<am3d:spPr><a:xfrm>{xfrm}</a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></am3d:spPr>'
        f'<am3d:camera><am3d:pos x="{px}" y="{py}" z="{pz}"/><am3d:up dx="{ux}" dy="{uy}" dz="{uz}"/>'
        f'<am3d:lookAt x="0" y="0" z="0"/><am3d:perspective fov="{FOV * 60000}"/></am3d:camera>'
        f'<am3d:trans><am3d:meterPerModelUnit n="{cam["mpu"][0]}" d="{cam["mpu"][1]}"/>'
        f'<am3d:preTrans dx="{tx}" dy="{ty}" dz="{tz}"/>'
        f'<am3d:scale><am3d:sx {one}/><am3d:sy {one}/><am3d:sz {one}/></am3d:scale>'
        '<am3d:rot ax="0" ay="0" az="0"/><am3d:postTrans dx="0" dy="0" dz="0"/></am3d:trans>'
        f'<am3d:raster rName="ZN Slides" rVer="1.7"><am3d:blip r:embed="{img_rid}"/></am3d:raster>'
        f'<am3d:objViewport viewportSz="{cam["vp"]}"/>{LIGHTS}'
        '</am3d:model3d></a:graphicData></a:graphic></p:graphicFrame></mc:Choice>'
        '<mc:Fallback/></mc:AlternateContent>')


def apply_live(items, warnings=None):
    """Замена собранных картинок моделей вращаемыми моделями. Сбой одной — она остаётся картинкой. → сколько заменено."""
    from pptx.oxml import parse_xml
    from pptx.oxml.ns import qn
    done, parts, cache = 0, {}, {}
    for pic, glb, view in items:
        el = pic._element
        parent = el.getparent()
        if parent is None:
            continue
        try:
            lo, hi = _bounds_yup(glb, cache)
            xf = el.find(qn('p:spPr')).find(qn('a:xfrm')).find(qn('a:ext'))
            cam = camera(lo, hi, view, int(xf.get('cx')), int(xf.get('cy')))
            rid = _glb_part(pic.part, glb, parts)
            ac = parse_xml(live_xml(el, rid, cam))
        except Exception as e:                              # noqa: BLE001 — модель остаётся картинкой
            if warnings is not None:
                warnings.append(f'3D-модель «{Path(str(glb)).name}» оставлена картинкой: {type(e).__name__}')
            continue
        parent.replace(el, ac)
        ac.find(f'{{{NS_MC}}}Fallback').append(el)
        done += 1
    return done
