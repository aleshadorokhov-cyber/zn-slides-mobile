# -*- coding: utf-8 -*-
"""
model.py — ЕДИНАЯ МОДЕЛЬ ДОКУМЕНТА (то, что получается после чтения Word/Excel)
=============================================================================

Читатели файлов (readers/) превращают Word и Excel в одну и ту же структуру:

    Document
    ├── title, subtitle              — заголовок документа (если удалось определить)
    ├── sections: [Section]          — разделы (по заголовкам Word или листам Excel)
    │     ├── title, level           — заголовок раздела и его уровень (1, 2, 3)
    │     ├── blocks: [Block]        — содержимое по порядку: абзацы, списки, таблицы
    │     └── children: [Section]    — вложенные подразделы
    └── tables: {id: Table}          — все таблицы с данными (T1, T2 …)

Планировщики (planner_rules.py и planner_llm.py) работают ТОЛЬКО с этой моделью и
ничего не знают о форматах файлов. Чтобы добавить новый формат (например, PDF или
Markdown), достаточно написать читатель, который строит такую же модель.
"""
import re
from dataclasses import dataclass, field
from typing import List, Optional

from .textutil import parse_number


@dataclass
class ListItem:
    text: str
    bold: str = ''          # жирное начало пункта (часто это «заголовок» пункта)
    level: int = 0          # уровень вложенности (0 — верхний)
    mark: bool = False      # пункт выделен автором (маркер/цвет/«!») — на слайд в первую очередь


@dataclass
class Block:
    kind: str               # 'para' | 'list' | 'table' | 'image'
    text: str = ''          # для абзаца; для картинки — подпись
    bold: str = ''          # жирное начало абзаца
    items: List[ListItem] = field(default_factory=list)   # для списка
    ordered: bool = False   # нумерованный список
    table_id: str = ''      # для таблицы — ссылка на Document.tables
    image_id: str = ''      # для картинки — ссылка на Document.images
    mark: bool = False      # абзац/таблица/картинка выделены автором
    mark_text: str = ''     # выделенная ЧАСТЬ абзаца (если выделен не весь абзац)


@dataclass
class Section:
    title: str
    level: int = 1
    blocks: List[Block] = field(default_factory=list)
    children: List['Section'] = field(default_factory=list)
    source: str = ''        # имя файла / листа
    mark: bool = False      # заголовок раздела выделен автором — раздел обязателен в презентации
    marker: bool = False    # раздел-«слайд» из документа-сценария («Слайд 3»)

    def marked(self):
        """Есть ли в разделе выделенные фрагменты (или выделен сам раздел)."""
        if self.mark:
            return True
        for b in self.blocks:
            if b.mark or b.mark_text or any(i.mark for i in b.items):
                return True
        return any(c.marked() for c in self.children)

    def all_text(self, with_children=True):
        """Весь текст раздела (для заметок докладчика и для ИИ)."""
        out = []
        for b in self.blocks:
            if b.kind == 'para':
                out.append(b.text)
            elif b.kind == 'list':
                out.extend('• ' + i.text for i in b.items)
        if with_children:
            for c in self.children:
                out.append(c.title)
                out.append(c.all_text())
        return '\n'.join(t for t in out if t)


@dataclass
class Table:
    id: str
    columns: List[str]
    rows: List[List[str]]
    title: str = ''
    source: str = ''
    units: List[str] = field(default_factory=list)     # единица измерения столбца ('%', 'млн руб.' …)
    # заполняется analyze():
    label_col: int = 0
    numeric_cols: List[int] = field(default_factory=list)
    id_cols: List[int] = field(default_factory=list)
    is_time: bool = False
    total_row: Optional[int] = None

    DATE_HDR_RX = re.compile(r'(?i)(год|срок|year|дата|период|начал|оконч|заверш|старт|ввод)')
    ID_RX = re.compile(r'(?i)^\s*(№|n|#|no\.?|номер|п/п|№ п/п|п\.п\.|код|id)\s*$')

    def analyze(self):
        """Определяет, какие столбцы числовые, какой столбец — подписи, есть ли строка
        «Итого» и похожи ли подписи на время (годы, кварталы, месяцы).
        Столбцы-номера («№», «п/п», 1, 2, 3 …) данными не считаются."""
        ncol = len(self.columns)
        self.numeric_cols = []
        self.id_cols = []
        if len(self.units) < ncol:
            self.units = list(self.units) + [''] * (ncol - len(self.units))
        for j in range(ncol):
            vals = [r[j] for r in self.rows if j < len(r) and str(r[j]).strip()]
            if not vals:
                continue
            nums = [parse_number(v) for v in vals]
            if sum(v is not None for v in nums) >= max(1, 0.7 * len(vals)):
                good = [v for v in nums if v is not None]
                seq = len(good) >= 2 and good == [float(k) for k in range(int(good[0]), int(good[0]) + len(good))]
                if self.ID_RX.match(str(self.columns[j])) or (seq and j == 0 and len(good) == len(self.rows)):
                    self.id_cols.append(j)                     # номер строки — не данные
                    continue
                if j > 0 and self.DATE_HDR_RX.search(str(self.columns[j])) and self._yearlike(vals):
                    continue                                   # «Срок: 2026, 2027» — это даты, а не величины
                self.numeric_cols.append(j)
                if not self.units[j] and sum(str(v).strip().endswith('%') for v in vals) >= 0.7 * len(vals):
                    self.units[j] = '%'
        text_cols = [j for j in range(ncol) if j not in self.numeric_cols and j not in self.id_cols]
        # подписи — текстовый столбец без пропусков и с наибольшим числом разных значений
        def score(j):
            vals = [str(r[j]).strip() for r in self.rows if j < len(r)]
            filled = sum(1 for v in vals if v)
            return (filled == len(vals), len(set(v for v in vals if v)), -j)
        self.label_col = max(text_cols, key=score) if text_cols else 0
        if self.label_col in self.numeric_cols:
            self.numeric_cols.remove(self.label_col)
        # Первый столбец — годы (2021, 2022…): это подписи, а не данные
        if not text_cols and self.numeric_cols and self._yearlike([r[0] for r in self.rows]):
            self.label_col = 0
            self.numeric_cols = [j for j in self.numeric_cols if j != 0]
        labels = [str(r[self.label_col]) if self.label_col < len(r) else '' for r in self.rows]
        self.total_row = None
        for i, lab in enumerate(labels):
            if re.match(r'(?i)\s*(итого|всего|total|сумма)\b', lab):
                self.total_row = i
        self.is_time = self._timelike([l for i, l in enumerate(labels) if i != self.total_row])
        return self

    @staticmethod
    def _yearlike(vals):
        vals = [str(v).strip() for v in vals if str(v).strip()]
        return bool(vals) and all(re.fullmatch(r'(19|20)\d\d(\.0)?', v) for v in vals)

    @staticmethod
    def _timelike(labels):
        labels = [l.strip().lower() for l in labels if l.strip()]
        if len(labels) < 3:
            return False
        pat = re.compile(r'^((19|20)\d\d(\.0)?( ?г\.?)?|[1-4] ?(кв\.?|квартал)( (19|20)\d\d)?|q[1-4]( ?(19|20)\d\d)?|'
                         r'(янв|фев|мар|апр|ма[йя]|июн|июл|авг|сен|окт|ноя|дек)\w*( (19|20)\d\d)?|\d{1,2}[./]\d{2,4}|'
                         r'(19|20)\d\d[-./]\d{1,2}([-./]\d{1,2})?|h[12] ?(19|20)\d\d|[12] ?(полугодие|пол\.))$')
        return sum(bool(pat.match(l)) for l in labels) >= 0.8 * len(labels)

    def series(self, max_series=4, skip_total=True):
        """Данные для диаграммы: (подписи, [(имя ряда, [значения])])."""
        idx = [i for i in range(len(self.rows)) if not (skip_total and i == self.total_row)]
        labels = [str(self.rows[i][self.label_col]).strip() if self.label_col < len(self.rows[i]) else '' for i in idx]
        out = []
        for j in self.numeric_cols[:max_series]:
            vals = [parse_number(self.rows[i][j]) if j < len(self.rows[i]) else None for i in idx]
            out.append((self.columns[j] if j < len(self.columns) else f'Ряд {j}', vals))
        return labels, out


@dataclass
class Document:
    title: str = ''
    subtitle: str = ''
    sections: List[Section] = field(default_factory=list)
    tables: dict = field(default_factory=dict)
    images: dict = field(default_factory=dict)      # F1 → {'path', 'width', 'height', 'caption'}
    sources: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def add_image(self, path, width=0, height=0, caption=''):
        fid = f'F{len(self.images) + 1}'
        self.images[fid] = {'path': str(path), 'width': width, 'height': height, 'caption': caption}
        return fid

    def marks_count(self):
        n = 0
        for s in self.walk():
            n += int(s.mark)
            for b in s.blocks:
                n += int(bool(b.mark or b.mark_text)) + sum(i.mark for i in b.items)
        return n

    def add_table(self, columns, rows, title='', source='', units=None):
        tid = f'T{len(self.tables) + 1}'
        t = Table(tid, columns, rows, title=title, source=source, units=units or [])
        t.analyze()
        self.tables[tid] = t
        return t

    def walk(self):
        """Все разделы по порядку (обход в глубину)."""
        def rec(secs):
            for s in secs:
                yield s
                yield from rec(s.children)
        yield from rec(self.sections)

    def stats(self):
        secs = list(self.walk())
        return {
            'sections': len(secs),
            'paragraphs': sum(1 for s in secs for b in s.blocks if b.kind == 'para'),
            'lists': sum(1 for s in secs for b in s.blocks if b.kind == 'list'),
            'tables': len(self.tables),
            'images': len(self.images),
            'marks': self.marks_count(),
            'chars': sum(len(s.all_text(False)) for s in secs),
        }
