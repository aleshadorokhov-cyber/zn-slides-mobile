# -*- coding: utf-8 -*-
"""
revise.py — ЗАМЕЧАНИЯ И ПРАВКИ К СЛАЙДАМ
=======================================

Автор пишет замечание к слайду обычными словами («сделай короче», «покажи таблицей»,
«заголовок: Итоги 2026 года», «убери пункт 3») и нажимает «Исправить».

revise_slide(slide, remark, llm, spec) → (новый_слайд, что_сделано, предупреждения, режим)

  * если в настройках задана локальная модель ИИ — слайд исправляет она: получает JSON слайда
    и замечание, возвращает исправленный JSON. Числа в ответе проверяются: число, которого нет
    ни в плане, ни в замечании, модель выдумала — такая правка отменяется (правило проекта:
    цифры на слайдах — только из материалов);
  * без модели (или если она не ответила) замечание разбирается правилами: смена макета по
    словам («таблицей», «процессом», «SWOT», «план-график»…), заголовок / подзаголовок / вывод,
    «короче», «без пояснений», «оставь N пунктов», «убери / добавь пункт», «замени «А» на «Б»»,
    «поменяй местами 2 и 3».

Каждое замечание сохраняется в слайде (поле remarks: текст, что сделано, режим) — история правок
видна в плане и сохраняется вместе с ним.

apply_general(spec, text) — общие замечания ко всей презентации: «короче», «без анимации»,
«убери раздел «…»», «без пояснений». Число слайдов («не больше 12 слайдов») учитывается при
анализе (general_options), а в ИИ-режиме весь текст замечаний передаётся модели.
"""
import copy
import json
import re
import time

from .spec import LAYOUTS, normalize
from .textutil import clean, shorten

# --------------------------------------------------------------------------------------
# Макет по словам замечания (порядок важен: частные схемы — раньше общих)
# --------------------------------------------------------------------------------------
LAYOUT_WORDS = [
    (r'цепочк\w* (создания )?стоимост|value chain', 'value_chain'),
    (r'(разрез|схем|конструкци)\w* скважин|скважин\w* по (интервал|глубин)', 'well'),
    (r'обустройств|схем\w* месторожд|план\w* месторожд', 'field'),
    (r'гант|план-график|календарн\w* план', 'gantt'), (r'таблиц', 'table'),
    (r'диаграмм|(?<!план-)график(?!-)|гистограмм', 'chart'), (r'swot|свот', 'swot'), (r'(матриц|карт)\w* риск', 'risk'), (r'чек-?лист|статус', 'checklist'),
    (r'рыб\w* кост|исикав|причин\w* и следств', 'fishbone'), (r'айсберг', 'iceberg'), (r'пазл', 'puzzle'),
    (r'\bвес(ы|ах|ами)\b|чаш', 'balance'), (r'было.{0,6}стало', 'shift'),
    (r'(главн|одн|крупн)\w* (цифр|числ)', 'hero'), (r'лепест|цвет(ок|ком|ка)', 'petals'),
    (r'извилист|змейк|\bпут[ьи]\b', 'path'), (r'ментальн|mind ?map|карт\w* (мысл|идей)', 'mindmap'),
    (r'фактор\w*.{0,12}результат|сходящ', 'converge'), (r'дорожн\w* карт', 'roadmap'),
    (r'таймлайн|хронолог|лини\w* времени|шкал\w* времени', 'timeline'), (r'процесс|по шагам|шаги', 'process'),
    (r'пирамид', 'pyramid'), (r'воронк', 'funnel'), (r'ступен|лестниц', 'stairs'), (r'\bсот(ы|ами|ах)\b|шестиуг', 'honeycomb'),
    (r'\bсло(и|ями|ях)\b', 'layers'), (r'опор|колонн', 'pillars'), (r'шест[её]р', 'gears'), (r'пересечени|венн', 'venn'),
    (r'спидометр', 'gauge'), (r'полос', 'bars'), (r'пузыр', 'bubbles'), (r'дерев', 'tree'), (r'\bцикл', 'cycle'),
    (r'мишен|цел\w* и задач', 'target'), (r'сет[ьи] связ', 'hub'), (r'показател|kpi|плитк\w* (с )?цифр', 'kpi'),
    (r'сравнени|плюс\w* и минус', 'compare'), (r'карточк', 'cards'), (r'списк|список|перечн', 'list'),
    (r'тезис|цитат|текстом', 'text'), (r'итогов\w* плитк|выводами', 'conclusions'),
]
LAYOUT_WORDS = [(re.compile(p, re.I), k) for p, k in LAYOUT_WORDS]
CHANGE_RX = re.compile(r'(?i)в виде|\bвиде\b|сдела|передела|покажи|показать|оформ|представ|преврат|замени на|поменяй на|'
                       r'смени на|используй|лучше|хочу|нужн|\bкак\b|макет|схем|вместо')
SHORT_RX = re.compile(r'(?i)короче|сократ|кратк|меньше текста|лаконичн|сжат|покороче|убери воду|компактн')
NO_TEXT_RX = re.compile(r'(?i)без пояснени|только заголовк|убери пояснени|без описани')
QUOTE = r'[«"“„\']'
UNQUOTE = r'[»"”\']'


def _q(s):
    """Снимает кавычки и точку в конце."""
    s = (s or '').strip().strip('.').strip()
    m = re.fullmatch(QUOTE + r'(.*)' + UNQUOTE, s)
    return (m.group(1) if m else s).strip()


def _clauses(text):
    """Замечание → отдельные указания (по строкам, «;» и точкам между предложениями)."""
    parts = []
    for line in re.split(r'[\n;]+', text):
        parts += [p for p in re.split(r'(?<=[.!?])\s+(?=[А-ЯЁA-Z])', line) if p.strip()]
    return [p.strip() for p in parts]


def _strip(s):
    """Слайд без служебных полей (варианты, история)."""
    return {k: copy.deepcopy(v) for k, v in s.items() if k not in ('alts', 'alt_index', 'remarks') and not k.startswith('_')}


def _shorten_slide(s):
    """«Короче»: пояснения — до первой фразы (не длиннее ~90 знаков), абзацы — до двух, вывод — короче."""
    def cut(t, n=90):
        t = t or ''
        if len(t) <= n:
            return t
        first = re.split(r'(?<=[.!?])\s', t)[0]
        return first if len(first) <= n + 20 else shorten(t, n)
    for it in s.get('items') or []:
        if isinstance(it, dict):
            it['text'] = cut(it.get('text'))
    if s.get('paragraphs'):
        s['paragraphs'] = [cut(p, 160) for p in s['paragraphs'][:2]]
    if s.get('lead'):
        s['lead'] = cut(s['lead'], 140)
    for side in ('left', 'right'):
        if isinstance(s.get(side), dict):
            s[side]['items'] = [cut(x, 70) for x in s[side].get('items') or []][:5]
    if s.get('conclusion'):
        s['conclusion'] = cut(s['conclusion'], 110)
    s.pop('aside', None)
    return s


def _items_text(s):
    return [((it.get('title') or '') + ' ' + (it.get('text') or '')).lower() for it in s.get('items') or []]


def _revise_rules(s, remark):
    """Замечание → правки по правилам. Возвращает (слайд, сделано, не_понято)."""
    from .convert import convert_slide
    from .variety import _ok
    s = copy.deepcopy(s)
    done, unknown = [], []
    for cl in _clauses(remark):
        low = cl.lower()
        hit = False
        m = re.search(r'(?i)^(?:измени|поменяй|замени|сделай|исправь|новый|пусть)?\s*заголов\w*(?:\s+слайда)?\s*(?:на|:|—|–|-)\s*(.+)$', cl) \
            or re.search(r'(?i)^назови\s+(?:слайд\s+)?(.+)$', cl)
        if m and not re.search(r'(?i)подзаголов', cl):
            s['title'] = _q(m.group(1))
            done.append(f'заголовок: «{s["title"]}»')
            continue
        m = re.search(r'(?i)подзаголов\w*\s*(?:на|:|—|–|-)\s*(.+)$', cl)
        if m:
            s['subtitle'] = _q(m.group(1))
            done.append('подзаголовок изменён')
            continue
        if re.search(r'(?i)(убери|удали|без)\s+подзаголов', cl):
            s['subtitle'] = ''
            done.append('подзаголовок убран')
            continue
        m = re.search(r'(?i)^(?:добавь\s+|измени\s+|новый\s+)?вывод\w*\s*(?:на|:|—|–|-)\s*(.+)$', cl)
        if m:
            s['conclusion'] = _q(m.group(1))
            done.append('вывод изменён')
            continue
        if re.search(r'(?i)(убери|удали|без)\s+(вывод|баннер|итог)', cl):
            s['conclusion'] = ''
            done.append('вывод убран')
            continue
        m = re.search(r'(?i)(?:центр\w*|цель|в центре)\s*(?:на|:|—|–|-)\s*(.+)$', cl)
        if m and 'center' in s:
            s['center'] = _q(m.group(1))
            done.append('центральная фраза изменена')
            continue
        m = re.search(r'(?i)замени\s*' + QUOTE + r'(.+?)' + UNQUOTE + r'\s*на\s*' + QUOTE + r'(.+?)' + UNQUOTE, cl)
        if m:
            a, b = m.group(1), m.group(2)
            raw = json.dumps(s, ensure_ascii=False)
            if a in raw:
                s = json.loads(raw.replace(json.dumps(a, ensure_ascii=False)[1:-1], json.dumps(b, ensure_ascii=False)[1:-1]))
                done.append(f'«{a}» заменено на «{b}»')
            else:
                unknown.append(f'текст «{a}» на слайде не найден')
            continue
        items = s.get('items') if isinstance(s.get('items'), list) else None
        m = re.search(r'(?i)(?:убери|удали|исключи)\s+(?:(\d+)[-‑]?\w{0,3}\s+пункт\w*|пункт\w*\s*(?:№\s*)?(\d+))', cl)
        if m and items:
            k = int(m.group(1) or m.group(2)) - 1
            if 0 <= k < len(items):
                items.pop(k)
                done.append(f'пункт {k + 1} убран')
            else:
                unknown.append(f'пункта {k + 1} нет')
            continue
        m = re.search(r'(?i)(?:убери|удали|исключи)\s+(?:пункт\w*|элемент\w*|тезис\w*)?\s*' + QUOTE + r'(.+?)' + UNQUOTE, cl)
        if m and items:
            key = m.group(1).lower()
            k = next((i for i, t in enumerate(_items_text(s)) if key in t), None)
            if k is not None:
                items.pop(k)
                done.append(f'пункт «{m.group(1)}» убран')
            else:
                unknown.append(f'пункт «{m.group(1)}» не найден')
            continue
        m = re.search(r'(?i)добавь\s+(?:пункт|элемент|тезис|строку)\w*\s*(?::|—|–|-)?\s*(.+)$', cl)
        if m and items is not None:
            t = _q(m.group(1))
            parts = re.split(r'\s*[:—–]\s+', t, maxsplit=1)
            items.append({'title': parts[0], 'text': parts[1]} if len(parts) == 2 else {'title': '', 'text': t})
            done.append('пункт добавлен')
            continue
        m = re.search(r'(?i)помен\w*\s+местами\s+(?:пункт\w*\s+)?(\d+)\s*и\s*(\d+)', cl)
        if m and items:
            a, b = int(m.group(1)) - 1, int(m.group(2)) - 1
            if 0 <= a < len(items) and 0 <= b < len(items):
                items[a], items[b] = items[b], items[a]
                done.append(f'пункты {a + 1} и {b + 1} поменяны местами')
            continue
        m = re.search(r'(?i)оставь\s+(?:только\s+)?(\d+)|не\s+больше\s+(\d+)\s+(?:пункт|элемент|тезис)', cl)
        if m and items:
            k = int(m.group(1) or m.group(2))
            if 0 < k < len(items):
                del items[k:]
                done.append(f'оставлено {k} пунктов')
            continue
        if NO_TEXT_RX.search(cl) and items:
            if all(it.get('title') for it in items):
                for it in items:
                    it['text'] = ''
                done.append('пояснения убраны')
            else:
                unknown.append('у пунктов нет заголовков — пояснения не убраны')
            hit = True
        if SHORT_RX.search(cl):
            _shorten_slide(s)
            done.append('тексты сокращены')
            hit = True
        m = re.search(r'(?i)(?:добавь|вставь|поставь|подбери|нужн\w*|сделай\s+с)\s+(?:сюда\s+)?(?:картинк|иллюстрац|рисун|изображен|пиктограмм)\w*'
                      r'(?:\s+(?:про|с|со|о|об|на\s+тему|по\s+теме)\s+(.+))?', cl)
        if m and s.get('layout') not in ('title', 'end', 'section', 'agenda'):
            from .pictures import picture_alt, suggest
            base = (s.get('alts') or [s])[0] if s.get('layout') == 'image' and s.get('illustration') else s
            sug = suggest(base, 1, query=_q(m.group(1))) if m.group(1) else suggest(base, 1)
            if sug:
                e = sug[0][0]
                s = picture_alt(base, {'picture': e['id'], 'caption': ''}, label=f'Картинка: {e["name"]}')
                done.append(f'картинка из библиотеки: «{e["name"]}»')
            else:
                unknown.append('подходящей картинки в библиотеке не нашлось — выберите её кнопкой «Картинка» '
                               'или загрузите свою')
            continue
        if re.search(r'(?i)(убери|без)\s+(иллюстрац|рисун|картин)', cl) and s.get('layout') == 'image':
            new = convert_slide(dict(s, layout='list'), 'list') if s.get('items') else None
            s = dict(s, layout='list', images=[], illustration=False) if new is None else new
            s.pop('images', None)
            done.append('рисунок убран — слайд показан списком')
            continue
        want = None
        if CHANGE_RX.search(cl) or len(low.split()) <= 3:
            for rx, lay in LAYOUT_WORDS:
                if rx.search(cl):
                    want = lay
                    break
        if want and want != s.get('layout'):
            cand = convert_slide(copy.deepcopy(s), want)
            name = LAYOUTS[want]['name']
            if cand.get('layout') != want:
                unknown.append(f'для макета «{name}» не хватает данных (например, чисел или таблицы)')
            elif LAYOUTS[want]['kind'] == 'items' and not _ok(cand, want, explicit=True):
                info = LAYOUTS[want]
                unknown.append(f'макет «{name}» не подходит: нужно {info.get("min")}–{info.get("max")} элементов'
                               + (' и особые данные (сроки, статусы, уровни рисков)'
                                  if want in ('gantt', 'checklist', 'risk', 'swot', 'hero') else ''))
            else:
                s = cand
                done.append(f'слайд показан как «{name}»')
            continue
        if want:
            continue
        if not hit:
            unknown.append(f'«{shorten(cl, 60)}»')
    return s, done, unknown


# --------------------------------------------------------------------------------------
# Правка моделью ИИ
# --------------------------------------------------------------------------------------
SYSTEM = """Ты — редактор слайдов корпоративной презентации АО «Зарубежнефть».
Тебе дают слайд в формате JSON и замечание автора. Исправь слайд по замечанию и верни ТОЛЬКО
JSON-объект слайда того же формата (без пояснений вокруг).

ПРАВИЛА
1. Меняй только то, о чём просит замечание; остальное оставь как было.
2. НЕ придумывай числа, даты, проценты, суммы и факты. Используй только те, что уже есть в слайде,
   в замечании или в фрагменте материалов. Если для правки нужны новые данные — не выдумывай их,
   оставь как есть и скажи об этом в поле "comment".
3. Если автор просит другой вид слайда, смени поле "layout" на подходящий макет из списка
   и перенеси содержимое в поля этого макета.
4. Деловой русский язык, кратко: заголовок элемента 2–5 слов, пояснение 1–2 предложения.
5. В поле "comment" одной фразой напиши, что изменено.

МАКЕТЫ (поле layout)
{catalog}"""


def _numbers(text):
    from .planner_llm import _numbers as nums
    return nums(text)


def _texts(obj, path=()):
    """Все строки и числа слайда: [(путь, значение)] (служебные поля — без проверки)."""
    out = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in ('layout', 'icon', 'style', 'variant', 'type', 'svg', 'path', 'alt_label', 'comment'):
                continue
            out += _texts(v, path + (k,))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            out += _texts(v, path + (i,))
    elif isinstance(obj, (str, int, float)) and not isinstance(obj, bool):
        out.append((path, str(obj)))
    return out


def _get(obj, path):
    for p in path:
        try:
            obj = obj[p]
        except (KeyError, IndexError, TypeError):
            return None
    return obj


def _set(obj, path, val):
    for p in path[:-1]:
        obj = obj[p]
    obj[path[-1]] = val


def check_numbers(old, new, remark, spec=None):
    """Числа, которых нет ни в плане (spec), ни в старом слайде, ни в замечании, — выдуманы моделью:
    такие строки возвращаются к прежнему виду (или очищаются). Возвращает (слайд, предупреждения)."""
    known = _numbers(json.dumps(old, ensure_ascii=False) + ' ' + remark)
    if spec:
        known |= _numbers(json.dumps(spec.get('slides') or [], ensure_ascii=False))
    warn = []
    for path, val in _texts(new):
        bad = _numbers(val) - known
        if not bad:
            continue
        prev = _get(old, path)
        _set(new, path, prev if isinstance(prev, (str, int, float)) else '')
        warn.append(f'ИИ предложил число, которого нет в материалах ({", ".join(_fmt(x) for x in sorted(bad)[:3])}) — '
                    'эта правка отменена.')
    return new, warn


def _fmt(x):
    return str(int(x)) if float(x).is_integer() else str(x).replace('.', ',')


def _revise_llm(s, remark, llm, progress=None):
    from .llm_client import LLMError, chat, extract_json
    from .planner_llm import _catalog_text
    system = SYSTEM.format(catalog=_catalog_text())
    src = (s.get('notes') or '')[:2500]
    slide = {k: v for k, v in s.items() if k not in ('notes', 'images')}
    user = ('СЛАЙД:\n' + json.dumps(slide, ensure_ascii=False, indent=1) + '\n\nЗАМЕЧАНИЕ АВТОРА:\n' + remark +
            ('\n\nФРАГМЕНТ МАТЕРИАЛОВ (заметки к слайду):\n' + src if src else ''))
    text = chat(llm, system, user, progress=progress, max_tokens=2200)
    raw = extract_json(text)
    if isinstance(raw, dict) and isinstance(raw.get('slide'), dict):
        raw = dict(raw['slide'], comment=raw.get('comment') or raw['slide'].get('comment'))
    if not isinstance(raw, dict) or not raw.get('layout'):
        raise LLMError('модель вернула не слайд')
    comment = clean(str(raw.pop('comment', '') or ''))
    if s.get('images') and raw.get('layout') == 'image':
        raw['images'] = s['images']                         # рисунки модель не трогает
    if s.get('notes'):
        raw['notes'] = s['notes']
    return raw, comment


# --------------------------------------------------------------------------------------
# Главная функция
# --------------------------------------------------------------------------------------
def revise_slide(slide, remark, llm=None, spec=None, progress=None):
    """Исправляет слайд по замечанию. Возвращает (слайд, сделано: str, предупреждения: list, режим)."""
    from .alternatives import build_alts
    remark = clean(remark)
    if not remark:
        return slide, '', ['Замечание пустое.'], 'none'
    if isinstance(slide, dict) and slide.get('layout') == 'own':
        return slide, '', ['Свой слайд из файла PowerPoint переносится как есть: поправьте его в PowerPoint и загрузите снова.'], 'none'
    base = _strip(slide)
    warnings, mode, done = [], 'rules', ''
    new = None
    if llm and llm.get('model'):
        try:
            cand, comment = _revise_llm(base, remark, llm, progress)
            cand, w = check_numbers(base, cand, remark, spec)
            norm, w2 = normalize({'meta': {}, 'slides': [cand]}, add_title_end=False)
            if norm['slides']:
                new = norm['slides'][0]
                warnings += w + [x for x in w2 if 'продолжение' not in x]
                mode, done = 'ai', comment or 'слайд исправлен моделью ИИ'
                if len(norm['slides']) > 1:
                    warnings.append('Элементов стало больше, чем помещается на слайд, — лишние не показаны.')
        except Exception as e:                            # noqa: BLE001  (нет связи, неверный ответ)
            from .llm_client import Cancelled
            if isinstance(e, Cancelled):
                raise
            warnings.append(f'Модель ИИ не ответила ({e}) — замечание разобрано правилами.')
    if new is None:
        cand, did, unknown = _revise_rules(base, remark)
        norm, _ = normalize({'meta': {}, 'slides': [cand]}, add_title_end=False)
        new = norm['slides'][0] if norm['slides'] else base
        done = '; '.join(did)
        if unknown:
            warnings.append('Без модели ИИ не выполнено: ' + '; '.join(unknown) +
                            '. Включите локальную модель в настройках или поправьте слайд вручную.')
    if _strip(new) == base:
        done = done or 'изменений нет'
    alts = build_alts(new)
    if alts:
        new['alts'] = alts
    new.pop('alt_index', None)
    hist = list(slide.get('remarks') or [])
    hist.append({'text': remark, 'done': done, 'mode': mode, 'time': time.strftime('%d.%m.%Y %H:%M'),
                 'warnings': warnings[:3]})
    new['remarks'] = hist[-20:]
    return new, done, warnings, mode


# --------------------------------------------------------------------------------------
# Общие замечания ко всей презентации
# --------------------------------------------------------------------------------------
def general_options(text, opts):
    """Общие замечания → настройки анализа: «не больше 12 слайдов», «без анимации»."""
    text = text or ''
    opts = dict(opts or {})
    m = re.search(r'(?i)(?:не\s+больше|не\s+более|максимум|до|ровно|всего)\s+(\d{1,2})\s+слайд', text) or \
        re.search(r'(?i)(\d{1,2})\s+слайд', text)
    if m and not opts.get('target_slides'):
        n = int(m.group(1))
        if 3 <= n <= 60:
            opts['target_slides'] = n
    if re.search(r'(?i)без\s+анимац|убери\s+анимац|отключи\s+анимац', text):
        opts['animations'] = False
    if re.search(r'(?i)без\s+(картин|иллюстрац|рисунк)|не\s+(добавляй|нужны|надо)\s+(картин|иллюстрац)', text):
        opts['pictures'] = False
        opts['illustrations'] = 0
    return opts


def apply_general(spec, text):
    """Общие замечания, которые выполняются правилами для всего плана. Возвращает (spec, сделано)."""
    text = clean(text or '')
    if not text or not spec:
        return spec, []
    done = []
    slides = spec.get('slides') or []
    content = [s for s in slides if s.get('layout') not in ('title', 'end', 'agenda', 'section')]
    if re.search(r'(?i)без\s+анимац|убери\s+анимац|отключи\s+анимац', text):
        spec.setdefault('meta', {})['animations'] = False
        done.append('анимация отключена')
    if SHORT_RX.search(text):
        for s in content:
            _shorten_slide(s)
        done.append('тексты всех слайдов сокращены')
    if NO_TEXT_RX.search(text):
        for s in content:
            its = s.get('items') or []
            if its and all(isinstance(it, dict) and it.get('title') for it in its):
                for it in its:
                    it['text'] = ''
        done.append('пояснения у пунктов убраны')
    for m in re.finditer(r'(?i)(?:убери|удали|без|исключи)\s+(?:раздел\w*|слайд\w*)\s*' + QUOTE + r'(.+?)' + UNQUOTE, text):
        key = m.group(1).lower()
        before = len(slides)
        slides[:] = [s for s in slides if key not in (str(s.get('title') or '') + ' ' + str(s.get('section') or '')).lower()
                     or s.get('layout') in ('title', 'end')]
        if len(slides) < before:
            done.append(f'убраны слайды «{m.group(1)}» ({before - len(slides)})')
    if re.search(r'(?i)без\s+(содержани|оглавлени)', text):
        slides[:] = [s for s in slides if s.get('layout') != 'agenda']
        done.append('слайд «Содержание» убран')
    if re.search(r'(?i)без\s+(разделител|слайдов[- ]разделов)', text):
        slides[:] = [s for s in slides if s.get('layout') != 'section']
        done.append('слайды-разделители убраны')
    return spec, done
