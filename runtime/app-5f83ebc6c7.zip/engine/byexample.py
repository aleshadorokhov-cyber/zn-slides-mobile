# -*- coding: utf-8 -*-
"""
byexample.py — ПЛАН ПО ОБРАЗЦУ (1.7)
===================================

Прежние презентации из библиотеки (engine/library.py) — образцы. Модель поиска (эмбеддинги, та же, что ищет фразы)
сравнивает по смыслу слайды нового плана со слайдами образцов, а без неё — по совпадению слов. Модель ничего не
пишет: тексты и числа остаются из материалов доклада, из образца берётся только устройство.

  1. Образец — презентация библиотеки, на которую план похож больше всего (или выбранная автором).
  2. Вид слайда: у похожего слайда образца гистограмма — и у нового будет гистограмма (тот же тип диаграммы),
     процесс — процесс, таблица — таблица… Вид меняется только на вариант того же содержания (варианты слайда,
     alternatives.py, или логичная форма тех же данных, convert.py), для которого хватает данных.
  3. Порядок: разделы нового плана выстраиваются так, как идут похожие слайды в образце (выводы — в конце;
     в документе-сценарии «Слайд 1, Слайд 2…» порядок задал автор — он не меняется).
  4. Каркас: есть ли в образце содержание и слайды-разделители (если в настройках «авто»).

Результат: у слайда — поле example {'deck', 'n', 'title', 'kind', 'how', 'conf'} («как слайд 5 образца»),
в сведениях об анализе — info['example'].

  apply(spec, options, cfg, info, notify) — применить к готовому плану (после правил, поиска фраз или ИИ).
"""
import copy
import math
import re
import statistics

from .textutil import shorten

META = ('title', 'agenda', 'section', 'end')
CONTENT_ROLES = ('content', 'conclusions')
SEM_FLOOR = 0.3              # косинус ниже — слайды не похожи вовсе
MATCH = 0.35                 # уверенность (0…1), с которой слайд образца считается похожим
ORDER_MATCH = 0.5            # для порядка разделов — только уверенно похожие слайды
WORDS_MATCH, WORDS_ORDER = 0.45, 0.7     # без модели поиска (по словам) — строже: общие слова темы обманчивы
OTHER_DECK = 0.6             # слайд другой презентации библиотеки — только если похож заметно сильнее
SLIDE_N_RX = re.compile(r'(?i)^\s*(слайд|slide)\s*\d+\s*$')
CONT = ' (продолжение)'
CONCL_RX = re.compile(r'(?i)^\W*(\d+[.)]?\s*)?(выводы?|заключение|итоги|резюме|ключевые тезисы|основные выводы)\b')
PIE_LIKE = ('pie', 'doughnut', 'pie3d', 'pie_exploded', 'pie_of_pie', 'bar_of_pie', 'sunburst', 'waffle', 'treemap')
STACK_LIKE = ('stacked', 'stacked100', 'bar_stacked', 'bar_stacked100', 'area_stacked', 'area_stacked100',
              'line_stacked', 'line_stacked100', 'column3d_stacked', 'column3d_stacked100', 'bar3d_stacked', 'combo')
KEEP_KEYS = ('found', 'found_n', 'example', 'keep_layout', 'pictures')


# --------------------------------------------------------------------------------------
# Сходство слайдов
# --------------------------------------------------------------------------------------
def our_text(s):
    from .phrases import slide_query
    t = s.get('title') or ''
    q = slide_query(s)
    body = q[len(t):] if q.startswith(t) else q
    if SLIDE_N_RX.match(t):                                # «Слайд 3» — не заголовок: тема — в первой фразе
        t = ''
    return (t + '. ' + body.strip()).strip(' .')[:600]


def _title(text):
    return text.split('. ', 1)[0][:120]


def role_of(s):
    return 'conclusions' if _is_concl(s) else 'content'


def _word_conf(qs, ds):
    """Уверенность по словам: доля «веса» слов заголовка одного слайда, найденная в тексте другого (в обе стороны),
    и общая доля слов текста; вес слова — его редкость среди всех слайдов."""
    from .phrases import stems
    docs = [set(stems(t)) for t in qs + ds]
    n = len(docs) or 1
    df = {}
    for d in docs:
        for w in d:
            df[w] = df.get(w, 0) + 1
    # слова общей темы (есть на половине слайдов: «муфта», «скважина») не различают слайды — их вес ноль
    idf = {w: max(0.0, math.log((n - f + 0.5) / (f + 0.5))) for w, f in df.items()}
    q_all, d_all = docs[:len(qs)], docs[len(qs):]
    q_t = [set(stems(_title(t))) for t in qs]
    d_t = [set(stems(_title(t))) for t in ds]

    def cover(a, b):
        tot = sum(idf.get(w, 0) for w in a)
        return sum(idf.get(w, 0) for w in a & b) / tot if tot else 0.0

    def dice(a, b):
        tot = sum(idf.get(w, 0) for w in a) + sum(idf.get(w, 0) for w in b)
        return 2 * sum(idf.get(w, 0) for w in a & b) / tot if tot else 0.0
    out = []
    for i in range(len(qs)):
        row = []
        for j in range(len(ds)):
            sc = 0.4 * max(cover(q_t[i], d_all[j]), cover(d_t[j], q_all[i])) + 0.6 * dice(q_all[i], d_all[j])
            row.append(max(0.0, min(1.0, (sc - 0.2) / 0.5)))
        out.append(row)
    return out


def _sem_conf(cfg, qs, ds, notify=None):
    """Уверенность по смыслу (модель поиска): косинус, отнесённый к типичному сходству слайда с образцами."""
    from .phrases import dot, embed_texts
    vec = embed_texts(cfg, qs + ds, (lambda e: notify(dict(e, what='slides'))) if notify else None)
    out = []
    for q in qs:
        sc = [dot(vec[q], vec[d]) for d in ds]
        med = statistics.median(sc) if sc else 0.0
        out.append([max(0.0, min(1.0, (c - med) / 0.25)) if c >= SEM_FLOOR else 0.0 for c in sc])
    return out


def _unambiguous(m):
    """Слайд, одинаково похожий на несколько слайдов образца, похож «вообще на тему», а не на один из них —
    его уверенность снижается."""
    out = []
    for row in m:
        top = sorted(row, reverse=True)
        gap = top[0] - top[1] if len(top) > 1 else 1.0
        k = 1.0 if gap >= 0.12 else 0.5 + 0.5 * gap / 0.12
        out.append([c * k for c in row])
    return out


def match(cfg, qs, ds, notify=None, allow=None):
    """Матрица уверенности [слайд плана][слайд образцов] и способ: (матрица, по смыслу?, причина «по словам»).
    allow(i, j) → False — пара не сравнивается (выводы — только с выводами)."""
    from .llm_client import Cancelled, LLMError
    if not qs or not ds:
        return [[0.0] * len(ds) for _ in qs], False, ''
    m, sem, why = None, False, ''
    if cfg and cfg.get('embed_model'):
        try:
            m, sem = _sem_conf(cfg, qs, ds, notify), True
        except Cancelled:
            raise
        except LLMError as e:
            why = str(e)
    else:
        why = 'модель поиска не настроена'
    if m is None:
        m = _word_conf(qs, ds)
    if allow:
        m = [[c if allow(i, j) else 0.0 for j, c in enumerate(row)] for i, row in enumerate(m)]
    return _unambiguous(m), sem, why


# --------------------------------------------------------------------------------------
# Вид слайда
# --------------------------------------------------------------------------------------
def chart_ok(ch, t):
    """Подходит ли тип диаграммы t к данным ch (иначе тип не меняется)."""
    from .spec import CHART_TYPES
    if t not in CHART_TYPES:
        return False
    series = ch.get('series') or []
    cats = ch.get('categories') or []
    vals = [v for s in series for v in (s.get('values') or []) if v is not None]
    if not series or not cats or not vals:
        return False
    try:
        from .layouts.charts_ext import TYPES, prepare
    except ImportError:
        TYPES = {}
    if t in TYPES:
        got = prepare(t, cats, series)
        return got[0] == t and not got[3]
    if t in PIE_LIKE:
        return len(series) == 1 and 2 <= len(cats) <= 10 and all(v >= 0 for v in vals)
    if t in STACK_LIKE:
        return len(series) >= 2
    if t in ('line', 'area'):
        return len(cats) >= 3
    if t == 'radar':
        return 3 <= len(cats) <= 12
    return True


def _carry(new, old):
    for k in KEEP_KEYS:
        if k in old and k not in new:
            new[k] = old[k]
    return new


def adopt(s, rec):
    """Слайд плана в виде слайда образца rec. → (слайд, как: 'same' | 'layout' | 'chart' | 'kept')."""
    from .alternatives import FORMS, NAMES, _clean
    from .convert import convert_slide
    from .spec import LAYOUTS
    from .variety import FAMILY, _ok, apply_alt
    kind, ctype = rec.get('kind') or '', rec.get('chart') or ''
    lay = s.get('layout')
    if s.get('keep_layout') or kind in META or kind not in LAYOUTS or kind == 'image' or lay in META:
        return s, 'kept'

    def with_chart(x, how):
        ch = x.get('chart') if isinstance(x.get('chart'), dict) else None
        if ch and ctype and ch.get('type') != ctype and chart_ok(ch, ctype):
            x = copy.deepcopy(x)
            x['chart']['type'] = ctype
            alts = x.get('alts') or []
            k = x.get('alt_index') or 0
            if k < len(alts) and isinstance(alts[k].get('chart'), dict):     # выбранный вариант — с типом образца
                alts[k]['chart']['type'] = ctype
            return x, ('chart' if how == 'same' else how)
        return x, how
    if kind == lay:
        return with_chart(s, 'same')
    alts = s.get('alts') or []
    pick = [i for i, a in enumerate(alts) if a.get('layout') == kind]
    if kind == 'chart' and ctype:                          # вариант с тем же типом диаграммы — первым
        pick.sort(key=lambda i: (alts[i].get('chart') or {}).get('type') != ctype)
    if pick:
        return with_chart(_carry(apply_alt(s, pick[0]), s), 'layout')
    family = bool(FAMILY.get(kind)) and FAMILY.get(kind) == FAMILY.get(lay)
    # вид, угаданный по содержимому слайда образца (а не по его устройству), — только в пределах того же семейства
    if family or (rec.get('sure', True) and kind in FORMS.get(lay, [])):
        cand = convert_slide(copy.deepcopy(_clean(s)), kind)
        if cand.get('layout') == kind and (LAYOUTS[kind].get('kind') != 'items' or _ok(cand, kind)):
            cand['alt_label'] = f'Как в образце: {NAMES.get(kind, LAYOUTS[kind]["name"])}'
            cur = alts or [dict(_clean(s), alt_label=s.get('alt_label') or NAMES.get(lay, lay))]
            new_alts = list(cur) + [cand]
            return with_chart(_carry(apply_alt(dict(s, alts=new_alts), len(new_alts) - 1), s), 'layout')
    return s, 'kept'


# --------------------------------------------------------------------------------------
# Порядок и каркас
# --------------------------------------------------------------------------------------
def runs(slides):
    """Разделы плана подряд: [{'idx': [номера слайдов], 'key': подпись раздела, 'div': есть разделитель}].
    Титул, содержание и финал в разделы не входят."""
    out = []
    for i, s in enumerate(slides):
        lay = s.get('layout')
        if lay in ('title', 'agenda', 'end'):
            continue
        if lay == 'section':
            out.append({'idx': [i], 'key': None, 'div': True, 'title': s.get('title') or ''})
            continue
        key = s.get('section') or f'#{i}'
        if out and (out[-1]['key'] == key or (out[-1]['div'] and out[-1]['key'] is None)):
            out[-1]['idx'].append(i)
            out[-1]['key'] = key
        else:
            out.append({'idx': [i], 'key': key, 'div': False, 'title': s.get('section') or s.get('title') or ''})
    return out


def _is_concl(s):
    return s.get('layout') == 'conclusions' or bool(CONCL_RX.match(s.get('title') or ''))


def merge_continued(slides):
    """Слайды «(продолжение)» — обратно в свой слайд: вид меняется у слайда целиком, на страницы его заново
    разделит normalize()."""
    out = []
    for s in slides:
        t = s.get('title') or ''
        prev = out[-1] if out else None
        if prev is not None and t.endswith(CONT) and t[:-len(CONT)] == prev.get('title') and \
                s.get('layout') == prev.get('layout') and isinstance(s.get('items'), list) and \
                isinstance(prev.get('items'), list):
            prev['items'] = prev['items'] + s['items']
            if s.get('conclusion') and not prev.get('conclusion'):
                prev['conclusion'] = s['conclusion']
            continue
        out.append(dict(s))
    return out


def reorder(slides, pos):
    """Разделы — в порядке похожих слайдов образца. pos — {номер слайда плана: место похожего слайда в образце}.
    Раздел без похожих слайдов идёт за тем, за которым шёл; выводы — в конце. → (слайды, изменился ли порядок)."""
    rs = runs(slides)
    if sum(1 for r in rs if any(i in pos for i in r['idx'])) < 2:
        return slides, False
    keyed, last = [], -1.0
    for k, r in enumerate(rs):
        got = [pos[i] for i in r['idx'] if i in pos]
        if any(_is_concl(slides[i]) for i in r['idx'] if slides[i].get('layout') != 'section'):
            p = math.inf
        elif got:
            p = float(min(got))
            last = p
        else:
            p = last + 0.001 * (k + 1)
        keyed.append((p, k, r))
    order = [r for _, _, r in sorted(keyed, key=lambda t: (t[0], t[1]))]
    if [id(r) for r in order] == [id(r) for r in rs]:
        return slides, False
    inside = {i for r in rs for i in r['idx']}
    head = [s for i, s in enumerate(slides) if i not in inside and slides[i].get('layout') != 'end']
    tail = [s for s in slides if s.get('layout') == 'end']
    body = [slides[i] for r in order for i in r['idx']]
    return head + body + tail, True


def skeleton(slides, sample, options):
    """Содержание и разделители — как в образце (только если в настройках «авто»). → (слайды, [что сделано])."""
    done = []
    has_agenda = any(r.get('role') == 'agenda' for r in sample)
    dividers = sum(1 for r in sample if r.get('role') == 'section')
    rs = runs(slides)
    if options.get('agenda', 'auto') == 'auto':
        ours = [i for i, s in enumerate(slides) if s.get('layout') == 'agenda']
        if has_agenda and not ours and len(rs) >= 3:
            items = [{'title': '', 'text': shorten(r['title'], 70)} for r in rs if r['title']][:10]
            if len(items) >= 2:
                at = 1 if slides and slides[0].get('layout') == 'title' else 0
                slides = slides[:at] + [{'layout': 'agenda', 'title': 'Содержание', 'items': items}] + slides[at:]
                done.append('agenda+')
        elif not has_agenda and ours:
            slides = [s for s in slides if s.get('layout') != 'agenda']
            done.append('agenda-')
    if options.get('sections', 'auto') == 'auto':
        ours = any(s.get('layout') == 'section' for s in slides)
        if dividers >= 2 and not ours and 3 <= len(rs) <= 8:
            out, n = [], 0
            # в образце разделитель и перед разделом из одного слайда — так же; иначе — перед разделами от двух слайдов
            per = sum(1 for r in sample if r.get('role') in CONTENT_ROLES) / dividers
            least = 1 if per <= 1.5 else 2
            big = {r['idx'][0] for r in runs(slides) if len(r['idx']) >= least and not _is_concl(slides[r['idx'][0]])}
            for i, s in enumerate(slides):
                if i in big:
                    n += 1
                    out.append({'layout': 'section', 'title': s.get('section') or s.get('title') or '', 'subtitle': '',
                                'number': f'{n:02d}'})
                out.append(s)
            if n >= 2:
                slides = out
                done.append('sections+')
        elif not dividers and ours:
            slides = [s for s in slides if s.get('layout') != 'section']
            done.append('sections-')
    n = 0
    for s in slides:                                     # номера разделителей — по новому порядку
        if s.get('layout') == 'section':
            n += 1
            s['number'] = f'{n:02d}'
    return slides, done


def _sync_agenda(slides):
    """Пункты содержания — в новом порядке разделов."""
    ag = next((s for s in slides if s.get('layout') == 'agenda'), None)
    if not ag or not isinstance(ag.get('items'), list):
        return
    titles = [r['title'] for r in runs(slides) if r['title']]

    def place(it):
        t = str(it.get('text') or it.get('title') or '').lower()[:30]
        return next((k for k, x in enumerate(titles) if x.lower()[:30] == t or (t and x.lower().startswith(t[:20]))),
                    len(titles))
    ag['items'] = sorted(ag['items'], key=place)


# --------------------------------------------------------------------------------------
# Главная функция
# --------------------------------------------------------------------------------------
def apply(spec, options=None, cfg=None, info=None, notify=None):
    """План по образцу. options['example']: 'auto' (по умолчанию — самая похожая презентация библиотеки),
    'off' или id презентации библиотеки. cfg — настройки моделей (нужна модель поиска; без неё — по словам).
    info['example'] — что сделано (для окна плана)."""
    from .library import decks
    from .spec import LAYOUTS, normalize
    options = options or {}
    info = info if info is not None else {}
    choice = str(options.get('example') or 'auto')
    if choice == 'off' or not spec or not spec.get('slides'):
        return spec
    ds = decks()
    if choice != 'auto':
        ds = [d for d in ds if d['id'] == choice] or []
        if not ds:
            info['example'] = {'none': True, 'missing': True}
            return spec
    if not ds:
        return spec
    slides = merge_continued(spec['slides'])
    ours = [i for i, s in enumerate(slides) if s.get('layout') not in META]
    if len(ours) < 2:
        return spec
    cand = [(di, j) for di, d in enumerate(ds) for j, r in enumerate(d['slides'])
            if r.get('role') in CONTENT_ROLES and r.get('text')]
    if not cand:
        return spec
    if notify:
        notify({'phase': 'example'})
    roles = [role_of(slides[i]) for i in ours]           # выводы — с выводами образца, остальное — с остальным
    croles = [ds[d2]['slides'][j].get('role') for d2, j in cand]
    conf, semantic, why = match(cfg, [our_text(slides[i]) for i in ours], [ds[d2]['slides'][j]['text'] for d2, j in cand],
                                notify, lambda r, k: roles[r] == croles[k])
    # образец — презентация, на которую план похож больше всего
    score = {}
    for di in range(len(ds)):
        cols = [k for k, (d2, _) in enumerate(cand) if d2 == di]
        best = [max((conf[r][k] for k in cols), default=0.0) for r in range(len(ours))]
        lim = MATCH if semantic else WORDS_MATCH
        score[di] = (sum(b for b in best if b >= lim), sum(1 for b in best if b >= lim))
    m_slide, m_order = (MATCH, ORDER_MATCH) if semantic else (WORDS_MATCH, WORDS_ORDER)
    di = max(score, key=lambda d: score[d])
    need = 1 if choice != 'auto' else max(2, math.ceil(0.25 * len(ours)))
    base = {'decks': len(ds), 'semantic': semantic, 'reason': why}
    if score[di][1] < need:
        info['example'] = dict(base, none=True)
        return spec
    deck = ds[di]
    # вид слайдов: похожий слайд образца (или заметно более похожий — из другой презентации)
    pos, changed, charts, matched, same, others = {}, 0, 0, 0, 0, set()
    new = list(slides)
    for r, i in enumerate(ours):
        best = None
        for k, (d2, j) in enumerate(cand):
            c = conf[r][k] + (0.1 if d2 == di else 0.0)
            if conf[r][k] >= (m_slide if d2 == di else OTHER_DECK) and (best is None or c > best[0]):
                best = (c, d2, j, conf[r][k])
        if best is None:
            continue
        _, d2, j, c = best
        rec = ds[d2]['slides'][j]
        if d2 != di:
            others.add(ds[d2]['name'])
        elif c >= m_order:
            pos[i] = j
        s2, how = adopt(slides[i], rec)
        s2 = dict(s2)
        s2['example'] = {'deck': ds[d2]['name'], 'n': rec.get('n'), 'title': rec.get('title') or '',
                         'kind': rec.get('kind') or '', 'kind_name': (LAYOUTS.get(rec.get('kind')) or {}).get('name', ''),
                         'chart': rec.get('chart') or '', 'how': how, 'conf': round(c, 2)}
        new[i] = s2
        matched += 1
        changed += how == 'layout'
        charts += how == 'chart'
        same += how == 'same'
    reordered = False
    if not (info.get('script') or options.get('_script')):
        new, reordered = reorder(new, pos)
    new, frame = skeleton(new, deck['slides'], options)
    if reordered:
        _sync_agenda(new)
    spec2, _ = normalize(dict(spec, slides=new))
    spec['slides'] = spec2['slides']
    info['example'] = dict(base, deck=deck['name'], id=deck['id'], matched=matched, changed=changed, charts=charts, same=same,
                           kept=matched - changed - charts - same,
                           reordered=reordered, frame=frame, others=sorted(others)[:3],
                           slides=sum(1 for r in deck['slides'] if r.get('role') in CONTENT_ROLES))
    return spec
