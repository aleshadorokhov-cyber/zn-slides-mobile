# -*- coding: utf-8 -*-
"""
templates.py — СВОИ ШАБЛОНЫ ПРЕЗЕНТАЦИЙ: загрузка, разбор оформления, список, выбор
==================================================================================

Кроме встроенного корпоративного шаблона Зарубежнефти (assets/template/base_deck.pptx —
он не меняется и остаётся шаблоном по умолчанию) пользователь может загрузить свои
шаблоны PowerPoint (.pptx или .potx) и переключаться между ними.

Шаблон хранится в output/templates/<id>/ :
    template.pptx  — сам шаблон (.potx сохраняется как .pptx — содержимое то же);
    meta.json      — что удалось понять из шаблона (см. analyze) и настройки пользователя;
    metrics.json   — ширины символов шрифтов шаблона (для подгонки текста, fontmetrics.py);
    preview_N.jpg  — картинки-образцы (строит app.py через LibreOffice/PowerPoint).

Разбор шаблона (analyze):
  * размер слайда;
  * макеты для четырёх ролей: титульный, контентный (слайды с содержанием), разделитель
    раздела, финальный — по типу макета, по заполнителям и по названию; с 1.9 пользователь
    отмечает роли прямо на слайдах загруженного файла (file_slides, update(role_slides)):
    берётся макет отмеченного слайда, а у титула, раздела и финала — ещё и его собственное
    оформление: фон, картинки и фигуры без текста (decor_of, apply_decor);
  * рабочая область контентного слайда: под заголовком шаблона, в стороне от логотипа,
    подвала и полос оформления (фигуры мастера и макета);
  * тема: 12 цветов и два шрифта (заголовки, основной текст); основной и акцентный цвет
    для перекраски макетов (их тоже можно задать вручную);
  * тёмный ли фон у контентного макета (тогда под содержимым рисуется светлая подложка).

Сборка по шаблону — nts/theme.py, слайды-«рамки» — layouts/meta.py и layouts/base.py.
"""
import copy
import io
import json
import re
import shutil
import threading
import time
import zipfile
from pathlib import Path

from lxml import etree
from pptx import Presentation
from pptx.enum.shapes import PP_PLACEHOLDER as PH
from pptx.opc.constants import RELATIONSHIP_TYPE as RT
from pptx.oxml.ns import qn

from .nts import config as C
from .nts.theme import Theme, hls

TPL_DIR = C.OUTPUT_DIR / 'templates'
BUILTIN = 'zn'
BUILTIN_NAME = 'АО «Зарубежнефть» (корпоративный)'
ID_RX = re.compile(r'[0-9a-f]{12}')
MAX_BYTES = 50 * 1024 * 1024
MAX_TEMPLATES = 40
ROLES = ('title', 'content', 'section', 'end')
ROLE_NAMES = {'title': 'Титульный слайд', 'content': 'Слайды с содержанием', 'section': 'Разделитель раздела',
              'end': 'Финальный слайд'}
EMU = 914400
_LOCK = threading.RLock()
_THEMES = {}                                  # id → (rev, Theme)

CT_MAIN = 'application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml'
CT_OTHER = {'application/vnd.openxmlformats-officedocument.presentationml.template.main+xml': 'шаблон .potx',
            'application/vnd.openxmlformats-officedocument.presentationml.slideshow.main+xml': 'демонстрация .ppsx'}
TITLES = (PH.TITLE, PH.CENTER_TITLE, PH.VERTICAL_TITLE)
FOOTERS = (PH.DATE, PH.FOOTER, PH.SLIDE_NUMBER, PH.HEADER)


class TemplateError(ValueError):
    """Шаблон не подходит — текст ошибки показывается пользователю."""


# --------------------------------------------------------------------------------------
# Пакет .pptx / .potx
# --------------------------------------------------------------------------------------
def normalize_package(data):
    """Байты .pptx/.potx/.ppsx → байты .pptx (у шаблона и демонстрации отличается только тип
    главной части). Файлы с макросами и старый .ppt — понятный отказ."""
    if len(data) > MAX_BYTES:
        raise TemplateError(f'Файл больше {MAX_BYTES // 1024 // 1024} МБ.')
    if data[:8] == b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1':
        raise TemplateError('Это файл старого формата .ppt/.pot. Откройте его в PowerPoint и сохраните как .pptx или .potx.')
    try:
        zin = zipfile.ZipFile(io.BytesIO(data))
        ct = zin.read('[Content_Types].xml').decode('utf-8')
    except (zipfile.BadZipFile, KeyError, UnicodeDecodeError):
        raise TemplateError('Файл не похож на презентацию PowerPoint (.pptx или .potx).')
    if 'macroEnabled' in ct:
        raise TemplateError('В файле есть макросы (.pptm/.potm). Сохраните шаблон в PowerPoint как .pptx или .potx.')
    if CT_MAIN in ct:
        return data
    for other in CT_OTHER:
        if other in ct:
            out = io.BytesIO()
            with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zout:
                for info in zin.infolist():
                    b = zin.read(info.filename)
                    if info.filename == '[Content_Types].xml':
                        b = ct.replace(other, CT_MAIN).encode('utf-8')
                    zout.writestr(info, b, compress_type=zipfile.ZIP_DEFLATED)
            return out.getvalue()
    raise TemplateError('Файл не похож на презентацию PowerPoint (.pptx или .potx).')


# --------------------------------------------------------------------------------------
# Цвета темы
# --------------------------------------------------------------------------------------
SCHEME = ('dk1', 'lt1', 'dk2', 'lt2', 'accent1', 'accent2', 'accent3', 'accent4', 'accent5', 'accent6', 'hlink',
          'folHlink')
DEFAULT_COLORS = {'dk1': '000000', 'lt1': 'FFFFFF', 'dk2': '44546A', 'lt2': 'E7E6E6', 'accent1': '4472C4',
                  'accent2': 'ED7D31', 'accent3': 'A5A5A5', 'accent4': 'FFC000', 'accent5': '5B9BD5',
                  'accent6': '70AD47', 'hlink': '0563C1', 'folHlink': '954F72'}


def _theme_el(master):
    try:
        return etree.fromstring(master.part.part_related_by(RT.THEME).blob)
    except (KeyError, etree.XMLSyntaxError, ValueError):
        return None


def theme_colors(master):
    """12 цветов темы мастера → {'dk1': 'RRGGBB', …}."""
    out = dict(DEFAULT_COLORS)
    th = _theme_el(master)
    cs = th.find('.//' + qn('a:clrScheme')) if th is not None else None
    if cs is None:
        return out
    for name in SCHEME:
        el = cs.find(qn('a:' + name))
        if el is None:
            continue
        srgb, sys_ = el.find(qn('a:srgbClr')), el.find(qn('a:sysClr'))
        v = srgb.get('val') if srgb is not None else (sys_.get('lastClr') if sys_ is not None else None)
        if v and re.fullmatch(r'[0-9A-Fa-f]{6}', v):
            out[name] = v.upper()
    return out


def theme_fonts(master):
    """Шрифты темы: {'major': шрифт заголовков, 'minor': основной текст}."""
    th = _theme_el(master)
    out = {'major': 'Calibri Light', 'minor': 'Calibri'}
    if th is None:
        return out
    for key in ('major', 'minor'):
        lat = th.find('.//' + qn(f'a:{key}Font') + '/' + qn('a:latin'))
        if lat is not None and (lat.get('typeface') or '').strip():
            out[key] = lat.get('typeface').strip()
    return out


def _clrmap(master, layout):
    m = master._element.find(qn('p:clrMap'))
    cmap = dict(m.attrib) if m is not None else {}
    ov = layout._element.find(qn('p:clrMapOvr') + '/' + qn('a:overrideClrMapping'))
    if ov is not None:
        cmap.update(ov.attrib)
    return cmap


def _resolve(el, colors, cmap, ph=None):
    """Цвет из элемента заливки (solidFill/gradFill/bgRef …) → 'RRGGBB' или None."""
    if el is None:
        return None
    for c in el.iter():
        tag = etree.QName(c).localname
        v = None
        if tag == 'srgbClr':
            v = c.get('val')
        elif tag == 'sysClr':
            v = c.get('lastClr')
        elif tag == 'schemeClr':
            name = c.get('val')
            if name == 'phClr':
                v = ph
            else:
                v = colors.get(cmap.get(name, name)) or colors.get(name)
        elif tag == 'prstClr':
            v = {'white': 'FFFFFF', 'black': '000000'}.get(c.get('val'))
        if v:
            return _mods(v.upper(), c)
    return None


def _mods(v, el):
    """lumMod/lumOff/tint/shade у цвета темы — приблизительно (по светлоте)."""
    import colorsys
    r, g, b = (int(v[i:i + 2], 16) / 255 for i in (0, 2, 4))
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    for m in el:
        tag, val = etree.QName(m).localname, m.get('val')
        try:
            k = int(val) / 100000
        except (TypeError, ValueError):
            continue
        if tag == 'lumMod':
            l *= k
        elif tag == 'lumOff':
            l += k
        elif tag == 'tint':
            l = l + (1 - l) * (1 - k)
        elif tag == 'shade':
            l *= k
    r, g, b = colorsys.hls_to_rgb(h, min(1, max(0, l)), s)
    return '%02X%02X%02X' % (round(r * 255), round(g * 255), round(b * 255))


def luminance(v):
    r, g, b = (int(v[i:i + 2], 16) / 255 for i in (0, 2, 4))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _image_color(part, rid):
    """Средний цвет картинки (фон-картинка мастера или макета)."""
    try:
        from PIL import Image
        blob = part.related_part(rid).blob
        with Image.open(io.BytesIO(blob)) as im:
            px = im.convert('RGB').resize((1, 1), Image.BILINEAR).getpixel((0, 0))
        return '%02X%02X%02X' % px
    except Exception:                                        # noqa: BLE001
        return None


def background(master, layout, colors, sw, sh):
    """Цвет фона контентного макета (с учётом картинки во весь слайд) → 'RRGGBB'."""
    cmap = _clrmap(master, layout)
    show_master = layout._element.get('showMasterSp') != '0'
    for obj in (layout, master) if show_master else (layout,):
        for shp in obj.shapes:                               # картинка во весь слайд закрывает фон
            if shp.is_placeholder or shp.shape_type != 13 or shp.width is None:
                continue
            if shp.width * shp.height >= 0.8 * sw * sh:
                blip = shp._element.find('.//' + qn('a:blip'))
                rid = blip.get(qn('r:embed')) if blip is not None else None
                got = rid and _image_color(obj.part, rid)
                if got:
                    return got
    for obj in (layout, master):
        bg = obj._element.find(qn('p:cSld') + '/' + qn('p:bg'))
        if bg is None:
            continue
        pr = bg.find(qn('p:bgPr'))
        if pr is not None:
            blip = pr.find('.//' + qn('a:blip'))
            if blip is not None and blip.get(qn('r:embed')):
                got = _image_color(obj.part, blip.get(qn('r:embed')))
                if got:
                    return got
            got = _resolve(pr, colors, cmap)
            if got:
                return got
        ref = bg.find(qn('p:bgRef'))
        if ref is not None:
            got = _resolve(ref, colors, cmap)
            if got:
                return got
    return colors.get(cmap.get('bg1', 'lt1'), 'FFFFFF')


def decoration_colors(master, layouts, colors, sw, sh):
    """Цвета фигур оформления мастера и макетов (полосы, плашки, логотип) → [(цвет, площадь)],
    самые заметные первыми. Многие шаблоны красят оформление прямо, не через цвета темы."""
    acc = {}

    def walk(shapes, cmap):
        for shp in shapes:
            if shp.is_placeholder:
                continue
            if shp.shape_type == 6:                          # группа
                walk(shp.shapes, cmap)
                continue
            sppr = shp._element.find(qn('p:spPr'))
            if sppr is None or shp.width is None:
                continue
            fill = next((f for f in (sppr.find(qn('a:solidFill')), sppr.find(qn('a:gradFill')), sppr.find(qn('a:pattFill')))
                         if f is not None), None)
            col = _resolve(fill, colors, cmap)
            if not col:
                continue
            h, l, s = hls(col)
            if s < 0.18 or l < 0.08 or l > 0.92:
                continue
            acc[col] = acc.get(col, 0) + min(shp.width * shp.height, 0.3 * sw * sh)

    seen_master = False
    for lay in layouts:
        cmap = _clrmap(master, lay)
        walk(lay.shapes, cmap)
        if lay._element.get('showMasterSp') != '0' and not seen_master:
            walk(master.shapes, cmap)
            seen_master = True
    return [(c, a / (sw * sh)) for c, a in sorted(acc.items(), key=lambda t: -t[1])]


def pick_colors(colors, deco=()):
    """Основной и акцентный цвет для перекраски макетов (вместо синего и зелёного Зарубежнефти):
    самый заметный цвет оформления шаблона, иначе цвета темы."""
    def ok(v, lo=0.12, hi=0.78):
        h, l, s = hls(v)
        return s >= 0.2 and lo < l < hi
    order = [colors.get(k) for k in ('accent1', 'dk2', 'accent2', 'accent3', 'accent4', 'accent5', 'accent6')]
    primary = next((c for c, share in deco if share >= 0.01 and ok(c, 0.15, 0.75)), None)
    primary = primary or next((v for v in order if v and ok(v)), colors.get('accent1') or '0078AE')
    ph = hls(primary)[0] * 360
    accent = None
    cands = [c for c, share in deco if share >= 0.004] + [colors.get(k) for k in ('accent2', 'accent3', 'accent4', 'accent5',
                                                                                  'accent6', 'accent1')]
    for v in cands:
        if not v or v == primary or not ok(v, 0.15, 0.82):
            continue
        dh = abs((hls(v)[0] * 360 - ph + 180) % 360 - 180)
        if dh >= 25:
            accent = v
            break
    return primary, accent or colors.get('accent2') or primary


def auto_palette(primary, accent, colors):
    """До трёх основных и трёх акцентных цветов (1.9): основной и акцентный цвет шаблона, затем другие заметные цвета
    его темы — по очереди в основные и акцентные. Белые, чёрные, серые и почти одинаковые цвета пропускаются."""
    def ok(v):
        h, l, s_ = hls(v)
        return s_ >= 0.2 and 0.12 < l < 0.82

    def far(v, got):
        h, l, s_ = hls(v)
        for g in got:
            gh, gl, gs = hls(g)
            if abs((h - gh + 0.5) % 1.0 - 0.5) * 360 < 14 and abs(l - gl) < 0.12:
                return False
        return True
    ps, acs = [primary.upper()], [accent.upper()] if accent and accent.upper() != primary.upper() else []
    rest = [colors.get(k) for k in ('accent1', 'accent2', 'accent3', 'accent4', 'accent5', 'accent6', 'dk2')]
    turn = 0 if acs else 1
    for v in rest:
        if not v or not HEX_RX.fullmatch(v) or not ok(v) or not far(v.upper(), ps + acs):
            continue
        lst = acs if turn else ps
        if len(lst) >= 3:
            lst = ps if turn else acs
            if len(lst) >= 3:
                break
        lst.append(v.upper())
        turn = 1 - turn
    return ps, acs or [primary.upper()]


def palette_of(info):
    """Основные и акцентные цвета шаблона: выбранные пользователем или подобранные (auto_palette)."""
    ap, aa = auto_palette(info.get('auto_primary') or '0078AE', info.get('auto_accent') or '4BAF46', info.get('colors') or {})
    ps = info.get('user_primaries') or ([info['user_primary']] + ap[1:] if info.get('user_primary') else ap)
    acs = info.get('user_accents') or ([info['user_accent']] + aa[1:] if info.get('user_accent') else aa)
    return ps[:3], acs[:3], ap, aa


# --------------------------------------------------------------------------------------
# Макеты
# --------------------------------------------------------------------------------------
def _rect(shp):
    try:
        if shp.left is None or shp.width is None:
            return None
        return [round(shp.left / EMU, 3), round(shp.top / EMU, 3), round(shp.width / EMU, 3), round(shp.height / EMU, 3)]
    except (AttributeError, TypeError, ValueError):
        return None


def _sz_of(el):
    """Кегль первого уровня из lstStyle/txStyles (lvl1pPr/defRPr@sz) → пт или None."""
    if el is None:
        return None
    d = el.find(qn('a:lvl1pPr') + '/' + qn('a:defRPr'))
    if d is not None and d.get('sz'):
        try:
            return int(d.get('sz')) / 100
        except ValueError:
            return None
    return None


def ph_size(ph, master, title):
    """Кегль заполнителя по умолчанию: свой стиль макета → заполнитель мастера → стиль мастера."""
    got = _sz_of(ph._element.find('.//' + qn('a:lstStyle')))
    if got:
        return got
    want = PH.TITLE if title else PH.BODY
    for mph in master.placeholders:
        try:
            t = mph.placeholder_format.type
        except Exception:                                    # noqa: BLE001
            continue
        if (t in TITLES) == title and (title or t == want):
            got = _sz_of(mph._element.find('.//' + qn('a:lstStyle')))
            if got:
                return got
            break
    st = master._element.find(qn('p:txStyles') + '/' + qn('p:titleStyle' if title else 'p:bodyStyle'))
    return _sz_of(st) or (40.0 if title else 20.0)


def layout_info(layout):
    phs = []
    for ph in layout.placeholders:
        try:
            t = ph.placeholder_format.type
            idx = ph.placeholder_format.idx
        except Exception:                                    # noqa: BLE001
            continue
        phs.append({'type': t, 'idx': idx, 'rect': _rect(ph)})
    return {'name': layout.name or '', 'type': layout._element.get('type') or '', 'phs': phs}


_RX = {
    'title': re.compile(r'титул|обложк|title slide|cover', re.I),
    'section': re.compile(r'раздел|глава|section|divider|chapter|header', re.I),
    'content': re.compile(r'только заголовок|title only|заголовок и объект|title and content|контент|content', re.I),
    'end': re.compile(r'спасибо|благодар|thank|финал|заверш|конец|end|closing|контакт|contact|q ?& ?a|вопрос', re.I),
}


def _count(info, types):
    return sum(1 for p in info['phs'] if p['type'] in types)


def _title_pos(info, sh):
    """Где заголовок макета: 'top' — вверху (как у слайдов с содержанием), 'mid' — посередине, None — нет."""
    r = next((p['rect'] for p in info['phs'] if p['type'] in TITLES and p['rect']), None)
    if not r:
        return None
    return 'top' if r[1] < sh * 0.15 and r[3] < sh * 0.3 else 'mid' if r[1] + r[3] / 2 > sh * 0.3 else 'top'


def _score(role, info, dark, sh=7.5):
    has_title = _count(info, TITLES) > 0
    has_ctr = _count(info, (PH.CENTER_TITLE,)) > 0
    has_sub = _count(info, (PH.SUBTITLE,)) > 0
    pics = _count(info, (PH.PICTURE, PH.BITMAP, PH.MEDIA_CLIP, PH.CHART, PH.TABLE, PH.ORG_CHART))
    bodies = _count(info, (PH.BODY, PH.OBJECT))
    typ, name = info['type'], info['name']
    sc = 0
    if role == 'title':
        sc = 100 * (typ == 'title') + 50 * has_ctr + 40 * bool(_RX['title'].search(name)) + 20 * has_sub - 15 * pics
    elif role == 'section':
        sc = 100 * (typ == 'secHead') + 50 * bool(_RX['section'].search(name)) - 15 * pics
    elif role == 'content':
        pos = _title_pos(info, sh)
        sc = (100 * (typ == 'titleOnly') + 60 * (typ in ('obj', 'tx')) + 30 * bool(_RX['content'].search(name))
              + 25 * has_title - 25 * pics - 12 * max(0, bodies - 1) - 60 * (typ in ('title', 'secHead'))
              - 30 * has_ctr - 40 * bool(dark) + 25 * (pos == 'top') - 45 * (pos == 'mid'))
        if not has_title:
            sc -= 80
    elif role == 'end':
        sc = 80 * bool(_RX['end'].search(name)) - 15 * pics
    return sc


def all_layouts(prs):
    """[(mi, li, layout)] — макеты всех мастеров шаблона."""
    return [(mi, li, lay) for mi, m in enumerate(prs.slide_masters) for li, lay in enumerate(m.slide_layouts)]


def auto_roles(prs, darks):
    """Макеты для ролей по умолчанию: {'title': [mi, li], …}."""
    lays = [(mi, li, layout_info(lay)) for mi, li, lay in all_layouts(prs)]
    sh = prs.slide_height / EMU
    roles = {}
    for role in ('title', 'content', 'section'):
        best = max(lays, key=lambda t: (_score(role, t[2], darks.get((t[0], t[1])), sh), -t[0], -t[1]))
        roles[role] = [best[0], best[1]]
    if _score('section', next(t[2] for t in lays if [t[0], t[1]] == roles['section']), False) < 40:
        roles['section'] = roles['title']                    # своего разделителя нет — на титульном макете
    end = max(lays, key=lambda t: (_score('end', t[2], False), -t[0], -t[1]))
    roles['end'] = [end[0], end[1]] if _score('end', end[2], False) >= 60 else roles['title']
    return roles


def _overlap(a0, a1, b0, b1):
    return max(0.0, min(a1, b1) - max(a0, b0))


def _obstacles(layout, master, sw, sh):
    """Логотипы, полосы, картинки макета и образца слайдов (не заполнители, не фон на весь слайд)."""
    out = []
    show_master = layout._element.get('showMasterSp') != '0'
    for obj in (layout, master) if show_master else (layout,):
        for shp in obj.shapes:
            if shp.is_placeholder:
                continue
            r = _rect(shp)
            if r and r[2] * r[3] < 0.45 * sw * sh and r[2] > 0 and r[3] >= 0:
                out.append(r)
    return out


def _narrow(r, obstacles):
    """Поле текста [l, t, w, h] без логотипа справа: ширина — до него. → (поле, сужено ли)."""
    l, t, w, h = r[:4]
    safe = w
    for x, y, ow, oh in obstacles:
        if _overlap(y, y + oh, t, t + h) > min(0.25 * h, 0.2) and l + w * 0.4 < x < l + w:
            safe = min(safe, x - l - 0.15)
    safe = max(safe, w * 0.4)
    return ([l, t, round(safe, 3), h], True) if safe < w - 0.05 else (list(r[:4]), False)


def content_frame(layout, master, sw, sh):
    """Рабочая область контентного макета (дюймы): поля, верх (без подзаголовка и с ним), низ,
    место заголовка и подзаголовка."""
    title, sub, sub_idx, num = None, None, None, None
    for ph in layout.placeholders:
        try:
            t = ph.placeholder_format.type
        except Exception:                                    # noqa: BLE001
            continue
        r = _rect(ph)
        if r and t in TITLES and title is None:
            title = r
        elif t == PH.SLIDE_NUMBER and r:
            num = r
    if title is None:
        title = [round(sw * 0.045, 3), round(sh * 0.05, 3), round(sw * 0.91, 3), round(sh * 0.12, 3)]
    tl, tt, tw, th = title
    for ph in layout.placeholders:                           # подзаголовок шаблона — узкое поле сразу под заголовком
        try:
            t, idx = ph.placeholder_format.type, ph.placeholder_format.idx
        except Exception:                                    # noqa: BLE001
            continue
        r = _rect(ph)
        if r and t in (PH.SUBTITLE, PH.BODY) and -0.15 <= r[1] - (tt + th) <= 0.5 and r[3] <= 0.8 and r[2] >= tw * 0.5:
            sub, sub_idx = r, idx
            break
    low = tt + th / 2 > sh * 0.55                            # заголовок внизу слайда (редко)
    L = tl if tl < sw * 0.3 else sw * 0.05
    L = max(0.2, L)
    R = sw - L
    if low:
        top = top_sub = sh * 0.07
        bottom = tt - 0.12
    else:
        sb = (sub[1] + sub[3]) if sub else (tt + th + 0.47)
        top = tt + th + 0.12
        top_sub = sb + 0.1
        bottom = sh - max(0.3, sh * 0.05)
    obstacles = _obstacles(layout, master, sw, sh)
    if num:
        obstacles.append(num)
    safe_w = tw                                              # логотип справа от заголовка — заголовок до него
    for x, y, w, h in obstacles:
        if _overlap(y, y + h, tt, tt + th) > 0.25 * th and tl + tw * 0.5 < x < tl + tw:
            safe_w = min(safe_w, x - tl - 0.15)
    safe_w = max(safe_w, tw * 0.5)
    band = max(0.5, bottom - top)
    for x, y, w, h in obstacles:
        if y + h <= top + 0.05 or y >= sh:
            continue
        if not low and y >= top + 0.45 * band and _overlap(x, x + w, L, R) > 0.02:
            bottom = min(bottom, y - 0.1)                    # подвал, логотип, полоса снизу
        elif _overlap(y, y + h, top, bottom) > 0.5 * band:
            if x >= sw * 0.55:
                R = min(R, x - 0.12)                         # полоса или картинка справа
            elif x + w <= sw * 0.45:
                L = max(L, x + w + 0.12)                     # полоса слева
    # не меньше половины слайда в ширину и 45 % в высоту
    if R - L < sw * 0.55:
        L, R = max(0.2, min(L, sw * 0.2)), min(sw - 0.2, max(R, L + sw * 0.55))
    if bottom - top < sh * 0.45:
        bottom = min(sh - 0.1, top + sh * 0.45)
    top_sub = min(top_sub, bottom - sh * 0.4)
    r3 = lambda v: round(v, 3)                               # noqa: E731
    return {'L': r3(L), 'R': r3(R), 'top': r3(top), 'top_sub': r3(max(top, top_sub)), 'bottom': r3(bottom),
            'title': title, 'title_safe': [tl, tt, r3(safe_w), th] if safe_w < tw - 0.05 else None,
            'sub': sub or [r3(tl), r3(tt + th + 0.02), r3(tw), 0.42], 'sub_idx': sub_idx}


def slots(layout, master, sw=13.333, sh=7.5):
    """Заполнители заголовка и текста макета: [l, t, w, h, кегль, idx, сужено] (для титула, раздела,
    финала). Поле, на которое заходит логотип справа, сужается до него (сужено = True)."""
    out = {'title': None, 'body': None}
    best = 0
    for ph in layout.placeholders:
        try:
            t, idx = ph.placeholder_format.type, ph.placeholder_format.idx
        except Exception:                                    # noqa: BLE001
            continue
        r = _rect(ph)
        if not r:
            continue
        if t in TITLES and out['title'] is None:
            out['title'] = r + [ph_size(ph, master, True), idx]
        elif t in (PH.SUBTITLE, PH.BODY, PH.OBJECT):
            area = r[2] * r[3] + (1000 if t == PH.SUBTITLE else 0)
            if area > best:
                best = area
                out['body'] = r + [ph_size(ph, master, False), idx]
    obstacles = _obstacles(layout, master, sw, sh)
    for k, v in out.items():
        if v:
            box, narrowed = _narrow(v, obstacles)
            out[k] = box + [v[4], v[5], narrowed]
    return out


def analyze(prs, roles=None):
    """Разбор оформления шаблона. roles — макеты, выбранные пользователем ({'title': [mi, li], …})."""
    sw, sh = prs.slide_width / EMU, prs.slide_height / EMU
    lays = all_layouts(prs)
    if not lays:
        raise TemplateError('В шаблоне нет ни одного макета слайдов.')
    masters = prs.slide_masters
    darks, bgs = {}, {}
    for mi, li, lay in lays:
        colors_m = theme_colors(masters[mi])
        bg = background(masters[mi], lay, colors_m, prs.slide_width, prs.slide_height)
        bgs[(mi, li)] = bg
        darks[(mi, li)] = luminance(bg) < 0.45
    auto = auto_roles(prs, darks)
    chosen = dict(auto)
    valid = {(mi, li) for mi, li, _ in lays}
    for role, v in (roles or {}).items():
        if role in ROLES and isinstance(v, (list, tuple)) and len(v) == 2 and tuple(v) in valid:
            chosen[role] = [int(v[0]), int(v[1])]
    cmi, cli = chosen['content']
    master = masters[cmi]
    layout = master.slide_layouts[cli]
    colors = theme_colors(master)
    fonts = theme_fonts(master)
    deco_layouts = [masters[v[0]].slide_layouts[v[1]] for v in (chosen['content'], chosen['title']) if v[0] == cmi]
    deco = decoration_colors(master, deco_layouts, colors, prs.slide_width, prs.slide_height)
    primary, accent = pick_colors(colors, deco)
    frame = content_frame(layout, master, sw, sh)
    dark = darks[(cmi, cli)]
    title_slot = slots(layout, master, sw, sh)['title']
    warnings = []
    if not any(p['type'] in TITLES for p in layout_info(layout)['phs']):
        warnings.append('У макета слайдов с содержанием нет поля заголовка — заголовок будет обычной надписью.')
    if dark:
        warnings.append('Фон слайдов с содержанием тёмный — под содержимым будет светлая подложка. '
                        'Можно выбрать другой макет в настройках шаблона.')
    if chosen['section'] == chosen['title'] and auto['section'] == auto['title']:
        warnings.append('Своего макета разделителя в шаблоне нет — разделы будут на титульном макете.')
    ratio = sw / sh
    if abs(ratio - 16 / 9) > 0.03:
        warnings.append(f'Формат слайда {_aspect(sw, sh)}, а не 16:9 — макеты подстроены под ширину шаблона.')
    return {
        'size': [round(sw, 3), round(sh, 3)], 'aspect': _aspect(sw, sh),
        'layouts': [{'key': f'{mi}:{li}', 'name': lay.name or f'Макет {li + 1}', 'type': lay._element.get('type') or '',
                     'dark': darks[(mi, li)]} for mi, li, lay in lays],
        'masters': len(masters), 'roles': chosen, 'auto_roles': auto, 'frame': frame,
        'slots': {role: slots(masters[v[0]].slide_layouts[v[1]], masters[v[0]], sw, sh) for role, v in chosen.items()},
        'title_size': (title_slot or [0] * 5)[4] or 32.0, 'colors': colors, 'fonts': fonts,
        'auto_primary': primary, 'auto_accent': accent, 'dark_content': dark, 'background': bgs[(cmi, cli)],
        'ink': (colors.get('lt1', 'FFFFFF') if dark else
                colors.get('dk2') if luminance(colors.get('dk2', '000000')) < 0.35 else colors.get('dk1', '000000')),
        'warnings': warnings,
    }


def _aspect(w, h):
    r = w / h
    for name, v in (('16:9', 16 / 9), ('16:10', 1.6), ('4:3', 4 / 3), ('A4', 297 / 210)):
        if abs(r - v) < 0.03:
            return name
    return f'{w * 2.54:.1f} × {h * 2.54:.1f} см'


def embedded_fonts(prs):
    """[(имя, жирный, байты)] — шрифты, встроенные в шаблон."""
    out = []
    lst = prs.part._element.find(qn('p:embeddedFontLst'))
    if lst is None:
        return out
    for ef in lst.findall(qn('p:embeddedFont')):
        f = ef.find(qn('p:font'))
        name = f.get('typeface') if f is not None else ''
        for tag, bold in (('p:regular', False), ('p:bold', True)):
            el = ef.find(qn(tag))
            rid = el.get(qn('r:id')) if el is not None else None
            if rid:
                try:
                    out.append((name, bold, prs.part.related_part(rid).blob))
                except KeyError:
                    pass
    return out


# --------------------------------------------------------------------------------------
# Хранилище
# --------------------------------------------------------------------------------------
def _dir(tid):
    if not isinstance(tid, str) or not ID_RX.fullmatch(tid):
        return None
    d = TPL_DIR / tid
    return d if (d / 'meta.json').exists() and (d / 'template.pptx').exists() else None


def _read(d):
    try:
        info = json.loads((d / 'meta.json').read_text(encoding='utf-8'))
        info['rev'] = str((d / 'meta.json').stat().st_mtime_ns)
        return info
    except (OSError, ValueError):
        return None


def _write(d, info):
    info = {k: v for k, v in info.items() if k != 'rev'}
    tmp = d / f'meta.{threading.get_ident()}.tmp'
    tmp.write_text(json.dumps(info, ensure_ascii=False, indent=1), encoding='utf-8')
    tmp.replace(d / 'meta.json')


def builtin_info():
    return {'id': BUILTIN, 'name': BUILTIN_NAME, 'builtin': True, 'size': [13.333, 7.5], 'aspect': '16:9',
            'fonts': {'major': 'TT Bluescreens Pro', 'minor': 'TT Bluescreens Pro'},
            'primary': '00326E', 'accent': '4BAF46', 'colors': {}, 'warnings': [], 'layouts': [], 'rev': 'builtin'}


def public(info):
    """Сведения о шаблоне для страницы (без служебных полей сборки)."""
    if info.get('builtin'):
        return dict(info)
    keep = ('id', 'name', 'added', 'file', 'size', 'aspect', 'fonts', 'fonts_approx', 'colors', 'primary', 'accent',
            'auto_primary', 'auto_accent', 'warnings', 'layouts', 'dark_content', 'rev', 'masters', 'background')
    out = {k: info.get(k) for k in keep}
    out['roles'] = {r: f'{v[0]}:{v[1]}' for r, v in (info.get('roles') or {}).items()}
    out['auto_roles'] = {r: f'{v[0]}:{v[1]}' for r, v in (info.get('auto_roles') or {}).items()}
    out['role_slides'] = {r: n for r, n in (info.get('role_slides') or {}).items() if r in ROLES and isinstance(n, int)}
    out['primaries'], out['accents'], out['auto_primaries'], out['auto_accents'] = palette_of(info)
    out['builtin'] = False
    return out


def list_templates():
    """Все шаблоны: встроенный первым, затем свои — в порядке загрузки."""
    out = [builtin_info()]
    if TPL_DIR.is_dir():
        own = []
        for d in TPL_DIR.iterdir():
            if d.is_dir() and _dir(d.name):
                info = _read(d)
                if info:
                    own.append(public(info))
        out += sorted(own, key=lambda i: i.get('added') or 0)
    return out


def get(tid):
    if tid in (None, '', BUILTIN):
        return builtin_info()
    d = _dir(tid)
    info = _read(d) if d else None
    return public(info) if info else None


def add_template(data, filename='шаблон.pptx', name=None):
    """Загрузка шаблона → сведения о нём. Тот же файл второй раз не дублируется."""
    import hashlib
    from . import fontmetrics
    data = normalize_package(data)
    try:
        prs = Presentation(io.BytesIO(data))
    except Exception as e:                                   # noqa: BLE001
        raise TemplateError(f'PowerPoint-файл не читается: {type(e).__name__}.')
    info = analyze(prs)
    tid = hashlib.sha1(data).hexdigest()[:12]
    with _LOCK:
        d = TPL_DIR / tid
        if _dir(tid):
            got = _read(d)
            if got:
                return public(got)
        own = [x for x in TPL_DIR.iterdir() if x.is_dir() and _dir(x.name)] if TPL_DIR.is_dir() else []
        if len(own) >= MAX_TEMPLATES:
            raise TemplateError(f'Загружено уже {MAX_TEMPLATES} шаблонов — удалите ненужные.')
        d.mkdir(parents=True, exist_ok=True)
        (d / 'template.pptx').write_bytes(data)
    metrics, approx, how = fontmetrics.metrics_for(info['fonts']['major'], info['fonts']['minor'], embedded_fonts(prs))
    (d / 'metrics.json').write_text(json.dumps(metrics, ensure_ascii=False), encoding='utf-8')
    stem = Path(filename or '').stem.strip() or 'Шаблон'
    info.update(id=tid, name=(name or stem)[:80], file=Path(filename or '').name[:120], added=time.time(),
                primary=info['auto_primary'], accent=info['auto_accent'], fonts_approx=approx, fonts_how=how,
                user_primary='', user_accent='')
    info['primaries'], info['accents'], _, _ = palette_of(info)
    if approx:
        info['warnings'].append('Шрифт ' + ', '.join(f'«{f}»' for f in approx) +
                                ' не найден на этом компьютере — размер текста подобран приблизительно.')
    nocyr = fontmetrics.no_cyrillic(how, info['fonts'])
    if nocyr:
        info['warnings'].append('В шрифте ' + ', '.join(f'«{f}»' for f in nocyr) +
                                ' нет русских букв — PowerPoint покажет русский текст другим шрифтом.')
    with _LOCK:
        _write(d, info)
    return public(_read(d))


HEX_RX = re.compile(r'#?([0-9A-Fa-f]{6})')


def update(tid, changes):
    """Переименовать шаблон, выбрать макеты для ролей (списком или слайдами файла), задать основные и акцентные цвета."""
    d = _dir(tid)
    if not d:
        raise TemplateError('Шаблон не найден.')
    with _LOCK:
        info = _read(d)
        if 'name' in changes:
            nm = re.sub(r'\s+', ' ', str(changes.get('name') or '')).strip()[:80]
            if nm:
                info['name'] = nm
        picked = changes.get('role_slides')
        if isinstance(picked, dict):                         # 1.9: роли отмечены на слайдах файла
            prs0 = Presentation(str(d / 'template.pptx'))
            slides, _gen = file_slides_of(prs0)
            rs = dict(info.get('role_slides') or {})
            rk = dict(changes.get('roles') or {}) if isinstance(changes.get('roles'), dict) else {}
            for role, n in picked.items():
                if role not in ROLES:
                    continue
                if isinstance(n, int) and not isinstance(n, bool) and 0 <= n < len(slides):
                    rs[role] = n
                    rk[role] = slides[n]['layout']
                elif n is None:
                    rs.pop(role, None)
            info['role_slides'] = rs
            changes = dict(changes, roles=rk)
        elif isinstance(changes.get('roles'), dict):        # макет выбран списком — отметка слайда снимается
            info['role_slides'] = {r: n for r, n in (info.get('role_slides') or {}).items() if r not in changes['roles']}
        if isinstance(changes.get('roles'), dict):
            roles = dict(info['roles'])
            for role, key in changes['roles'].items():
                if role in ROLES and isinstance(key, str) and re.fullmatch(r'\d+:\d+', key):
                    roles[role] = [int(x) for x in key.split(':')]
            prs = Presentation(str(d / 'template.pptx'))
            fresh = analyze(prs, roles)
            for k in ('roles', 'frame', 'slots', 'title_size', 'colors', 'fonts', 'auto_primary', 'auto_accent',
                      'dark_content', 'background', 'ink', 'layouts'):
                info[k] = fresh[k]
            keep = [w for w in info.get('warnings', []) if w.startswith('Шрифт ')]
            info['warnings'] = fresh['warnings'] + keep
        for key in ('primary', 'accent'):
            if key in changes:
                m = HEX_RX.fullmatch(str(changes.get(key) or '').strip())
                info['user_' + key] = m.group(1).upper() if m else ''
                info['user_' + key + 's'] = []
        for key in ('primaries', 'accents'):                 # 1.9: до трёх цветов; пустой список — как в шаблоне
            if isinstance(changes.get(key), list):
                got = [HEX_RX.fullmatch(str(v or '').strip()) for v in changes[key][:12]]
                info['user_' + key] = [m.group(1).upper() for m in got if m][:3]
                info['user_' + key[:-1]] = ''
        ps, acs, _, _ = palette_of(info)
        info['primaries'], info['accents'] = ps, acs
        info['primary'], info['accent'] = ps[0], acs[0]
        _write(d, info)
        return public(_read(d))


def delete(tid):
    d = _dir(tid)
    if not d:
        return False
    with _LOCK:
        shutil.rmtree(d, ignore_errors=True)
        _THEMES.pop(tid, None)
    return True


def revision(tid):
    """Метка версии настроек шаблона (для кэша миниатюр)."""
    if tid in (None, '', BUILTIN):
        return BUILTIN
    d = _dir(tid)
    try:
        return f"{tid}:{(d / 'meta.json').stat().st_mtime_ns}" if d else BUILTIN
    except OSError:
        return BUILTIN


def theme_for(tid):
    """Тема сборки для шаблона tid (None — встроенный шаблон или такого шаблона нет)."""
    if tid in (None, '', BUILTIN):
        return None
    d = _dir(tid)
    if not d:
        return None
    info = _read(d)
    if not info:
        return None
    with _LOCK:
        got = _THEMES.get(tid)
        if got and got[0] == info['rev']:
            return got[1]
        from . import textfit
        from .nts.compact import compact_template
        try:
            metrics = json.loads((d / 'metrics.json').read_text(encoding='utf-8'))
        except (OSError, ValueError):
            metrics = None
        info = dict(info)
        info['primaries'], info['accents'], _, _ = palette_of(info)   # шаблоны до 1.9 — тоже несколькими цветами
        th = Theme(info, compact_template(d / 'template.pptx'), metrics)
        if metrics:
            textfit.register_metrics(th.metrics_key, metrics)
        _THEMES[tid] = (info['rev'], th)
        return th


# --------------------------------------------------------------------------------------
# Роли на слайдах файла (1.9): пользователь листает слайды шаблона и отмечает титульный, обычный, раздел, финал
# --------------------------------------------------------------------------------------
def _slide_title(sl):
    for shp in sl.shapes:
        if shp.is_placeholder and shp.has_text_frame and shp.placeholder_format.type in TITLES:
            t = re.sub(r'\s+', ' ', shp.text_frame.text).strip()
            if t:
                return t[:80]
    for shp in sl.shapes:
        if shp.has_text_frame:
            t = re.sub(r'\s+', ' ', shp.text_frame.text).strip()
            if t:
                return t[:80]
    return ''


def file_slides_of(prs):
    """Слайды файла шаблона → ([{'n', 'layout': 'mi:li', 'layout_name', 'title', 'hidden'}], generated).
    У шаблона без слайдов (только макеты, обычно .potx) — по одному «слайду» на макет (generated=True)."""
    keys = {}
    for mi, li, lay in all_layouts(prs):
        keys[lay.part.partname] = (mi, li)
    out = []
    for n, sl in enumerate(prs.slides):
        lay = sl.slide_layout
        mi, li = keys.get(lay.part.partname, (0, 0))
        out.append({'n': n, 'layout': f'{mi}:{li}', 'layout_name': lay.name or f'Макет {li + 1}', 'title': _slide_title(sl),
                    'hidden': sl._element.get('show') == '0'})
    if out:
        return out, False
    return [{'n': i, 'layout': f'{mi}:{li}', 'layout_name': lay.name or f'Макет {li + 1}', 'title': '', 'hidden': False}
            for i, (mi, li, lay) in enumerate(all_layouts(prs))], True


def file_slides(tid):
    """Слайды шаблона для окна «Настроить»: {'slides', 'generated', 'roles' (макеты ролей), 'role_slides' (отмечено
    пользователем или предложено: первый слайд на макете роли)}."""
    d = _dir(tid)
    if not d:
        raise TemplateError('Шаблон не найден.')
    info = _read(d)
    prs = Presentation(str(d / 'template.pptx'))
    slides, gen = file_slides_of(prs)
    roles = {r: f'{v[0]}:{v[1]}' for r, v in (info.get('roles') or {}).items()}
    picked = {r: n for r, n in (info.get('role_slides') or {}).items() if isinstance(n, int) and n < len(slides)}
    suggest = dict(picked)
    if not gen and slides:                                   # слайды шаблона обычно по порядку: титул, …, финал
        vis = [x for x in slides if not x['hidden']] or slides
        guess = {'title': vis[0]['n']}
        if len(vis) >= 3:
            guess['end'] = vis[-1]['n']
        rest = [x for x in vis if x['n'] not in guess.values()]
        sec = next((x for x in rest if x['layout'] == roles.get('section')), None) or \
            next((x for x in rest if re.search(r'section|раздел', x['layout_name'], re.I)), None)
        if sec:
            guess['section'] = sec['n']
            rest = [x for x in rest if x is not sec]
        con = next((x for x in rest if x['layout'] == roles.get('content')), None) or \
            next((x for x in rest if re.search(r'content|объект|текст|содерж', x['layout_name'], re.I)), None) or (rest[0] if rest else None)
        if con:
            guess['content'] = con['n']
        for r, n in guess.items():
            suggest.setdefault(r, n)
    for r in ROLES:
        if r not in suggest:
            hit = next((x['n'] for x in slides if x['layout'] == roles.get(r) and not x['hidden']), None)
            if hit is None:
                hit = next((x['n'] for x in slides if x['layout'] == roles.get(r)), None)
            if hit is not None:
                suggest[r] = hit
    return {'slides': slides, 'generated': gen, 'roles': roles, 'role_slides': picked, 'suggest': suggest,
            'size': info.get('size'), 'rev': info.get('rev')}


def layouts_deck(prs):
    """Шаблон без слайдов: по слайду на каждый макет (в заголовке — название макета) — для картинок в окне выбора."""
    sld = prs.slides._sldIdLst
    for sid in list(sld):
        prs.part.drop_rel(sid.rId)
        sld.remove(sid)
    for mi, li, lay in all_layouts(prs):
        sl = prs.slides.add_slide(lay)
        for ph in sl.placeholders:
            try:
                kind = ph.placeholder_format.type
            except Exception:                                # noqa: BLE001
                continue
            if kind in TITLES and ph.has_text_frame:
                ph.text_frame.text = lay.name or f'Макет {li + 1}'
    return prs


_DECOR_TAGS = ('sp', 'pic', 'grpSp', 'cxnSp')
R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'


def _has_text(el):
    return any((t.text or '').strip() for t in el.iter(qn('a:t')))


def _bbox(el):
    """(x, y, w, h) фигуры в дюймах (или None)."""
    xfrm = el.find('.//' + qn('a:xfrm'))
    if xfrm is None:
        xfrm = el.find('.//' + qn('p:xfrm'))
    off = xfrm.find(qn('a:off')) if xfrm is not None else None
    ext = xfrm.find(qn('a:ext')) if xfrm is not None else None
    if off is None or ext is None:
        return None
    return (int(off.get('x', 0)) / EMU, int(off.get('y', 0)) / EMU, int(ext.get('cx', 0)) / EMU, int(ext.get('cy', 0)) / EMU)


def decor_of(sl, frame=None):
    """Оформление слайда шаблона, которого нет в его макете: фон слайда и фигуры без текста (картинки, полосы,
    логотипы). frame — рабочая область (L, top, R, bottom): тогда берётся только то, что целиком вне её, и без фона
    (обычные слайды: содержимое не должно лечь на картинку образца). → (фон или None, [фигуры], часть слайда)."""
    tree = sl.shapes._spTree
    shapes = []
    for el in tree:
        tag = etree.QName(el).localname
        if tag not in _DECOR_TAGS or el.find('.//' + qn('p:ph')) is not None or _has_text(el):
            continue
        if el.find('.//' + qn('p:graphicFrame')) is not None:
            continue
        if frame:
            box = _bbox(el)
            if not box:
                continue
            x, y, w, h = box
            L, T, R, B = frame
            if not (x + w <= L + 0.02 or x >= R - 0.02 or y + h <= T + 0.02 or y >= B - 0.02):
                continue
        shapes.append(copy.deepcopy(el))
    bg = None
    if not frame:
        got = sl._element.find(qn('p:cSld') + '/' + qn('p:bg'))
        bg = copy.deepcopy(got) if got is not None else None
    return (bg, shapes, sl.part) if (bg is not None or shapes) else None


def _relink(el, src, dst):
    """Ссылки на картинки (r:embed, r:link, r:id) — из части слайда-образца в часть нового слайда."""
    memo = {}
    for node in el.iter():
        for att, rid in list(node.attrib.items()):
            if not att.startswith('{%s}' % R_NS):
                continue
            if rid not in memo:
                try:
                    rel = src.rels[rid]
                except KeyError:
                    memo[rid] = None
                    continue
                if rel.is_external:
                    memo[rid] = dst.relate_to(rel.target_ref, rel.reltype, is_external=True)
                else:
                    memo[rid] = dst.relate_to(rel.target_part, rel.reltype)
            if memo[rid]:
                node.set(att, memo[rid])
            else:
                del node.attrib[att]


def apply_decor(sl, decor):
    """Оформление слайда-образца → на новый слайд той же роли: фон — вместо фона макета, фигуры — под всем
    остальным (первыми в дереве фигур). Имена начинаются с «zn-tpl»: перенос в поля шаблона их не двигает."""
    if not decor:
        return
    bg, shapes, src = decor
    if bg is not None:
        el = copy.deepcopy(bg)
        _relink(el, src, sl.part)
        csld = sl._element.find(qn('p:cSld'))
        old = csld.find(qn('p:bg'))
        if old is not None:
            csld.remove(old)
        csld.insert(0, el)
    tree = sl.shapes._spTree
    pos = 2                                                  # после nvGrpSpPr и grpSpPr — под всем остальным
    for el0 in shapes:
        el = copy.deepcopy(el0)
        _relink(el, src, sl.part)
        tree.insert(pos, el)
        pos += 1
        for k, c in enumerate(el.iter(qn('p:cNvPr'))):
            c.set('id', str(sl.shapes._next_shape_id))
            if k == 0:
                c.set('name', ('zn-tpl-decor ' + (c.get('name') or '')).strip())


def capture_decor(prs, info):
    """Перед сборкой (пока слайды шаблона не удалены): оформление отмеченных слайдов-образцов по ролям."""
    rs = info.get('role_slides') or {}
    if not rs or not len(prs.slides):
        return {}
    f = info.get('frame') or {}
    content_frame_ = (f.get('L', 0), f.get('top', 0), f.get('R', 0), f.get('bottom', 0)) if f else None
    out = {}
    slides = list(prs.slides)
    for role, n in rs.items():
        if role in ROLES and isinstance(n, int) and 0 <= n < len(slides):
            try:
                got = decor_of(slides[n], content_frame_ if role == 'content' else None)
            except Exception:                                # noqa: BLE001 — образец не разобрался: только макет
                got = None
            if got:
                out[role] = got
    return out


def preview_files(tid):
    d = TPL_DIR / (tid if tid != BUILTIN else '_builtin')
    return d, sorted(d.glob('preview_*.jpg')) if d.is_dir() else []
