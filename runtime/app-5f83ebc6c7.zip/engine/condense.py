# -*- coding: utf-8 -*-
"""
condense.py — ИЗ ТЕКСТА ДОКЛАДА В ТЕЗИСЫ, ЧИСЛА И СХЕМЫ
======================================================

Документы часто написаны как РЕЧЬ докладчика («Вначале обратимся к проблеме…», «Из
представленных диаграмм видно, что…», «Рассмотрим технологию…»). На слайде такие фразы
выглядят нелепо. Этот модуль превращает связный текст в материал для слайдов:

  despeech(sentence)     — убирает «разговорные» обороты и ссылки на слайд/рисунок;
                           пустая строка — предложение было чисто служебным;
  theses(text)           — тезисы: предложения без «воды», сокращённые до 1 строки-2;
  facts(text)            — числовые факты: «236 отказов погружного оборудования» →
                           {value: '236', unit: 'отказов', title: 'Погружного оборудования…'};
  steps(text)            — последовательность действий («Перед…», «Далее…», «После…») → шаги;
  pros_cons(paras)       — «Достоинства: …», «Недостатки: …» → (объект, плюсы, минусы);
  params(paras)          — строки «Параметр = значение» → показатели;
  topic_title(text)      — тема фрагмента для заголовка, когда в документе стоит только
                           «Слайд 3» (по ключевым словам: актуальность, цель и задачи…);
  is_slide_marker(title) — заголовок вида «Слайд 3» / «Слайд 3. Название».
"""
import re

from .textutil import cap, clean, parse_number, sentences, shorten

# --------------------------------------------------------------------------------------
# Речевые обороты
# --------------------------------------------------------------------------------------
# Предложения, которые целиком служебные: ссылки на слайд, рисунок, приглашение «рассмотрим»
_META_SENT = re.compile(
    r'(?i)^(обратимся к рис|см\.\s*рис|на (этом |данном |следующем )?слайде|как (видно|показано) на (рис|слайд)|'
    r'продукция и е[её] (технические )?хар|благодар\w* за внимание|спасибо за внимание|готов ответить|'
    r'перейд[её]м к|далее рассмотрим$|рассмотрим подробнее$)')
_META_TAIL = re.compile(r'(?i)\s*(показан\w* на (слайде|рисунке|рис\.?\s*\d*)|приведен\w* на (слайде|рис\.?\s*\d*))\.?$')
# Начальные обороты, которые убираются (остаток предложения — тезис)
_LEAD_IN = [
    r'вначале|сначала|для начала|прежде всего|итак|таким образом|следовательно|в итоге|в результате|кроме того|'
    r'также|причем|причём|при этом|важный момент\s*[-–—:]?|стоит отметить,?\s*что|следует отметить,?\s*что|необходимо отметить,?\s*что|'
    r'важно отметить,?\s*что|отметим,?\s*что|как правило|в данной работе|в настоящей работе|в рамках (данной )?работы',
    r'из (представленн\w+|приведенн\w+) (диаграмм\w*|данных|графиков|таблиц\w*|рисунк\w*) видно,?\s*что',
    r'как видно (из|на) [\wё ]+?,\s*', r'(на|из) рис\.?\s*\d+[\wё ,]*?(показан\w*|изображен\w*|видно)[,:]?\s*(что)?',
    r'здесь изображен\w*', r'обратимся к [\wё .]+?\.\s*',
    r'я предлагаю', r'мы предлагаем', r'предлагаю', r'мной (были )?', r'нами (были )?',
]
_LEAD_RX = re.compile(r'(?i)^(?:' + '|'.join(f'(?:{p})' for p in _LEAD_IN) + r')[\s,:]*')
_INVITE = re.compile(r'(?i)^(рассмотрим|выполним|обратимся к|разберем|разберём|покажем|приведем|приведём|'
                     r'остановимся на|перейдем к|перейдём к)\s+')
_SPEECH_WORDS = re.compile(r'(?i)(?<!мы )\b(будем рассматривать|рассматриваем)\b')


def despeech(s):
    """Предложение речи → тезис для слайда ('' — если предложение служебное)."""
    s = clean(s)
    if not s or s.endswith('?'):
        return ''                                        # риторический вопрос — не тезис
    if _META_SENT.match(s):
        return ''
    s = _META_TAIL.sub('.', s)
    for _ in range(3):                                   # несколько оборотов подряд
        s2 = _LEAD_RX.sub('', s)
        if s2 == s:
            break
        s = s2
    if _INVITE.match(s):
        return ''                                        # «Рассмотрим технологию…» — вступление, не тезис
    s = _SPEECH_WORDS.sub('рассматриваются', s)
    # «…характеристики, которыми мы будем руководствоваться при подборе это: …» → «…характеристики: …»
    s = re.sub(r'(?i),\s*котор\w+\s+(?:мы|я)\s+[^,:]*?(?:,?\s+это)?\s*:', ':', s)
    s = re.sub(r'(?i),?\s+это\s*:', ':', s)
    s = re.sub(r',\s*:', ':', s)
    s = re.sub(r'\s*\((?:рис\.?|см\.)[^)]*\)', '', s)     # «(рис. 2)»
    s = re.sub(r'\s{2,}', ' ', s).strip(' ,;:-–—')
    if len(s) < 12:
        return ''
    return cap(s if s.endswith(('.', '!', '…', ')', '»')) else s + '.')


def sents(text):
    """Предложения с учётом «…л.с. (50 кВт) Из представленных…»: скобка, за которой идёт
    заглавная буква, тоже завершает предложение."""
    text = re.sub(r'\)\s+(?=[А-ЯЁA-Z][а-яёa-z])', '). ', clean(text))     # «(3 п. п.) NPV …» — не конец фразы
    text = re.sub(r'(л\.\s?с\.|м-ю|м/р)\s+(?=[А-ЯЁ][а-яё])', r'\1 ¶ ', text)
    out = []
    for part in text.split(' ¶ '):
        out.extend(sentences(part))
    return out


def theses(text, max_n=6, max_chars=170):
    """Связный текст → список тезисов (без служебных фраз, каждый не длиннее max_chars)."""
    out = []
    for s in sents(text):
        t = despeech(s)
        if t:
            out.append(shorten(t, max_chars))
        if len(out) >= max_n:
            break
    return out


# --------------------------------------------------------------------------------------
# Числовые факты
# --------------------------------------------------------------------------------------
_U = (r'%|процентн\w*\s+пункт\w*|п\.\s?п\.|процент\w*|раз(?:а)?\b|млн\.?\s?руб\w*|тыс\.?\s?руб\w*|млрд\.?\s?руб\w*|'
      r'руб\w*|₽|долл\w*\.?(?:\s?/\s?барр?\w*\.?)?|\$|м3/сут|м³/сут|т/сут|м/сут|т/т\b|мПа[·*.]?\s?с\b|мД\b|'
      r'тыс\.?\s?м[3³]|млн\.?\s?м[3³]|млрд\.?\s?м[3³]|м[3³]|'
      r'л\.\s?с\.|кВт[·*]?ч|кВт|МВт|Н\s?\*\s?м|Н·м|об/мин|мм|см|км|м\b|Гц|°\s?[CС]|атм|МПа|бар\b|ч\b|час\w*|сут\w*|'
      r'мин\b|недел\w*|месяц\w*|лет|года?\b|'
      r'шт\.?|скважин\w*|отказ\w*|секци\w*|ремонт\w*|случа\w*|объект\w*|насос\w*|установ\w*|муфт\w*|проект\w*|'
      r'чел\w*|тонн\w*|т\b|тыс\.?\s?т\b|млн\.?\s?т\b|баррел\w*')
_NUM_TXT = r'(?<![\w.,/])(\d+(?:[  ]\d{3})*(?:[.,]\d+)?)'
_FACT_RX = re.compile(
    _NUM_TXT + r'(?:-?(?:х|ми|ти|го|й|ой|ти|ми))?\s?'
    r'(?:(млн|тыс|млрд)\.?\s?(\d+(?:[.,]\d+)?)?\s?(тыс\.?)?\s?)?'
    r'(' + _U + r')?', re.I)
_ORD_AFTER = re.compile(r'^\s*-?(?:й|я|е|го|му|ой|м)\b')


def _norm_unit(u):
    u = clean(u or '')
    lu = u.lower()
    if re.match(r'процентн\w*\s+пункт|п\.\s?п', lu):
        return 'п.\u00a0п.'
    if re.match(r'процент', lu):
        return '%'
    if re.match(r'мпа[·*.]?\s?с', lu):
        return 'мПа·с'
    if re.match(r'долл', lu):
        return 'долл./барр.' if '/' in lu else 'долл.'
    if re.match(r'(тыс|млн|млрд)\.?\s?м[3³]', lu):
        b = re.match(r'(тыс|млн|млрд)', lu).group(1)
        return (b + '.' if b == 'тыс' else b) + ' м³'
    if lu in ('м3', 'м³'):
        return 'м³'
    if re.match(r'м3/сут', lu):
        return 'м³/сут'
    if re.match(r'(млн)\.?\s?т$', lu):
        return 'млн т'
    if re.match(r'°', lu):
        return '°C'
    if re.match(r'недел', lu):
        return 'нед.'
    if re.match(r'месяц', lu):
        return 'мес.'
    if re.match(r'раз', lu):
        return 'раз'
    if re.match(r'руб', lu):
        return 'руб.'
    if re.match(r'млн\.?\s?руб', lu):
        return 'млн руб.'
    if re.match(r'тыс\.?\s?руб', lu):
        return 'тыс. руб.'
    if re.match(r'млрд\.?\s?руб', lu):
        return 'млрд руб.'
    return u.replace(' * ', '·').replace('*', '·')


_STOP_BEFORE = re.compile(r'(?i)(рис\.?|рисунок|№|п\.|пункт|слайд|таблиц\w*|табл\.|вариант\w*|схем\w*|скважин\w*|куст\w*)\s*$')
_ID_AFTER = re.compile(r'(?i)^\s*(куст|скв\.?|бис|№)')
_NUMERAL_SUFFIX = re.compile(r'^-(ми|ти|х|и|ю|ть)\b')
_COUNT_UNIT = re.compile(r'(?i)^(отказ|скважин|случа|объект|ремонт|проект|шт|насос|установ|секци|муфт|чел|раз)')
_FILLER_VERB = re.compile(r'(?i)\b(было|был|была|были|составил\w*|составля\w*|равн\w*|достиг\w*|около|порядка|всего|'
                          r'что|то есть|т\.\s?е\.|из них|причем|причём|рассчитан\w*|выбрана?|выбран\w*|'
                          r'настраивать как минимум на|как минимум|не менее|более|свыше)\b')
_CLAUSE_SPLIT = re.compile(r'[,;:(]|\s(?:и|а|но|что|которые|который|которая|так как|если|при этом)\s')


def _nominative(phrase):
    """«внешним диаметром» → «внешний диаметр», «скоростью вращения» → «скорость вращения»
    (только творительный падеж после «с/со» и в начале фразы — самые частые случаи)."""
    ws = phrase.split()
    out, changed = [], True
    for i, w in enumerate(ws):
        lw = w.lower()
        if changed and len(lw) > 4:
            if re.search(r'ости$', lw):
                out.append(w[:-1] + 'ь')
                changed = False
                continue
            if re.search(r'ой$', lw) and i + 1 < len(ws) and re.search(r'(?i)(ью|ой)$', ws[i + 1]):
                out.append(w[:-2] + 'ая')                 # «номинальной производительностью» → «номинальная …»
                continue
            if re.search(r'(ым|им)$', lw):
                out.append(w[:-2] + ('ий' if lw[-3] in 'кгхжшчщ' or lw.endswith('им') else 'ый'))
                continue
            if re.search(r'ью$', lw):
                out.append(w[:-2] + 'ь')
                changed = False
                continue
            if re.search(r'[^аеиоуыэюя]ом$', lw):
                out.append(w[:-2])
                changed = False
                continue
            if re.search(r'ем$', lw) and len(lw) > 5:
                out.append(w[:-2] + 'ь')
                changed = False
                continue
        changed = False
        out.append(w)
    return ' '.join(out)


def _clause_before(before):
    parts = [p for p in _CLAUSE_SPLIT.split(before) if p is not None]
    for c in reversed(parts or [before]):
        c = _FILLER_VERB.sub(' ', c)
        c = re.sub(r'(?i)\bв среднем\b', ' ', c)
        c = re.sub(r'(?i)\b(до|от|в|на|за|с|со|по|около)\s*$', '', c.strip())
        c = re.sub(r'(?i)^\s*(с|со|при|для|на|в|по)\s+', '', c.strip())
        ws = [w for w in c.split() if w]
        while ws and re.search(r'(?i)(ся|ть|ет|ют|ит|ат|ят|ется|ются)$', ws[-1]) and len(ws) > 1:
            ws.pop()                                  # «…рекомендуется» в конце подписи не нужен
        if ws:
            return ' '.join(ws[-5:])
    return ''


def _last_np(label):
    """Последняя именная группа после предлога «с/со/при»: «скважины с дебитом» → «дебитом»."""
    m = list(re.finditer(r'(?i)\b(с|со|при)\s+', label))
    if m:
        tail = label[m[-1].end():]
        ws = tail.split()
        while len(ws) > 1 and re.search(r'(?i)(ами|ями|ыми|ими)$', ws[0]):
            ws = ws[1:]                              # «погружными двигателями мощностью» → «мощностью»
        if ws:
            return ' '.join(ws[:3])
    return label


_GOV = re.compile(r'(?i)(?:^|\s)(?:с|со|характеризу\w+|облада\w+|отлича\w+|оснащ\w+)\s')
_INSTR = re.compile(r'(?i)(ой|ей|ью|ом|ем|ым|им)$')
_FILL_END = re.compile(r'(?i)\s*\b(около|порядка|примерно|почти|до|не менее|не более|более|свыше|в среднем)\s*$')


def _nom_instr(ws):
    """Творительный падеж → именительный: «средней эффективной толщиной» → «средняя эффективная толщина»,
    «вязкостью нефти» → «вязкость нефти», «внешним диаметром» → «внешний диаметр»."""
    out = []
    for i, w in enumerate(ws):
        lw = w.lower()
        nxt = ws[i + 1] if i + 1 < len(ws) else ''
        adj = bool(_INSTR.search(nxt))           # дальше ещё слово в творительном — это прилагательное
        if lw.endswith('ью'):
            return out + [w[:-2] + 'ь'] + ws[i + 1:]
        if re.search(r'(ым|им)$', lw) and adj:
            out.append(w[:-2] + ('ий' if lw[-3] in 'кгхжшчщ' or lw.endswith('им') else 'ый'))
            continue
        if re.search(r'[ое]й$', lw) and adj:
            out.append(w[:-2] + ('ая' if lw.endswith('ой') else 'яя'))
            continue
        if lw.endswith('ой'):
            return out + [w[:-2] + 'а'] + ws[i + 1:]
        if lw.endswith('ией'):
            return out + [w[:-2] + 'я'] + ws[i + 1:]
        if lw.endswith('ием'):
            return out + [w[:-2] + 'е'] + ws[i + 1:]
        if re.search(r'[^аеиоуыэюя]ом$', lw):
            return out + [w[:-2]] + ws[i + 1:]
        return []                                # не творительный падеж — подписи не будет
    return out


def _instr_label(before):
    """Подпись из творительного падежа перед числом: «скважины с дебитом 5 т/сут» → «Дебит»,
    «характеризуется толщиной 7,4 м, пористостью 21 %» → «Пористость», «мощностью 50 кВт» → «Мощность»."""
    b = _FILL_END.sub('', before.rstrip())
    gm = list(_GOV.finditer(b))
    if gm:
        seg = re.split(r'[,;(]\s*|\s(?:и|а также)\s', b[gm[-1].end():])[-1]
    else:                                        # без «с»: только «…остью/…ностью» прямо перед числом
        w = b.split()[-1:] if b.split() else []
        if not w or not re.search(r'(?i)\w{3,}(ость|ност|ть)ю$', w[0]):
            return ''
        seg = w[0]
    seg = _FILL_END.sub('', seg.strip())
    ws = seg.split()
    while len(ws) > 1 and re.search(r'(?i)(ами|ями|ыми|ими)$', ws[0]):
        ws = ws[1:]                              # «погружными двигателями мощностью» → «мощностью»
    if not 1 <= len(ws) <= 5 or not _INSTR.search(ws[0]):
        return ''
    lab = ' '.join(_nom_instr(ws))
    return cap(lab) if lab else ''


_PLACE = [(re.compile(r'(?i)залега\w*\s+на\s+глубин\w*\s*$'), 'Глубина залегания'),
          (re.compile(r'(?i)на\s+глубин\w*\s*$'), 'Глубина'),
          (re.compile(r'(?i)ставк\w* дисконтирования\s*$'), 'Ставка дисконтирования'),
          (re.compile(r'(?i)цена нефти(?: марки \w+)?\s+(?:принят\w*\s+)?на уровне\s*$'), 'Цена нефти'),
          (re.compile(r'(?i)срок\w* поставки\b.{0,30}\s(?:составля\w*|состав\w+)\s*$'), 'Срок поставки')]


def _place_label(before):
    """Устойчивые обороты: «залегает на глубине 1 800 м» → «Глубина залегания»."""
    for rx, lab in _PLACE:
        if rx.search(before.rstrip() + ' '):
            return lab
    return ''


_CHANGE = re.compile(r'(?i)\b(увелич\w*|повы[сш]\w*|нарастить|сниз\w*|сократ\w*|уменьш\w*)\s+'
                     r'((?:[\wё«»-]+\s+){1,5}?)на\s*$')


_INTR = re.compile(r'(?i)(?:^|[,;]\s*|\s)([^,;:()—–]{3,70}?)\s+((?:вырос|возрос)(?:л[аио])?|вырастет|вырастут|'
                   r'(?:увеличил|повысил|сократил|снизил|уменьшил)(?:ся|ась|ось|ись)|'
                   r'(?:увеличит|повысит|сократит|снизит|уменьшит)(?:ся)|упал[аио]?)\s+'
                   r'(?:примерно\s+|почти\s+|ещё\s+|еще\s+|более чем\s+|около\s+|в среднем\s+)?на\s*$')
_ADJ_GEN = [('ая', 'ой'), ('яя', 'ей'), ('ый', 'ого'), ('ий', 'его'), ('ое', 'ого'), ('ее', 'его'),
            ('ые', 'ых'), ('ие', 'их')]


def _genitive(phrase):
    """Родительный падеж начала именной группы: «Средняя заработная плата» → «средней заработной платы»,
    «Текучесть кадров» → «текучести кадров», «КИН» → «КИН». Не уверены — ''."""
    ws = phrase.split()
    out, i = [], 0
    while i < len(ws) and len(ws[i]) > 3 and not ws[i].isupper():
        w, lw = ws[i], ws[i].lower()
        end = next((g for e, g in _ADJ_GEN if lw.endswith(e)), None)
        if end is None or i == len(ws) - 1:
            break
        out.append(w[:-2] + end)
        i += 1
    if i >= len(ws):
        return ''
    w, lw = ws[i], ws[i].lower()
    plural = bool(out) and out[-1].lower().endswith(('ых', 'их'))
    if w.isupper() or re.search(r'[a-z]', lw):
        n = w                                       # аббревиатура / латиница не склоняется
    elif plural:                                    # «удельные выбросы» → «удельных выбросов»
        if lw.endswith('ия'):
            n = w[:-1] + 'й'
        elif re.search(r'[тд]ы$', lw):
            n = w[:-1]                              # «затраты» → «затрат»
        elif lw.endswith('ы'):
            n = w[:-1] + 'ов'
        else:
            return ''
    elif re.search(r'[тд]ы$', lw) and not out:
        n = w[:-1]                                  # «Затраты на …» → «затрат на …»
    elif re.search(r'[бвзлмнпрсф]ы$', lw) and not out:
        n = w[:-1] + 'ов'                           # «Выбросы …» → «выбросов …»
    elif re.search(r'[гкхжчшщ]а$', lw):
        n = w[:-1] + 'и'
    elif lw.endswith('а'):
        n = w[:-1] + 'ы'
    elif lw.endswith('я') and not lw.endswith('ия'):
        n = w[:-1] + 'и'
    elif lw.endswith('ия'):
        n = w[:-1] + 'и'
    elif re.search(r'(ость|ность|сть)$', lw):
        n = w[:-1] + 'и'
    elif re.search(r'[бвгдзклмнпрстфх]$', lw):
        n = w + 'а'
    elif lw.endswith('й'):
        n = w[:-1] + 'я'
    elif lw.endswith('ие'):
        n = w[:-1] + 'я'
    elif lw.endswith('о'):
        n = w[:-1] + 'а'
    else:
        return ''
    res = ' '.join(out + [n] + ws[i + 1:])
    return res[:1].lower() + res[1:] if not res.split()[0].isupper() else res


def _intrans_label(before):
    """«Средняя заработная плата выросла на 13 %» → «Рост средней заработной платы» (13 % — не сама зарплата)."""
    m = _INTR.search(before.rstrip() + ' ')
    if not m:
        return ''
    from .digest import _subject
    subj = _subject(m.group(1).strip())
    if not subj:
        return ''
    ws = subj.split()
    cut = next((i for i, w in enumerate(ws) if i >= 2 and w.lower() in ('по', 'в', 'на', 'за', 'для', 'при', 'у', 'из')), None)
    if len(ws) > 4 and cut:
        subj = ' '.join(ws[:cut])                 # «Выбросы загрязняющих веществ в атмосферу по …» — без хвоста
    gen = _genitive(subj)
    grow = re.match(r'(?i)(вырос|возрос|вырастет|вырастут|увелич|повыс)', m.group(2))
    if not gen:
        return f'{cap(subj)}: {"рост" if grow else "снижение"}'
    return ('Рост ' if grow else 'Снижение ') + gen


def _cmp_label(s, before, after):
    """«Затраты … составили 3,9 млрд руб., что на 12 % больше, чем годом ранее» → «Рост затрат …»."""
    if not (re.search(r'(?i),\s*что\s+(?:почти\s+|примерно\s+|ещё\s+)?на\s*$', before)
            and re.match(r'(?i)\s*(больше|выше|меньше|ниже)', after)):
        return ''
    from .digest import fact_label
    nums = list(re.finditer(r'\d[\d  ]*(?:[.,]\d+)?', before[:before.rfind(',')]))
    subj = fact_label(s, nums[-1].start()) if nums else ''          # подлежащее при предыдущем числе
    gen = _genitive(subj) if subj else ''
    if not gen:
        return ''
    return ('Рост ' if re.match(r'(?i)\s*(больше|выше)', after) else 'Снижение ') + gen


def _change_label(before):
    """«позволит увеличить КИН на участке ОПР на 4,5 п. п.» → «Прирост КИН на участке ОПР»."""
    m = _CHANGE.search(before.rstrip() + ' ')
    if not m:
        return ''
    ws = m.group(2).split()
    w0 = ws[0]
    if w0.isupper():
        pass                                     # аббревиатура: КИН, NPV
    elif re.search(r'(?i)[^аеиоуыэюяь]у$', w0):
        ws[0] = w0[:-1] + ('и' if w0[-2].lower() in 'гкхжчшщ' else 'ы')     # «добычу» → «добычи»
    elif re.search(r'(?i)ость$', w0):
        ws[0] = w0[:-1] + 'и'                    # «эффективность» → «эффективности»
    elif re.search(r'(?i)[бвгджзклмнпрстфхцчшщ]$', w0):
        ws[0] = w0 + 'а'                         # «дебит» → «дебита»
    else:
        return ''
    word = 'Прирост' if re.match(r'(?i)(увелич|повы|нарост)', m.group(1)) else 'Снижение'
    return word + ' ' + ' '.join(ws)


def _clause_after(after):
    a = re.split(r'[,.;:(]|\s(?:что|так как|если|которые|который)\s', after)[0]
    a = _FILLER_VERB.sub(' ', a)
    ws = a.split()
    return ' '.join(ws[:7])


_CLAUSE_B = re.compile(r';\s|,\s(?=(?:а|но|и|что|причём|причем|при этом|однако|тогда как)\s)|:\s')


def _num_clause(s, pos):
    """Часть сложного предложения, в которой стоит число (границы — «;», «, а», «, но», «, что», «:»)."""
    cuts = [0] + [m.end() for m in _CLAUSE_B.finditer(s)] + [len(s)]
    for a, b in zip(cuts, cuts[1:]):
        if a <= pos < b:
            part = s[a:b].strip(' ,;:')
            part = re.sub(r'(?i)^(а|но|и|что|причём|причем|при этом|однако|тогда как)\s+', '', part)
            return cap(part) if len(part.split()) >= 4 else s
    return s


def facts(text, max_n=6):
    """Числовые факты из текста: [{'value', 'unit', 'title', 'text', '_sent', '_v'}].

    Пропускаются годы, номера (рисунков, слайдов, скважин, кустов, «1-й и 2-й»), числа в скобках,
    диапазоны «от 4 до 6», голые числа без единицы (если это не «из них 25» после счётного факта).
    Подпись — смысловая часть того же предложения: «с внешним диаметром 95 мм» → «Внешний диаметр»."""
    from .digest import clean_sentence, fact_label, good_label
    out = []
    used_ctx = set()
    prev_count_unit = ''
    for s in sents(text):
        s = clean(s)
        if s.endswith('?'):
            continue
        for m in _FACT_RX.finditer(s):
            num, big, big2, thou, unit = m.group(1), m.group(2), m.group(3), m.group(4), m.group(5)
            val = parse_number(num)
            if val is None:
                continue
            before, after_full = s[:m.start()], s[m.end():]
            tail = s[m.end(1):m.end(1) + 5]
            numeral = bool(_NUMERAL_SUFFIX.match(tail))
            if numeral:
                after_full = s[m.end(1) + _NUMERAL_SUFFIX.match(tail).end():]
            if _STOP_BEFORE.search(before) or _ID_AFTER.match(after_full):
                continue
            if not unit and not numeral and _ORD_AFTER.match(tail):
                continue
            if before.rstrip().endswith('(') or re.match(r'\s*/\s*\d', s[m.end(1):]):
                continue                                       # «(50 кВт)», дроби «1/3»
            if 1900 <= val <= 2100 and not big and (not unit or re.match(r'(?i)год|г\.', unit or '')):
                continue                                       # год
            if re.match(r'\s*([-–—]|до)\s*\d', s[m.end(1):]) or re.search(r'(?i)\bот\s*$', before):
                continue                                       # начало диапазона «от 4 до 6», «8–10»
            value = num.replace(' ', ' ')
            u = _norm_unit(unit)
            if big:                                            # «1 млн 874 тыс. рублей» → 1,874 млн руб.
                if big2 and thou:
                    v = val + (parse_number(big2) or 0) / 1000
                    value = f'{v:.3f}'.rstrip('0').rstrip('.').replace('.', ',')
                b_ = big.lower().rstrip('.')
                u = ((b_ + '.' if b_ == 'тыс' else b_) + ' ' + (u or '')).strip()
            count = bool(u) and bool(_COUNT_UNIT.match(u)) and u != 'раз'
            if not u:
                if re.search(r'(?i)из них\s*$|из которых\s*$', before) and prev_count_unit:
                    u, count = prev_count_unit, True
                elif numeral and re.search(r'(?i)(число|количество|кол-во)', before):
                    count = True
                elif val < 10 or not re.search(r'(?i)(число|количество|кол-во|всего|из них)', before):
                    continue
            rng = re.search(r'(?i)(?:\bот\s+)?(\d{1,3}(?:[  ]\d{3})+(?:[.,]\d+)?|\d+(?:[.,]\d+)?)\s*(?:[–—-]|\s+до\s+)\s*$',
                            before)
            if rng and parse_number(rng.group(1)) is not None and parse_number(rng.group(1)) < val:
                value = f'{rng.group(1)}–{value}'              # диапазон «8–10 %», «от 50 до 67 л.с.»
                before = before[:rng.start()]
            elif re.search(r'(?i)\bдо\s*$', before):
                value = 'до ' + value
            # подпись
            fl = fact_label(s, len(before)) if count else ''
            if count and fl and good_label(fl) and not re.search(r'(?i)^(?:всего|число|количество)$', fl):
                label = fl                             # «Численность персонала составила 9 870 человек»
            elif count:
                label = _clause_after(after_full)
                if u and not re.match(r'(?i)раз', u):
                    label = (u + ' ' + label).strip()
                    prev_count_unit = u
                    u = ''
                if len(label) < 6:
                    label = _clause_before(before)
            elif u == 'раз':
                label = _clause_after(after_full) or _clause_before(before)
            else:
                label = (_place_label(before) or _intrans_label(before) or _cmp_label(s, before, after_full)
                         or fact_label(s, len(before))
                         or _instr_label(before) or _change_label(before))
            label = re.sub(r'\s{2,}', ' ', label).strip(' .,;:—–-')
            label = re.sub(r'(?i)\s+(?:в|на|по|за|при|у|для|из)\s+(?:его|её|ее|их|него|неё|них)\s+[\wё-]+$', '', label)
            if not good_label(label):
                label = ''                                     # подпись не получилась — покажем предложение

            if not label and count:
                continue
            ctx = ''
            clause = _num_clause(s, m.start())
            if label and clause not in used_ctx:          # пояснение — часть фразы с этим числом (один раз)
                used_ctx.add(clause)
                ctx = clean_sentence(clause) or ''
                ctx = shorten(ctx, 100) if ctx else ''
                if (len(ctx.split()) < len(label.split()) + 4 or ctx.endswith('…')
                        or re.sub(r'\D', '', num)[:3] not in re.sub(r'\D', '', ctx)):
                    ctx = ''                                   # без самого числа пояснение не к месту
            out.append({'value': value, 'unit': u, 'title': cap(shorten(label, 60)) if label else '', 'text': '',
                        '_sent': s, '_v': val, '_count': count, '_ctx': ctx})
            if len(out) >= max_n:
                return out
    return out


def funnel_facts(fs):
    """Последовательно уменьшающиеся счётные величины одного вида (236 отказов → 25 → 8) → воронка."""
    cnt = [f for f in fs if f.get('_count')]
    if len(cnt) < 3:
        return None
    vals = [f['_v'] for f in cnt]
    if all(a > b for a, b in zip(vals, vals[1:])):
        return cnt
    return None


# --------------------------------------------------------------------------------------
# Последовательность действий
# --------------------------------------------------------------------------------------
_STEP_RX = re.compile(r'(?i)^(сначала|вначале|перед\b|далее|затем|потом|после\b|при (определ|достиж)|это вызывает|'
                      r'в результате|в итоге|на (первом|втором|третьем|следующем) этапе|первым|вторым|третьим|'
                      r'наконец|в конце)')


def steps(text, min_n=3, max_n=6):
    """Связный текст с маркерами последовательности → шаги [{'title','text'}] (или None)."""
    ss = [clean(s) for s in sents(text)]
    idx = [i for i, s in enumerate(ss) if _STEP_RX.match(s)]
    if len(idx) < min_n - 1:
        return None
    start = max(0, idx[0] - 1)
    chain = ss[start:]
    from .digest import clean_sentence
    out = []
    for s in chain:
        t = clean_sentence(s)
        if not t:
            continue                                   # «Сначала я коротко напомню…» — план доклада, не шаг
        t = re.sub(r'(?i)^(сначала|вначале|далее|затем|потом|наконец|в конце)[,\s]+', '', t)
        out.append({'title': '', 'text': shorten(cap(t), 150)})
    out = [o for o in out if len(o['text']) > 12]
    if len(out) < min_n:
        return None
    return out[:max_n]


# --------------------------------------------------------------------------------------
# Достоинства / недостатки, параметры
# --------------------------------------------------------------------------------------
_PRO = re.compile(r'(?i)^(достоинств\w*|преимуществ\w*|плюсы)\s*[:—–-]\s*')
_CON = re.compile(r'(?i)^(недостат\w*|минусы|ограничени\w*)\s*[:—–-]\s*')


def _split_list(s):
    return [cap(x.strip(' .;')) for x in re.split(r';|\n', s) if x.strip(' .;')]


def pros_cons(texts):
    """Абзацы «Объект.» / «Достоинства: …» / «Недостатки: …» →
    [{'name', 'pros': […], 'cons': […]}] (по одному на объект)."""
    groups, cur = [], None
    for t in texts:
        t = clean(t)
        mp, mc = _PRO.match(t), _CON.match(t)
        if mp or mc:
            if cur is None:
                cur = {'name': '', 'pros': [], 'cons': []}
                groups.append(cur)
            (cur['pros'] if mp else cur['cons']).extend(_split_list(t[(mp or mc).end():]))
        elif len(t) <= 80:
            cur = {'name': t.rstrip('.:'), 'pros': [], 'cons': []}
            groups.append(cur)
        else:
            cur = None
    groups = [g for g in groups if g['pros'] or g['cons']]
    return groups or None


_PARAM = re.compile(r'^\s*([^=:]{2,40}?)\s*(?:=|[-–—:])\s*([-−]?\d[\d  ]*(?:[.,]\d+)?)\s*([^\s\d][^,;]{0,14})?\s*$')


def params(texts):
    """Строки «Ннасоса=1500м», «Раб. частота-50Гц» → [{'value','unit','title'}] (или None)."""
    out = []
    for t in texts:
        m = _PARAM.match(clean(t))
        if m:
            out.append({'value': m.group(2).strip(), 'unit': (m.group(3) or '').strip(' .'),
                        'title': cap(m.group(1).strip(' .')), 'text': ''})
    return out if len(out) >= 3 and len(out) >= 0.5 * len(texts) else None


# --------------------------------------------------------------------------------------
# Документ-сценарий («Слайд 1», «Слайд 2»…)
# --------------------------------------------------------------------------------------
_MARKER = re.compile(r'(?i)^\s*(слайд|slide|кадр)\s*№?\s*(\d{1,3})\s*[.:)—–-]?\s*(.*)$')


def is_slide_marker(title):
    """'Слайд 3' → (3, ''); 'Слайд 3. Цель проекта' → (3, 'Цель проекта'); иначе None."""
    m = _MARKER.match(clean(title or ''))
    if not m:
        return None
    return int(m.group(2)), m.group(3).strip()


_TOPICS = [
    (r'спасибо за внимание|благодар\w* за внимание|готов ответить на вопросы', '__end__'),
    (r'\bактуальн', 'Актуальность проблемы'),
    (r'\bцел(ью|ь)\b.{0,200}\bзадач|\bзадач.{0,200}\bцел(ью|ь)\b', 'Цель и задачи'),
    (r'\bцел(ью|ь) (проекта|работы)\b', 'Цель проекта'),
    (r'в результате (проделанной )?работы|результаты работы', 'Результаты работы'),
    (r'экономическ\w* (эффект|целесообразн)|прирост прибыли|прибыль составила|окупаем', 'Экономический эффект'),
    (r'\bвыводы?\b|заключени', 'Выводы'),
    (r'в настоящее время|текущее состояние|сейчас используются', 'Текущее состояние'),
    (r'существуют следующие виды|виды \w+|типы \w+|классификац', 'Виды и классификация'),
    (r'производител|поставщик', 'Производители и поставщики'),
    (r'технологи\w+ (применения|расклинивания|внедрения)', 'Технология применения'),
    (r'достоинств|недостатк|преимуществ', 'Достоинства и недостатки'),
    (r'\bподбор\b|выбор \w+|подобран', 'Подбор оборудования'),
    (r'геометрическ|габарит', 'Геометрические параметры'),
    (r'\bрасч[её]т\b|=\s*\d', 'Расчёт'),
    (r'риск', 'Риски'),
    (r'\bпроблем|отказ\w* (оборудования|насос)|заклинива', 'Суть проблемы'),
    (r'план\w* (работ|мероприятий)|дорожн\w* карт|график', 'План работ'),
]
_TOPIC_RX = [(re.compile(p, re.I | re.S), t) for p, t in _TOPICS]


def topic_title(text, first_line=''):
    """Заголовок для фрагмента без заголовка: короткая первая строка (если похожа на заголовок),
    иначе тема по ключевым словам, иначе — смысловое начало первого тезиса.
    '__end__' — фрагмент «Спасибо за внимание»."""
    fl = clean(first_line).rstrip('.:')
    if fl and len(fl) <= 70 and not fl.endswith('?') and len(fl.split()) <= 9 and not re.search(r'[=]', fl):
        return cap(fl)
    head = clean(text)[:900]
    for rx, t in _TOPIC_RX:
        if rx.search(head):
            return t
    th = theses(text, 1)
    if th:
        t = re.split(r'[,:;—–(]', th[0])[0].strip(' .')
        ws = t.split()
        return cap(' '.join(ws[:6])) if ws else ''
    return ''
