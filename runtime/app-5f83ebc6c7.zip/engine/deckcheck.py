# -*- coding: utf-8 -*-
"""
deckcheck.py — ПРОВЕРКА ГОТОВОГО ФАЙЛА (1.7)
===========================================
План проверяют рецензент и сверка чисел, а здесь проверяется сама собранная презентация — так, как её увидит зритель.

  По файлу (всегда, программа просмотра не нужна):
    * надпись не помещается в рамку (оценка по ширинам символов шрифта — как при подгонке кегля);
    * мелкий шрифт (меньше 9 пт) — с последних рядов не прочитать;
    * надпись, таблица, диаграмма или картинка за краем слайда.
  По картинке слайдов (есть LibreOffice или PowerPoint — файл переводится в PDF, и смотрятся места всех букв):
    * буквы за рамкой своей надписи, таблицы, диаграммы (текст «вылез» вниз или вбок);
    * буквы за краем слайда;
    * буквы друг на друге: надписи наезжают одна на другую, подписи диаграммы слиплись.
  Если программа просмотра заменила шрифт шаблона другим (шрифт не установлен), проверка по картинке примерная:
  показываются только явные случаи, и это написано в результате.

Результат — как у рецензента: {'deck': [...], 'slides': [{'i', 'title', 'items', 'pages', 'img'}], 'counts', ...}.
У замечания — место на слайде 'box' (доли ширины и высоты): окно проверки обводит его на картинке слайда. У слайда
плана — исправление «Сократить текст» (то же, что у рецензента). Свои слайды из PowerPoint проверяются, но не правятся.
"""
import base64
import io
import re

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE, PP_PLACEHOLDER
from pptx.oxml.ns import qn

from .readers.pptx_reader import EMU, _leaves
from .nts.theme import use as use_theme
from .textfit import LINE_FACTOR, wrap_lines

TR = (1 / EMU, 0, 1 / EMU, 0)
MIN_PT = 9                     # мельче — с последних рядов не прочитать (основной текст корпоративных слайдов 14–18 пт)
TINY_PT = 8
MAX_PER_SLIDE = 6
TO_PDF = None                  # app.py: функция «презентация → PDF» (LibreOffice или PowerPoint), если программа есть
SKIP_PH = (PP_PLACEHOLDER.DATE, PP_PLACEHOLDER.FOOTER, PP_PLACEHOLDER.SLIDE_NUMBER, PP_PLACEHOLDER.HEADER)
NAMES = {'overflow': 'текст не помещается', 'small': 'мелкий шрифт', 'offslide': 'за краем слайда',
         'spill': 'текст за рамкой', 'offpage': 'текст за краем слайда', 'overlap': 'надписи друг на друге'}


def _snip(t, n=48):
    t = re.sub(r'\s+', ' ', str(t or '')).strip()
    return t if len(t) <= n else t[:n].rsplit(' ', 1)[0] + '…'


def _pt(v):
    return f'{round(v * 2) / 2:g}'.replace('.', ',')


def _norm(t):
    return re.sub(r'[^0-9a-zа-я]+', '', str(t or '').lower().replace('ё', 'е'))


# ---------------------------------------------------------------------------------------------
# Фигуры слайда
# ---------------------------------------------------------------------------------------------
def _kind(sh):
    if getattr(sh, 'has_table', False) and sh.has_table:
        return 'table'
    if getattr(sh, 'has_chart', False) and sh.has_chart:
        return 'chart'
    if sh.shape_type == MSO_SHAPE_TYPE.PICTURE or sh._element.tag == qn('p:pic'):
        return 'picture'
    if sh._element.tag == qn('p:graphicFrame'):
        return 'frame'
    if getattr(sh, 'has_text_frame', False) and sh.has_text_frame and sh.text_frame.text.strip():
        return 'text'
    return 'shape'


def _ph(sh):
    if not sh.is_placeholder:
        return None
    try:
        return sh.placeholder_format.type
    except (ValueError, AttributeError):
        return None


def _box(sh, b):
    rot = (getattr(sh, 'rotation', 0) or 0) % 180
    if 45 < rot < 135:                                       # повёрнута на 90°: рамка на экране — другой формы
        cx, cy, w, h = (b[0] + b[2]) / 2, (b[1] + b[3]) / 2, b[2] - b[0], b[3] - b[1]
        return cx - h / 2, cy - w / 2, cx + h / 2, cy + w / 2
    return b


def shapes_of(slide, W, H):
    """Фигуры слайда (группы раскрыты): [{'kind', 'box' (дюймы), 'text', 'sh', 'ph', 'auto'}]."""
    out = []
    for sh, b in _leaves(slide.shapes, TR):
        k = _kind(sh)
        text = ''
        if k == 'text':
            text = sh.text_frame.text
        elif k == 'table':
            text = ' '.join(c.text for r in sh.table.rows for c in r.cells)
        out.append({'kind': k, 'box': _box(sh, b), 'text': text, 'sh': sh, 'ph': _ph(sh),
                    'auto': k == 'text' and _autofit(_bodies(sh))[0] == 'spAutoFit'})
    return out


def _fixed_shapes(slide):
    """Надписи макета и образца слайдов (логотип, подписи): их буквы на картинке — не «вылезший» текст."""
    out = []
    for src in (slide.slide_layout, slide.slide_layout.slide_master):
        for sh, b in _leaves(src.shapes, TR):
            if not sh.is_placeholder and getattr(sh, 'has_text_frame', False) and sh.has_text_frame and sh.text_frame.text.strip():
                out.append({'kind': 'text', 'box': b, 'text': sh.text_frame.text, 'sh': sh, 'ph': None, 'auto': False, 'fixed': True})
    return out


# ---------------------------------------------------------------------------------------------
# Проверка по файлу
# ---------------------------------------------------------------------------------------------
def _bodies(sh):
    """Свойства рамки текста: у поля-заполнителя то, что не задано на слайде, берётся из макета, затем из образца."""
    out, cur = [], sh
    for _ in range(3):
        if cur is None or not getattr(cur, 'has_text_frame', False) or not cur.has_text_frame:
            break
        b = cur.text_frame._txBody.find(qn('a:bodyPr'))
        if b is not None:
            out.append(b)
        cur = getattr(cur, '_base_placeholder', None) if cur.is_placeholder else None
    return out


def _body_attr(bodies, name, dflt):
    for b in bodies:
        v = b.get(name)
        if v not in (None, ''):
            return v
    return dflt


def _autofit(bodies):
    for b in bodies:
        for tag in ('a:spAutoFit', 'a:normAutofit', 'a:noAutofit'):
            el = b.find(qn(tag))
            if el is not None:
                return tag[2:], el
    return 'noAutofit', None


def _style_line(sh):
    """Межстрочный интервал стиля образца (заголовки — titleStyle, остальное — bodyStyle), доля одинарного."""
    try:
        if not sh.is_placeholder:
            return 1.0
        master = sh.part.slide_layout.slide_master if hasattr(sh.part, 'slide_layout') else None
        if master is None:
            return 1.0
        st = 'p:titleStyle' if _ph(sh) in (PP_PLACEHOLDER.TITLE, PP_PLACEHOLDER.CENTER_TITLE) else 'p:bodyStyle'
        el = master._element.find(qn('p:txStyles') + '/' + qn(st) + '/' + qn('a:lvl1pPr') + '/' + qn('a:lnSpc') + '/' + qn('a:spcPct'))
        return int(el.get('val', '100000')) / 100000 if el is not None else 1.0
    except Exception:                                          # noqa: BLE001
        return 1.0


def _need(sh, avail_w, bodies, majors=()):
    """Высота текста надписи по оценке, дюймы (None — кегль неизвестен: его задаёт макет)."""
    tf = sh.text_frame
    if _body_attr(bodies, 'wrap', 'square') == 'none':
        return None
    scale, red = 1.0, 0.0
    kind, na = _autofit(bodies)
    na = na if kind == 'normAutofit' else None
    if na is not None:
        scale = int(na.get('fontScale', '100000')) / 100000
        red = int(na.get('lnSpcReduction', '0')) / 100000
    total = 0.0
    base_line = _style_line(sh)
    title_ph = _ph(sh) in (PP_PLACEHOLDER.TITLE, PP_PLACEHOLDER.CENTER_TITLE)
    for p in tf.paragraphs:
        text = ''.join(r.text for r in p.runs).replace('\v', '\n').replace('\x0b', '\n')
        sizes = [r.font.size.pt for r in p.runs if r.font.size is not None and r.text.strip()]
        if not text.strip():
            sz = p.runs[0].font.size.pt if p.runs and p.runs[0].font.size else (sizes[0] if sizes else 12)
            total += sz * LINE_FACTOR / 72
            continue
        if not sizes:
            return None
        runs = [(len(r.text), r.font.size.pt if r.font.size is not None else max(sizes), bool(r.font.bold)) for r in p.runs]
        n = max(1, sum(x[0] for x in runs))
        size = sum(c * z for c, z, _ in runs) / n * scale           # «4» 26 пт + « из 10 выполнено» 15 пт — средний кегль
        top = max(sizes) * scale                                     # первая строка — по самому крупному
        bold = sum(c for c, _, b in runs if b) > n / 2
        faces = [x.find(qn('a:latin')).get('typeface', '') for x in (r._r.find(qn('a:rPr')) for r in p.runs)
                 if x is not None and x.find(qn('a:latin')) is not None]
        major = any(f.startswith('+mj') or (majors and f in majors) for f in faces) if faces else title_ph
        font = 'b' if bold else ('mj' if major else 'mn')
        ppr = p._p.find(qn('a:pPr'))
        line = LINE_FACTOR * base_line
        ls = ppr.find(qn('a:lnSpc')) if ppr is not None else None
        if ls is not None and ls.find(qn('a:spcPct')) is not None:
            line = LINE_FACTOR * int(ls.find(qn('a:spcPct')).get('val', '100000')) / 100000
        line *= (1 - red)
        extra = 0.0
        for tag in ('a:spcBef', 'a:spcAft'):
            sp = ppr.find(qn(tag)) if ppr is not None else None
            pts = sp.find(qn('a:spcPts')) if sp is not None else None
            if pts is not None:
                extra += int(pts.get('val', '0')) / 100 / 72
        lines = len(wrap_lines(text, avail_w, size, font))
        total += (top + (lines - 1) * size) * line / 72 + extra
    return total


def file_issues(slide, shapes, W, H, majors=()):
    """Замечания по самому файлу: [{'kind', 'level', 'text', 'box'}]. majors — шрифт заголовков темы."""
    out = []
    zoom = W / 13.333 - 0.005                                    # слайд 4:3 (10 дюймов) показывают так же крупно
    for s in shapes:
        x0, y0, x1, y1 = s['box']
        k = s['kind']
        if s['ph'] in SKIP_PH:
            continue
        if k in ('text', 'table', 'chart', 'picture', 'frame') and (x0 < -0.1 or y0 < -0.1 or x1 > W + 0.1 or y1 > H + 0.1):
            what = {'table': 'Таблица', 'chart': 'Диаграмма', 'picture': 'Картинка', 'frame': 'Объект'}.get(k)
            out.append({'kind': 'offslide', 'level': 'warn', 'box': s['box'],
                        'text': f'{what} выходит за край слайда.' if what else f'Надпись выходит за край слайда: «{_snip(s["text"])}».'})
        if k == 'text':
            sh = s['sh']
            if not re.search(r'[0-9A-Za-zА-Яа-яЁё]', s['text']):
                continue                                         # кавычки-украшения, значки
            sizes = [r.font.size.pt for p in sh.text_frame.paragraphs for r in p.runs if r.font.size is not None and r.text.strip()]
            if sizes and min(sizes) < MIN_PT * zoom:
                m = min(sizes)
                out.append({'kind': 'small', 'level': 'warn' if m < TINY_PT * zoom else 'tip', 'box': s['box'],
                            'text': f'Мелкий шрифт — {_pt(m)} пт: «{_snip(s["text"], 36)}». С последних рядов такой не прочитать.'})
            bodies = _bodies(sh)
            ins = tuple(int(_body_attr(bodies, a, d)) / EMU for a, d in
                        (('lIns', 91440), ('tIns', 45720), ('rIns', 91440), ('bIns', 45720)))
            aw, ah = (x1 - x0) - ins[0] - ins[2], (y1 - y0) - ins[1] - ins[3]
            if aw <= 0.2 or ah <= 0.05:
                continue
            need = _need(sh, aw, bodies, majors)
            if need is None:
                continue
            if _autofit(bodies)[0] == 'spAutoFit':
                if y0 + ins[1] + need + ins[3] > H + 0.1:
                    out.append({'kind': 'overflow', 'level': 'warn', 'box': (x0, y0, x1, min(H, y0 + need)),
                                'text': f'Текст доходит до края слайда: «{_snip(s["text"])}».'})
            elif need > ah * 1.12 + 0.08:
                out.append({'kind': 'overflow', 'level': 'warn', 'box': (x0, y0, x1, min(H, y0 + ins[1] + need)),
                            'text': f'Текст не помещается в рамку: «{_snip(s["text"])}».'})
        if k == 'table':
            for r in s['sh'].table.rows:
                for c in r.cells:
                    sizes = [x.font.size.pt for p in c.text_frame.paragraphs for x in p.runs if x.font.size is not None and x.text.strip()]
                    if sizes and min(sizes) < MIN_PT * zoom:
                        out.append({'kind': 'small', 'level': 'warn' if min(sizes) < TINY_PT * zoom else 'tip', 'box': s['box'],
                                    'text': f'Мелкий шрифт в таблице — {_pt(min(sizes))} пт. С последних рядов такой не прочитать.'})
                        break
                else:
                    continue
                break
    return out


# ---------------------------------------------------------------------------------------------
# Проверка по картинке (PDF)
# ---------------------------------------------------------------------------------------------
def _chars(page, Hpt):
    """Буквы страницы: [(номер, буква, x0, y0, x1, y1)] в дюймах (y — сверху), без пробелов и пустых."""
    import pypdfium2.raw as raw
    tp = page.get_textpage()
    out = []
    try:
        for i in range(tp.count_chars()):
            u = raw.FPDFText_GetUnicode(tp.raw, i)
            ch = chr(u) if u and u < 0x110000 else ''
            if not ch.strip() or ch in '￾￿':
                continue
            l, b, r, t = tp.get_charbox(i)
            if r - l < 0.3 or t - b < 0.3:
                continue
            out.append((i, ch, l / 72, (Hpt - t) / 72, r / 72, (Hpt - b) / 72))
    finally:
        tp.close()
    return out


def _fonts_used(pdf, pages=4):
    """Имена шрифтов, которыми нарисован текст первых страниц PDF (без приставки подмножества «ABCDEF+»)."""
    import ctypes

    import pypdfium2.raw as raw
    names = set()
    for k in range(min(pages, len(pdf))):
        tp = pdf[k].get_textpage()
        try:
            n = tp.count_chars()
            for i in range(0, n, max(1, n // 40)):
                buf = ctypes.create_string_buffer(256)
                flags = ctypes.c_int()
                if raw.FPDFText_GetFontInfo(tp.raw, i, buf, 256, ctypes.byref(flags)):
                    names.add(buf.value.decode('latin-1', 'replace').split('+', 1)[-1])
        finally:
            tp.close()
    return names


def theme_fonts(prs, which='major|minor'):
    """Шрифты темы шаблона: заголовков (major) и основного текста (minor)."""
    out = set()
    try:
        master = prs.slide_masters[0]
        for rel in master.part.rels.values():
            if rel.reltype.endswith('/theme'):
                xml = rel.target_part.blob.decode('utf-8', 'replace')
                out |= set(re.findall(r'<a:(?:' + which + r')Font>\s*<a:latin typeface="([^"]+)"', xml))
    except Exception:                                          # noqa: BLE001
        pass
    return out


def _dist(c, b):
    cx, cy = (c[2] + c[4]) / 2, (c[3] + c[5]) / 2
    dx = max(b[0] - cx, 0, cx - b[2])
    dy = max(b[1] - cy, 0, cy - b[3])
    return (dx * dx + dy * dy) ** 0.5


def _inside(c, b, tol):
    cx, cy = (c[2] + c[4]) / 2, (c[3] + c[5]) / 2
    return b[0] - tol <= cx <= b[2] + tol and b[1] - tol <= cy <= b[3] + tol


def render_issues(chars, shapes, W, H, approx=False):
    """Замечания по картинке слайда: буквы за рамкой своей фигуры, за краем слайда, буквы друг на друге."""
    out = []
    holders = [s for s in shapes if s['kind'] in ('text', 'table', 'chart', 'frame')
               or (s['kind'] == 'picture' and (s['box'][2] - s['box'][0]) * (s['box'][3] - s['box'][1]) < W * H * 0.6)]
    tol = 0.05
    boxes = []
    for s in holders:
        b = s['box']
        if s.get('auto'):                                      # рамка растёт по тексту: её высота в файле — не итог
            b = (b[0], b[1], b[2], H)
        boxes.append(b)
    off, stray = [], {}
    for c in chars:
        cx, cy = (c[2] + c[4]) / 2, (c[3] + c[5]) / 2
        if cx < -0.02 or cy < -0.02 or cx > W + 0.02 or cy > H + 0.02:
            off.append(c)
            continue
        if any(_inside(c, b, tol) for b in boxes):
            continue
        if not holders:
            continue
        k = min(range(len(holders)), key=lambda j: _dist(c, boxes[j]))
        stray.setdefault(k, []).append(c)
    if off:
        bx = (max(0, min(c[2] for c in off)), max(0, min(c[3] for c in off)), min(W, max(c[4] for c in off)), min(H, max(c[5] for c in off)))
        own = [s for s in holders if any(_inside(c, s['box'], 0.05) for c in off) and s['text'].strip()]
        what = _snip(own[0]['text']) if own else _snip(''.join(c[1] for c in off), 30)
        out.append({'kind': 'offpage', 'level': 'warn', 'box': bx, 'text': f'Текст за краем слайда: «{what}».'})
    if approx:                 # шрифт заменён: ширины букв другие — переносы и наложения не показательны
        return out
    for k, cs in stray.items():
        if len(cs) < 2:
            continue
        s = holders[k]
        b = s['box']
        bx = (min(b[0], min(c[2] for c in cs)), min(b[1], min(c[3] for c in cs)),
              max(b[2], max(c[4] for c in cs)), max(b[3], max(c[5] for c in cs)))
        what = {'table': 'Таблица не помещается в своё место', 'chart': 'Подписи диаграммы выходят за её рамку',
                'picture': 'Текст картинки выходит за её рамку'}.get(s['kind'])
        text = f'{what}.' if what else f'Текст выходит за рамку: «{_snip(s["text"])}».'
        out.append({'kind': 'spill', 'level': 'warn', 'box': bx, 'text': text})
    # буквы друг на друге (разные строки или разные надписи)
    grid = {}
    for n, c in enumerate(chars):
        for gx in range(int(c[2] / 0.25), int(c[4] / 0.25) + 1):
            for gy in range(int(c[3] / 0.25), int(c[5] / 0.25) + 1):
                grid.setdefault((gx, gy), []).append(n)
    hits = set()
    for cell in grid.values():
        for a in range(len(cell)):
            ca = chars[cell[a]]
            for b in range(a + 1, len(cell)):
                cb = chars[cell[b]]
                if abs(ca[0] - cb[0]) <= 2:
                    continue
                ix = min(ca[4], cb[4]) - max(ca[2], cb[2])
                iy = min(ca[5], cb[5]) - max(ca[3], cb[3])
                if ix <= 0 or iy <= 0:
                    continue
                small = min((ca[4] - ca[2]) * (ca[5] - ca[3]), (cb[4] - cb[2]) * (cb[5] - cb[3]))
                if small > 0 and ix * iy > 0.35 * small:
                    hits.add(cell[a])
                    hits.add(cell[b])
    if len(hits) >= 2:
        hs = [chars[n] for n in hits]
        owners = []
        for c in hs:
            inside = [s for s in holders if _inside(c, s['box'], 0.02)]
            if inside:
                owners.append(min(inside, key=lambda s: (s['box'][2] - s['box'][0]) * (s['box'][3] - s['box'][1])))
        chart = owners and all(o['kind'] == 'chart' for o in owners)
        bx = (min(c[2] for c in hs), min(c[3] for c in hs), max(c[4] for c in hs), max(c[5] for c in hs))
        names = list(dict.fromkeys(_snip(o['text'], 30) for o in owners if o['kind'] == 'text' and o['text'].strip()))[:2]
        text = ('Подписи диаграммы наезжают друг на друга.' if chart else
                'Надписи наезжают друг на друга' + (': ' + ' и '.join(f'«{x}»' for x in names) if names else '') + '.')
        out.append({'kind': 'overlap', 'level': 'tip' if chart else 'warn', 'box': bx, 'text': text})
    return out


def _rasterize(pdf, k, width=640):
    page = pdf[k]
    scale = width / page.get_size()[0]
    img = page.render(scale=scale).to_pil().convert('RGB')
    buf = io.BytesIO()
    img.save(buf, 'JPEG', quality=82)
    return 'data:image/jpeg;base64,' + base64.b64encode(buf.getvalue()).decode('ascii')


# ---------------------------------------------------------------------------------------------
# Слайды файла ↔ слайды плана
# ---------------------------------------------------------------------------------------------
def _title_of(slide, shapes):
    for s in shapes:
        if s['ph'] in (PP_PLACEHOLDER.TITLE, PP_PLACEHOLDER.CENTER_TITLE) and s['text'].strip():
            return s['text']
    texts = [s for s in shapes if s['kind'] == 'text' and s['text'].strip() and s['ph'] not in SKIP_PH]
    return min(texts, key=lambda s: s['box'][1])['text'] if texts else ''


def match_plan(titles, spec):
    """Номер слайда плана для каждого слайда файла (None — не нашёлся). Продолжения («… (продолжение)») — к своему;
    заголовок, поправленный при сборке (словарь, правописание), — по похожести; свой слайд из PowerPoint и слайд без
    заголовка — по порядку; «Спасибо за внимание!» шаблона — к финальному."""
    from difflib import SequenceMatcher
    meta = (spec or {}).get('meta') or {}
    plan = [(_norm(s.get('title') or (meta.get('title') if s.get('layout') == 'title' else '')), s.get('layout'))
            for s in (spec or {}).get('slides') or [] if isinstance(s, dict)]
    out, j, used = [], 0, set()
    for k, t in enumerate(titles):
        n = _norm(t.replace('(продолжение)', '').rstrip('…'))
        hit = None
        for q in range(j, len(plan)):
            p = plan[q][0]
            if n and p and (n == p or p.startswith(n) or (n.startswith(p) and len(p) >= 6)):
                hit = q
                break
        if hit is None and n:
            best = max(((SequenceMatcher(None, n, plan[q][0]).ratio(), q) for q in range(j, min(len(plan), j + 4))
                        if plan[q][0]), default=(0, None))
            hit = best[1] if best[0] >= 0.75 else None
        if hit is None:
            q = j + 1 if j in used else j                       # следующий слайд плана по порядку
            if q < len(plan) and (plan[q][1] in ('own', 'end') or not plan[q][0]):
                hit = q
        if hit is None and (not n or k == len(titles) - 1):     # финальный слайд: «Спасибо за внимание!» шаблона
            hit = next((q for q in range(j, len(plan)) if plan[q][1] == 'end'), None)
        out.append(hit)
        if hit is not None:
            j = hit
            used.add(hit)
    return out


# ---------------------------------------------------------------------------------------------
# Вся проверка
# ---------------------------------------------------------------------------------------------
def check(pptx_path, spec=None, pdf_path=None, images=True, width=640, template=None):
    """Проверить собранный файл → результат в виде рецензента (см. описание модуля).
    template — свой шаблон (id), на котором собран файл: текст меряется ширинами его шрифтов."""
    from .templates import BUILTIN, theme_for
    tid = template if template is not None else ((spec or {}).get('meta') or {}).get('template') or ''
    th = theme_for(tid) if tid and tid != BUILTIN else None
    with use_theme(th):
        return _check(pptx_path, spec, pdf_path, images, width)


def _check(pptx_path, spec, pdf_path, images, width):
    prs = Presentation(str(pptx_path))
    W, H = prs.slide_width / EMU, prs.slide_height / EMU
    slides = list(prs.slides)
    majors = theme_fonts(prs, 'major')
    per = []
    titles = []
    for sl in slides:
        sh = shapes_of(sl, W, H)
        titles.append(_title_of(sl, sh))
        per.append({'shapes': sh, 'fixed': _fixed_shapes(sl), 'items': file_issues(sl, sh, W, H, majors)})
    pdf, engine_note, approx, rendered = None, '', False, False
    if pdf_path:
        try:
            import pypdfium2 as pdfium
            pdf = pdfium.PdfDocument(str(pdf_path))
        except Exception as e:                                 # noqa: BLE001
            engine_note = f'картинки слайдов не прочитаны ({type(e).__name__})'
    if pdf is not None:
        if len(pdf) != len(slides):
            engine_note = f'в картинке {len(pdf)} страниц, а слайдов {len(slides)} — проверка по картинке пропущена'
        else:
            from .fontmetrics import SUBST
            want = {_norm(x) for f in theme_fonts(prs) for x in [f] + SUBST.get(f.lower(), [])}
            got = {_norm(f) for f in _fonts_used(pdf)}
            approx = bool(want) and not any(w and any(w in g or g in w for g in got if g) for w in want)
            Hpt = pdf[0].get_size()[1]
            for k in range(len(slides)):
                chars = _chars(pdf[k], Hpt)
                per[k]['items'] += render_issues(chars, per[k]['shapes'] + per[k]['fixed'], W, H, approx)
            rendered = True
    # одно замечание вида на фигуру, сначала важные; «за краем» по картинке — если файл этого ещё не нашёл;
    # точная картинка (шрифт тот же) важнее оценки «не помещается»: что на картинке в рамке, то помещается
    for p in per:
        if any(it['kind'] == 'offslide' for it in p['items']):
            p['items'] = [it for it in p['items'] if it['kind'] != 'offpage']
        if rendered and not approx:
            p['items'] = [it for it in p['items'] if it['kind'] != 'overflow']
        seen, items = set(), []
        for it in sorted(p['items'], key=lambda x: x['level'] != 'warn'):
            key = (it['kind'], tuple(round(v, 1) for v in it['box']))
            if key in seen:
                continue
            seen.add(key)
            items.append(it)
        p['items'] = items[:MAX_PER_SLIDE]
    idx = match_plan(titles, spec)
    plan = (spec or {}).get('slides') or []
    deck, by = [], {}
    for k, p in enumerate(per):
        if not p['items']:
            continue
        i = idx[k]
        img = _rasterize(pdf, k, width) if images and rendered else None
        page = {'n': k + 1, 'img': img}
        items = []
        for m, it in enumerate(p['items']):
            x0, y0, x1, y1 = it['box']
            items.append({'id': f'file:{it["kind"]}:{k}:{m}', 'kind': it['kind'], 'level': it['level'], 'text': it['text'],
                          'src': 'готовый файл' + (', по картинке' if it['kind'] in ('spill', 'offpage', 'overlap') else ''),
                          'page': k + 1, 'box': [round(max(-0.02, min(1.02, v)), 4) for v in (x0 / W, y0 / H, x1 / W, y1 / H)]})
        if i is None or i >= len(plan):
            for it in items:
                it['text'] = f'Слайд {k + 1} файла: {it["text"]}'
            deck += items
            continue
        e = by.setdefault(i, {'i': i, 'title': re.sub(r'\s+', ' ', str(plan[i].get('title') or '')) or f'Слайд {i + 1}',
                               'items': [], 'pages': []})
        e['pages'].append(page)
        e['items'] += items
    fixes = {}
    for i, e in by.items():
        s = plan[i]
        if s.get('layout') in ('own', 'title', 'end') or not any(it['kind'] in ('overflow', 'spill', 'overlap', 'small') for it in e['items']):
            continue
        if i not in fixes:
            from .review import _shortened
            try:
                fixes[i] = _shortened(s)
            except Exception:                                  # noqa: BLE001
                fixes[i] = None
        if fixes[i]:
            for it in e['items']:
                if it['kind'] in ('overflow', 'spill', 'overlap', 'small'):
                    it['fix'] = {'label': 'Сократить текст', 'slide': fixes[i]}
    out_slides = [by[i] for i in sorted(by)]
    allf = deck + [it for e in out_slides for it in e['items']]
    note = []
    if rendered and approx:
        note.append('Шрифт шаблона не установлен на этом компьютере, поэтому по картинке слайдов показаны только явные случаи.')
    if engine_note:
        note.append('Проверка по картинке: ' + engine_note + '.')
    if not pdf_path:
        note.append('Проверка только по файлу: для проверки по картинке слайдов нужен LibreOffice или PowerPoint.')
    return {'mode': 'file', 'deck': deck, 'slides': out_slides, 'warnings': [], 'rendered': rendered, 'approx': approx,
            'notes': note, 'n_slides': len(slides),
            'counts': {'warn': sum(f['level'] == 'warn' for f in allf), 'tip': sum(f['level'] == 'tip' for f in allf)}}


def check_spec(spec, tmpdir, to_pdf=None, images=True):
    """Собрать план во временную папку и проверить готовый файл."""
    from pathlib import Path

    from . import build
    path = Path(tmpdir) / 'проверка.pptx'
    build(spec, path)
    pdf = None
    conv = to_pdf or TO_PDF
    if conv is not None:
        try:
            pdf = conv(path)
        except Exception:                                      # noqa: BLE001 — без картинки проверка идёт по файлу
            pdf = None
    r = check(path, spec, pdf, images=images)
    if conv is not None and pdf is None:
        r['notes'].append('Картинки слайдов построить не удалось — проверка только по файлу.')
    return r
