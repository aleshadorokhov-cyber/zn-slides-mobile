# -*- coding: utf-8 -*-
"""
svgdraw.py — РИСУНОК МОДЕЛИ ИИ (SVG) → ФИГУРЫ POWERPOINT
=======================================================

Модель ИИ рисует иллюстрацию в виде кода SVG (векторный рисунок). Этот модуль:

  * достаёт SVG из ответа модели и очищает его (только безопасные элементы: rect, circle, ellipse,
    line, polyline, polygon, path, g, defs, linearGradient, radialGradient, stop — без скриптов,
    ссылок, текста и картинок); sanitize() возвращает очищенный текст SVG — он хранится в плане;
  * переводит рисунок в НАТИВНЫЕ фигуры PowerPoint (draw()): прямоугольники и овалы — стандартными
    фигурами, остальное — полилиниями (кривые Безье и дуги аппроксимируются отрезками);
    поддерживаются заливка и контур, прозрачность (opacity / fill-opacity / stroke-opacity),
    линейные и радиальные градиенты, трансформации (matrix, translate, scale, rotate, skewX/Y),
    наследование стилей от групп, атрибут style.

Фигуры можно править в PowerPoint как обычные; LibreOffice рисует их так же (миниатюры вариантов).
"""
import base64
import math
import re

from lxml import etree
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn
from pptx.util import Emu, Pt

ALLOWED = {'svg', 'g', 'defs', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon', 'path',
           'linearGradient', 'radialGradient', 'stop'}
DRAWABLE = {'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon', 'path'}
ATTRS = {'viewBox', 'width', 'height', 'x', 'y', 'rx', 'ry', 'cx', 'cy', 'r', 'x1', 'y1', 'x2', 'y2', 'fx', 'fy',
         'points', 'd', 'fill', 'stroke', 'stroke-width', 'opacity', 'fill-opacity', 'stroke-opacity', 'transform',
         'id', 'offset', 'stop-color', 'stop-opacity', 'style', 'gradientUnits', 'fill-rule', 'stroke-linecap',
         'stroke-linejoin', 'href', 'preserveAspectRatio'}
STYLE_KEYS = {'fill', 'stroke', 'stroke-width', 'opacity', 'fill-opacity', 'stroke-opacity', 'stop-color',
              'stop-opacity', 'fill-rule'}
MAX_CHARS = 120_000          # больше — не рисунок, а мусор
MAX_SHAPES = 220             # столько фигур максимум попадёт на слайд
MAX_POINTS = 600             # точек в одной полилинии
EMU_IN = 914400

NAMED = {
    'black': '000000', 'white': 'ffffff', 'red': 'ff0000', 'green': '008000', 'blue': '0000ff', 'yellow': 'ffff00',
    'orange': 'ffa500', 'gray': '808080', 'grey': '808080', 'silver': 'c0c0c0', 'navy': '000080',
    'teal': '008080', 'lime': '00ff00', 'aqua': '00ffff', 'cyan': '00ffff', 'maroon': '800000', 'olive': '808000',
    'purple': '800080', 'fuchsia': 'ff00ff', 'magenta': 'ff00ff', 'brown': 'a52a2a', 'pink': 'ffc0cb',
    'gold': 'ffd700', 'beige': 'f5f5dc', 'ivory': 'fffff0', 'khaki': 'f0e68c', 'lightgray': 'd3d3d3',
    'lightgrey': 'd3d3d3', 'darkgray': 'a9a9a9', 'darkgrey': 'a9a9a9', 'lightblue': 'add8e6', 'skyblue': '87ceeb',
    'steelblue': '4682b4', 'darkblue': '00008b', 'royalblue': '4169e1', 'dodgerblue': '1e90ff',
    'lightgreen': '90ee90', 'darkgreen': '006400', 'forestgreen': '228b22', 'seagreen': '2e8b57',
    'yellowgreen': '9acd32', 'limegreen': '32cd32', 'whitesmoke': 'f5f5f5', 'gainsboro': 'dcdcdc',
    'slategray': '708090', 'darkslategray': '2f4f4f', 'tomato': 'ff6347', 'coral': 'ff7f50', 'tan': 'd2b48c',
    'chocolate': 'd2691e', 'sienna': 'a0522d', 'crimson': 'dc143c', 'indigo': '4b0082', 'violet': 'ee82ee',
    'aliceblue': 'f0f8ff', 'azure': 'f0ffff', 'honeydew': 'f0fff0', 'lavender': 'e6e6fa', 'linen': 'faf0e6',
}


class SvgError(Exception):
    pass


# ======================================================================================
# Извлечение и очистка
# ======================================================================================
def extract_svg(text):
    """Код SVG из ответа модели (с черновиком <think>, ```svg-блоками, пояснениями вокруг)."""
    t = re.sub(r'(?s)<think>.*?</think>', '', text or '')
    i = t.find('<svg')
    if i < 0:
        raise SvgError('в ответе модели нет рисунка SVG')
    j = t.rfind('</svg>')
    return t[i:j + 6] if j > i else t[i:] + '</svg>'           # оборванный ответ — закрываем тег


def _local(tag):
    return tag.rsplit('}', 1)[-1] if isinstance(tag, str) else ''


def _parse(svg_text):
    if len(svg_text) > MAX_CHARS:
        raise SvgError('рисунок слишком большой')
    parser = etree.XMLParser(resolve_entities=False, no_network=True, remove_comments=True, remove_pis=True,
                             recover=True, huge_tree=False, load_dtd=False)
    try:
        root = etree.fromstring(svg_text.encode('utf-8'), parser)
    except etree.XMLSyntaxError as e:
        raise SvgError(f'неверный код SVG: {e}')
    if root is None or _local(root.tag) != 'svg':
        raise SvgError('неверный код SVG')
    return root


def _inline_css(root):
    """Простые правила <style> (.класс{…}, rect{…}, circle,ellipse{…}) переносятся в атрибут style
    элементов: модели иногда задают цвета классами, а без этого фигуры стали бы чёрными."""
    rules = []
    for el in root.iter():
        if isinstance(el.tag, str) and _local(el.tag) == 'style' and el.text:
            css = re.sub(r'(?s)/\*.*?\*/', '', el.text)
            for sel, body in re.findall(r'([^{}]+)\{([^{}]*)\}', css):
                for one in sel.split(','):
                    one = one.strip()
                    if re.fullmatch(r'\.[\w\-]+|[a-zA-Z]+|[a-zA-Z]+\.[\w\-]+', one):
                        rules.append((one, body.strip().strip(';')))
    if not rules:
        return
    for el in root.iter():
        if not isinstance(el.tag, str):
            continue
        name = _local(el.tag)
        classes = set((el.get('class') or '').split())
        decl = []
        for sel, body in rules:
            tag, _, cls = sel.partition('.') if not sel.startswith('.') else ('', '.', sel[1:])
            if (not tag or tag == name) and (not cls or cls in classes):
                decl.append(body)
        if decl:
            el.set('style', ';'.join(decl + [el.get('style') or '']).strip(';'))


def _strip(root):
    """Удаляет запрещённые элементы и атрибуты, снимает пространства имён."""
    _inline_css(root)
    for el in list(root.iter()):
        if not isinstance(el.tag, str):                  # комментарии и т. п.
            el.getparent().remove(el)
            continue
        name = _local(el.tag)
        if name not in ALLOWED:
            if el is not root and el.getparent() is not None:
                el.getparent().remove(el)
            continue
        el.tag = name
        for a in list(el.attrib):
            la = _local(a)
            v = el.attrib[a]
            if la not in ATTRS or (la == 'href' and not v.startswith('#')) or 'javascript' in v.lower() \
                    or ('url(' in v and not re.search(r'url\(\s*#[\w\-.]+\s*\)', v)):
                del el.attrib[a]
            elif la != a:                               # xlink:href → href
                del el.attrib[a]
                el.attrib[la] = v
        el.text = None if name != 'svg' else None
        el.tail = None
    etree.cleanup_namespaces(root)
    return root


def sanitize(svg_text):
    """Очищенный текст SVG (для хранения в плане и показа в браузере). Ошибка → SvgError."""
    root = _strip(_parse(svg_text))
    n = sum(1 for el in root.iter() if el.tag in DRAWABLE)
    if n == 0:
        raise SvgError('в рисунке нет ни одной фигуры')
    out = etree.tostring(root, encoding='unicode')
    if 'xmlns=' not in out[:200]:
        out = out.replace('<svg', '<svg xmlns="http://www.w3.org/2000/svg"', 1)
    return out


def data_url(svg_text):
    """data:-ссылка на рисунок (для превью в браузере)."""
    return 'data:image/svg+xml;base64,' + base64.b64encode(svg_text.encode('utf-8')).decode('ascii')


# ======================================================================================
# Разбор значений
# ======================================================================================
_NUM = re.compile(r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?')


def _num(v, default=0.0, ref=None):
    if v is None:
        return default
    s = str(v).strip()
    m = _NUM.match(s)
    if not m:
        return default
    x = float(m.group(0))
    if s.endswith('%') and ref is not None:
        x = x / 100 * ref
    return x if math.isfinite(x) else default


def _nums(s):
    return [float(x) for x in _NUM.findall(s or '') if math.isfinite(float(x))]


def color(v):
    """'#0078AE' / '#07a' / 'rgb(0,120,174)' / имя → (r, g, b); 'none' → None; url(#id) → ('url', id)."""
    if v is None:
        return 'inherit'
    s = str(v).strip().lower()
    if s in ('', 'inherit'):
        return 'inherit'
    if s in ('none', 'transparent'):
        return None
    m = re.match(r'url\(\s*#([\w\-.]+)\s*\)', str(v).strip(), re.I)
    if m:
        return ('url', m.group(1))                          # id — с учётом регистра (id="skyGrad")
    if s.startswith('#'):
        h = s[1:]
        if len(h) in (3, 4):
            h = ''.join(c * 2 for c in h[:3])
        if len(h) in (6, 8) and re.fullmatch(r'[0-9a-f]+', h[:6]):
            return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
        return (0, 0, 0)
    m = re.match(r'rgba?\(([^)]*)\)', s)
    if m:
        parts = [p.strip() for p in m.group(1).split(',')][:3]
        out = []
        for p in parts:
            x = _num(p)
            out.append(int(round(x * 2.55)) if p.endswith('%') else int(round(x)))
        while len(out) < 3:
            out.append(0)
        return tuple(max(0, min(255, c)) for c in out)
    if s in NAMED:
        h = NAMED[s]
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    if s == 'currentcolor':
        return (0, 0, 0)
    return (0, 0, 0)


def _style(el):
    """Свойства оформления элемента: атрибуты + style="…" (style важнее)."""
    p = {k: el.get(k) for k in STYLE_KEYS if el.get(k) is not None}
    for part in (el.get('style') or '').split(';'):
        if ':' in part:
            k, v = part.split(':', 1)
            k = k.strip().lower()
            if k in STYLE_KEYS:
                p[k] = v.strip()
    return p


# ======================================================================================
# Трансформации (матрица a b c d e f: x' = a·x + c·y + e, y' = b·x + d·y + f)
# ======================================================================================
ID = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)


def _mul(m, n):
    a, b, c, d, e, f = m
    a2, b2, c2, d2, e2, f2 = n
    return (a * a2 + c * b2, b * a2 + d * b2, a * c2 + c * d2, b * c2 + d * d2, a * e2 + c * f2 + e, b * e2 + d * f2 + f)


def transform(s):
    m = ID
    for name, args in re.findall(r'(matrix|translate|scale|rotate|skewX|skewY)\s*\(([^)]*)\)', s or ''):
        v = _nums(args)
        if name == 'matrix' and len(v) >= 6:
            t = tuple(v[:6])
        elif name == 'translate' and v:
            t = (1, 0, 0, 1, v[0], v[1] if len(v) > 1 else 0)
        elif name == 'scale' and v:
            t = (v[0], 0, 0, v[1] if len(v) > 1 else v[0], 0, 0)
        elif name == 'rotate' and v:
            a = math.radians(v[0])
            r = (math.cos(a), math.sin(a), -math.sin(a), math.cos(a), 0, 0)
            if len(v) >= 3:
                t = _mul(_mul((1, 0, 0, 1, v[1], v[2]), r), (1, 0, 0, 1, -v[1], -v[2]))
            else:
                t = r
        elif name == 'skewX' and v:
            t = (1, 0, math.tan(math.radians(v[0])), 1, 0, 0)
        elif name == 'skewY' and v:
            t = (1, math.tan(math.radians(v[0])), 0, 1, 0, 0)
        else:
            continue
        m = _mul(m, t)
    return m


def _apply(m, x, y):
    a, b, c, d, e, f = m
    return a * x + c * y + e, b * x + d * y + f


def _scale_of(m):
    a, b, c, d, _, _ = m
    return math.sqrt(abs(a * d - b * c)) or 1.0


# ======================================================================================
# Контуры: path d → список подконтуров [(точки, замкнут)]
# ======================================================================================
class _Scan:
    def __init__(self, s):
        self.s, self.i = s, 0

    def _skip(self):
        while self.i < len(self.s) and self.s[self.i] in ' \t\r\n,':
            self.i += 1

    def cmd(self):
        self._skip()
        if self.i < len(self.s) and self.s[self.i].isalpha():
            c = self.s[self.i]
            self.i += 1
            return c
        return None

    def more(self):
        self._skip()
        return self.i < len(self.s) and not self.s[self.i].isalpha()

    def num(self):
        self._skip()
        m = _NUM.match(self.s, self.i)
        if not m:
            raise SvgError('ошибка в контуре path')
        self.i = m.end()
        return float(m.group(0))

    def flag(self):
        self._skip()
        if self.i < len(self.s) and self.s[self.i] in '01':
            self.i += 1
            return self.s[self.i - 1] == '1'
        raise SvgError('ошибка в дуге контура path')


def _cubic(p0, p1, p2, p3, n):
    out = []
    for k in range(1, n + 1):
        t = k / n
        u = 1 - t
        out.append((u ** 3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t ** 3 * p3[0],
                    u ** 3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t ** 3 * p3[1]))
    return out


def _quad(p0, p1, p2, n):
    out = []
    for k in range(1, n + 1):
        t = k / n
        u = 1 - t
        out.append((u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0], u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1]))
    return out


def _segs(*pts):
    """Число отрезков для кривой — по длине ломаной из контрольных точек."""
    ln = sum(math.dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1))
    return max(4, min(28, int(ln / 12) + 4))


def _arc(p0, rx, ry, phi, large, sweep, p1):
    """Дуга эллипса (параметры SVG) → точки (без начальной)."""
    if rx == 0 or ry == 0 or p0 == p1:
        return [p1]
    rx, ry = abs(rx), abs(ry)
    cp, sp = math.cos(math.radians(phi)), math.sin(math.radians(phi))
    dx, dy = (p0[0] - p1[0]) / 2, (p0[1] - p1[1]) / 2
    x1, y1 = cp * dx + sp * dy, -sp * dx + cp * dy
    lam = x1 * x1 / (rx * rx) + y1 * y1 / (ry * ry)
    if lam > 1:
        s = math.sqrt(lam)
        rx, ry = rx * s, ry * s
    num = rx * rx * ry * ry - rx * rx * y1 * y1 - ry * ry * x1 * x1
    den = rx * rx * y1 * y1 + ry * ry * x1 * x1
    co = math.sqrt(max(0.0, num / den)) if den else 0.0
    if large == sweep:
        co = -co
    cx1, cy1 = co * rx * y1 / ry, -co * ry * x1 / rx
    cx = cp * cx1 - sp * cy1 + (p0[0] + p1[0]) / 2
    cy = sp * cx1 + cp * cy1 + (p0[1] + p1[1]) / 2

    def ang(ux, uy, vx, vy):
        a = math.atan2(ux * vy - uy * vx, ux * vx + uy * vy)
        return a
    t1 = ang(1, 0, (x1 - cx1) / rx, (y1 - cy1) / ry)
    dt = ang((x1 - cx1) / rx, (y1 - cy1) / ry, (-x1 - cx1) / rx, (-y1 - cy1) / ry)
    if not sweep and dt > 0:
        dt -= 2 * math.pi
    elif sweep and dt < 0:
        dt += 2 * math.pi
    n = max(4, min(48, int(abs(dt) / (math.pi / 16)) + 2))
    out = []
    for k in range(1, n + 1):
        t = t1 + dt * k / n
        x, y = rx * math.cos(t), ry * math.sin(t)
        out.append((cp * x - sp * y + cx, sp * x + cp * y + cy))
    out[-1] = p1
    return out


def path_contours(d):
    """Строка d → [(точки, замкнут)] в координатах пользователя."""
    sc = _Scan(d or '')
    subs = []
    pts = []
    cur = (0.0, 0.0)
    start = cur
    last_c = None                 # последняя контрольная точка (для S/T)
    last_cmd = ''
    cmd = None

    def flush(closed):
        nonlocal pts
        if len(pts) >= 2:
            subs.append((pts, closed))
        pts = []

    while True:
        c = sc.cmd()
        if c is None:
            if cmd is None or not sc.more():
                break
            c = cmd                                         # повтор команды без буквы
            if c in 'Mm':
                c = 'L' if c == 'M' else 'l'                # после M неявные пары — это L
        cmd = c
        rel = c.islower()
        C = c.upper()
        if C == 'Z':
            if pts:
                flush(True)
            cur = start
            last_c = None
            last_cmd = 'Z'
            cmd = None
            continue
        try:
            if C == 'M':
                x, y = sc.num(), sc.num()
                if rel:
                    x, y = cur[0] + x, cur[1] + y
                flush(False)
                cur = start = (x, y)
                pts = [cur]
                last_c = None
            elif C in 'LHV':
                if C == 'L':
                    x, y = sc.num(), sc.num()
                    if rel:
                        x, y = cur[0] + x, cur[1] + y
                elif C == 'H':
                    x = sc.num()
                    x, y = (cur[0] + x if rel else x), cur[1]
                else:
                    y = sc.num()
                    x, y = cur[0], (cur[1] + y if rel else y)
                if not pts:
                    pts = [cur]
                cur = (x, y)
                pts.append(cur)
                last_c = None
            elif C in 'CS':
                if C == 'C':
                    x1, y1 = sc.num(), sc.num()
                    if rel:
                        x1, y1 = cur[0] + x1, cur[1] + y1
                else:
                    if last_c is not None and last_cmd in 'CS':
                        x1, y1 = 2 * cur[0] - last_c[0], 2 * cur[1] - last_c[1]
                    else:
                        x1, y1 = cur
                x2, y2, x, y = sc.num(), sc.num(), sc.num(), sc.num()
                if rel:
                    x2, y2, x, y = cur[0] + x2, cur[1] + y2, cur[0] + x, cur[1] + y
                if not pts:
                    pts = [cur]
                pts += _cubic(cur, (x1, y1), (x2, y2), (x, y), _segs(cur, (x1, y1), (x2, y2), (x, y)))
                last_c = (x2, y2)
                cur = (x, y)
            elif C in 'QT':
                if C == 'Q':
                    x1, y1 = sc.num(), sc.num()
                    if rel:
                        x1, y1 = cur[0] + x1, cur[1] + y1
                else:
                    if last_c is not None and last_cmd in 'QT':
                        x1, y1 = 2 * cur[0] - last_c[0], 2 * cur[1] - last_c[1]
                    else:
                        x1, y1 = cur
                x, y = sc.num(), sc.num()
                if rel:
                    x, y = cur[0] + x, cur[1] + y
                if not pts:
                    pts = [cur]
                pts += _quad(cur, (x1, y1), (x, y), _segs(cur, (x1, y1), (x, y)))
                last_c = (x1, y1)
                cur = (x, y)
            elif C == 'A':
                rx, ry, phi = sc.num(), sc.num(), sc.num()
                large, sweep = sc.flag(), sc.flag()
                x, y = sc.num(), sc.num()
                if rel:
                    x, y = cur[0] + x, cur[1] + y
                if not pts:
                    pts = [cur]
                pts += _arc(cur, rx, ry, phi, large, sweep, (x, y))
                cur = (x, y)
                last_c = None
            else:
                raise SvgError(f'неизвестная команда контура «{c}»')
        except SvgError:
            break                                            # оборванный контур — рисуем, что успели
        last_cmd = C
        if len(pts) > MAX_POINTS * 4:
            break
    flush(False)
    return subs


def _ellipse_pts(cx, cy, rx, ry, n=48):
    return [(cx + rx * math.cos(2 * math.pi * k / n), cy + ry * math.sin(2 * math.pi * k / n)) for k in range(n)]


def _points(s):
    v = _nums(s)
    return [(v[i], v[i + 1]) for i in range(0, len(v) - 1, 2)]


# ======================================================================================
# Градиенты
# ======================================================================================
def _gradients(root):
    """id → {'kind': 'linear'|'radial', 'stops': [(pos 0..1, (r,g,b), alpha 0..1)], 'angle': градусы}."""
    raw = {el.get('id'): el for el in root.iter() if el.tag in ('linearGradient', 'radialGradient') and el.get('id')}
    out = {}
    for gid, el in raw.items():
        src = el
        for _ in range(3):                                  # стопы могут быть у «родителя» по href
            if src.findall('stop') or not (src.get('href') or '').startswith('#'):
                break
            src = raw.get(src.get('href')[1:], src)
        stops = []
        for st in src.findall('stop'):
            p = _style(st)
            off = _num(st.get('offset'), 0)
            if str(st.get('offset') or '').strip().endswith('%'):
                off /= 100
            col = color(p.get('stop-color', '#000000'))
            if not isinstance(col, tuple) or len(col) != 3:
                col = (0, 0, 0)
            stops.append((max(0.0, min(1.0, off)), col, max(0.0, min(1.0, _num(p.get('stop-opacity'), 1)))))
        if not stops:
            continue
        stops.sort(key=lambda s: s[0])
        if el.tag == 'linearGradient':
            def g(name, d):
                v = el.get(name)
                if v is None:
                    return d
                x = _num(v, d)
                return x / 100 if str(v).strip().endswith('%') else x
            x1, y1, x2, y2 = g('x1', 0), g('y1', 0), g('x2', 1), g('y2', 0)
            angle = math.degrees(math.atan2(y2 - y1, x2 - x1)) % 360 if (x1, y1) != (x2, y2) else 0
            out[gid] = {'kind': 'linear', 'stops': stops, 'angle': angle}
        else:
            out[gid] = {'kind': 'radial', 'stops': stops, 'angle': 0}
    return out


# ======================================================================================
# Сбор фигур
# ======================================================================================
def _collect(root):
    """[{kind, geom, fill, fill_a, stroke, stroke_a, sw, m}] в порядке рисования."""
    items = []
    inherit_keys = ('fill', 'stroke', 'stroke-width', 'fill-opacity', 'stroke-opacity')

    def walk(el, props, m, op):
        if el.tag in ('defs', 'linearGradient', 'radialGradient', 'stop'):
            return
        p = dict(props)
        own = _style(el)
        for k in inherit_keys:
            if k in own:
                p[k] = own[k]
        op = op * max(0.0, min(1.0, _num(own.get('opacity'), 1)))
        if el.get('transform'):
            m = _mul(m, transform(el.get('transform')))
        if el.tag in ('svg', 'g'):
            for ch in el:
                walk(ch, p, m, op)
            return
        if el.tag not in DRAWABLE or len(items) >= MAX_SHAPES:
            return
        fill = color(p.get('fill', '#000000'))
        if fill == 'inherit':
            fill = (0, 0, 0)
        stroke = color(p.get('stroke', 'none'))
        if stroke == 'inherit':
            stroke = None
        if el.tag in ('line', 'polyline'):
            fill = None if el.tag == 'line' else fill
        geom = None
        if el.tag == 'rect':
            x, y = _num(el.get('x')), _num(el.get('y'))
            w, h = _num(el.get('width')), _num(el.get('height'))
            if w <= 0 or h <= 0:
                return
            rx = el.get('rx')
            ry = el.get('ry')
            r = min(_num(rx if rx is not None else ry, 0), w / 2, h / 2)
            geom = ('rect', (x, y, w, h, max(0.0, r)))
        elif el.tag == 'circle':
            r = _num(el.get('r'))
            if r <= 0:
                return
            geom = ('ellipse', (_num(el.get('cx')), _num(el.get('cy')), r, r))
        elif el.tag == 'ellipse':
            rx, ry = _num(el.get('rx')), _num(el.get('ry'))
            if rx <= 0 or ry <= 0:
                return
            geom = ('ellipse', (_num(el.get('cx')), _num(el.get('cy')), rx, ry))
        elif el.tag == 'line':
            geom = ('poly', [([(_num(el.get('x1')), _num(el.get('y1'))), (_num(el.get('x2')), _num(el.get('y2')))], False)])
        elif el.tag in ('polyline', 'polygon'):
            pts = _points(el.get('points'))
            if len(pts) < 2:
                return
            geom = ('poly', [(pts, el.tag == 'polygon')])
        elif el.tag == 'path':
            subs = path_contours(el.get('d'))
            if not subs:
                return
            geom = ('poly', subs)
        if geom is None or (fill is None and stroke is None):
            return
        items.append({'geom': geom, 'm': m, 'fill': fill, 'stroke': stroke,
                      'fill_a': op * max(0.0, min(1.0, _num(p.get('fill-opacity'), 1))),
                      'stroke_a': op * max(0.0, min(1.0, _num(p.get('stroke-opacity'), 1))),
                      'sw': max(0.0, _num(p.get('stroke-width'), 1))})

    walk(root, {}, ID, 1.0)
    return items


def viewbox(root):
    vb = _nums(root.get('viewBox'))
    if len(vb) == 4 and vb[2] > 0 and vb[3] > 0:
        return tuple(vb)
    w, h = _num(root.get('width'), 0), _num(root.get('height'), 0)
    if w > 0 and h > 0:
        return (0.0, 0.0, w, h)
    return (0.0, 0.0, 800.0, 600.0)


def aspect(svg_text):
    """Отношение ширины к высоте рисунка."""
    try:
        vb = viewbox(_strip(_parse(svg_text)))
        return vb[2] / vb[3]
    except SvgError:
        return 4 / 3


# ======================================================================================
# Вывод в PowerPoint
# ======================================================================================
def _hex(c):
    return '%02X%02X%02X' % tuple(int(max(0, min(255, v))) for v in c)


def _set_alpha(fill_parent, alpha):
    """Прозрачность для a:srgbClr внутри a:solidFill (alpha 0..1)."""
    if alpha >= 0.999:
        return
    clr = fill_parent.find('.//' + qn('a:srgbClr'))
    if clr is not None:
        etree.SubElement(clr, qn('a:alpha')).set('val', str(int(alpha * 100000)))


def _grad_xml(g, alpha):
    gf = etree.Element(qn('a:gradFill'))
    gf.set('rotWithShape', '1')
    lst = etree.SubElement(gf, qn('a:gsLst'))
    stops = g['stops'] if len(g['stops']) > 1 else g['stops'] * 2
    for i, (pos, col, a) in enumerate(stops):
        gs = etree.SubElement(lst, qn('a:gs'))
        gs.set('pos', str(int(round((pos if len(g['stops']) > 1 else i) * 100000))))
        c = etree.SubElement(gs, qn('a:srgbClr'))
        c.set('val', _hex(col))
        if a * alpha < 0.999:
            etree.SubElement(c, qn('a:alpha')).set('val', str(int(a * alpha * 100000)))
    if g['kind'] == 'radial':
        p = etree.SubElement(gf, qn('a:path'))
        p.set('path', 'circle')
        r = etree.SubElement(p, qn('a:fillToRect'))
        for k in ('l', 't', 'r', 'b'):
            r.set(k, '50000')
    else:
        lin = etree.SubElement(gf, qn('a:lin'))
        lin.set('ang', str(int(round(g['angle'] * 60000)) % 21600000))
        lin.set('scaled', '0')
    return gf


def _style_shape(shp, it, grads, k):
    """Заливка, контур и прозрачность фигуры."""
    from .nts.effects import no_shadow
    fill = it['fill']
    if fill is None:
        shp.fill.background()
    elif isinstance(fill, tuple) and fill and fill[0] == 'url':
        g = grads.get(fill[1]) or next((v for k_, v in grads.items() if k_.lower() == fill[1].lower()), None)
        shp.fill.solid()
        if g:
            sp = shp._element.spPr
            old = sp.find(qn('a:solidFill'))
            new = _grad_xml(g, it['fill_a'])
            old.addprevious(new)
            sp.remove(old)
        else:
            shp.fill.fore_color.rgb = RGBColor(0x00, 0x78, 0xAE)
    else:
        shp.fill.solid()
        shp.fill.fore_color.rgb = RGBColor(*fill)
        _set_alpha(shp._element.spPr.find(qn('a:solidFill')), it['fill_a'])
    stroke = it['stroke']
    if stroke is None or it['sw'] <= 0:
        shp.line.fill.background()
    else:
        col = stroke
        if isinstance(stroke, tuple) and stroke and stroke[0] == 'url':
            g = grads.get(stroke[1])
            col = g['stops'][0][1] if g else (0, 50, 110)
        shp.line.color.rgb = RGBColor(*col)
        shp.line.width = Pt(max(0.25, min(24.0, it['sw'] * _scale_of(it['m']) * k * 72)))
        ln = shp._element.spPr.find(qn('a:ln'))
        if ln is not None:
            _set_alpha(ln, it['stroke_a'])
            ln.set('cap', 'rnd')
            if ln.find(qn('a:round')) is None:
                etree.SubElement(ln, qn('a:round'))
    no_shadow(shp)
    st = shp._element.find(qn('p:style'))                    # без ссылок на стиль темы (тени, контуры темы)
    if st is not None:
        shp._element.remove(st)


def draw(container, svg_text, x, y, w, h):
    """Рисует SVG фигурами PowerPoint в прямоугольнике (x, y, w, h) — дюймы, с сохранением пропорций.
    container — слайд или группа (у них есть .shapes). Возвращает число фигур. Ошибка → SvgError."""
    root = _strip(_parse(svg_text))
    vx, vy, vw, vh = viewbox(root)
    k = min(w / vw, h / vh)                                  # дюймов на единицу рисунка
    ox = x + (w - vw * k) / 2 - vx * k
    oy = y + (h - vh * k) / 2 - vy * k
    grads = _gradients(root)
    items = _collect(root)
    if not items:
        raise SvgError('в рисунке нет ни одной фигуры')

    def emu(px, py):
        return int(round((ox + px * k) * EMU_IN)), int(round((oy + py * k) * EMU_IN))

    n = 0
    for it in items:
        m = it['m']
        kind, g = it['geom']
        axis = abs(m[1]) < 1e-9 and abs(m[2]) < 1e-9          # без поворота и наклона — можно стандартной фигурой
        shp = None
        if kind == 'rect' and axis:
            rx_, ry_, rw, rh, r = g
            x1, y1 = _apply(m, rx_, ry_)
            x2, y2 = _apply(m, rx_ + rw, ry_ + rh)
            (ex1, ey1), (ex2, ey2) = emu(min(x1, x2), min(y1, y2)), emu(max(x1, x2), max(y1, y2))
            if ex2 - ex1 < 2000 or ey2 - ey1 < 2000:
                continue
            shp = container.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if r > 0 else MSO_SHAPE.RECTANGLE,
                                             Emu(ex1), Emu(ey1), Emu(ex2 - ex1), Emu(ey2 - ey1))
            if r > 0:
                shp.adjustments[0] = max(0.0, min(0.5, r / min(rw, rh)))
        elif kind == 'ellipse' and axis:
            cx, cy, rx_, ry_ = g
            x1, y1 = _apply(m, cx - rx_, cy - ry_)
            x2, y2 = _apply(m, cx + rx_, cy + ry_)
            (ex1, ey1), (ex2, ey2) = emu(min(x1, x2), min(y1, y2)), emu(max(x1, x2), max(y1, y2))
            if ex2 - ex1 < 2000 or ey2 - ey1 < 2000:
                continue
            shp = container.shapes.add_shape(MSO_SHAPE.OVAL, Emu(ex1), Emu(ey1), Emu(ex2 - ex1), Emu(ey2 - ey1))
        else:
            if kind == 'rect':
                rx_, ry_, rw, rh, _r = g
                subs = [([(rx_, ry_), (rx_ + rw, ry_), (rx_ + rw, ry_ + rh), (rx_, ry_ + rh)], True)]
            elif kind == 'ellipse':
                subs = [(_ellipse_pts(*g), True)]
            else:
                subs = g
            closed_fill = it['fill'] is not None
            contours = []
            for pts, closed in subs:
                tp = [emu(*_apply(m, px, py)) for px, py in pts[:MAX_POINTS]]
                # подряд одинаковые точки — убираем
                tp = [p for i, p in enumerate(tp) if i == 0 or p != tp[i - 1]]
                if len(tp) >= 2:
                    contours.append((tp, closed or closed_fill))
            if not contours:
                continue
            fb = container.shapes.build_freeform(contours[0][0][0][0], contours[0][0][0][1], scale=1.0)
            for ci, (tp, closed) in enumerate(contours):
                if ci:
                    fb.move_to(tp[0][0], tp[0][1])
                fb.add_line_segments(tp[1:], close=closed)
            try:
                shp = fb.convert_to_shape()
            except Exception:                                # вырожденный контур (нулевой размер)
                continue
        _style_shape(shp, it, grads, k)
        n += 1
    if n == 0:
        raise SvgError('в рисунке нет ни одной видимой фигуры')
    return n
