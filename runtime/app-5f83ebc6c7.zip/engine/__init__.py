# -*- coding: utf-8 -*-
"""
engine — ДВИЖОК КОНСТРУКТОРА ПРЕЗЕНТАЦИЙ
=======================================

Конвейер:

  файлы Word/Excel ──▶ readers ──▶ Document (model.py)
                                     │
                     ┌───────────────┴───────────────┐
                     ▼                               ▼
            planner_rules (правила)        planner_llm (локальная ИИ)
                     └───────────────┬───────────────┘
                                     ▼
                       СПЕЦИФИКАЦИЯ (spec.py, JSON) ◀── правка в веб-интерфейсе
                                     ▼
                       render.build_pptx ──▶ layouts/* ──▶ .pptx (корпоративный шаблон)

Две функции верхнего уровня — их вызывают веб-приложение (app.py) и командная строка (cli.py):
    analyze(files, options, llm_settings) → (spec, warnings, info)
    build(spec, out_path)                 → (path, warnings, slides_count)
"""
from .planner_rules import plan_rules
from .readers import SUPPORTED, read_files
from .render import build_preview_deck, build_pptx  # noqa: F401
from . import templates  # noqa: F401  (свои шаблоны оформления)
from .spec import catalog, normalize  # noqa: F401


def analyze(files, options=None, llm=None, progress=None):
    """files — [(путь, исходное_имя)]; options — настройки плана; llm — настройки ИИ или None;
    progress(event) — обратный вызов для индикатора хода (см. planner_llm.plan_llm).

    Режим options['mode']: 'rules' (по умолчанию), 'search' (правила + поиск готовых фраз моделью поиска
    в материалах и библиотеке, 1.7) или 'ai'. В режиме 'ai' при любой ошибке модели (нет связи, неверный
    ответ) используется план по правилам — с предупреждением. В режиме 'search' без модели поиска фразы
    подбираются по совпадению слов. Отмена пользователем (llm_client.Cancelled) пробрасывается наверх.
    Фразы материалов сохраняются (meta.pool) — для окна «🔎 Подходящие фразы» у слайда.
    """
    from .revise import general_options
    remarks = str((options or {}).get('remarks') or '').strip()      # общие замечания автора к презентации
    options = general_options(remarks, options or {})
    notify = progress or (lambda e: None)
    notify({'phase': 'read'})
    doc = read_files(files, notify)
    try:                                          # вид документа — до подготовки плана (1.7.2)
        from .docview import view_from_doc
        doc._view, doc._files = view_from_doc(doc), list(files)
    except Exception:                             # noqa: BLE001 — без него план всё равно строится
        doc._view = None
    from .prepare import prepare
    pinfo = prepare(doc, options)                 # документ-сценарий, пометки автора, название
    info = {'stats': doc.stats(), 'title': doc.title, 'sources': doc.sources, 'mode_used': 'rules',
            'script': pinfo['script'], 'marks': pinfo['marks']}
    if not doc.sections:
        return None, doc.warnings + ['В файлах не найдено текста или таблиц.'], info
    options = dict(options, _notify=notify, _script=bool(pinfo['script']))
    from .phrases import pool_from_doc
    doc_pool = pool_from_doc(doc)
    if options.get('mode') == 'search':
        spec, warnings = _plan_search(doc, doc_pool, options, llm, notify, info)
        _general(spec, remarks, info, options, llm if (info.get('search') or {}).get('semantic') else None)
        _keep_sources(spec, doc_pool, doc)
        return spec, warnings, info
    if options.get('mode') == 'ai' and llm:
        from .llm_client import Cancelled, describe
        from .planner_llm import plan_llm
        stats = {}
        info.update(describe(llm))              # llm_provider, llm_model, llm_cloud (облачная: данные уходят наружу)

        def prog(e):
            if e.get('phase') == 'done':
                stats.update(e.get('stats') or {})
            notify(e)
        try:
            spec, warnings = plan_llm(doc, options, llm, progress=prog)
            _general(spec, remarks, info, options, llm)
            _keep_sources(spec, doc_pool, doc)
            info['mode_used'] = 'ai'
            info['ai_level'] = 'full' if str(options.get('ai_level') or '').lower() == 'full' else 'fast'
            info['llm'] = stats
            return spec, warnings, info
        except Cancelled:
            raise
        except Exception as e:                      # noqa: BLE001
            info['llm'] = stats
            spec, warnings = plan_rules(doc, options)
            _general(spec, remarks, info, options)
            _keep_sources(spec, doc_pool, doc)
            who = f'облачной модели {info["llm_provider_name"]}' if info['llm_cloud'] else 'локальной ИИ'
            return spec, [f'Не удалось получить план от {who}: {e} План построен по правилам.'] + warnings, info
    spec, warnings = plan_rules(doc, options)
    _general(spec, remarks, info, options)
    _keep_sources(spec, doc_pool, doc)
    return spec, warnings, info


def _keep_sources(spec, doc_pool, doc):
    """Фразы материалов (окно «🔎 Подходящие фразы», meta.pool), их числа (сверка чисел, meta.facts — 1.7), вид
    документа, чтобы показать фразу в нём (meta.view — 1.7.2), тема доклада и ключевые слова материалов
    (meta.topics, meta.keywords — 1.8, по базе ключевых слов)."""
    from .phrases import save_pool
    spec['meta']['pool'] = save_pool(doc_pool)
    try:
        from .factcheck import facts_from_doc, save_facts
        spec['meta']['facts'] = save_facts(facts_from_doc(doc))
    except Exception:                                   # noqa: BLE001 — без сверки чисел план всё равно готов
        spec['meta']['facts'] = ''
    try:                                                # документ-источник для «📄 В документе» (1.7.2)
        from .docview import save_view
        spec['meta']['view'] = save_view(getattr(doc, '_view', None), getattr(doc, '_files', ()))
    except Exception:                                   # noqa: BLE001
        spec['meta']['view'] = ''
    try:                                                # тема доклада и ключевые слова материалов (1.8)
        from .keywords import detect
        found = detect([p.get('t') or '' for p in doc_pool])
        spec['meta']['topics'] = [{'id': t['id'], 'name': t['name'], 'words': t['words'][:6]} for t in found['topics']]
        spec['meta']['keywords'] = [k['w'] for k in found['keywords']][:20]
    except Exception:                                   # noqa: BLE001
        spec['meta']['topics'], spec['meta']['keywords'] = [], []


def _plan_search(doc, doc_pool, options, llm, notify, info):
    """План по правилам, «тонкие» слайды дополнены готовыми фразами из материалов, у каждого слайда —
    подходящие фразы из материалов и библиотеки. Модель поиска только сравнивает предложения по смыслу."""
    from .library import pool as library_pool
    from .phrases import Finder
    lib = library_pool()
    finder = Finder(doc_pool, lib, llm)
    notify({'phase': 'embed', 'done': 0, 'total': len(doc_pool) + len(lib)})
    finder.prepare(notify)
    spec, warnings = plan_rules(doc, dict(options, _finder=finder))
    notify({'phase': 'found'})
    finder.attach_found(spec['slides'])
    added = sum(int(s.get('found_n') or 0) for s in spec['slides'])
    info['mode_used'] = 'search'
    info['search'] = {'semantic': finder.semantic, 'phrases': len(doc_pool), 'library': len(lib), 'added': added,
                      'model': str((llm or {}).get('embed_model') or '') if finder.semantic else ''}
    return spec, finder.warnings + warnings


def _general(spec, remarks, info, options=None, llm=None):
    """План по образцу (вид и порядок слайдов — как у похожей прежней презентации из библиотеки), картинки из
    библиотеки к подходящим слайдам (если не выключены) и общие замечания, которые выполняются правилами (сократить,
    без анимации, убрать раздел…). llm — настройки моделей: тогда слайды образцов и картинки подбираются по смыслу
    (локальная модель поиска, 1.7); без неё — по словам."""
    options = options or {}
    if options.get('example', 'auto') != 'off':
        from .byexample import apply as by_example
        ecfg = llm if (llm and llm.get('embed_model')) else options.get('_embed')
        by_example(spec, options, ecfg, info, options.get('_notify'))
    if options.get('pictures', True) is not False:
        from .pictures import auto_pictures
        st = {}
        info['pictures'] = auto_pictures(spec.get('slides') or [], cfg=llm, stats=st)
        if st.get('semantic'):
            info['pictures_semantic'] = st['semantic']
    if remarks:
        from .revise import apply_general
        _, done = apply_general(spec, remarks)
        info['remarks_done'] = done


def build(spec, out_path, template=None):
    return build_pptx(spec, out_path, template)
