# -*- coding: utf-8 -*-
"""
review.py — РЕЦЕНЗЕНТ И СРАВНЕНИЕ С ЭТАЛОНАМИ (1.7)
==================================================

Две команды окна «✔ Проверить»:

  review(spec, llm, cfg, progress)    — «Замечания»: рецензент читает план как руководитель, которому его
                                        покажут. Правила находят слайды с данными без вывода, перегруз текстом,
                                        повторы, расхождения одного показателя на разных слайдах, пустые слайды,
                                        несовпадение содержания с разделами, однообразие подряд, нет выводов,
                                        нет предложения или решения, числа без источника. Локальная модель ИИ
                                        (если включена) добавляет замечания по смыслу: вывод не следует из чисел,
                                        непонятный заголовок, логика порядка.
  compare(spec, llm, cfg, progress)   — «Сравнить с эталонами»: план сравнивается с лучшими презентациями
                                        из библиотеки (⭐ эталоны, engine/library.py): число слайдов, объём текста
                                        на слайде, доля диаграмм и схем, заголовки-выводы, каркас (содержание,
                                        разделители, где выводы) и каждый слайд — с похожим слайдом эталона
                                        (модель поиска по смыслу, без неё — по словам). Модель ИИ (если включена)
                                        добавляет рекомендации, глядя на эталоны.

Результат обеих: {'mode': 'rules' | 'ai', 'deck': [замечание], 'slides': [{'i', 'title', 'items': [замечание]}],
'warnings': [...], 'etalons': {...} (у сравнения)}. Замечание:
  {'id', 'kind', 'level': 'warn' | 'tip', 'text', 'src': 'правила' | 'ИИ' | 'эталоны', 'ref'?, 'fix'?}
fix — исправление одним нажатием:
  {'label', 'slide': {...}}                — заменить слайд готовым (правила: сократить, вывод по данным, вид…);
  {'label', 'remark': '…'}                 — замечание к слайду, его выполняет модель ИИ (/api/revise);
  {'label', 'action': 'drop'}              — убрать слайд;
  {'label', 'action': 'slides', 'slides'}  — заменить слайды плана целиком (каркас, порядок, новый слайд);
  {'label', 'action': 'many', 'slides': {номер: слайд}} — заменить несколько слайдов;
  {'label', 'action': 'tab', 'tab': 'facts'} — открыть сверку чисел;
  {'label', 'action': 'set', 'path', 'raw', 'value'} — число в тексте слайда заменить числом из материалов.
Ни одно исправление не добавляет чисел, которых нет в плане: текст сокращается, вид меняется на вариант того же
содержания, выводы собираются из выводов слайдов; новые формулировки пишет только модель ИИ, а /api/revise
отменяет её правку с выдуманным числом.
"""
import copy
import json
import re
import statistics

from .textutil import clean, shorten

META = ('title', 'agenda', 'section', 'end')
TEXT_KINDS = ('list', 'text', 'cards', 'conclusions')
DATA_KINDS = ('chart', 'table', 'kpi', 'hero', 'bars', 'gauge', 'bubbles', 'compare', 'shift', 'funnel')
WORDS_MAX = {'list': 80, 'text': 90, 'cards': 80, 'conclusions': 70, 'table': 140}
WORDS_DEFAULT = 60
TITLE_MAX = 90
MAX_PER_SLIDE = 3
MAX_AI = 10
CONT = ' (продолжение)'
CONCL_RX = re.compile(r'(?i)^\W*(\d+[.)]?\s*)?(выводы?|заключение|итоги|резюме|ключевые (тезисы|итоги|выводы)|основные выводы|'
                      r'главное|коротко о главном)\b')
ASK_RX = re.compile(r'(?i)предлага|предложени|просим|прошу|решени[ея]|рекоменд|утверд|одобр|согласова|поручи|следующие шаги|'
                    r'дальнейшие (шаги|действия)|план действий')
# заголовок-вывод: число или сказуемое («выросла», «окупается», «выше плана»), а не тема («Бюджет программы»)
VERB_RX = re.compile(r'(?i)(?<![а-яё])(вырос|выросл|раст[её]т|растут|снизил|снижа|сократил|сокраща|увеличил|увеличива|'
                     r'уменьшил|достиг|превыс|превыша|обеспеч|позвол|требу|окупа|выполн|перевыполн|оста[её]т|оставал|'
                     r'состав(ил|ля)|занима|опереж|отста[её]т|отстал|сохран|улучш|ухудш|стал[аио]?(?![а-яё])|станет|будет|'
                     r'можно|нужн|необходим|да[её]т|дают|приносит|приносят|выше|ниже|больше|меньше|лучше|хуже|'
                     r'удвоил|утроил|вернул|окуп|опережа|растёт|падает|упал|упала|упали|сниз|повысил|повыша|ускор|замедл)')
NAMES_EXTRA = {'chart': 'Диаграмма', 'table': 'Таблица', 'kpi': 'Показатели', 'text': 'Текст', 'image': 'Рисунок'}
_GENERIC = {'тысяч', 'милли', 'млрд', 'рубле', 'рубля', 'годов', 'года', 'году', 'всего', 'итого', 'более', 'менее',
            'около', 'плана', 'план', 'факт', 'целом', 'также', 'этого', 'который', 'котор', 'после', 'перио'}


# --------------------------------------------------------------------------------------
# Общие помощники
# --------------------------------------------------------------------------------------
def _low(t):
    """Текст для сравнения: без типографики (неразрывные пробелы) и регистра."""
    return re.sub(r'[\s\u00a0\u202f]+', ' ', clean(str(t or ''))).strip().lower()


def _texts(s):
    from .phrases import slide_texts
    return slide_texts(s)


def words_of(s):
    """Слов на слайде без заголовка (у таблицы — и в ячейках)."""
    from .phrases import _WORD
    n = sum(len(_WORD.findall(t)) for t in _texts(s)[1:])
    if s.get('layout') == 'table':
        n += sum(len(_WORD.findall(str(c))) for r in s.get('rows') or [] if isinstance(r, list) for c in r)
    return n


def is_concl_title(t):
    """Заголовок-вывод: с числом, со сказуемым или «Тема: суть» / «Тема — суть» («Виды муфт: выбор — фрикционная»)."""
    t = clean(t or '')
    if not t or CONCL_RX.match(t):
        return False
    tail = re.split(r':\s|\s[—–]\s', t, maxsplit=1)
    return bool(re.search(r'\d', t)) or bool(VERB_RX.search(t)) or (len(tail) == 2 and len(tail[1].split()) >= 2)


def _is_concl(s):
    return s.get('layout') == 'conclusions' or bool(CONCL_RX.match(clean(s.get('title') or '')))


def _content(slides):
    """Содержательные слайды плана; свои слайды из файла PowerPoint (own) переносятся как есть — их не проверяем."""
    return [i for i, s in enumerate(slides) if s.get('layout') not in META and s.get('layout') != 'own']


def _name(lay):
    from .alternatives import NAMES
    from .spec import LAYOUTS
    return NAMES.get(lay) or NAMES_EXTRA.get(lay) or (LAYOUTS.get(lay) or {}).get('name') or lay


def _title(s, i):
    t = clean(s.get('title') or '')
    return t or {'title': 'Титульный слайд', 'end': 'Финальный слайд'}.get(s.get('layout'), f'Слайд {i + 1}')


def _finish(new):
    """Исправленный слайд — к виду плана: проверка полей (normalize) и варианты слайда заново."""
    from .alternatives import build_alts
    from .spec import normalize
    keep = {k: new[k] for k in ('notes', 'section', 'images', 'example', 'remarks', 'found', 'found_n') if k in new}
    base = {k: v for k, v in new.items() if k not in ('alts', 'alt_index')}
    norm, _ = normalize({'meta': {}, 'slides': [base]}, add_title_end=False)
    out = norm['slides'][0] if norm['slides'] else base
    if len(norm['slides']) > 1 and isinstance(out.get('items'), list):
        out['items'] = out['items'] + [it for x in norm['slides'][1:] for it in (x.get('items') or [])]
    out.update(keep)
    alts = build_alts(out)
    if alts:
        out['alts'] = alts
    return out


def _same(a, b):
    strip = lambda s: {k: v for k, v in s.items() if k not in ('alts', 'alt_index', 'alt_label', 'remarks')}
    return json.dumps(strip(a), ensure_ascii=False, sort_keys=True) == json.dumps(strip(b), ensure_ascii=False, sort_keys=True)


def _shortened(s):
    from .revise import _shorten_slide
    new = _shorten_slide(copy.deepcopy(s))
    return None if _same(new, s) else _finish(new)


class _Out:
    """Сборщик замечаний: не больше MAX_PER_SLIDE на слайд, одно замечание одного вида на слайд."""

    def __init__(self, slides):
        self.slides = slides
        self.deck, self.per = [], {}

    def add(self, i, kind, level, text, src='правила', fix=None, ref=''):
        f = {'id': f'{src}:{kind}:{i}', 'kind': kind, 'level': level, 'text': text, 'src': src}
        if ref:
            f['ref'] = ref
        if fix:
            f['fix'] = fix
        if i is None:
            if not any(x['kind'] == kind for x in self.deck):
                self.deck.append(f)
            return
        lst = self.per.setdefault(i, [])
        if any(x['kind'] == kind for x in lst) or len(lst) >= MAX_PER_SLIDE:
            return
        lst.append(f)

    def result(self, mode, warnings, **extra):
        order = {'warn': 0, 'tip': 1}
        slides = [{'i': i, 'title': _title(self.slides[i], i), 'items': sorted(v, key=lambda f: order[f['level']])}
                  for i, v in sorted(self.per.items()) if v]
        out = {'mode': mode, 'deck': sorted(self.deck, key=lambda f: order[f['level']]), 'slides': slides,
               'warnings': warnings, 'counts': {
                   'warn': sum(f['level'] == 'warn' for f in self.deck) + sum(f['level'] == 'warn' for x in slides for f in x['items']),
                   'tip': sum(f['level'] == 'tip' for f in self.deck) + sum(f['level'] == 'tip' for x in slides for f in x['items'])}}
        out.update(extra)
        return out


# --------------------------------------------------------------------------------------
# Правила рецензента
# --------------------------------------------------------------------------------------
def _takeaway(s):
    """Есть ли у слайда вывод: подпись к диаграмме, строка «Вывод», подзаголовок-фраза или заголовок-вывод."""
    if s.get('insights') or clean(s.get('conclusion') or ''):
        return True
    sub = clean(s.get('subtitle') or '')
    if sub and len(sub.split()) >= 5 and not sub.lower().startswith('единицы'):
        return True
    return is_concl_title(s.get('title'))


def _rule_takeaway(out, slides, ai):
    from .insights import make_insights
    for i in _content(slides):
        s = slides[i]
        if s.get('layout') not in DATA_KINDS or _is_concl(s) or _takeaway(s):
            continue
        fix = None
        if s.get('layout') == 'chart' and isinstance(s.get('chart'), dict):
            try:
                ins = make_insights(s['chart'])
            except Exception:                              # noqa: BLE001 — неполные данные диаграммы
                ins = []
            if ins:
                fix = {'label': 'Добавить выводы по данным', 'slide': _finish(dict(copy.deepcopy(s), insights=ins[:3]))}
        if not fix and ai:
            fix = {'label': 'Добавить вывод (ИИ)', 'remark': 'Добавь вывод одной фразой: что из этого следует для '
                   'слушателя. Только по фактам и числам этого слайда, новых чисел не добавляй.'}
        out.add(i, 'takeaway', 'tip' if s.get('layout') == 'table' else 'warn',
                'Нет вывода: слайд показывает данные, но не говорит, что из них следует.', fix=fix)


def _rule_text(out, slides):
    for i in _content(slides):
        s = slides[i]
        n, lim = words_of(s), WORDS_MAX.get(s.get('layout'), WORDS_DEFAULT)
        long_item = max((len(clean(it.get('text') or '')) for it in s.get('items') or [] if isinstance(it, dict)), default=0)
        if n <= lim and long_item <= 220:
            continue
        new = _shortened(s)
        out.add(i, 'text', 'warn', f'Много текста: {n} слов (удобно читать до {lim}). Слушатель будет читать, а не слушать.',
                fix={'label': 'Сократить', 'slide': new} if new else None)


def _rule_title(out, slides, ai):
    from .condense import topic_title
    for i in _content(slides):
        s = slides[i]
        t = clean(s.get('title') or '')
        if not t or re.match(r'(?i)^\s*(слайд|slide)\s*\d+\s*$', t):
            body = ' '.join(_texts(s)[1:])
            nt = clean(s.get('section') or '')            # раздел слайда — лучший заголовок; иначе — тема по тексту
            if not nt or _low(nt) in {_low(slides[k].get('title')) for k in _content(slides) if k != i}:
                nt = topic_title(body) if body else ''
                nt = nt if nt and len(nt.split()) <= 7 else ''
            fix = {'label': f'Заголовок «{nt}»', 'slide': _finish(dict(copy.deepcopy(s), title=nt))} if nt and nt != '__end__' \
                else ({'label': 'Придумать заголовок (ИИ)', 'remark': 'Придумай короткий заголовок слайда (до 8 слов) по его содержанию.'} if ai else None)
            out.add(i, 'title', 'warn', 'Нет заголовка: непонятно, о чём слайд.', fix=fix)
        elif len(t) > TITLE_MAX:
            fix = {'label': 'Сократить заголовок (ИИ)', 'remark': 'Сократи заголовок до 6–8 слов, смысл и числа сохрани.'} if ai else None
            out.add(i, 'title', 'tip', f'Длинный заголовок ({len(t)} знаков): на слайде он займёт две-три строки.', fix=fix)


def _rule_empty(out, slides):
    for i in _content(slides):
        s = slides[i]
        if _texts(s)[1:] or s.get('chart') or s.get('rows') or s.get('images') or s.get('svg') or s.get('illustration'):
            continue
        out.add(i, 'empty', 'warn', 'Пустой слайд: кроме заголовка на нём ничего нет.', fix={'label': 'Убрать слайд', 'action': 'drop'})


def _rule_repeat(out, slides):
    from .phrases import stems
    idx = _content(slides)
    st = {i: set(stems(' '.join(_texts(slides[i])))) for i in idx}
    for a_k, a in enumerate(idx):
        ta = _low(slides[a].get('title'))
        for b in idx[a_k + 1:]:
            tb = _low(slides[b].get('title'))
            if tb.endswith(CONT) or ta.endswith(CONT):
                continue
            sa, sb = st[a], st[b]
            dice = 2 * len(sa & sb) / (len(sa) + len(sb)) if sa and sb else 0.0
            if (ta and ta == tb and dice >= 0.5) or (dice >= 0.75 and min(len(sa), len(sb)) >= 8):
                out.add(b, 'repeat', 'warn', f'Повтор: слайд почти такой же, как слайд {a + 1} «{shorten(_title(slides[a], a), 60)}».',
                        fix={'label': 'Убрать этот слайд', 'action': 'drop'})


def _rule_contradiction(out, slides, idx=None):
    """Один и тот же показатель на разных слайдах с разными значениями (в тексте; данные диаграмм не сравниваются).
    idx — числа материалов (factcheck.Index): если в материалах есть только одно из двух чисел, другое предлагается
    заменить им."""
    from .factcheck import _words, slide_numbers
    toks = []
    for i in _content(slides):
        for n in slide_numbers(slides[i]):
            if 'series' in n['path']:
                continue
            ctx, raw = n['ctx'], n['tok']['raw']
            at = ctx.find(raw)
            near = ' '.join(ctx[:at].split()[-5:] + ctx[at + len(raw):].split()[:2]) if at >= 0 else ctx
            w = {x for x in _words(near) if x not in _GENERIC}   # название показателя — рядом с числом
            years = set(re.findall(r'(?<!\d)(?:19|20)\d\d(?!\d)', n['ctx']))
            toks.append((i, n, w, years))
    seen = set()
    for a in range(len(toks)):
        ia, na, wa, ya = toks[a]
        for b in range(a + 1, len(toks)):
            ib, nb, wb, yb = toks[b]
            if ia == ib or (ia, ib) in seen:
                continue
            ta, tb = na['tok'], nb['tok']
            if ta['p'] != tb['p'] or (ya and yb and ya != yb):
                continue
            va, vb = ta['v'] * ta['m'], tb['v'] * tb['m']
            if not va or not vb or va == vb or (va > 0) != (vb > 0):
                continue
            d = min(ta['d'], tb['d'])
            if round(ta['v'] * ta['m'] / tb['m'], d) == round(tb['v'], d) or round(tb['v'] * tb['m'] / ta['m'], d) == round(ta['v'], d):
                continue                                   # то же число, по-разному округлённое
            r = max(abs(va), abs(vb)) / min(abs(va), abs(vb))
            common = wa & wb
            if r > 1.3 or len(common) < 2 or len(common) / max(1, len(wa | wb)) < 0.34:
                continue
            seen.add((ia, ib))
            ok = lambda n: bool(idx) and idx.match(n['tok'], _words(n['ctx']), True)[0] in ('ok', 'rounded', 'derived')
            oka, okb = ok(na), ok(nb)
            if oka != okb:                                 # в материалах — только одно: другое заменить им
                (iw, nw, nr, ir) = (ib, nb, na, ia) if oka else (ia, na, nb, ib)
                fix_raw = re.search(r'[-−]?\d[\d \u00a0\u202f]*(?:[.,]\d+)?', nr['tok']['raw'])
                out.add(iw, 'contra', 'warn', f'Расхождение: здесь «{nw["tok"]["raw"]}», а на слайде {ir + 1} — «{nr["tok"]["raw"]}», '
                        f'и в материалах доклада — «{nr["tok"]["raw"]}».',
                        fix={'label': f'Заменить на {fix_raw.group(0).strip()}', 'action': 'set', 'path': nw['path'],
                             'raw': nw['tok']['raw'], 'value': fix_raw.group(0).strip()} if fix_raw else None)
                continue
            out.add(ib, 'contra', 'warn', f'Расхождение: здесь «{tb["raw"]}», а на слайде {ia + 1} «{ta["raw"]}» '
                    f'(«{shorten(na["ctx"], 70)}»). Проверьте, какое число верное.')


def _rule_agenda(out, slides):
    from .byexample import runs
    ag = next((i for i, s in enumerate(slides) if s.get('layout') == 'agenda'), None)
    if ag is None or not isinstance(slides[ag].get('items'), list):
        return
    titles = [r['title'] for r in runs(slides) if r['title']]
    low = [_low(t)[:30] for t in titles]
    items = [clean(str(it.get('text') or it.get('title') or '') if isinstance(it, dict) else str(it)) for it in slides[ag]['items']]

    def found(t):
        t = _low(t)[:30]
        return t and any(x == t or x.startswith(t[:20]) or t.startswith(x[:20]) for x in low)
    lost = [t for t in items if t and not found(t)]
    if not lost:
        return
    new = copy.deepcopy(slides[ag])
    new['items'] = [{'title': '', 'text': shorten(t, 70)} for t in titles][:10]
    out.add(ag, 'agenda', 'warn', 'Содержание не совпадает с разделами: ' + ', '.join(f'«{shorten(t, 40)}»' for t in lost[:3]) +
            (' — таких разделов в плане нет.' if len(lost) > 1 else ' — такого раздела в плане нет.'),
            fix={'label': 'Собрать содержание по разделам', 'slide': _finish(new)} if len(new['items']) >= 2 else None)


def _rule_monotone(out, slides):
    from .variety import apply_alt
    idx = _content(slides)
    k = 0
    while k < len(idx):
        lay = slides[idx[k]].get('layout')
        j = k
        while j + 1 < len(idx) and idx[j + 1] == idx[j] + 1 and slides[idx[j + 1]].get('layout') == lay:
            j += 1
        if lay in TEXT_KINDS and j - k >= 2:
            mid = idx[k + 1]
            s = slides[mid]
            alts = s.get('alts') or []
            pick = next((a for a, x in enumerate(alts) if x.get('layout') not in (lay, 'text') and a != (s.get('alt_index') or 0)), None)
            fix = {'label': f'Показать как «{alts[pick].get("alt_label") or _name(alts[pick].get("layout"))}»',
                   'slide': apply_alt(s, pick)} if pick is not None else None
            out.add(mid, 'monotone', 'tip', f'Однообразно: {j - k + 1} слайда подряд — «{_name(lay)}». Смените вид хотя бы у одного.', fix=fix)
        k = j + 1


def _conclusions_slide(slides):
    """Слайд «Выводы» из выводов самих слайдов (строка «Вывод», первая подпись диаграммы, подзаголовок-фраза)."""
    got = []
    for i in _content(slides):
        s = slides[i]
        if _is_concl(s):
            continue
        t = clean(s.get('conclusion') or '') or (clean(str(s['insights'][0])) if s.get('insights') else '')
        if not t and is_concl_title(s.get('title')):
            t = clean(s.get('title'))
        if t and _low(t) not in {_low(g) for g in got}:
            got.append(t)
    if len(got) < 2:
        return None
    return _finish({'layout': 'conclusions', 'title': 'Выводы', 'items': [{'title': '', 'text': shorten(t, 160)} for t in got[:5]]})


def _with_slide(slides, new, at=None):
    out = [s for s in slides]
    if at is None:
        at = next((i for i, s in enumerate(out) if s.get('layout') == 'end'), len(out))
    out.insert(at, new)
    return out


def _rule_deck(out, slides, facts=None):
    content = [slides[i] for i in _content(slides)]
    if len(content) >= 4 and not any(_is_concl(s) for s in content):
        new = _conclusions_slide(slides)
        out.add(None, 'concl', 'warn', 'Нет слайда с выводами: слушатель уйдёт без главного.',
                fix={'label': 'Добавить «Выводы» из выводов слайдов', 'action': 'slides', 'slides': _with_slide(slides, new)} if new else None)
    if len(content) >= 4 and not any(ASK_RX.search(' '.join(_texts(s))) for s in content[-3:] + [x for x in content if _is_concl(x)]):
        out.add(None, 'ask', 'tip', 'В конце не сказано, чего вы ждёте от слушателей: решения, одобрения, поручения. '
                'Если доклад ради решения — добавьте его в выводы.')
    if facts:
        c = facts.get('counts') or {}
        bad = (c.get('missing') or 0) + (c.get('library') or 0)
        if bad:
            out.add(None, 'facts', 'warn', f'Чисел, которых нет в материалах доклада: {bad}.',
                    fix={'label': 'Открыть сверку чисел', 'action': 'tab', 'tab': 'facts'})


# --------------------------------------------------------------------------------------
# Модель ИИ
# --------------------------------------------------------------------------------------
SYSTEM_REVIEW = """Ты — опытный рецензент презентаций для руководства нефтегазовой компании АО «Зарубежнефть».
Тебе дают план презентации: слайды с номерами, видом и текстом. Найди то, что помешает руководителю понять доклад
и принять решение: вывод не следует из чисел, слайд без мысли, непонятный или слишком общий заголовок, повтор,
противоречие между слайдами, нарушена логика порядка, в конце нет предложения или решения, жаргон и канцелярит.
Не повторяй замечания, которые уже найдены (они перечислены). Не придумывай чисел и фактов.

Ответь только JSON без пояснений:
{"deck": [{"text": "замечание ко всей презентации"}],
 "slides": [{"n": номер слайда, "level": "warn" или "tip", "text": "что не так — одна фраза",
             "remark": "что сделать со слайдом — коротко, как замечание автору; без новых чисел"}]}
Не больше 10 замечаний, только существенные. Если всё хорошо — пустые списки."""

SYSTEM_ETALON = """Ты — опытный редактор презентаций АО «Зарубежнефть». Тебе дают эталонные презентации компании
(их устройство: слайды, виды, заголовки, объём текста) и новый план. Скажи, что изменить в новом плане, чтобы он был
сделан так же хорошо, как эталоны: подача, заголовки, порядок, объём текста, наглядность. Не повторяй уже найденное
(оно перечислено). Не придумывай чисел и фактов.

Ответь только JSON без пояснений:
{"deck": [{"text": "рекомендация ко всей презентации"}],
 "slides": [{"n": номер слайда, "level": "warn" или "tip", "text": "чем слайд отличается от эталонов — одна фраза",
             "remark": "что сделать со слайдом — коротко, как замечание автору; без новых чисел"}]}
Не больше 10 рекомендаций, только существенные."""


def _outline_text(slides, limit=320):
    rows = []
    for i, s in enumerate(slides):
        if s.get('layout') == 'own':
            rows.append(f'{i + 1}. [свой слайд из файла, не меняется] {clean(s.get("title") or "")}')
            continue
        body = ' '.join(_texts(s)[1:])
        rows.append(f'{i + 1}. [{_name(s.get("layout"))}] {clean(s.get("title") or "")}' +
                    (f' — {shorten(body, limit)}' if body else ''))
    return '\n'.join(rows)


def _found_text(out):
    lines = [f'- вся презентация: {f["text"]}' for f in out.deck]
    lines += [f'- слайд {i + 1}: {f["text"]}' for i, v in sorted(out.per.items()) for f in v]
    return '\n'.join(lines) or '- ничего'


def _ask_ai(out, slides, llm, system, user, src, progress=None):
    from .llm_client import chat, extract_json
    text = chat(llm, system, user, progress=(lambda e: progress(dict(e, kind='review'))) if progress else None, max_tokens=1800)
    raw = extract_json(text)
    if not isinstance(raw, dict):
        raise ValueError('модель ответила не в том виде')
    n = 0
    for d in raw.get('deck') or []:
        t = clean(str(d.get('text') if isinstance(d, dict) else d))[:300]
        if t and n < MAX_AI:
            out.deck.append({'id': f'{src}:deck:{n}', 'kind': f'ai{n}', 'level': 'tip', 'text': t, 'src': src})
            n += 1
    for d in raw.get('slides') or []:
        if not isinstance(d, dict) or n >= MAX_AI:
            continue
        try:
            i = int(d.get('n')) - 1
        except (TypeError, ValueError):
            continue
        t = clean(str(d.get('text') or ''))[:300]
        if not (0 <= i < len(slides)) or not t or slides[i].get('layout') == 'own':
            continue
        rem = clean(str(d.get('remark') or ''))[:400]
        out.add(i, f'ai{n}', 'warn' if d.get('level') == 'warn' else 'tip', t, src=src,
                fix={'label': 'Исправить (ИИ)', 'remark': rem} if rem and slides[i].get('layout') not in ('title', 'end') else None)
        n += 1
    return n


def _fact_index(spec):
    try:
        from .factcheck import index_for
        return index_for(spec.get('meta') or {}) if (spec.get('meta') or {}).get('facts') else None
    except Exception:                                      # noqa: BLE001
        return None


def _facts(spec):
    if not (spec.get('meta') or {}).get('facts'):
        return None
    try:
        from .factcheck import verify
        r = verify(spec)
        return None if 'error' in r else r
    except Exception:                                      # noqa: BLE001 — сверка чисел не мешает рецензенту
        return None


def review(spec, llm=None, cfg=None, progress=None):
    """Замечания рецензента к плану. llm — модель ИИ (если автор включил «с ИИ»), иначе только правила."""
    from .llm_client import Cancelled
    slides = spec.get('slides') or []
    out = _Out(slides)
    ai = bool(llm and llm.get('model'))
    if progress:
        progress({'phase': 'rules'})
    _rule_empty(out, slides)
    _rule_title(out, slides, ai)
    _rule_takeaway(out, slides, ai)
    _rule_text(out, slides)
    _rule_repeat(out, slides)
    _rule_contradiction(out, slides, _fact_index(spec))
    _rule_agenda(out, slides)
    _rule_monotone(out, slides)
    _rule_deck(out, slides, _facts(spec))
    warnings, mode = [], 'rules'
    if ai:
        user = 'ПЛАН ПРЕЗЕНТАЦИИ «' + clean((spec.get('meta') or {}).get('title') or '') + '»:\n' + _outline_text(slides) + \
               '\n\nУЖЕ НАЙДЕНО:\n' + _found_text(out)
        try:
            _ask_ai(out, slides, llm, SYSTEM_REVIEW, user, 'ИИ', progress)
            mode = 'ai'
        except Cancelled:
            raise
        except Exception as e:                             # noqa: BLE001 — нет связи, неверный ответ
            warnings.append(f'Модель ИИ не ответила ({e}) — замечания найдены правилами.')
    return out.result(mode, warnings)


# --------------------------------------------------------------------------------------
# Сравнение с эталонами
# --------------------------------------------------------------------------------------
def _share(xs):
    return round(sum(1 for x in xs if x) / len(xs), 2) if xs else 0.0


def ref_stats(outline):
    """Устройство эталона (разбор pptx_reader.outline_pptx) → показатели для сравнения."""
    from .phrases import _WORD
    content = [r for r in outline if r.get('role') in ('content', 'conclusions')]
    kinds = [r.get('kind') or '' for r in content]
    words = [r['words'] if isinstance(r.get('words'), int) else len(_WORD.findall(r.get('text') or '')) for r in content]
    first = [r for r in outline if r.get('role') not in ('title', 'agenda', 'section')][:3]
    return {'n': len(content), 'words': round(statistics.median(words)) if words else 0,
            'text': _share([k in TEXT_KINDS for k in kinds]), 'chart': _share([k == 'chart' for k in kinds]),
            'visual': _share([k not in TEXT_KINDS for k in kinds]),
            'action': _share([is_concl_title(r.get('title')) for r in content if r.get('role') == 'content']),
            'agenda': any(r.get('role') == 'agenda' for r in outline),
            'sections': sum(1 for r in outline if r.get('role') == 'section'),
            'concl': any(r.get('role') == 'conclusions' for r in outline),
            'summary_first': any(r.get('role') == 'conclusions' for r in first) and len(content) >= 5}


def plan_stats(slides):
    idx = _content(slides)
    content = [slides[i] for i in idx]
    kinds = [s.get('layout') for s in content]
    words = [words_of(s) for s in content]
    first = [s for s in slides if s.get('layout') not in ('title', 'agenda', 'section')][:3]
    return {'n': len(content), 'words': round(statistics.median(words)) if words else 0,
            'text': _share([k in TEXT_KINDS for k in kinds]), 'chart': _share([k == 'chart' for k in kinds]),
            'visual': _share([k not in TEXT_KINDS for k in kinds]),
            'action': _share([is_concl_title(s.get('title')) for s in content if not _is_concl(s)]),
            'agenda': any(s.get('layout') == 'agenda' for s in slides),
            'sections': sum(1 for s in slides if s.get('layout') == 'section'),
            'concl': any(_is_concl(s) for s in content),
            'summary_first': any(_is_concl(s) for s in first) and len(content) >= 5}


def _pct(x):
    return f'{round(x * 100)} %'


def _range(vals):
    lo, hi = min(vals), max(vals)
    return f'{lo}' if lo == hi else f'{lo}–{hi}'


def _most(vals):
    return sum(1 for v in vals if v) * 2 > len(vals)


def _ref_name(d, n=None):
    nm = re.sub(r'\.pptx$', '', d['name'], flags=re.I)
    return f'«{nm}»' + (f', слайд {n}' if n else '')


def _match_slides(slides, refs, cfg, progress=None):
    """Похожий слайд эталона для каждого содержательного слайда плана: {номер: (эталон, запись, уверенность)}."""
    from .byexample import MATCH, WORDS_MATCH, match, our_text
    idx = [i for i in _content(slides) if not _is_concl(slides[i])]
    pool = [(d, r) for d in refs for r in d['slides'] if r.get('role') == 'content' and r.get('text')]
    if not idx or not pool:
        return {}, False, ''
    m, sem, why = match(cfg, [our_text(slides[i]) for i in idx], [r['text'] for _, r in pool],
                        (lambda e: progress(dict(e, phase='embed'))) if progress else None)
    floor = MATCH if sem else WORDS_MATCH
    out = {}
    for k, i in enumerate(idx):
        j = max(range(len(pool)), key=lambda j: m[k][j])
        if m[k][j] >= floor:
            out[i] = (pool[j][0], pool[j][1], round(m[k][j], 2))
    return out, sem, why


def _skeleton_like(slides, ref):
    from .byexample import _sync_agenda, skeleton
    new, done = skeleton(copy.deepcopy(slides), ref['slides'], {'agenda': 'auto', 'sections': 'auto'})
    _sync_agenda(new)
    return (new, done) if done else (None, [])


def compare(spec, llm=None, cfg=None, progress=None):
    """Сравнение плана с эталонами библиотеки. Эталонов нет → {'error', 'no_etalons': True}."""
    from .library import etalons
    from .llm_client import Cancelled
    refs = etalons()
    if not refs:
        return {'error': 'Эталонов пока нет. Отметьте ⭐ лучшие презентации в библиотеке материалов или загрузите их здесь.',
                'no_etalons': True}
    slides = spec.get('slides') or []
    out = _Out(slides)
    ai = bool(llm and llm.get('model'))
    if progress:
        progress({'phase': 'rules'})
    st = [ref_stats(d['slides']) for d in refs]
    me = plan_stats(slides)
    warnings = []
    pairs, sem, why = _match_slides(slides, refs, cfg, progress)
    if not sem and pairs is not None and why and cfg and cfg.get('embed_model'):
        warnings.append(f'Модель поиска недоступна ({why}) — похожие слайды найдены по совпадению слов.')
    # главный эталон — с наибольшим числом похожих слайдов (по нему — каркас)
    votes = {}
    for d, _, c in pairs.values():
        votes[d['id']] = votes.get(d['id'], 0) + c
    main = max(refs, key=lambda d: votes.get(d['id'], 0)) if votes else refs[-1]

    # --- вся презентация
    ns = [x['n'] for x in st]
    if me['n'] > max(ns) * 1.15 + 1:
        out.add(None, 'n', 'warn', f'В эталонах {_range(ns)} содержательных слайдов, у вас {me["n"]}. Объедините похожие слайды '
                'или перенесите подробности в приложение.', src='эталоны')
    elif me['n'] < min(ns) * 0.8 - 1:
        out.add(None, 'n', 'tip', f'В эталонах {_range(ns)} содержательных слайдов, у вас {me["n"]}: возможно, '
                'не хватает данных или выводов.', src='эталоны')
    w_ref = round(statistics.median([x['words'] for x in st]))
    if me['words'] > w_ref * 1.4 and me['words'] - w_ref >= 10:
        many = {}
        for i in _content(slides):
            if words_of(slides[i]) > max(25, w_ref * 1.5):
                new = _shortened(slides[i])
                if new:
                    many[i] = new
        out.add(None, 'words', 'warn', f'Текста на слайде больше, чем в эталонах: обычно {me["words"]} слов против {w_ref}.',
                src='эталоны', fix={'label': f'Сократить слайды: {len(many)}', 'action': 'many', 'slides': many} if many else None)
    t_ref = statistics.median([x['text'] for x in st])
    if me['text'] - t_ref > 0.25:
        out.add(None, 'visual', 'tip', f'В эталонах текстовых слайдов (списки, карточки) {_pct(t_ref)}, у вас {_pct(me["text"])}: '
                'часть слайдов лучше показать схемой, диаграммой или таблицей — см. замечания к слайдам.', src='эталоны')
    c_ref = statistics.median([x['chart'] for x in st])
    if c_ref - me['chart'] > 0.2:
        out.add(None, 'chart', 'tip', f'В эталонах диаграммы на {_pct(c_ref)} слайдов, у вас на {_pct(me["chart"])}. '
                'Если в материалах есть таблицы с числами, покажите их диаграммами.', src='эталоны')
    a_ref = statistics.median([x['action'] for x in st])
    if a_ref >= 0.5 and a_ref - me['action'] > 0.25:
        ex = [r['title'] for d in refs for r in d['slides'] if r.get('role') == 'content' and is_concl_title(r.get('title'))][:2]
        out.add(None, 'action', 'tip', f'В эталонах заголовок — вывод ({_pct(a_ref)} слайдов' +
                (', например: ' + '; '.join(f'«{shorten(t, 70)}»' for t in ex) if ex else '') +
                f'), у вас {_pct(me["action"])}. Заголовок-вывод сразу говорит, что показывает слайд.', src='эталоны')
    struct = []
    if _most([x['agenda'] for x in st]) != me['agenda']:
        struct.append('содержание' if not me['agenda'] else 'без содержания')
    ref_div = _most([x['sections'] >= 2 for x in st])
    if ref_div != (me['sections'] >= 2):
        struct.append('слайды-разделители' if ref_div else 'без разделителей')
    if struct:
        new, done = _skeleton_like(slides, main)
        text = 'Каркас не как в эталонах: в эталонах — ' + ', '.join(struct) + '.'
        if ref_div and me['sections'] < 2 and 'sections+' not in done:
            from .byexample import runs
            text += (f' Разделителей автоматически не добавить: разделов в плане {len(runs(slides))} — объедините близкие '
                     'разделы (поле «Раздел» у слайдов), и разделители встанут.')
        names = {'agenda+': 'добавить содержание', 'agenda-': 'убрать содержание', 'sections+': 'добавить разделители',
                 'sections-': 'убрать разделители'}
        label = ', '.join(names[d] for d in done if d in names)
        out.add(None, 'skeleton', 'tip', text, src='эталоны', ref=_ref_name(main),
                fix={'label': label[:1].upper() + label[1:], 'action': 'slides', 'slides': new} if new and label else None)
    if _most([x['concl'] for x in st]) and not me['concl'] and me['n'] >= 4:
        new = _conclusions_slide(slides)
        out.add(None, 'concl', 'warn', 'В эталонах есть слайд с выводами, у вас нет.', src='эталоны',
                fix={'label': 'Добавить «Выводы» из выводов слайдов', 'action': 'slides', 'slides': _with_slide(slides, new)} if new else None)
    if _most([x['summary_first'] for x in st]) and me['concl'] and not me['summary_first']:
        ci = next(i for i in _content(slides) if _is_concl(slides[i]))
        rest = [s for k, s in enumerate(slides) if k != ci]
        at = next((k for k, s in enumerate(rest) if s.get('layout') not in ('title', 'agenda')), 1)
        out.add(None, 'order', 'tip', 'В эталонах главное — в начале: выводы идут сразу после титула, а подробности — за ними.',
                src='эталоны', fix={'label': 'Перенести выводы в начало', 'action': 'slides', 'slides': _with_slide(rest, slides[ci], at)})

    # --- слайды: с похожим слайдом эталона
    from .byexample import adopt
    for i, (d, r, conf) in sorted(pairs.items()):
        s = slides[i]
        ref = _ref_name(d, r.get('n'))
        kind = r.get('kind') or ''
        if kind and kind != s.get('layout') and kind not in META:
            new, how = adopt(s, r)
            if how in ('layout', 'chart') and new.get('layout') != s.get('layout'):
                out.add(i, 'kind', 'tip', f'В эталоне похожий слайд — «{_name(new.get("layout"))}», у вас «{_name(s.get("layout"))}».',
                        src='эталоны', ref=ref, fix={'label': 'Сделать как в эталоне', 'slide': new})
        rw, mw = r.get('words') if isinstance(r.get('words'), int) else 0, words_of(s)
        if rw and mw > max(40, rw * 1.6):
            new = _shortened(s)
            out.add(i, 'words', 'tip', f'Текста больше, чем на похожем слайде эталона: {mw} слов против {rw}.', src='эталоны',
                    ref=ref, fix={'label': 'Сократить', 'slide': new} if new else None)
        if is_concl_title(r.get('title')) and not is_concl_title(s.get('title')) and not _is_concl(s):
            fix = {'label': 'Заголовок-вывод (ИИ)', 'remark': 'Перепиши заголовок как вывод: что показывает слайд, одной фразой '
                   'до 10 слов. Только по фактам и числам слайда, новых чисел не добавляй.'} if ai else None
            out.add(i, 'action', 'tip', f'В эталоне заголовок — вывод: «{shorten(r.get("title") or "", 90)}».', src='эталоны',
                    ref=ref, fix=fix)

    mode = 'rules'
    if ai:
        lines = []
        for d, x in zip(refs[-3:], st[-3:]):
            lines.append(f'Эталон {_ref_name(d)}: слайдов {x["n"]}, слов на слайде ~{x["words"]}, диаграмм {_pct(x["chart"])}, '
                         f'заголовков-выводов {_pct(x["action"])}.')
            lines += [f'  {r.get("n")}. [{_name(r.get("kind"))}] {clean(r.get("title") or "")}' for r in d['slides'][:25]]
        user = 'ЭТАЛОНЫ:\n' + '\n'.join(lines) + '\n\nНОВЫЙ ПЛАН «' + clean((spec.get('meta') or {}).get('title') or '') + \
               '»:\n' + _outline_text(slides, 220) + '\n\nУЖЕ НАЙДЕНО:\n' + _found_text(out)
        try:
            _ask_ai(out, slides, llm, SYSTEM_ETALON, user, 'эталоны (ИИ)', progress)
            mode = 'ai'
        except Cancelled:
            raise
        except Exception as e:                             # noqa: BLE001
            warnings.append(f'Модель ИИ не ответила ({e}) — сравнение сделано правилами.')
    info = {'decks': [{'id': d['id'], 'name': d['name'], 'slides': x['n']} for d, x in zip(refs, st)],
            'main': main['name'], 'semantic': sem, 'matched': len(pairs),
            'stats': {'plan': me, 'refs': {'n': _range(ns), 'words': w_ref, 'text': t_ref, 'chart': c_ref, 'action': a_ref}}}
    return out.result(mode, warnings, etalons=info)
