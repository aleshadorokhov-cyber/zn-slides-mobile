# -*- coding: utf-8 -*-
"""
photofx.py — ЭФФЕКТЫ ДЛЯ ФОТОГРАФИЙ НА СЛАЙДАХ (1.7)
=================================================

Эффекты — те же, что у PowerPoint на вкладке «Формат рисунка», и записываются в файл так же, как их
записывает PowerPoint (DrawingML): в готовой презентации их можно поменять или снять обычными средствами.

    ЭФФЕКТ (effect)                         ЦВЕТ (tone)
    frame       белая рамка с тенью         ''      как есть
    shadow      мягкая тень                 bright  ярче и контрастнее (Коррекция)
    rounded     скруглённые углы + тень     bw      чёрно-белое (Перекрасить: оттенки серого)
    oval        круг (портреты)             brand   в фирменном синем (Перекрасить: двухцветный)
    soft        сглаживание краёв           light   осветлённое, как подложка (Перекрасить: обесцвечивание)
    fade        плавное осветление к краю
    glow        подсветка фирменным зелёным
    reflection  отражение
    perspective перспектива (поворот объёмной фигуры)
    none        без эффекта

Эффект выбирают в окне плана (у каждой картинки слайда). Если автор его не выбрал, эффект предлагает
модель, которая видит изображения (та же, что даёт картинкам названия: suggest_model), а без неё — правила
по снимку: яркость, цвета, доля белого фона и место на слайде (suggest_rules). Схемы, скриншоты и рисунки
с прозрачным фоном эффекты не портят: им — рамка или ничего. Векторные рисунки (SVG) строятся фигурами,
эффекты фото к ним не применяются.

  EFFECTS, TONES — списки для окна; clean(im) — проверка значений из плана;
  placement(s, i) — где стоит картинка; stats(path) — разбор снимка; suggest(...) — выбрать эффект;
  fit_box(...) — место под эффект (круг — квадрат, отражению — запас снизу); apply(...) — записать в pptx.
"""
import re
import threading
from pathlib import Path

from lxml import etree
from pptx.oxml.ns import qn
from pptx.util import Emu, Inches, Pt

EFFECTS = {
    'frame': ('Белая рамка с тенью', 'как фотография на стенде; подходит и снимкам, и схемам'),
    'shadow': ('Мягкая тень', 'снимок чуть приподнят над слайдом'),
    'rounded': ('Скруглённые углы', 'с мягкой тенью; хорошо для двух-трёх снимков рядом'),
    'oval': ('Круг', 'для портретов людей: снимок обрезается по кругу'),
    'soft': ('Сглаживание краёв', 'края снимка плавно растворяются в фоне слайда'),
    'fade': ('Плавное осветление', 'снимок плавно светлеет к краю, где текст или подпись'),
    'glow': ('Подсветка', 'фирменное зелёное свечение вокруг снимка — для главного кадра'),
    'reflection': ('Отражение', 'зеркальное отражение под снимком (видно в PowerPoint, в предпросмотре PDF — нет)'),
    'perspective': ('Перспектива', 'снимок слегка повёрнут в глубину (видно в PowerPoint, в предпросмотре PDF — нет)'),
    'none': ('Без эффекта', 'снимок как есть'),
}
TONES = {
    '': ('Цвет как есть', ''),
    'bright': ('Ярче и контрастнее', 'для тёмных и блёклых снимков'),
    'bw': ('Чёрно-белое', 'спокойный вид; несколько разных снимков смотрятся одной серией'),
    'brand': ('В фирменном синем', 'снимок перекрашен в тёмно-синий цвет Компании'),
    'light': ('Осветлённое', 'бледный снимок, как подложка'),
}
BY = ('user', 'model', 'rules')
FADE_DIRS = ('left', 'right', 'bottom', 'top')
NAVY_HEX, GREEN_HEX, SHADOW_HEX = '00326E', '4BAF46', '1F2A44'

_STATS = {}
_STATS_LOCK = threading.Lock()


def clean(im):
    """Поля эффекта картинки из плана → проверенный словарь (неизвестные значения отбрасываются)."""
    out = {}
    if not isinstance(im, dict):
        return out
    if im.get('effect') in EFFECTS:
        out['effect'] = im['effect']
    if im.get('tone') in TONES and im.get('tone'):
        out['tone'] = im['tone']
    if out and im.get('effect_by') in BY:
        out['effect_by'] = im['effect_by']
    if out and isinstance(im.get('effect_why'), str) and im['effect_why'].strip():
        out['effect_why'] = re.sub(r'\s+', ' ', im['effect_why']).strip()[:160]
    return out


def label(effect, tone=''):
    """«Плавное осветление · чёрно-белое» — для подписи в окне и заметок."""
    name = EFFECTS.get(effect, ('', ''))[0]
    t = TONES.get(tone or '', ('', ''))[0] if tone else ''
    return ' · '.join(x for x in (name, t.lower() if t else '') if x)


# --------------------------------------------------------------------------------------
# Где стоит картинка на слайде (так же, как её ставит макет layouts/schemes.render_image)
# --------------------------------------------------------------------------------------
def placement(s, i=0):
    """{'role': 'illustration'|'grid'|'full', 'n', 'text_side': 'left'|'right'|'', 'caption': bool, 'fade': сторона}.
    illustration — один снимок справа, тезисы слева; grid — снимки слева, тезисы справа; full — без тезисов."""
    ims = [im for im in (s.get('images') or []) if isinstance(im, dict)][:3]
    n = max(1, len(ims))
    items = [it for it in (s.get('items') or []) if isinstance(it, dict) and (it.get('text') or it.get('title'))]
    im = ims[i] if 0 <= i < len(ims) else {}
    cap = bool(im.get('caption'))
    if s.get('illustration') and items and i == 0:
        return {'role': 'illustration', 'n': 1, 'text_side': 'left', 'caption': False, 'fade': 'left'}
    if items:
        return {'role': 'grid', 'n': n, 'text_side': 'right', 'caption': cap, 'fade': 'right' if n == 1 else 'bottom'}
    return {'role': 'full', 'n': n, 'text_side': '', 'caption': cap, 'fade': 'bottom'}


def describe(place, title=''):
    """Место картинки словами — для модели."""
    p = place
    where = {'illustration': 'один снимок справа, слева от него тезисы слайда',
             'grid': ('один снимок слева, справа от него тезисы' if p['n'] == 1 else
                      f'{p["n"]} снимка рядом в левой части слайда, справа тезисы'),
             'full': ('снимок крупно на весь слайд' if p['n'] == 1 else f'{p["n"]} снимка рядом на весь слайд')}[p['role']]
    return (f'Слайд «{title}». ' if title else '') + where + ('; под снимком подпись' if p['caption'] else '') + \
        '. Фон слайда белый, фирменные цвета — тёмно-синий и зелёный.'


# --------------------------------------------------------------------------------------
# Разбор снимка (без модели): яркость, контраст, насыщенность, белый фон, прозрачность
# --------------------------------------------------------------------------------------
def stats(path):
    """{'kind': 'photo'|'scheme'|'transparent', 'light', 'contrast', 'sat', 'white', 'colors', 'aspect'} или {}."""
    p = Path(str(path or ''))
    try:
        st = p.stat()
    except OSError:
        return {}
    key = f'{p}|{st.st_mtime_ns}|{st.st_size}'
    with _STATS_LOCK:
        if key in _STATS:
            return _STATS[key]
    try:
        from PIL import Image, ImageStat
        with Image.open(p) as im0:
            w, h = im0.size
            transparent = False
            if im0.mode in ('RGBA', 'LA', 'PA') or (im0.mode == 'P' and 'transparency' in im0.info):
                a = im0.convert('RGBA').getchannel('A').resize((64, 64))
                transparent = sum(1 for v in a.getdata() if v < 200) > 64 * 64 * 0.04
            im = im0.convert('RGB').resize((64, 64))
        L = im.convert('L')
        sl = ImageStat.Stat(L)
        hsv = im.convert('HSV')
        sat = ImageStat.Stat(hsv.getchannel('S')).mean[0]
        px = list(zip(L.getdata(), hsv.getchannel('S').getdata()))
        white = sum(1 for lv, sv in px if lv > 232 and sv < 25) / len(px)
        colors = len({(r >> 4, g >> 4, b >> 4) for r, g, b in im.getdata()})
    except Exception:                                      # noqa: BLE001 — непрочитанный снимок просто без разбора
        return {}
    kind = 'transparent' if transparent else ('scheme' if white > 0.42 or colors < 48 else 'photo')
    out = {'kind': kind, 'light': round(sl.mean[0]), 'contrast': round(sl.stddev[0]), 'sat': round(sat),
           'white': round(white, 2), 'colors': colors, 'aspect': round(w / max(h, 1), 2)}
    with _STATS_LOCK:
        if len(_STATS) > 500:
            _STATS.clear()
        _STATS[key] = out
    return out


def suggest_rules(st, place):
    """Эффект по разбору снимка и месту на слайде → {'effect', 'tone', 'why', 'by': 'rules'}."""
    kind = (st or {}).get('kind') or 'photo'
    if kind == 'transparent':
        return {'effect': 'none', 'tone': '', 'by': 'rules',
                'why': 'рисунок с прозрачным фоном — эффекты исказили бы его контур'}
    if kind == 'scheme':
        return {'effect': 'frame', 'tone': '', 'by': 'rules',
                'why': 'похоже на схему или скриншот — рамка отделяет его от слайда и не мешает читать'}
    tone, tone_why = '', ''
    if st.get('light', 128) < 85:
        tone, tone_why = 'bright', 'снимок тёмный — добавлена яркость'
    elif st.get('contrast', 60) < 32:
        tone, tone_why = 'bright', 'снимок блёклый — добавлен контраст'
    if place['n'] >= 2:
        eff, why = 'rounded', 'несколько снимков рядом — одинаковые скруглённые углы собирают их в серию'
    elif place['role'] == 'illustration':
        if st.get('light', 128) > 200:
            eff, why = 'rounded', 'светлый снимок на белом слайде — тень отделяет его от фона'
        else:
            eff, why = 'fade', 'снимок рядом с текстом — плавно светлеет к тезисам и сливается со слайдом'
    elif place['role'] == 'grid':
        eff, why = 'soft', 'снимок рядом с тезисами — мягкие края без жёсткой рамки'
    else:
        eff, why = ('shadow', 'крупный снимок с подписью — мягкая тень приподнимает его над слайдом') if place['caption'] \
            else ('fade', 'крупный снимок — плавно светлеет книзу, к выводу слайда')
    return {'effect': eff, 'tone': tone, 'by': 'rules', 'why': why + ('; ' + tone_why if tone_why else '')}


# --------------------------------------------------------------------------------------
# Модель, которая видит изображения, предлагает эффект
# --------------------------------------------------------------------------------------
EFFECT_PROMPT = ('Ты дизайнер презентаций нефтегазовой компании. Посмотри на изображение: оно стоит на слайде. {where}\n'
                 'Выбери один эффект для изображения, как в PowerPoint:\n{effects}\n'
                 'И цвет:\n{tones}\n'
                 'Правила: схемам, таблицам, скриншотам и логотипам — frame или none; портрету одного человека — oval; '
                 'тёмному снимку — tone bright; снимку рядом с текстом хорошо подходит fade; несколько снимков на слайде '
                 'должны выглядеть одинаково. Ответь строго JSON: '
                 '{{"effect": "…", "tone": "…", "why": "почему, 5–12 слов по-русски"}}')


def prompt(place, title=''):
    eff = '\n'.join(f'- {k}: {v[0].lower()} — {v[1]}' for k, v in EFFECTS.items())
    ton = '\n'.join(f'- {k or "none"}: {v[0].lower()}' + (f' — {v[1]}' if v[1] else '') for k, v in TONES.items())
    return EFFECT_PROMPT.format(where=describe(place, title), effects=eff, tones=ton)


def parse_answer(d):
    """Ответ модели (уже JSON) → {'effect', 'tone', 'why'} или None, если эффект не из списка."""
    if not isinstance(d, dict):
        return None
    eff = str(d.get('effect') or d.get('эффект') or '').strip().lower()
    eff = {'soft_edges': 'soft', 'softedge': 'soft', 'circle': 'oval', 'round': 'rounded', 'border': 'frame',
           'gradient': 'fade', 'no': 'none', 'reflect': 'reflection', '3d': 'perspective'}.get(eff, eff)
    if eff not in EFFECTS:
        return None
    tone = str(d.get('tone') or d.get('цвет') or '').strip().lower()
    tone = {'none': '', 'as_is': '', 'original': '', 'grayscale': 'bw', 'gray': 'bw', 'blue': 'brand', 'duotone': 'brand',
            'washout': 'light', 'brighter': 'bright'}.get(tone, tone)
    if tone not in TONES:
        tone = ''
    why = re.sub(r'\s+', ' ', str(d.get('why') or d.get('почему') or '')).strip().strip('"«»')[:160]
    return {'effect': eff, 'tone': tone, 'why': why}


def suggest_model(cfg, path, place, title=''):
    """Эффект предлагает модель, которая видит изображения. → {'effect', 'tone', 'why', 'by': 'model', 'model'}.
    Ошибка связи, модель без зрения или ответ не из списка → LLMError."""
    from .llm_client import LLMError, side_cfg, vision_json
    from .pictures import vision_jpeg
    d = vision_json(cfg, prompt(place, title), vision_jpeg(path, side=640), max_tokens=200)
    r = parse_answer(d)
    if not r:
        raise LLMError('модель ответила не эффектом из списка')
    r['why'] = r['why'] or EFFECTS[r['effect']][1]
    return dict(r, by='model', model=side_cfg(cfg, 'vision')['model'])


def suggest(s, i, cfg=None, use_model=False):
    """Эффект для картинки i слайда s: модель (если use_model и она на связи), иначе правила по снимку.
    → {'effect', 'tone', 'why', 'by', 'note'?}. Векторный рисунок → None (эффекты фото к нему не применяются)."""
    from .pictures import resolve
    ims = s.get('images') or []
    if not 0 <= i < len(ims):
        return None
    im = resolve(ims[i])
    if not im or im.get('svg') or not im.get('path'):
        return None
    place = placement(s, i)
    st = stats(im['path'])
    if use_model and cfg and st.get('kind') != 'transparent':   # прозрачный фон (значок, 3D-модель) — без эффектов, модель не нужна
        from .llm_client import LLMError
        try:
            return suggest_model(cfg, im['path'], place, s.get('title') or '')
        except LLMError as e:
            return dict(suggest_rules(st, place), note=f'модель не ответила ({e}) — эффект подобран по снимку')
    return suggest_rules(st, place)


def choose(s, i, im):
    """Эффект, которым картинка будет нарисована: выбранный автором (или предложенный и сохранённый в плане),
    иначе — по правилам. → (effect, tone, fade_dir)."""
    place = placement(s, i)
    eff, tone = im.get('effect'), im.get('tone') or ''
    if eff not in EFFECTS:
        r = suggest_rules(stats(im.get('path')), place)
        eff, tone = r['effect'], (tone if tone in TONES and tone else r['tone'])
    return eff, (tone if tone in TONES else ''), place['fade']


# --------------------------------------------------------------------------------------
# Запись эффекта в pptx
# --------------------------------------------------------------------------------------
def fit_box(effect, x, y, w, h):
    """Место под картинку с эффектом (дюймы): круг — квадрат по центру, отражению — запас снизу."""
    if effect == 'oval':
        d = min(w, h)
        return x + (w - d) / 2, y + (h - d) / 2, d, d
    if effect == 'reflection':
        k = 0.74
        return x + w * (1 - k) / 2, y, w * k, h * k
    if effect in ('frame', 'glow'):                        # рамка и свечение выходят за край — чуть меньше
        m = 0.06 if effect == 'frame' else 0.1
        return x + m, y + m, max(0.2, w - 2 * m), max(0.2, h - 2 * m)
    return x, y, w, h


_SPPR_ORDER = ('a:xfrm', 'a:custGeom', 'a:prstGeom', 'a:noFill', 'a:solidFill', 'a:gradFill', 'a:blipFill',
               'a:pattFill', 'a:grpFill', 'a:ln', 'a:effectLst', 'a:effectDag', 'a:scene3d', 'a:sp3d', 'a:extLst')
_EFF_ORDER = ('a:blur', 'a:fillOverlay', 'a:glow', 'a:innerShdw', 'a:outerShdw', 'a:prstShdw', 'a:reflection', 'a:softEdge')


def _ordered(parent, tag, order):
    """Дочерний элемент tag на своём месте по порядку схемы (PowerPoint строг к порядку)."""
    el = parent.find(qn(tag))
    if el is not None:
        return el
    el = etree.Element(qn(tag))
    pos = order.index(tag)
    after = [c for c in parent if c.tag in {qn(t) for t in order[pos + 1:]}]
    if after:
        after[0].addprevious(el)
    else:
        parent.append(el)
    return el


def _clr(parent, hexcol, alpha=None):
    c = etree.SubElement(parent, qn('a:srgbClr'))
    c.set('val', hexcol)
    if alpha is not None:
        etree.SubElement(c, qn('a:alpha')).set('val', str(int(alpha * 1000)))
    return c


def _effects(spPr):
    return _ordered(spPr, 'a:effectLst', _SPPR_ORDER)


def _add_eff(spPr, tag):
    return _ordered(_effects(spPr), tag, _EFF_ORDER)


def _shadow(spPr, blur=14, dist=4, alpha=24):
    sh = _add_eff(spPr, 'a:outerShdw')
    sh.set('blurRad', str(int(Pt(blur))))
    sh.set('dist', str(int(Pt(dist))))
    sh.set('dir', '5400000')
    sh.set('algn', 't')
    sh.set('rotWithShape', '0')
    _clr(sh, SHADOW_HEX, alpha)


def _geom(spPr, prst, adj=None):
    g = spPr.find(qn('a:prstGeom'))
    if g is None:
        g = _ordered(spPr, 'a:prstGeom', _SPPR_ORDER)
    g.set('prst', prst)
    for c in list(g):
        g.remove(c)
    av = etree.SubElement(g, qn('a:avLst'))
    if adj is not None:
        gd = etree.SubElement(av, qn('a:gd'))
        gd.set('name', 'adj')
        gd.set('fmla', f'val {int(adj)}')


def _line(spPr, pt, hexcol='FFFFFF'):
    ln = _ordered(spPr, 'a:ln', _SPPR_ORDER)
    for c in list(ln):
        ln.remove(c)
    ln.set('w', str(int(Pt(pt))))
    _clr(etree.SubElement(ln, qn('a:solidFill')), hexcol)


PIXEL_TONES = ('bright', 'light')


def toned_path(path, tone):
    """«Ярче» и «осветлённое» записываются в сам снимок (Pillow): коррекцию яркости из файла PowerPoint
    предпросмотр LibreOffice не показывает. Копия — в output/cache/fx; другие цвета — как есть (путь тот же)."""
    if tone not in PIXEL_TONES:
        return path
    import hashlib
    from PIL import Image, ImageEnhance
    from .nts import config as C
    p = Path(path)
    try:
        st = p.stat()
    except OSError:
        return path
    key = hashlib.sha1(f'{p}|{st.st_mtime_ns}|{st.st_size}|{tone}'.encode('utf-8')).hexdigest()[:20]
    out_dir = C.OUTPUT_DIR / 'cache' / 'fx'
    try:
        with Image.open(p) as im0:
            alpha = im0.mode in ('RGBA', 'LA') or (im0.mode == 'P' and 'transparency' in im0.info)
            dst = out_dir / f'{key}{".png" if alpha else ".jpg"}'
            if dst.exists():
                return str(dst)
            im = im0.convert('RGBA' if alpha else 'RGB')
        rgb = im.convert('RGB')
        if tone == 'bright':
            rgb = ImageEnhance.Contrast(ImageEnhance.Brightness(rgb).enhance(1.18)).enhance(1.15)
        else:                                               # обесцвечивание (как «Перекрасить → Подложка»)
            rgb = Image.blend(ImageEnhance.Contrast(rgb).enhance(0.45), Image.new('RGB', rgb.size, 'white'), 0.55)
        out_dir.mkdir(parents=True, exist_ok=True)
        if alpha:
            rgb.putalpha(im.getchannel('A'))
            rgb.save(dst, 'PNG', optimize=True)
        else:
            rgb.save(dst, 'JPEG', quality=90)
        return str(dst)
    except Exception:                                      # noqa: BLE001 — не вышло — снимок как есть
        return path


def _tone(pic, tone):
    blip = pic._element.blipFill.find(qn('a:blip'))
    if blip is None or not tone or tone in PIXEL_TONES:
        return
    ext = blip.find(qn('a:extLst'))

    def add(tag):
        el = etree.Element(qn(tag))
        if ext is not None:
            ext.addprevious(el)
        else:
            blip.append(el)
        return el
    if tone == 'bw':
        add('a:grayscl')
    elif tone == 'brand':
        duo = add('a:duotone')
        c = _clr(duo, NAVY_HEX)
        etree.SubElement(c, qn('a:shade')).set('val', '45000')
        etree.SubElement(c, qn('a:satMod')).set('val', '135000')
        etree.SubElement(duo, qn('a:prstClr')).set('val', 'white')


def _crop_square(pic):
    """Круг: снимок обрезается до квадрата (по ширине — по центру, по высоте — ближе к верху, где обычно лицо)."""
    import io
    from PIL import Image
    try:
        with Image.open(io.BytesIO(pic.image.blob)) as im:
            w, h = im.size
    except Exception:                                      # noqa: BLE001
        return
    if w > h:
        k = (1 - h / w) / 2
        pic.crop_left, pic.crop_right = k, k
    elif h > w:
        k = 1 - w / h
        pic.crop_top, pic.crop_bottom = k * 0.25, k * 0.75


def _fade(g, x, y, w, h, side, bg='FFFFFF'):
    """Плавное осветление: поверх снимка — прямоугольник с градиентом от прозрачного к цвету фона слайда.
    Так делают в PowerPoint вручную; фигуру можно сдвинуть или удалить."""
    from pptx.enum.shapes import MSO_SHAPE
    shp = g.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    shp.name = 'Плавное осветление'
    shp.line.fill.background()
    spPr = shp._element.spPr
    for tag in ('a:solidFill', 'a:noFill', 'a:gradFill'):
        for c in spPr.findall(qn(tag)):
            spPr.remove(c)
    gf = _ordered(spPr, 'a:gradFill', _SPPR_ORDER)
    gf.set('rotWithShape', '1')
    gs = etree.SubElement(gf, qn('a:gsLst'))
    for pos, a in ((0, 0), (40000, 0), (78000, 70), (100000, 100)):
        st = etree.SubElement(gs, qn('a:gs'))
        st.set('pos', str(pos))
        _clr(st, bg, a)
    lin = etree.SubElement(gf, qn('a:lin'))
    lin.set('ang', str({'right': 0, 'bottom': 5400000, 'left': 10800000, 'top': 16200000}[side]))
    lin.set('scaled', '0')
    _effects(spPr)                                         # без тени темы
    tb = shp._element.find(qn('p:txBody'))
    if tb is not None:
        shp._element.remove(tb)
    return shp


def apply(g, pic, effect, tone='', fade_dir='left', box=None):
    """Записывает эффект и цвет в картинку pic (p:pic). g — группа, в которой лежит картинка (для накладки
    «плавного осветления»), box — (x, y, w, h) картинки в дюймах."""
    spPr = pic._element.spPr
    _tone(pic, tone)
    if effect == 'frame':
        _line(spPr, 6)
        _shadow(spPr, 14, 4, 22)
    elif effect == 'shadow':
        _shadow(spPr, 18, 5, 30)
    elif effect == 'rounded':
        _geom(spPr, 'roundRect', 7000)
        _shadow(spPr, 14, 4, 24)
    elif effect == 'oval':
        _crop_square(pic)
        _geom(spPr, 'ellipse')
        _line(spPr, 3)
        _shadow(spPr, 12, 3, 24)
    elif effect == 'soft':
        x, y, w, h = box or (0, 0, Emu(pic.width).inches, Emu(pic.height).inches)
        _add_eff(spPr, 'a:softEdge').set('rad', str(int(Inches(min(w, h) * 0.09))))
    elif effect == 'glow':
        gl = _add_eff(spPr, 'a:glow')
        gl.set('rad', str(int(Pt(9))))
        _clr(gl, GREEN_HEX, 50)
    elif effect == 'reflection':
        r = _add_eff(spPr, 'a:reflection')
        for k, v in (('blurRad', '6350'), ('stA', '45000'), ('endA', '300'), ('endPos', '30000'), ('dist', '25400'),
                     ('dir', '5400000'), ('sy', '-100000'), ('algn', 'bl'), ('rotWithShape', '0')):
            r.set(k, v)
    elif effect == 'perspective':
        _shadow(spPr, 16, 6, 22)
        sc = _ordered(spPr, 'a:scene3d', _SPPR_ORDER)
        cam = etree.SubElement(sc, qn('a:camera'))
        cam.set('prst', 'perspectiveContrastingLeftFacing' if fade_dir == 'left' else 'perspectiveContrastingRightFacing')
        lr = etree.SubElement(sc, qn('a:lightRig'))
        lr.set('rig', 'threePt')
        lr.set('dir', 't')
    elif effect == 'fade' and box:
        _effects(spPr)
        _fade(g, *box, fade_dir if fade_dir in FADE_DIRS else 'left')
    else:
        _effects(spPr)                                     # «без эффекта»: пустой список — и без тени темы
    return pic
