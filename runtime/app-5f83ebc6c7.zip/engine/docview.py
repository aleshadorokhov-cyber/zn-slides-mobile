# -*- coding: utf-8 -*-
"""
docview.py — ДОКУМЕНТ-ИСТОЧНИК С ВЫДЕЛЕННОЙ ФРАЗОЙ (1.7.2)
=========================================================

Щелчок по найденной фразе («🔎 Подходящие фразы» у слайда) открывает документ, из которого она взята, и
показывает её выделением цветом. Работает для материалов доклада и для «📚 Библиотеки материалов».

  * Вид документа — его текст в том порядке, в каком его прочитал конструктор: заголовки, абзацы, пункты
    списков, таблицы, подписи рисунков; по файлам материалов. Снимок делается при анализе ДО подготовки
    плана (prepare меняет заголовки и может убирать разделы) и хранится в output/cache/views/<id>.json
    (7 дней, как фразы и числа — meta.view). У библиотеки — output/library/views/<id>.json, а у файлов,
    добавленных до 1.7.2, строится при первом открытии из самого файла.
  * Где фраза — сравнение только букв и цифр (без пробелов, знаков, кавычек и тире, «ё» = «е»), поэтому
    находится и фраза из PDF с переносами, и абзац Word с неразрывными пробелами; нет целиком — по началу
    фразы, затем по одним буквам (в тексте некоторых PDF числа стоят не на своём месте).
  * Оригинал с выделением: Word (.docx) — копия файла, где фраза выделена маркером (жёлтым, остальные
    найденные — бирюзовым; прежнее выделение маркером в копии снято); PDF — копия с пометками-выделением, открывается на нужной странице. Оригиналы
    материалов доклада (только .docx и .pdf) хранятся в output/cache/src/ те же 7 дней; у библиотеки
    оригинал — её собственный файл.

  view_from_doc(doc) → снимок;  save_view(view, files) → id;  load_view(id);  library_view(id)
  locate(blocks, phrases) → [[блок, начало, конец, номер фразы]]
  pick_file(view, src, phrases) → номер файла;  docx_highlight(путь, фразы) → байты;
  pdf_highlight(путь, фразы) → (байты, страница);  pdf_page(путь, фраза) → страница
"""
import hashlib
import io
import json
import re
import shutil
from pathlib import Path

from .nts import config as C
from .textutil import clean

VIEW_DIR = C.OUTPUT_DIR / 'cache' / 'views'
SRC_DIR = C.OUTPUT_DIR / 'cache' / 'src'
VIEW_RX = re.compile(r'[0-9a-f]{16}')
ORIG_RX = re.compile(r'[0-9a-f]{16}\.(docx|pdf)')
ORIG_EXT = ('.docx', '.pdf')                 # оригинал с выделением — только для Word и PDF
MAX_ORIG = 60 * 1024 * 1024                  # больше — оригинал не хранится (вид документа есть всегда)
MAX_BLOCKS = 40000
MAX_ROWS = 300                               # строк таблицы в виде документа
MAX_CELL = 400
SEND_BLOCKS = 6000                           # в окно — не больше стольких блоков вокруг найденного места

_KEEP = re.compile(r'[0-9a-zа-я]')
_LETTER = re.compile(r'[a-zа-я]')


# --------------------------------------------------------------------------------------
# Снимок документа
# --------------------------------------------------------------------------------------
def _file_of(src, files):
    """Имя файла материалов по источнику раздела («книга.xlsx / Лист1» → «книга.xlsx»)."""
    src = str(src or '')
    for f in files:
        if src == f or src.startswith(f + ' / '):
            return f
    return files[0] if files else src


def view_from_doc(doc):
    """Текст документа по файлам: {'v': 1, 'files': [{'name', 'ext', 'blocks': [...]}]}.
    Блок — {'k': 'h' (заголовок, 'l' — уровень) | 'p' (абзац) | 'li' (пункт, 'l' — уровень, 'o' — номер)
    | 'tb' (таблица: 't' — название, 'c' — столбцы, 'r' — строки) | 'img' (рисунок: подпись), 't': текст}."""
    files = [str(s) for s in (getattr(doc, 'sources', None) or [])]
    out, n = {}, [0]

    def blocks_of(name):
        if name not in out:
            out[name] = []
        return out[name]

    def add(name, b):
        if n[0] < MAX_BLOCKS:
            blocks_of(name).append(b)
            n[0] += 1

    def walk(sec, depth):
        name = _file_of(getattr(sec, 'source', ''), files)
        title = clean(sec.title or '')
        if title and (sec.level or 0) > 0:
            add(name, {'k': 'h', 'l': max(1, min(4, depth)), 't': title})
        for b in sec.blocks:
            if b.kind == 'para' and clean(b.text):
                add(name, dict({'k': 'p', 't': b.text.strip()}, **({'m': 1} if b.mark or b.mark_text else {})))
            elif b.kind == 'list':
                for i, it in enumerate(b.items):
                    if clean(it.text):
                        add(name, {'k': 'li', 't': it.text.strip(), 'l': max(0, min(4, it.level or 0)),
                                   'o': (i + 1) if b.ordered else 0})
            elif b.kind == 'table':
                t = doc.tables.get(b.table_id)
                if t is not None:
                    add(name, {'k': 'tb', 't': clean(t.title or ''), 'id': t.id,
                               'c': [str(c)[:MAX_CELL] for c in (t.columns or [])],
                               'r': [[str(c)[:MAX_CELL] for c in row] for row in (t.rows or [])[:MAX_ROWS]],
                               'more': max(0, len(t.rows or []) - MAX_ROWS)})
            elif b.kind == 'image':
                add(name, {'k': 'img', 't': clean(b.text or '')})
        for ch in sec.children:
            walk(ch, depth + 1)

    for s in doc.sections:
        walk(s, 1)
    order = [f for f in files if f in out] + [f for f in out if f not in files]
    return {'v': 1, 'files': [{'name': f, 'ext': Path(f).suffix.lower(), 'blocks': out[f]} for f in order]}


def _keep_original(path, name):
    """Копия оригинала материалов (Word, PDF) в output/cache/src/ → имя файла в кэше или ''."""
    ext = Path(str(name)).suffix.lower()
    try:
        p = Path(path)
        if ext not in ORIG_EXT or not p.is_file() or p.stat().st_size > MAX_ORIG:
            return ''
        h = hashlib.sha1()
        with open(p, 'rb') as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b''):
                h.update(chunk)
        key = f'{h.hexdigest()[:16]}{ext}'
        SRC_DIR.mkdir(parents=True, exist_ok=True)
        dst = SRC_DIR / key
        if dst.exists():
            dst.touch()
        else:
            tmp = dst.with_suffix('.tmp')
            shutil.copyfile(p, tmp)
            tmp.replace(dst)
        return key
    except OSError:
        return ''


def save_view(view, files=()):
    """Снимок → output/cache/views/<id>.json (оригиналы Word и PDF — рядом, в output/cache/src/). → id или ''."""
    if not view or not view.get('files'):
        return ''
    names = {str(n): p for p, n in (files or [])}
    for f in view['files']:
        if f['name'] in names:
            key = _keep_original(names[f['name']], f['name'])
            if key:
                f['orig'] = key
    data = json.dumps(view, ensure_ascii=False, separators=(',', ':'))
    vid = hashlib.sha1(data.encode('utf-8')).hexdigest()[:16]
    try:
        VIEW_DIR.mkdir(parents=True, exist_ok=True)
        p = VIEW_DIR / f'{vid}.json'
        if p.exists():
            p.touch()
        else:
            tmp = p.with_suffix('.tmp')
            tmp.write_text(data, encoding='utf-8')
            tmp.replace(p)
    except OSError:
        return ''
    return vid


def load_view(vid):
    """Снимок по id (нет — удалён очисткой кэша через 7 дней) → словарь или None."""
    if not VIEW_RX.fullmatch(str(vid or '')):
        return None
    p = VIEW_DIR / f'{vid}.json'
    try:
        d = json.loads(p.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None
    try:
        p.touch()                                     # открывали — пусть поживёт ещё
    except OSError:
        pass
    return d if isinstance(d, dict) and isinstance(d.get('files'), list) else None


def original_path(key):
    """Путь к оригиналу материалов в кэше по имени из снимка (или None)."""
    if not ORIG_RX.fullmatch(str(key or '')):
        return None
    p = SRC_DIR / key
    return p if p.is_file() else None


def library_view(fid):
    """Снимок файла библиотеки (output/library/views/<id>.json); у файлов, добавленных до 1.7.2, — строится из файла.
    → (снимок, путь к файлу) или (None, None)."""
    from . import library as L
    if not L.ID_RX.fullmatch(str(fid or '')):
        return None, None
    e = next((x for x in L.items() if x.get('id') == fid), None)
    path = next(iter((L.LIB_DIR / 'files').glob(f'{fid}.*')), None)
    if not e or not path:
        return None, None
    vp = L.LIB_DIR / 'views' / f'{fid}.json'
    try:
        d = json.loads(vp.read_text(encoding='utf-8'))
        if isinstance(d, dict) and isinstance(d.get('files'), list):
            return d, path
    except (OSError, ValueError):
        pass
    from .readers import read_files
    view = view_from_doc(read_files([(str(path), e['name'])]))
    try:
        vp.parent.mkdir(parents=True, exist_ok=True)
        vp.write_text(json.dumps(view, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    except OSError:
        pass
    return view, path


# --------------------------------------------------------------------------------------
# Где фраза
# --------------------------------------------------------------------------------------
def norm_map(text, digits=True):
    """Только буквы и цифры (digits=False — только буквы) в нижнем регистре («ё» → «е») и для каждого — место
    в исходном тексте."""
    keep, idx = [], []
    rx = _KEEP if digits else _LETTER
    for i, ch in enumerate(str(text or '')):
        c = ch.lower()
        if c == 'ё':
            c = 'е'
        if rx.match(c):
            keep.append(c)
            idx.append(i)
    return ''.join(keep), idx


def norm(text):
    return norm_map(text)[0]


def variants(phrase):
    """Как искать фразу: [(строка, с цифрами ли)]. Целиком; если нет — по началу (¾, 0,6 и 0,45 слов, не меньше 4 слов
    и 20 букв): фразу могли взять из длинного пункта; наконец — по одним буквам: в тексте некоторых PDF числа стоят
    не на своём месте («в среднем в год : 8–10 %»)."""
    full = norm(phrase)
    out = [(full, True)] if len(full) >= 4 else []
    words = re.findall(r'[0-9a-zа-яё]+', str(phrase or '').lower())
    if len(words) >= 6:
        for frac in (0.75, 0.6, 0.45):
            v = norm(' '.join(words[:max(4, round(len(words) * frac))]))
            if len(v) >= 20 and (v, True) not in out:
                out.append((v, True))
    letters = norm_map(phrase, digits=False)[0]
    if len(letters) >= 16 and letters != full:
        out.append((letters, False))
    return out


class Texts:
    """Набор текстов (блоки, абзацы, страницы) для поиска фраз: нормализуется один раз."""

    def __init__(self, texts):
        self.texts = list(texts)
        self.maps = [norm_map(t) for t in self.texts]
        self.lmaps = None                                    # только буквы — считаются, когда понадобятся

    def _find(self, q, digits=True):
        if not digits and self.lmaps is None:
            self.lmaps = [norm_map(t, digits=False) for t in self.texts]
        out = []
        for ti, (t, idx) in enumerate(self.maps if digits else self.lmaps):
            i = t.find(q)
            while i >= 0:
                out.append((ti, idx[i], idx[i + len(q) - 1] + 1))
                i = t.find(q, i + len(q))
        return out

    def find(self, phrase):
        """Места фразы: [(номер текста, начало, конец)] — первым вариантом поиска, который что-то нашёл."""
        for q, digits in variants(phrase):
            got = self._find(q, digits)
            if got:
                return got
        return []


def find_all(text, phrase):
    """Все места фразы в одном тексте: [(начало, конец)]."""
    return [(a, b) for _, a, b in Texts([text]).find(phrase)]


def _cells(b):
    if b.get('k') == 'tb':
        yield -1, -1, b.get('t') or ''
        for j, c in enumerate(b.get('c') or []):
            yield -1, j, c
        for i, row in enumerate(b.get('r') or []):
            for j, c in enumerate(row):
                yield i, j, c
    else:
        yield None, None, b.get('t') or ''


def locate(blocks, phrases):
    """Места фраз в блоках: [[блок, начало, конец, номер фразы]] (в таблице — [[блок, начало, конец, номер, строка,
    столбец]]; строка −1 — название или заголовок столбца)."""
    where, texts = [], []
    for bi, b in enumerate(blocks):
        for r, c, text in _cells(b):
            where.append((bi, r, c))
            texts.append(text)
    tx = Texts(texts)
    out = []
    for k, ph in enumerate(phrases):
        for ti, a, e in tx.find(ph):
            bi, r, c = where[ti]
            out.append([bi, a, e, k] + ([r, c] if r is not None else []))
    out.sort(key=lambda h: (h[0], h[1]))
    return out


def pick_file(view, src, phrases):
    """Номер файла снимка: тот, где есть первая фраза (сначала — названный в источнике фразы)."""
    files = view.get('files') or []
    if not files:
        return -1
    names = [f['name'] for f in files]
    first = _file_of(src, names) if src else names[0]
    order = sorted(range(len(files)), key=lambda i: names[i] != first)
    if phrases:
        for i in order:
            if any(h[3] == 0 for h in locate(files[i]['blocks'], phrases[:1])):
                return i
    return order[0]


def window(blocks, hits):
    """Очень длинный документ: блоки вокруг первого найденного места → (начало, блоки, места со сдвигом)."""
    if len(blocks) <= SEND_BLOCKS:
        return 0, blocks, hits
    main = next((h[0] for h in hits if h[3] == 0), hits[0][0] if hits else 0)
    a = max(0, min(main - SEND_BLOCKS // 3, len(blocks) - SEND_BLOCKS))
    b = a + SEND_BLOCKS
    return a, blocks[a:b], [[h[0] - a] + h[1:] for h in hits if a <= h[0] < b]


# --------------------------------------------------------------------------------------
# Word с выделением
# --------------------------------------------------------------------------------------
def _runs_of(p_el):
    from docx.oxml.ns import qn
    xp = './w:r | ./w:hyperlink/w:r | ./w:ins/w:r | ./w:smartTag/w:r | ./w:sdt/w:sdtContent/w:r | ./w:fldSimple/w:r'
    out = []
    for r in p_el.xpath(xp):
        for ch in r:
            if ch.tag == qn('w:t'):
                out.append((r, ch, ch.text or ''))
            elif ch.tag in (qn('w:tab'), qn('w:br'), qn('w:cr')):
                out.append((r, None, ' '))
    return out


def _split_run(r, t, a, b):
    """Отделяет символы [a, b) текста t (единственного w:t в r) в свой фрагмент → этот фрагмент (w:r)."""
    import copy
    from docx.oxml.ns import qn
    text = t.text or ''
    if a <= 0 and b >= len(text):
        return r
    parts = [(0, a), (a, b), (b, len(text))]
    made, mid = [], None
    for s, e in parts:
        if e <= s:
            continue
        nr = copy.deepcopy(r)
        for ch in list(nr):
            if ch.tag != qn('w:rPr'):
                nr.remove(ch)
        nt = copy.deepcopy(t)
        nt.text = text[s:e]
        nt.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
        nr.append(nt)
        made.append(nr)
        if (s, e) == (a, b):
            mid = nr
    for nr in made:
        r.addprevious(nr)
    r.getparent().remove(r)
    return mid


def _mark_runs(p_el, s, e, color):
    """Выделяет маркером символы [s, e) текста абзаца (по фрагментам; фрагмент с несколькими частями — целиком)."""
    from docx.text.run import Run
    from docx.oxml.ns import qn
    pos, todo = 0, []
    for r, t, text in _runs_of(p_el):
        a, b = max(s, pos), min(e, pos + len(text))
        if a < b:
            todo.append((r, t, a - pos, b - pos))
        pos += len(text)
    done = set()
    for r, t, a, b in todo:
        single = t is not None and len([c for c in r if c.tag == qn('w:t')]) == 1 and len(r) <= 2
        target = _split_run(r, t, a, b) if single and r.getparent() is not None else r
        if id(target) in done or target.getparent() is None:
            continue
        done.add(id(target))
        Run(target, None).font.highlight_color = color


def docx_highlight(path, phrases):
    """Копия документа Word: первая фраза выделена жёлтым маркером, остальные — бирюзовым; прежнее выделение маркером
    в копии снято, чтобы не путать с найденным. → (байты, найдено фраз)."""
    import docx
    from docx.enum.text import WD_COLOR_INDEX
    from docx.oxml.ns import qn
    d = docx.Document(str(path))
    for h in list(d.element.body.iter(qn('w:highlight'))):   # в копии выделены только найденные фразы
        h.getparent().remove(h)
    found = set()
    paras = [(p_el, _runs_of(p_el)) for p_el in d.element.body.iter(qn('w:p'))]
    paras = [(p_el, runs) for p_el, runs in paras if runs]
    tx = Texts([''.join(x[2] for x in runs) for _, runs in paras])
    hits = {}
    for k, ph in enumerate(phrases):
        for ti, s, e in tx.find(ph):
            hits.setdefault(ti, []).append((s, e, k))
            found.add(k)
    for ti, items in hits.items():
        for s, e, k in sorted(items, key=lambda h: -h[0]):     # с конца — места левее не сдвигаются
            _mark_runs(paras[ti][0], s, e, WD_COLOR_INDEX.YELLOW if k == 0 else WD_COLOR_INDEX.TURQUOISE)
    buf = io.BytesIO()
    d.save(buf)
    return buf.getvalue(), len(found)


# --------------------------------------------------------------------------------------
# PDF с выделением
# --------------------------------------------------------------------------------------
def _page_text(tp):
    """Текст страницы, где номер символа = номер символа PDFium (перенос в конце строки — «\x02»)."""
    import pypdfium2.raw as R
    n = tp.count_chars()
    try:
        t = tp.get_text_range(0, n)
    except Exception:                                   # noqa: BLE001
        t = ''
    if len(t) == n:
        return t
    return ''.join(chr(R.FPDFText_GetUnicode(tp.raw, i) or 32) for i in range(n))


def _pdf_places(pdf, phrases):
    """[(страница, номер фразы, начало, конец)] в номерах символов PDFium."""
    texts = []
    for pi in range(len(pdf)):
        page = pdf[pi]
        tp = page.get_textpage()
        try:
            texts.append(_page_text(tp))
        finally:
            tp.close()
            page.close()
    tx = Texts(texts)
    return [(pi, k, a, e) for k, ph in enumerate(phrases) for pi, a, e in tx.find(ph)]


def pdf_page(path, phrase):
    """Номер страницы (с 1), где фраза, или 0."""
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(str(path))
    try:
        got = _pdf_places(pdf, [phrase])
        return got[0][0] + 1 if got else 0
    finally:
        pdf.close()


def pdf_highlight(path, phrases):
    """Копия PDF с пометками-выделением (первая фраза — жёлтым, остальные — бирюзовым). → (байты, страница первой
    фразы с 1 или 0, найдено фраз)."""
    import pypdfium2 as pdfium
    import pypdfium2.raw as R
    pdf = pdfium.PdfDocument(str(path))
    try:
        places = _pdf_places(pdf, phrases)
        first = next((p for p in places if p[1] == 0), None)
        by_page = {}
        for pi, k, s, e in places:
            by_page.setdefault(pi, []).append((k, s, e))
        for pi, items in by_page.items():
            page = pdf[pi]
            tp = page.get_textpage()
            try:
                for k, s, e in items:
                    n = tp.count_rects(s, e - s)
                    rects = [tp.get_rect(i) for i in range(n)]
                    if not rects:
                        continue
                    annot = R.FPDFPage_CreateAnnot(page.raw, R.FPDF_ANNOT_HIGHLIGHT)
                    if not annot:
                        continue
                    try:
                        col = (255, 214, 0, 150) if k == 0 else (64, 200, 224, 120)
                        R.FPDFAnnot_SetColor(annot, R.FPDFANNOT_COLORTYPE_Color, *col)
                        for l, b, r, t in rects:
                            q = R.FS_QUADPOINTSF(l, t, r, t, l, b, r, b)
                            R.FPDFAnnot_AppendAttachmentPoints(annot, q)
                        box = R.FS_RECTF(min(x[0] for x in rects), max(x[3] for x in rects),
                                         max(x[2] for x in rects), min(x[1] for x in rects))
                        R.FPDFAnnot_SetRect(annot, box)
                    finally:
                        R.FPDFPage_CloseAnnot(annot)
            finally:
                tp.close()
                page.close()
        buf = io.BytesIO()
        pdf.save(buf)
        return buf.getvalue(), (first[0] + 1 if first else 0), len({p[1] for p in places})
    finally:
        pdf.close()
