# -*- coding: utf-8 -*-
"""
fill.py — СЛАЙД ЗАПОЛНЕН: МИНИМУМ ПУСТЫХ МЕСТ (1.9)
==================================================

Просьба пользователя: «все элементы на слайде в совокупности должны покрывать всю площадь слайда,
оставляя минимум пустых мест». Макеты рисуют элементы по своей сетке, а короткий текст оставляет
в карточках и подписях пустоты. После того как макет нарисовал слайд, здесь два шага:

  1. Текст крупнее, пока помещается. В каждой текстовой рамке с запасом места кегль растёт (до ×1,5,
     не больше 24 пт; крупные числа и заголовки ≥ 26 пт не трогаются). Однотипные рамки слайда (карточки
     одного размера) растут одинаково — кегль у них остаётся общим. Ниже текста в рамке может стоять
     другой элемент (большая цифра карточки, значок) — текст до него не дорастает.
  2. Всё содержимое слайда — на всю рабочую область. Считается рамка видимого содержимого (фигуры
     с заливкой, линии, картинки, диаграммы и сам текст, а не пустые рамки). Если она заметно меньше
     рабочей области, содержимое увеличивается целиком (до ×1,25, кегли — вместе с ним) и встаёт по
     центру; остаётся пустая полоса снизу — содержимое опускается к середине области.

Работает в координатах корпоративной сетки до переноса на свой шаблон (nts/theme.py → finish),
поэтому одинаково для корпоративного и своих шаблонов. Слайды-заставки (титул, раздел, финал)
и свои слайды из PowerPoint не меняются.
"""
from pptx.oxml.ns import qn

from ..nts import config as C
from ..nts.theme import _scale_tree
from ..textfit import LINE_FACTOR, WIDTH_SAFETY, _word_em, wrap_lines

EMU = 914400
GROW_MAX, GROW_ABS, GROW_SKIP = 1.5, 24.0, 26.0     # рост текста: во сколько раз, до какого кегля; крупнее — не трогать
GROW_ROOM = 0.9                                     # выросший текст занимает не больше 90 % места (запас на перенос)
SCALE_MAX = 1.25                                    # рост всего содержимого слайда
NO_SCALE = {'chart', 'table', 'map', 'image', 'text', 'agenda'}   # эти макеты и так по всей области
NO_GROW = {'table', 'agenda'}
_FILLS = ('solidFill', 'gradFill', 'blipFill', 'pattFill')


# ------------------------------------------------------------------ геометрия: фигуры и их место на слайде
class _Tf:
    """Перевод координат фигуры внутри групп в координаты слайда (дюймы)."""

    def __init__(self, ox=0.0, oy=0.0, kx=1.0, ky=1.0):
        self.ox, self.oy, self.kx, self.ky = ox, oy, kx, ky

    def __call__(self, x, y):
        return self.ox + x * self.kx, self.oy + y * self.ky

    def child(self, grp):
        xf = grp.find(qn('p:grpSpPr') + '/' + qn('a:xfrm'))
        if xf is None:
            return self
        off, ext, cho, che = (xf.find(qn('a:' + t)) for t in ('off', 'ext', 'chOff', 'chExt'))
        if off is None or ext is None or cho is None or che is None:
            return self
        kx = int(ext.get('cx', 0)) / max(1, int(che.get('cx', 1)))
        ky = int(ext.get('cy', 0)) / max(1, int(che.get('cy', 1)))
        ox, oy = self(int(off.get('x', 0)) / EMU, int(off.get('y', 0)) / EMU)
        cx, cy = int(cho.get('x', 0)) / EMU, int(cho.get('y', 0)) / EMU
        return _Tf(ox - cx * kx * self.kx, oy - cy * ky * self.ky, self.kx * kx, self.ky * ky)


def _xfrm(el):
    tag = el.tag
    if tag == qn('p:graphicFrame'):
        return el.find(qn('p:xfrm'))
    if tag == qn('p:grpSp'):
        return el.find(qn('p:grpSpPr') + '/' + qn('a:xfrm'))
    return el.find(qn('p:spPr') + '/' + qn('a:xfrm'))


def _rect(el, tf):
    xf = _xfrm(el)
    if xf is None or xf.find(qn('a:off')) is None or xf.find(qn('a:ext')) is None:
        return None
    off, ext = xf.find(qn('a:off')), xf.find(qn('a:ext'))
    x, y = tf(int(off.get('x', 0)) / EMU, int(off.get('y', 0)) / EMU)
    return [x, y, int(ext.get('cx', 0)) / EMU * tf.kx, int(ext.get('cy', 0)) / EMU * tf.ky]


def _painted(el):
    """Фигура видна сама по себе: заливка или линия (а не только рамка для текста)."""
    sp = el.find(qn('p:spPr'))
    if sp is None:
        return False
    if any(sp.find(qn('a:' + f)) is not None for f in _FILLS):
        return True
    ln = sp.find(qn('a:ln'))
    return ln is not None and ln.find(qn('a:noFill')) is None and (ln.find(qn('a:solidFill')) is not None or ln.find(qn('a:gradFill')) is not None)


def _walk(shapes_el, tf, out, parent=None):
    """Все фигуры (кроме групп) с местом на слайде: (элемент, [x, y, w, h], родитель)."""
    for el in shapes_el:
        tag = el.tag
        if tag == qn('p:grpSp'):
            nv = el.find(qn('p:nvGrpSpPr') + '/' + qn('p:cNvPr'))
            if nv is not None and (nv.get('name') or '').startswith('zn-'):
                continue                                   # баннер-вывод, оформление шаблона
            _walk(el, tf.child(el), out, el)
        elif tag in (qn('p:sp'), qn('p:pic'), qn('p:graphicFrame'), qn('p:cxnSp')):
            r = _rect(el, tf)
            if r is not None:
                out.append((el, r, parent))


# ------------------------------------------------------------------ текст: сколько места он занимает
def _body(el):
    tx = el.find(qn('p:txBody'))
    return tx if tx is not None and ''.join(t.text or '' for t in tx.iter(qn('a:t'))).strip() else None


def _insets(bp):
    d = {'lIns': 91440, 'rIns': 91440, 'tIns': 45720, 'bIns': 45720}
    return [int(bp.get(k, d[k])) / EMU for k in ('lIns', 'tIns', 'rIns', 'bIns')]


def _paras(tx):
    """Абзацы рамки: [(текст, кегль, шрифт, интервал строк, отступ после пт)]."""
    out = []
    for p in tx.findall(qn('a:p')):
        txt = ''.join((t.text or '') for t in p.iter(qn('a:t')))
        sizes, n_bold, major = [], 0, False
        for r in p.iter(qn('a:rPr')):
            if r.get('sz'):
                sizes.append(int(r.get('sz')) / 100)
            t = r.getparent().find(qn('a:t'))
            if t is None or not (t.text or '').strip():
                continue
            if r.get('b') == '1':
                n_bold += len(t.text)
            lat = r.find(qn('a:latin'))
            major = major or (lat is not None and (lat.get('typeface') or '').startswith('+mj'))
        # шрифт абзаца — как в проверке готового файла (deckcheck): больше половины полужирным — жирный, иначе заголовочный
        # или основной
        font = 'b' if n_bold > len(txt) / 2 else ('mj' if major else 'mn')
        if not sizes:
            e = p.find(qn('a:endParaRPr'))
            sizes = [int(e.get('sz')) / 100] if e is not None and e.get('sz') else [18.0]
        ppr = p.find(qn('a:pPr'))
        line, after, before = LINE_FACTOR, 0.0, 0.0
        if ppr is not None:
            sp = ppr.find(qn('a:lnSpc') + '/' + qn('a:spcPct'))
            if sp is not None:
                line = LINE_FACTOR * int(sp.get('val')) / 100000
            for tag, key in (('a:spcAft', 'after'), ('a:spcBef', 'before')):
                pts = ppr.find(qn(tag) + '/' + qn('a:spcPts'))
                if pts is not None:
                    if key == 'after':
                        after = int(pts.get('val')) / 100
                    else:
                        before = int(pts.get('val')) / 100
        out.append((txt, max(sizes), font, line, after + before))
    return out


def _text_size(paras, width, k=1.0, wrap=True):
    """Высота и ширина самой длинной строки текста при кегле ×k (дюймы); False — слово не влезает в строку."""
    h, wmax = 0.0, 0.0
    for i, (txt, size, font, line, gap) in enumerate(paras):
        s = size * k
        if wrap:
            lim = width * WIDTH_SAFETY * 72.0 / s
            if any(_word_em(w, font) > lim for w in txt.replace('\n', ' ').split(' ')):
                return None
            lines = wrap_lines(txt, width, s, font) if txt else ['']
        else:
            lines = txt.split('\n') or ['']
        wmax = max([wmax] + [_word_em(t, font) * s / 72.0 for t in lines])
        h += len(lines) * s * line / 72.0 + (gap * k / 72.0 if i < len(paras) - 1 else 0)
    return h, wmax


def _text_box(el, r):
    """Рамка, которую текст фигуры занимает на самом деле: [x, y, w, h] или None."""
    tx = _body(el)
    if tx is None:
        return None
    bp = tx.find(qn('a:bodyPr'))
    li, ti, ri, bi = _insets(bp)
    iw, ih = max(0.05, r[2] - li - ri), max(0.05, r[3] - ti - bi)
    wrap = bp.get('wrap') != 'none'
    got = _text_size(_paras(tx), iw, 1.0, wrap)
    if not got:
        return [r[0], r[1], r[2], r[3]]
    th, tw = min(got[0], ih), min(got[1], iw)
    anchor = bp.get('anchor', 't')
    y = r[1] + ti + (0 if anchor == 't' else ((ih - th) / 2 if anchor == 'ctr' else ih - th))
    algn = {p.find(qn('a:pPr')).get('algn') for p in tx.findall(qn('a:p')) if p.find(qn('a:pPr')) is not None} or {'l'}
    if 'ctr' in algn:
        x = r[0] + li + (iw - tw) / 2
    elif algn == {'r'}:
        x = r[0] + li + iw - tw
    else:
        x = r[0] + li
    return [x, y, tw, th]


# ------------------------------------------------------------------ шаг 1: текст крупнее, пока помещается
def _grow_factor(el, r, sibs):
    tx = _body(el)
    bp = tx.find(qn('a:bodyPr'))
    if bp.find(qn('a:normAutofit')) is not None or bp.find(qn('a:spAutoFit')) is not None:
        return None
    paras = _paras(tx)
    base = max(p[1] for p in paras)
    if base >= GROW_SKIP or base <= 0:
        return None
    li, ti, ri, bi = _insets(bp)
    iw, ih = r[2] - li - ri, r[3] - ti - bi
    if iw < 0.3 or ih < 0.15:
        return None
    wrap = bp.get('wrap') != 'none'
    if any(r.get('b') == '1' for r in tx.iter(qn('a:rPr'))):
        iw *= 0.95                                         # полужирные слова шире обычных
    now = _text_size(paras, iw, 1.0, wrap)
    if not now or now[0] > ih * 1.01:
        return None
    # ниже текста в той же рамке — другой элемент (цифра, значок): текст до него не дорастает
    anchor = bp.get('anchor', 't')
    limit = ih
    if anchor == 't':
        y_end = r[1] + ti + now[0]
        for el2, r2 in sibs:
            if el2 is el or r2[1] <= y_end + 0.02 or r2[1] >= r[1] + r[3]:
                continue
            if r2[0] <= r[0] and r2[0] + r2[2] >= r[0] + r[2] and r2[1] <= r[1]:
                continue                                   # подложка под рамкой
            ov = min(r[0] + r[2], r2[0] + r2[2]) - max(r[0], r2[0])
            if ov > 0.12 * r[2]:
                limit = min(limit, r2[1] - 0.06 - (r[1] + ti))
    for el2, r2 in sibs:                                   # текст на кружке или кольце: крупнее — вылезет за круг
        g2 = el2.find(qn('p:spPr') + '/' + qn('a:prstGeom')) if el2.tag == qn('p:sp') else None
        if el2 is not el and g2 is not None and g2.get('prst') in ('ellipse', 'donut', 'blockArc', 'arc', 'pie', 'chord'):
            cx, cy = r[0] + r[2] / 2, r[1] + r[3] / 2
            if r2[0] <= cx <= r2[0] + r2[2] and r2[1] <= cy <= r2[1] + r2[3]:
                return None
    limit *= GROW_ROOM
    if limit < now[0] * 1.08:
        return None
    k_max = min(GROW_MAX, GROW_ABS / base)
    k, best = 1.05, 1.0
    while k <= k_max + 1e-9:
        got = _text_size(paras, iw, k, wrap)
        if not got or got[0] > limit or (not wrap and got[1] > iw * WIDTH_SAFETY):
            break
        best = k
        k += 0.05
    return best if best >= 1.08 else None


def _apply_k(tx, k):
    for tag in ('a:rPr', 'a:defRPr', 'a:endParaRPr'):
        for e in tx.iter(qn(tag)):
            if e.get('sz'):
                e.set('sz', str(int(round(int(e.get('sz')) * k / 50.0)) * 50))    # шаг 0,5 пт
    for e in tx.iter(qn('a:spcPts')):
        e.set('val', str(int(int(e.get('val')) * k)))


def _growable(el):
    if el.tag != qn('p:sp') or _body(el) is None or el.find('.//' + qn('p:ph')) is not None:
        return False
    if (el.find(qn('p:nvSpPr') + '/' + qn('p:cNvPr')).get('name') or '').startswith('zn-'):
        return False
    geom = el.find(qn('p:spPr') + '/' + qn('a:prstGeom'))
    if geom is not None and geom.get('prst') in ('ellipse', 'donut', 'blockArc', 'arc'):
        return False                                       # кружки-бейджи, кольца: текст по месту
    return len(''.join(t.text or '' for t in _body(el).iter(qn('a:t'))).strip()) > 3


def grow_text(sl):
    """Шаг 1 для слайда. Возвращает, сколько рамок выросло."""
    items = []
    _walk(sl.shapes._spTree, _Tf(), items)
    by_parent = {}
    for el, r, par in items:
        by_parent.setdefault(id(par), []).append((el, r))
    groups = {}
    for el, r, par in items:
        if not _growable(el):
            continue
        paras = _paras(_body(el))
        key = (round(r[2], 1), round(r[3], 1), max(p[1] for p in paras), paras[0][2])
        groups.setdefault(key, []).append((el, _grow_factor(el, r, by_parent.get(id(par), []))))
    n = 0
    for lst in groups.values():
        if any(k is None for _, k in lst):                 # однотипные рамки растут вместе или никак
            continue
        k = min(k for _, k in lst)
        for el, _ in lst:
            _apply_k(_body(el), k)
            n += 1
    return n


# ------------------------------------------------------------------ шаг 2: всё содержимое — на всю рабочую область
def _content(sl):
    """Фигуры верхнего уровня, которые рисует макет (без заполнителей шаблона, баннера-вывода и оформления)."""
    out = []
    for el in sl.shapes._spTree:
        if el.tag not in (qn('p:sp'), qn('p:pic'), qn('p:graphicFrame'), qn('p:cxnSp'), qn('p:grpSp')):
            continue
        if el.find('.//' + qn('p:ph')) is not None and el.tag != qn('p:grpSp'):
            continue
        nv = el.find('.//' + qn('p:cNvPr'))
        if nv is not None and (nv.get('name') or '').startswith('zn-'):
            continue
        out.append(el)
    return out


def visible_box(els):
    items = []
    for el in els:
        if el.tag == qn('p:grpSp'):
            _walk(el, _Tf().child(el), items, el)
        else:
            r = _rect(el, _Tf())
            if r is not None:
                items.append((el, r, None))
    boxes = []
    for el, r, _ in items:
        if el.tag in (qn('p:pic'), qn('p:graphicFrame'), qn('p:cxnSp')) or _painted(el):
            boxes.append(r)
        elif el.tag == qn('p:sp'):
            t = _text_box(el, r)
            if t:
                boxes.append(t)
    boxes = [b for b in boxes if b[2] > 0.01 or b[3] > 0.01]
    if not boxes:
        return None
    x0 = min(b[0] for b in boxes)
    y0 = min(b[1] for b in boxes)
    return [x0, y0, max(b[0] + b[2] for b in boxes) - x0, max(b[1] + b[3] for b in boxes) - y0]


def _move(el, k, dx, dy):
    """x' = x·k + dx (дюймы) для фигуры верхнего уровня; размер ×k."""
    xf = _xfrm(el)
    if xf is None:
        return
    off, ext = xf.find(qn('a:off')), xf.find(qn('a:ext'))
    if off is not None:
        off.set('x', str(int(round(int(off.get('x', 0)) * k + dx * EMU))))
        off.set('y', str(int(round(int(off.get('y', 0)) * k + dy * EMU))))
    if ext is not None and k != 1.0:
        ext.set('cx', str(int(round(int(ext.get('cx', 0)) * k))))
        ext.set('cy', str(int(round(int(ext.get('cy', 0)) * k))))


def _boxes(els):
    """Рамки фигур (полные, включая рамки текста) и видимые части — для проверки границ слайда."""
    items = []
    for el in els:
        if el.tag == qn('p:grpSp'):
            _walk(el, _Tf().child(el), items, el)
        else:
            r = _rect(el, _Tf())
            if r is not None:
                items.append((el, r, None))
    return [r for _, r, _ in items]


def fit_area(sl, top, bottom, layout=''):
    """Содержимое слайда — крупнее и по центру рабочей области. Возвращает коэффициент (1 — не увеличивалось)."""
    els = _content(sl)
    b = visible_box(els)
    if not b or b[2] < 0.5 or b[3] < 0.3:
        return 1.0
    fx, fy, fw, fh = C.L, top + 0.05, C.CW, bottom - top - 0.05
    full = _boxes(els)
    lo_x, hi_x = 0.18, C.SLIDE_W - 0.18                    # рамки фигур не выходят за края слайда

    def place(k):
        dx = fx + (fw - b[2] * k) / 2 - b[0] * k
        dy = fy + (fh - b[3] * k) / 2 - b[1] * k
        ok = all(r[0] * k + dx >= lo_x - 1e-3 and (r[0] + r[2]) * k + dx <= hi_x + 1e-3 for r in full
                 if r[2] < C.SLIDE_W * 0.98)
        return ok, dx, dy

    k = min(fw / b[2], fh / b[3], SCALE_MAX) if layout not in NO_SCALE else 1.0
    while k >= 1.06:
        ok, dx, dy = place(k)
        if ok:
            for el in els:
                _move(el, k, dx, dy)
                _scale_tree(el, k)
            return k
        k -= 0.03
    # пустая полоса снизу заметно больше, чем сверху, — содержимое к середине области
    top_gap, bot_gap = b[1] - fy, fy + fh - (b[1] + b[3])
    if layout not in NO_SCALE and bot_gap - top_gap > fh * 0.12:
        dy = (bot_gap - top_gap) / 2
        for el in els:
            _move(el, 1.0, 0.0, dy)
    return 1.0


def fill_slide(sl, top, bottom, layout=''):
    """Оба шага для одного слайда."""
    if layout not in NO_GROW:
        grow_text(sl)
    return fit_area(sl, top, bottom, layout)
