# -*- coding: utf-8 -*-
"""
charts_ext.py — ВСЕ ВИДЫ ДИАГРАММ POWERPOINT И НАУЧНЫЕ ГРАФИКИ (1.7)
================================================================

Базовые виды (гистограмма, линейчатая, график, круговая, кольцевая, области, лепестковая, столбцы + линия)
рисует layouts/data.render_chart. Здесь — остальные виды из окна «Вставка диаграммы» PowerPoint и то, чего
в PowerPoint нет. Способы построения:

  native  — настоящая диаграмма PowerPoint с таблицей Excel внутри (правится в PowerPoint): графики с накоплением,
            точечные, пузырьковые, биржевые, поверхности, вторичная круговая, объёмные (3D) виды, линия тренда.
            Виды, которых python-pptx не создаёт, получаются правкой XML диаграммы — так, как их записывает PowerPoint.
  emul    — виды PowerPoint 2016+ (каскадная, гистограмма распределения, Парето, «ящик с усами», воронка,
            «солнечные лучи») собраны из обычных диаграмм: файл открывается в любом PowerPoint и в LibreOffice,
            данные правятся в таблице Excel диаграммы.
  shapes  — фигуры PowerPoint (правятся мышью): «дерево» (squarify), схема связей (networkx), вафельная.
  image   — картинка matplotlib / seaborn / wordcloud (то, чего нет в PowerPoint): тепловая карта, скрипичная,
            плотность распределения, контурная карта, 3D-поверхность, 3D-точки, траектории скважин, роза,
            облако слов. Данные диаграммы дублируются в заметки докладчика.

Числа на диаграммах — только из данных слайда; вычисляются лишь производные величины (накопленный итог,
доли, интервалы гистограммы, квартили), и об этом сказано в подсказке вида.

  TYPES — каталог видов (для окна диаграммы и проверки плана); prepare(ctype, cats, series) — проверка данных;
  render(ctx, sl, s, x, y, w, h) — нарисовать; notes_text(s) — данные для заметок (виды-картинки).
"""
import io
import math
import statistics

from pptx.chart.data import BubbleChartData, CategoryChartData, XyChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION, XL_MARKER_STYLE
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches as I
from pptx.util import Pt
from lxml import etree

from ..nts.config import LGRAY, rgb
from ..nts.shapes import group, rect, text
from .base import BLUE, DBLUE, DGREEN, GRAY, GREEN, LGREEN, NAVY, WHITE
from ..chart_types import (GRID_TYPES, IMAGE_TYPES, PIE_TYPES, RAW_TYPES, TOTAL_RX, TYPES, XY_TYPES,  # noqa: F401
                           edge as _edge, prepare, split_path, to_num)

HEX = {'navy': '00326E', 'blue': '0078AE', 'green': '4BAF46', 'dgreen': '0A8F2D', 'lgreen': '9AC854', 'dblue': '005491',
       'gray': '5B6B7F', 'lgray': 'C5CDD8', 'soft': 'F2F5F9', 'down': '8C9BB0'}
PALETTE = ['00326E', '4BAF46', '0078AE', '9AC854', '005491', '0A8F2D', '7FBFDD', 'A5D8A2', '5A7FA8', 'C5CDD8']
SERIES_COLORS = [NAVY, GREEN, BLUE, LGREEN, DBLUE, DGREEN]
DOWN = rgb(HEX['down'])

# --------------------------------------------------------------------------------------
# Общие помощники
# --------------------------------------------------------------------------------------
def _fmt(vals, unit=''):
    from .data import _num_format
    return _num_format([{'values': vals}], unit)


def _style_text(chart):
    chart.font.size = Pt(11)
    chart.font.name = '+mn-lt'
    chart.font.color.rgb = GRAY
    chart.has_title = False


def _legend(chart, on, pos=XL_LEGEND_POSITION.BOTTOM):
    chart.has_legend = bool(on)
    if on:
        chart.legend.position = pos
        chart.legend.include_in_layout = False
        chart.legend.font.size = Pt(12)


def _axes(chart, fmt='General', cat=True):
    try:
        va = chart.value_axis
    except Exception:                                      # noqa: BLE001 — у круговых осей нет
        return
    va.has_major_gridlines = True
    va.major_gridlines.format.line.color.rgb = rgb('E3E8EF')
    va.major_gridlines.format.line.width = Pt(0.75)
    va.format.line.fill.background()
    va.tick_labels.font.size = Pt(11)
    va.tick_labels.number_format = fmt
    va.tick_labels.number_format_is_linked = False
    if cat:
        ca = chart.category_axis
        ca.format.line.color.rgb = LGRAY
        ca.tick_labels.font.size = Pt(11)
        ca.has_major_gridlines = False


def _zero(chart, series):
    """Столбцы и области — от нуля, если все числа неотрицательные: иначе разница кажется больше, чем есть."""
    vals = [v for s in series for v in s['values'] if v is not None]
    if vals and min(vals) >= 0:
        try:
            chart.value_axis.minimum_scale = 0
        except Exception:                                  # noqa: BLE001
            pass


def _cat_data(cats, series, fmt):
    cd = CategoryChartData(number_format=fmt)
    cd.categories = cats
    for s in series:
        cd.add_series(s['name'], s['values'])
    return cd


def _add(sl, xltype, data, box):
    x, y, w, h = box
    return sl.shapes.add_chart(xltype, I(x), I(y), I(w), I(h), data)


def _plot_el(chart, *tags):
    pa = chart._chartSpace.find('.//' + qn('c:plotArea'))
    for t in tags:
        el = pa.find(qn(t))
        if el is not None:
            return pa, el
    return pa, None


def _sub(parent, tag, val=None, **attrs):
    el = etree.SubElement(parent, qn(tag))
    if val is not None:
        el.set('val', str(val))
    for k, v in attrs.items():
        el.set(k, str(v))
    return el


def _new_axis_id(pa):
    used = {a.get('val') for a in pa.iter(qn('c:axId'))}
    return next(str(x) for x in range(70001, 80000) if str(x) not in used)


def _ser_axis(pa, crossax):
    """Ось рядов (третья ось объёмных диаграмм и поверхностей), скрытая или с подписями рядов."""
    sid = _new_axis_id(pa)
    ax = etree.Element(qn('c:serAx'))
    _sub(ax, 'c:axId', sid)
    sc = _sub(ax, 'c:scaling')
    _sub(sc, 'c:orientation', 'minMax')
    _sub(ax, 'c:delete', '0')
    _sub(ax, 'c:axPos', 'b')
    _sub(ax, 'c:majorTickMark', 'out')
    _sub(ax, 'c:minorTickMark', 'none')
    _sub(ax, 'c:tickLblPos', 'nextTo')
    _sub(ax, 'c:crossAx', crossax)
    _sub(ax, 'c:crosses', 'autoZero')
    last = [e for e in pa if e.tag in (qn('c:catAx'), qn('c:valAx'), qn('c:dateAx'), qn('c:serAx'))][-1]
    last.addnext(ax)
    return sid


def _view3d(chart, rot_x=15, rot_y=20, r_ang=True, persp=30, depth=None):
    ch = chart._chartSpace.find(qn('c:chart'))
    v = ch.find(qn('c:view3D'))
    if v is None:
        v = etree.Element(qn('c:view3D'))
        anchor = ch.find(qn('c:plotArea'))
        for t in ('c:floor', 'c:sideWall', 'c:backWall'):
            if ch.find(qn(t)) is not None:
                anchor = ch.find(qn(t))
                break
        anchor.addprevious(v)
    for c in list(v):
        v.remove(c)
    _sub(v, 'c:rotX', rot_x)
    _sub(v, 'c:rotY', rot_y)
    if depth:
        _sub(v, 'c:depthPercent', depth)
    _sub(v, 'c:rAngAx', '1' if r_ang else '0')
    if not r_ang:
        _sub(v, 'c:perspective', persp)
    # светлые «стены» и «пол» объёмной диаграммы
    for t in ('c:floor', 'c:sideWall', 'c:backWall'):
        if ch.find(qn(t)) is None:
            w = etree.Element(qn(t))
            _sub(w, 'c:thickness', '0')
            sp = _sub(w, 'c:spPr')
            _sub(sp, 'a:noFill')
            ln = _sub(sp, 'a:ln')
            _sub(ln, 'a:noFill')
            ch.find(qn('c:plotArea')).addprevious(w)
    return v


def _rename(el, tag):
    el.tag = qn(tag)
    return el


def _drop(el, *tags):
    for t in tags:
        for c in el.findall(qn(t)):
            el.remove(c)


def _insert_before(parent, el, before_tags):
    for t in before_tags:
        b = parent.find(qn(t))
        if b is not None:
            b.addprevious(el)
            return el
    parent.append(el)
    return el


def _color_series(plot, kind='fill', alpha=None, width=2.75, markers=False):
    from .data import _series_alpha
    for k, sr in enumerate(plot.series):
        col = SERIES_COLORS[k % len(SERIES_COLORS)]
        if kind == 'line':
            sr.format.line.color.rgb = col
            sr.format.line.width = Pt(width)
            if markers:
                sr.marker.style = XL_MARKER_STYLE.CIRCLE
                sr.marker.size = 7
                sr.marker.format.fill.solid()
                sr.marker.format.fill.fore_color.rgb = WHITE
                sr.marker.format.line.color.rgb = col
            else:
                try:
                    sr.marker.style = XL_MARKER_STYLE.NONE
                except Exception:                          # noqa: BLE001
                    pass
        else:
            sr.format.fill.solid()
            sr.format.fill.fore_color.rgb = col
            if alpha:
                _series_alpha(sr, alpha)
            if kind == 'area':
                sr.format.line.color.rgb = WHITE
                sr.format.line.width = Pt(1.25)


def _labels(plot, fmt, color=NAVY, size=11, pos=None):
    plot.has_data_labels = True
    dl = plot.data_labels
    dl.number_format = fmt
    dl.number_format_is_linked = False
    dl.font.size = Pt(size)
    dl.font.bold = True
    dl.font.color.rgb = color
    if pos is not None:
        try:
            dl.position = pos
        except Exception:                                  # noqa: BLE001 — не у всех видов задаётся положение
            pass
    return dl


def _point_label(series_obj, idx, txt, color=NAVY, size=11):
    tf = series_obj.points[idx].data_label.text_frame
    tf.text = txt
    for p in tf.paragraphs:
        for r in p.runs:
            r.font.size = Pt(size)
            r.font.bold = True
            r.font.color.rgb = color


def decimals(vals):
    """Сколько знаков после запятой у чисел источника (0–2): подписи пишутся так же, как в данных."""
    d = 0
    for v in vals:
        if v is None or float(v).is_integer():
            continue
        t = f'{abs(v):.6f}'.rstrip('0').split('.')
        d = max(d, min(2, len(t[1]) if len(t) > 1 else 0))
    return d


def _num_txt(v, unit='', dec=None):
    if v is None:
        return ''
    a = abs(v)
    if dec is not None:
        s = f'{v:,.{dec}f}'
    else:
        s = f'{v:,.0f}' if (float(v).is_integer() or a >= 100) else (f'{v:,.1f}' if a >= 10 else f'{v:,.2f}')
    s = s.replace(',', ' ').replace('.', ',')
    return s + (f' {unit}' if unit and unit != '%' else (' %' if unit == '%' else ''))


# --------------------------------------------------------------------------------------
# Настоящие диаграммы PowerPoint
# --------------------------------------------------------------------------------------
LINE_XL = {'line_plain': XL_CHART_TYPE.LINE, 'line_smooth': XL_CHART_TYPE.LINE, 'line_stacked': XL_CHART_TYPE.LINE_STACKED,
           'line_stacked100': XL_CHART_TYPE.LINE_STACKED_100}
AREA_XL = {'area_stacked': XL_CHART_TYPE.AREA_STACKED, 'area_stacked100': XL_CHART_TYPE.AREA_STACKED_100}
BAR3D = {'column3d': ('col', 'clustered', 'box'), 'column3d_stacked': ('col', 'stacked', 'box'),
         'column3d_stacked100': ('col', 'percentStacked', 'box'), 'cylinder': ('col', 'clustered', 'cylinder'),
         'cone': ('col', 'clustered', 'cone'), 'pyramid': ('col', 'clustered', 'pyramid'),
         'bar3d': ('bar', 'clustered', 'box'), 'bar3d_stacked': ('bar', 'stacked', 'box')}


def _r_line(sl, ch, box):
    cats, series, unit = ch['categories'], ch['series'], ch.get('unit') or ''
    t = ch['type']
    fmt = _fmt([v for s in series for v in s['values']], unit)
    gf = _add(sl, LINE_XL[t], _cat_data(cats, series, fmt), box)
    c = gf.chart
    _style_text(c)
    _legend(c, len(series) > 1)
    _axes(c, '0%' if t == 'line_stacked100' else fmt)
    plot = c.plots[0]
    _color_series(plot, 'line', width=2.5 if len(cats) > 20 else 2.75)
    for sr in plot.series:
        sr.smooth = t == 'line_smooth'
    if len(series) == 1 and len(cats) <= 12:
        _labels(plot, fmt, pos=XL_LABEL_POSITION.ABOVE, size=10.5)
    return gf


def _r_area(sl, ch, box):
    cats, series, unit = ch['categories'], ch['series'], ch.get('unit') or ''
    fmt = _fmt([v for s in series for v in s['values']], unit)
    gf = _add(sl, AREA_XL[ch['type']], _cat_data(cats, series, fmt), box)
    c = gf.chart
    _style_text(c)
    _legend(c, True)
    _axes(c, '0%' if ch['type'] == 'area_stacked100' else fmt)
    if ch['type'] != 'area_stacked100':
        _zero(c, series)
    _color_series(c.plots[0], 'area', alpha=90)
    return gf


def _r_bar100(sl, ch, box):
    from .data import _hide_label
    cats, series, unit = ch['categories'], ch['series'], ch.get('unit') or ''
    fmt = _fmt([v for s in series for v in s['values']], unit)
    gf = _add(sl, XL_CHART_TYPE.BAR_STACKED_100, _cat_data(cats, series, fmt), box)
    c = gf.chart
    _style_text(c)
    _legend(c, True)
    _axes(c, '0%')
    c.category_axis.reverse_order = True
    plot = c.plots[0]
    plot.gap_width = 50
    _color_series(plot)
    if len(cats) <= 8:
        _labels(plot, fmt, WHITE, 10.5, XL_LABEL_POSITION.CENTER)
        for k in range(len(cats)):
            tot = sum(abs(s['values'][k] or 0) for s in series) or 1
            for si, s in enumerate(series):
                v = s['values'][k]
                if v is None or abs(v) < 0.07 * tot:
                    _hide_label(plot.series[si], k)
    return gf


def _r_3d(sl, ch, box):
    """Объёмные виды: строится плоская диаграмма, затем её XML переводится в объёмную (как у PowerPoint)."""
    t = ch['type']
    cats, series, unit = ch['categories'], ch['series'], ch.get('unit') or ''
    fmt = _fmt([v for s in series for v in s['values']], unit)
    if t in BAR3D:
        bdir, grouping, shape = BAR3D[t]
        base = {('col', 'clustered'): XL_CHART_TYPE.COLUMN_CLUSTERED, ('col', 'stacked'): XL_CHART_TYPE.COLUMN_STACKED,
                ('col', 'percentStacked'): XL_CHART_TYPE.COLUMN_STACKED_100, ('bar', 'clustered'): XL_CHART_TYPE.BAR_CLUSTERED,
                ('bar', 'stacked'): XL_CHART_TYPE.BAR_STACKED}[(bdir, grouping)]
        gf = _add(sl, base, _cat_data(cats, series, fmt), box)
        c = gf.chart
        _style_text(c)
        _legend(c, len(series) > 1)
        _axes(c, '0%' if grouping == 'percentStacked' else fmt)
        if grouping != 'percentStacked':
            _zero(c, series)
        _color_series(c.plots[0])
        pa, bar = _plot_el(c, 'c:barChart')
        _rename(bar, 'c:bar3DChart')
        _drop(bar, 'c:overlap', 'c:serLines')
        for ser in bar.findall(qn('c:ser')):
            _drop(ser, 'c:invertIfNegative')
            if ser.find(qn('c:shape')) is None:
                _insert_before(ser, etree.Element(qn('c:shape')), ('c:extLst',)).set('val', shape)
            else:
                ser.find(qn('c:shape')).set('val', shape)
        gw = bar.find(qn('c:gapWidth'))
        if gw is None:
            gw = _insert_before(bar, etree.Element(qn('c:gapWidth')), ('c:axId',))
        gw.set('val', '80')
        sh = etree.Element(qn('c:shape'))
        sh.set('val', shape)
        _insert_before(bar, sh, ('c:axId',))
        _view3d(c, 15, 20, True)
        return gf
    if t == 'line3d' or t == 'area3d':
        base = XL_CHART_TYPE.LINE if t == 'line3d' else XL_CHART_TYPE.AREA
        gf = _add(sl, base, _cat_data(cats, series, fmt), box)
        c = gf.chart
        _style_text(c)
        _legend(c, len(series) > 1)
        _axes(c, fmt)
        if t == 'area3d':
            _zero(c, series)
        _color_series(c.plots[0], 'fill')
        pa, el = _plot_el(c, 'c:lineChart', 'c:areaChart')
        _rename(el, 'c:line3DChart' if t == 'line3d' else 'c:area3DChart')
        _drop(el, 'c:marker', 'c:hiLowLines', 'c:upDownBars', 'c:smooth')
        for ser in el.findall(qn('c:ser')):
            _drop(ser, 'c:marker', 'c:smooth')
        gd = etree.Element(qn('c:gapDepth'))
        gd.set('val', '150')
        _insert_before(el, gd, ('c:axId',))
        cat_id = el.findall(qn('c:axId'))[0].get('val')
        sid = _ser_axis(pa, el.findall(qn('c:axId'))[1].get('val'))
        el.findall(qn('c:axId'))[-1].addnext(etree.Element(qn('c:axId')))
        el.findall(qn('c:axId'))[-1].set('val', sid)
        # ось рядов пересекает ось категорий — как в PowerPoint
        sa = pa.find(qn('c:serAx'))
        sa.find(qn('c:crossAx')).set('val', cat_id)
        if len(series) == 1:
            sa.find(qn('c:delete')).set('val', '1')
        _view3d(c, 15, 20, False, 30, 100)
        return gf
    # круговая объёмная
    gf = _add(sl, XL_CHART_TYPE.PIE, _cat_data(cats, series[:1], fmt), box)
    c = gf.chart
    _pie_style(c, ch)
    pa, el = _plot_el(c, 'c:pieChart')
    _rename(el, 'c:pie3DChart')
    _drop(el, 'c:firstSliceAng')
    _view3d(c, 30, 0, False, 30)
    return gf


def _pie_style(c, ch, label_white=True):
    unit = ch.get('unit') or ''
    _style_text(c)
    _legend(c, True, XL_LEGEND_POSITION.RIGHT)
    plot = c.plots[0]
    for i, pt in enumerate(plot.series[0].points):
        pt.format.fill.solid()
        pt.format.fill.fore_color.rgb = rgb(PALETTE[i % len(PALETTE)])
        pt.format.line.color.rgb = WHITE
        pt.format.line.width = Pt(1.5)
    dl = _labels(plot, '0%' if unit != '%' else _fmt(ch['series'][0]['values'], unit), WHITE if label_white else NAVY, 12)
    if unit == '%':
        dl.show_value = True
    else:
        dl.show_percentage = True
        dl.show_value = False
    return plot


def _r_pie(sl, ch, box):
    t = ch['type']
    cats, series, unit = ch['categories'], ch['series'][:1], ch.get('unit') or ''
    vals = series[0]['values']
    if t in ('pie_of_pie', 'bar_of_pie'):                  # по убыванию: мелкие доли — в конце, они и уходят во второй круг
        order = sorted(range(len(cats)), key=lambda k: -(vals[k] or 0))
        cats = [cats[k] for k in order]
        series = [{'name': series[0]['name'], 'values': [vals[k] for k in order]}]
        vals = series[0]['values']
    fmt = _fmt(vals, unit)
    gf = _add(sl, XL_CHART_TYPE.PIE, _cat_data(cats, series, fmt), box)
    c = gf.chart
    plot = _pie_style(c, dict(ch, series=series))
    if t == 'pie_exploded':
        good = [v for v in vals if v is not None]
        if good:
            k = vals.index(max(good))
            ser = plot.series[0]._element
            dpts = ser.findall(qn('c:dPt'))
            dpt = next((d for d in dpts if d.find(qn('c:idx')).get('val') == str(k)), None)
            if dpt is not None:
                ex = etree.Element(qn('c:explosion'))
                ex.set('val', '14')
                (dpt.find(qn('c:bubble3D')) if dpt.find(qn('c:bubble3D')) is not None else dpt.find(qn('c:idx'))).addnext(ex)
        return gf
    if t in ('pie_of_pie', 'bar_of_pie'):
        tot = sum(v or 0 for v in vals) or 1
        small = sum(1 for v in vals if (v or 0) / tot < 0.1)
        small = max(2, min(5, small, len(vals) - 1))
        pa, el = _plot_el(c, 'c:pieChart')
        _rename(el, 'c:ofPieChart')
        _drop(el, 'c:firstSliceAng')
        opt = etree.Element(qn('c:ofPieType'))
        opt.set('val', 'pie' if t == 'pie_of_pie' else 'bar')
        el.insert(0, opt)
        for tag, val in (('c:gapWidth', '100'), ('c:splitType', 'pos'), ('c:splitPos', str(small)),
                         ('c:secondPieSize', '75')):
            _sub(el, tag, val)
        sll = _sub(el, 'c:serLines')
        sp = _sub(sll, 'c:spPr')
        ln = _sub(sp, 'a:ln', w='9525')
        sf = _sub(ln, 'a:solidFill')
        _sub(sf, 'a:srgbClr', HEX['lgray'])
    return gf


def _xy_points(cats, series):
    xs = [to_num(c) for c in cats]
    return xs, series


def _r_xy(sl, ch, box):
    from .data import _num_format
    t = ch['type']
    cats, series, unit = ch['categories'], ch['series'], ch.get('unit') or ''
    xs = [to_num(c) for c in cats]
    if t in ('bubble', 'bubble3d'):
        cd = BubbleChartData()
        pairs = [(series[i], series[i + 1]) for i in range(0, len(series) - 1, 2)]
        for ys, ss in pairs:
            s = cd.add_series(ys['name'])
            for x, y, z in zip(xs, ys['values'], ss['values']):
                if x is not None and y is not None and z is not None and z > 0:
                    s.add_data_point(x, y, z)
        xl = XL_CHART_TYPE.BUBBLE_THREE_D_EFFECT if t == 'bubble3d' else XL_CHART_TYPE.BUBBLE
        n_ser = len(pairs)
    else:
        cd = XyChartData()
        for sr in series:
            s = cd.add_series(sr['name'])
            for x, y in zip(xs, sr['values']):
                if x is not None and y is not None:
                    s.add_data_point(x, y)
        xl = {'scatter': XL_CHART_TYPE.XY_SCATTER, 'scatter_trend': XL_CHART_TYPE.XY_SCATTER,
              'scatter_lines': XL_CHART_TYPE.XY_SCATTER_LINES,
              'scatter_smooth': XL_CHART_TYPE.XY_SCATTER_SMOOTH}[t]
        n_ser = len(series)
    gf = _add(sl, xl, cd, box)
    c = gf.chart
    _style_text(c)
    _legend(c, n_ser > 1)
    fmt = _num_format(series, unit)
    va = c.value_axis
    va.has_major_gridlines = True
    va.major_gridlines.format.line.color.rgb = rgb('E3E8EF')
    va.format.line.fill.background()
    va.tick_labels.font.size = Pt(11)
    va.tick_labels.number_format = fmt
    va.tick_labels.number_format_is_linked = False
    xa = c.category_axis                                   # у точечной это ось значений X
    xa.format.line.color.rgb = LGRAY
    xa.tick_labels.font.size = Pt(11)
    xa.has_major_gridlines = False
    plot = c.plots[0]
    for k, sr in enumerate(plot.series):
        col = SERIES_COLORS[k % len(SERIES_COLORS)]
        if t in ('bubble', 'bubble3d'):
            sr.format.fill.solid()
            sr.format.fill.fore_color.rgb = col
            from .data import _series_alpha
            _series_alpha(sr, 75)
            sr.format.line.color.rgb = WHITE
            continue
        sr.marker.style = XL_MARKER_STYLE.CIRCLE
        sr.marker.size = 8
        sr.marker.format.fill.solid()
        sr.marker.format.fill.fore_color.rgb = col
        sr.marker.format.line.color.rgb = WHITE
        if t in ('scatter', 'scatter_trend'):
            sr.format.line.fill.background()
        else:
            sr.format.line.color.rgb = col
            sr.format.line.width = Pt(2.25)
        sm = sr._element.find(qn('c:smooth'))              # python-pptx пишет smooth=0 и у «точечной с кривыми»
        if sm is not None:
            sm.set('val', '1' if t == 'scatter_smooth' else '0')
        if t == 'scatter_trend':
            tl = etree.Element(qn('c:trendline'))
            _sub(tl, 'c:name').text = f'Тренд: {sr.name}' if n_ser > 1 else 'Тренд'
            sp = _sub(tl, 'c:spPr')
            ln = _sub(sp, 'a:ln', w='22225', cap='rnd')
            sf = _sub(ln, 'a:solidFill')
            _sub(sf, 'a:srgbClr', HEX['green'] if k == 0 else HEX['lgreen'])
            _sub(ln, 'a:prstDash', 'dash')
            _sub(tl, 'c:trendlineType', 'linear')
            _sub(tl, 'c:dispRSqr', '0')
            _sub(tl, 'c:dispEq', '0')
            _insert_before(sr._element, tl, ('c:errBars', 'c:xVal', 'c:yVal'))
    if t in ('bubble', 'bubble3d'):
        bc = c._chartSpace.find('.//' + qn('c:bubbleChart'))
        bs = bc.find(qn('c:bubbleScale'))
        if bs is None:
            bs = _insert_before(bc, etree.Element(qn('c:bubbleScale')), ('c:showNegBubbles', 'c:sizeRepresents', 'c:axId'))
        bs.set('val', '70')
    return gf


def _r_radar(sl, ch, box):
    cats, series, unit = ch['categories'], ch['series'], ch.get('unit') or ''
    fmt = _fmt([v for s in series for v in s['values']], unit)
    xl = XL_CHART_TYPE.RADAR if ch['type'] == 'radar_lines' else XL_CHART_TYPE.RADAR_MARKERS
    gf = _add(sl, xl, _cat_data(cats, series, fmt), box)
    c = gf.chart
    _style_text(c)
    _legend(c, len(series) > 1)
    _axes(c, fmt)
    c.category_axis.format.line.color.rgb = rgb('E3E8EF')
    c.category_axis.tick_labels.font.color.rgb = NAVY
    c.category_axis.tick_labels.font.size = Pt(12 if len(cats) <= 8 else 10.5)
    c.value_axis.tick_labels.font.size = Pt(9)
    _color_series(c.plots[0], 'line', width=2.5, markers=ch['type'] == 'radar_markers')
    for ser in c._chartSpace.iter(qn('c:ser')):           # у лепестковой нет «сглаживания» (python-pptx его пишет)
        _drop(ser, 'c:smooth')
    return gf


def _r_stock(sl, ch, box):
    """Биржевая: плоский график → c:stockChart (линии рядов скрыты, «тени» макс.–мин., у OHLC — свечи)."""
    cats, series, unit = ch['categories'], ch['series'], ch.get('unit') or ''
    fmt = _fmt([v for s in series for v in s['values']], unit)
    gf = _add(sl, XL_CHART_TYPE.LINE_MARKERS, _cat_data(cats, series, fmt), box)
    c = gf.chart
    _style_text(c)
    _legend(c, False)
    _axes(c, fmt)
    pa, el = _plot_el(c, 'c:lineChart')
    _rename(el, 'c:stockChart')
    _drop(el, 'c:grouping', 'c:varyColors', 'c:marker', 'c:smooth', 'c:dLbls', 'c:dropLines', 'c:hiLowLines', 'c:upDownBars')
    sers = el.findall(qn('c:ser'))
    close_i = len(sers) - 1
    for i, ser in enumerate(sers):
        _drop(ser, 'c:spPr', 'c:marker', 'c:smooth', 'c:dLbls')
        sp = etree.Element(qn('c:spPr'))
        ln = _sub(sp, 'a:ln', w='19050')
        _sub(ln, 'a:noFill')
        _insert_before(ser, sp, ('c:marker', 'c:dPt', 'c:dLbls', 'c:trendline', 'c:errBars', 'c:cat', 'c:val'))
        mk = etree.Element(qn('c:marker'))
        if i == close_i and len(sers) == 3:
            _sub(mk, 'c:symbol', 'dash')
            _sub(mk, 'c:size', '9')
            msp = _sub(mk, 'c:spPr')
            mf = _sub(msp, 'a:solidFill')
            _sub(mf, 'a:srgbClr', HEX['green'])
            mln = _sub(msp, 'a:ln', w='9525')
            mlf = _sub(mln, 'a:solidFill')
            _sub(mlf, 'a:srgbClr', HEX['green'])
        else:
            _sub(mk, 'c:symbol', 'none')
        sp.addnext(mk)
        sm = etree.Element(qn('c:smooth'))
        sm.set('val', '0')
        _insert_before(ser, sm, ('c:extLst',))
    hl = etree.Element(qn('c:hiLowLines'))
    sp = _sub(hl, 'c:spPr')
    ln = _sub(sp, 'a:ln', w='15875')
    sf = _sub(ln, 'a:solidFill')
    _sub(sf, 'a:srgbClr', HEX['navy'])
    first_ax = el.find(qn('c:axId'))
    first_ax.addprevious(hl)
    if len(sers) == 4:
        ud = etree.Element(qn('c:upDownBars'))
        _sub(ud, 'c:gapWidth', '150')
        up = _sub(ud, 'c:upBars')
        usp = _sub(up, 'c:spPr')
        uf = _sub(usp, 'a:solidFill')
        _sub(uf, 'a:srgbClr', HEX['green'])
        uln = _sub(usp, 'a:ln', w='9525')
        ulf = _sub(uln, 'a:solidFill')
        _sub(ulf, 'a:srgbClr', HEX['dgreen'])
        dn = _sub(ud, 'c:downBars')
        dsp = _sub(dn, 'c:spPr')
        df = _sub(dsp, 'a:solidFill')
        _sub(df, 'a:srgbClr', HEX['navy'])
        dln = _sub(dsp, 'a:ln', w='9525')
        dlf = _sub(dln, 'a:solidFill')
        _sub(dlf, 'a:srgbClr', HEX['navy'])
        first_ax.addprevious(ud)
    return gf


def _r_surface(sl, ch, box):
    """Поверхность и контурная: таблица (строки — ось категорий, ряды — ось рядов) → c:surface3DChart / c:surfaceChart.
    Полосы значений окрашены оттенками фирменной палитры (от синего к зелёному)."""
    t = ch['type']
    cats, series, unit = ch['categories'], ch['series'], ch.get('unit') or ''
    fmt = _fmt([v for s in series for v in s['values']], unit)
    gf = _add(sl, XL_CHART_TYPE.LINE, _cat_data(cats, series, fmt), box)
    c = gf.chart
    _style_text(c)
    _legend(c, True, XL_LEGEND_POSITION.RIGHT)
    _axes(c, fmt)
    pa, el = _plot_el(c, 'c:lineChart')
    flat = t in ('contour', 'contour_wire')
    _rename(el, 'c:surfaceChart' if flat else 'c:surface3DChart')
    _drop(el, 'c:grouping', 'c:varyColors', 'c:marker', 'c:smooth', 'c:dLbls', 'c:dropLines', 'c:hiLowLines', 'c:upDownBars')
    wf = etree.Element(qn('c:wireframe'))
    wf.set('val', '1' if t in ('surface_wire', 'contour_wire') else '0')
    el.insert(0, wf)
    for ser in el.findall(qn('c:ser')):
        _drop(ser, 'c:marker', 'c:smooth', 'c:dLbls', 'c:dPt', 'c:spPr', 'c:trendline', 'c:errBars')
    vals = [v for s in series for v in s['values'] if v is not None]
    lo, hi = (min(vals), max(vals)) if vals else (0, 1)
    from .data import _nice_step
    step = _nice_step((hi - lo) or 1, 5)
    nb = max(2, min(8, int(math.ceil(((hi - lo) or 1) / step)) + 1))
    ramp = ['00326E', '005491', '0078AE', '2E95C4', '4BAF46', '9AC854', 'C9E3A6', 'E8F3DA']
    bf = etree.Element(qn('c:bandFmts'))
    for i in range(nb):
        b = _sub(bf, 'c:bandFmt')
        _sub(b, 'c:idx', i)
        sp = _sub(b, 'c:spPr')
        col = ramp[min(len(ramp) - 1, round(i * (len(ramp) - 1) / max(1, nb - 1)))]
        if t in ('surface_wire', 'contour_wire'):
            ln = _sub(sp, 'a:ln', w='19050')
            lf = _sub(ln, 'a:solidFill')
            _sub(lf, 'a:srgbClr', col)
        else:
            f = _sub(sp, 'a:solidFill')
            _sub(f, 'a:srgbClr', col)
    el.find(qn('c:axId')).addprevious(bf)
    va = pa.find(qn('c:valAx'))
    vs = va.find(qn('c:scaling'))
    for tag, v in (('c:max', math.ceil(hi / step) * step), ('c:min', math.floor(lo / step) * step)):
        e = etree.Element(qn(tag))
        e.set('val', repr(float(v)))
        vs.append(e)
    mu = etree.Element(qn('c:majorUnit'))
    mu.set('val', repr(float(step)))
    _insert_before(va, mu, ('c:minorUnit', 'c:dispUnits', 'c:extLst'))
    cat_id = el.findall(qn('c:axId'))[0].get('val')
    sid = _ser_axis(pa, el.findall(qn('c:axId'))[1].get('val'))
    el.findall(qn('c:axId'))[-1].addnext(etree.Element(qn('c:axId')))
    el.findall(qn('c:axId'))[-1].set('val', sid)
    pa.find(qn('c:serAx')).find(qn('c:crossAx')).set('val', cat_id)
    if flat:
        _view3d(c, 90, 0, False, 0)
    else:
        _view3d(c, 20, 25, False, 30)
    return gf


# --------------------------------------------------------------------------------------
# Виды PowerPoint 2016+ — из обычных диаграмм
# --------------------------------------------------------------------------------------


def waterfall_steps(cats, vals):
    """Шаги каскада: [(подпись, низ, верх, вид 'up'|'down'|'total', значение)]. Первый шаг и строки «Итого / Всего»
    — столбцы от нуля (их значение — сам итог), остальные — изменения. Итог без числа — сумма предыдущих шагов."""
    out, run = [], 0.0
    for k, (c, v) in enumerate(zip(cats, vals)):
        if v is None and k and TOTAL_RX.match(str(c)):      # итог без числа — сумма шагов (в заметках сказано)
            v = run
        if v is None:
            continue
        if k == 0 or TOTAL_RX.match(str(c)):
            run = v
            out.append((c, min(0.0, v), max(0.0, v), 'total', v))
            continue
        lo, hi = sorted((run, run + v))
        out.append((c, lo, hi, 'up' if v >= 0 else 'down', v))
        run += v
    return out


def _r_waterfall(sl, ch, box):
    cats, unit = ch['categories'], ch.get('unit') or ''
    steps = waterfall_steps(cats, ch['series'][0]['values'])
    labels = [s[0] for s in steps]
    # 4 ряда с накоплением: невидимая «подставка» и видимый отрезок — отдельно для частей выше и ниже нуля
    bp, sp, bn, sn = [], [], [], []
    for _, lo, hi, kind, v in steps:
        if lo >= 0:
            bp.append(lo); sp.append(hi - lo); bn.append(0); sn.append(0)
        elif hi <= 0:
            bp.append(0); sp.append(0); bn.append(hi); sn.append(lo - hi)
        else:
            bp.append(0); sp.append(hi); bn.append(0); sn.append(lo)
    fmt = _fmt([s[4] for s in steps], unit)
    data = [{'name': 'Основание', 'values': bp}, {'name': ch['series'][0]['name'] or 'Изменение', 'values': sp},
            {'name': 'Основание (минус)', 'values': bn}, {'name': 'Изменение (минус)', 'values': sn}]
    gf = _add(sl, XL_CHART_TYPE.COLUMN_STACKED, _cat_data(labels, data, fmt), box)
    c = gf.chart
    _style_text(c)
    _legend(c, False)
    _axes(c, fmt)
    plot = c.plots[0]
    plot.gap_width = 45
    plot.overlap = 100
    colors = {'up': GREEN, 'down': DOWN, 'total': NAVY}
    for si, sr in enumerate(plot.series):
        if si in (0, 2):
            sr.format.fill.background()
            sr.format.line.fill.background()
            continue
        sr.format.fill.solid()
        sr.format.fill.fore_color.rgb = NAVY
        for k, st in enumerate(steps):
            pt = sr.points[k]
            pt.format.fill.solid()
            pt.format.fill.fore_color.rgb = colors[st[3]]
    # подписи: у каждого шага — его значение со знаком (у итогов — без знака); единица — в подписи оси, чтобы
    # подпись помещалась в узкий столбец
    short = unit if unit in ('%',) else ''
    if unit and unit != '%':
        _value_title(c, unit)
    dec = decimals(ch['series'][0]['values'])
    for k, (_, lo, hi, kind, v) in enumerate(steps):
        which = 1 if sp[k] >= abs(sn[k]) else 3
        txt = _num_txt(v, short, dec) if kind == 'total' else ('+' if v > 0 else '−') + _num_txt(abs(v), short, dec)
        _point_label(plot.series[which], k, txt, NAVY if kind != 'total' else NAVY, 11)
        lbl = plot.series[which].points[k].data_label
        try:
            lbl.position = XL_LABEL_POSITION.INSIDE_END if which == 1 else XL_LABEL_POSITION.INSIDE_BASE
        except Exception:                                  # noqa: BLE001
            pass
    return gf


def computed_totals(ch):
    """Подписи итогов каскада, которые посчитаны как сумма шагов (в данных числа не было)."""
    if ch.get('type') != 'waterfall' or not ch.get('series'):
        return []
    return [c for k, (c, v) in enumerate(zip(ch['categories'], ch['series'][0]['values']))
            if v is None and k and TOTAL_RX.match(str(c))]


def _value_title(chart, txt):
    va = chart.value_axis
    va.has_title = True
    tf = va.axis_title.text_frame
    tf.text = txt
    r = tf.paragraphs[0].runs[0]
    r.font.size = Pt(11)
    r.font.bold = False
    r.font.color.rgb = GRAY


def hist_bins(vals):
    """Интервалы гистограммы по данным: [(низ, верх, сколько)]. Число интервалов — правило Стёрджеса (5–15),
    границы — «круглые»."""
    from .data import _nice_step
    v = sorted(x for x in vals if x is not None)
    lo, hi = v[0], v[-1]
    if hi == lo:
        return [(lo, hi, len(v))]
    k = max(5, min(15, int(math.ceil(math.log2(len(v)) + 1))))
    step = _nice_step(hi - lo, k)
    start = math.floor(lo / step) * step
    edges = [start]
    while edges[-1] <= hi:
        edges.append(round(edges[-1] + step, 10))
    counts = [0] * (len(edges) - 1)
    for x in v:
        i = min(len(counts) - 1, int((x - start) // step))
        counts[i] += 1
    return [(edges[i], edges[i + 1], counts[i]) for i in range(len(counts))]


def _edge_txt(x):
    return (f'{x:,.0f}' if float(x).is_integer() or abs(x) >= 100 else f'{x:,.2f}'.rstrip('0').rstrip('.')).replace(',', ' ').replace('.', ',')


def _r_histogram(sl, ch, box):
    unit = ch.get('unit') or ''
    vals = [v for v in ch['series'][0]['values'] if v is not None]
    bins = hist_bins(vals)
    cats = [f'{_edge_txt(a)}–{_edge_txt(b)}' for a, b, _ in bins]
    data = [{'name': f'Число значений ({ch["series"][0]["name"]})', 'values': [n for _, _, n in bins]}]
    gf = _add(sl, XL_CHART_TYPE.COLUMN_CLUSTERED, _cat_data(cats, data, '0'), box)
    c = gf.chart
    _style_text(c)
    _legend(c, False)
    _axes(c, '0')
    plot = c.plots[0]
    plot.gap_width = 6
    sr = plot.series[0]
    sr.format.fill.solid()
    sr.format.fill.fore_color.rgb = BLUE
    sr.format.line.color.rgb = WHITE
    sr.format.line.width = Pt(1)
    if len(cats) <= 15:
        _labels(plot, '0', NAVY, 10.5, XL_LABEL_POSITION.OUTSIDE_END)
    c.category_axis.tick_labels.font.size = Pt(10 if len(cats) > 8 else 11)
    if unit:
        c.category_axis.has_title = True
        c.category_axis.axis_title.text_frame.text = f'Интервалы, {unit}'
        c.category_axis.axis_title.text_frame.paragraphs[0].runs[0].font.size = Pt(11)
    return gf


def _r_pareto(sl, ch, box):
    from .data import _to_combo
    from pptx.chart.axis import ValueAxis
    cats, unit = ch['categories'], ch.get('unit') or ''
    vals = ch['series'][0]['values']
    order = sorted([k for k in range(len(cats)) if vals[k] is not None], key=lambda k: -vals[k])
    c2 = [cats[k] for k in order]
    v2 = [vals[k] for k in order]
    tot = sum(v2) or 1
    cum, acc = [], 0.0
    for v in v2:
        acc += v
        cum.append(round(acc / tot, 4))
    fmt = _fmt(v2, unit)
    gf = _add(sl, XL_CHART_TYPE.COLUMN_CLUSTERED,
              _cat_data(c2, [{'name': ch['series'][0]['name'], 'values': v2}, {'name': 'Накопленная доля', 'values': cum}], fmt), box)
    c = gf.chart
    _to_combo(c, '0%')
    _style_text(c)
    _legend(c, True)
    va = ValueAxis(c._chartSpace.valAx_lst[0])
    va.has_major_gridlines = True
    va.major_gridlines.format.line.color.rgb = rgb('E3E8EF')
    va.format.line.fill.background()
    va.tick_labels.number_format = fmt
    va.tick_labels.number_format_is_linked = False
    va.minimum_scale = 0
    va2 = ValueAxis(c._chartSpace.valAx_lst[1])
    va2.minimum_scale, va2.maximum_scale, va2.major_unit = 0, 1, 0.2
    va2.has_major_gridlines = False
    va2.tick_labels.font.color.rgb = DGREEN
    plot = c.plots[0]
    plot.gap_width = 30
    sr = plot.series[0]
    sr.format.fill.solid()
    sr.format.fill.fore_color.rgb = NAVY
    lsr = c.plots[1].series[0]
    lsr.format.line.color.rgb = DGREEN
    lsr.format.line.width = Pt(2.75)
    lsr.marker.style = XL_MARKER_STYLE.CIRCLE
    lsr.marker.size = 7
    lsr.marker.format.fill.solid()
    lsr.marker.format.fill.fore_color.rgb = WHITE
    lsr.marker.format.line.color.rgb = DGREEN
    if len(c2) <= 10:
        _labels(plot, fmt, NAVY, 10.5, XL_LABEL_POSITION.OUTSIDE_END)
    return gf


def five_numbers(vals):
    """Минимум, нижний квартиль, медиана, верхний квартиль, максимум (квартили — как в Excel, «включительно»)."""
    v = sorted(x for x in vals if x is not None)
    if len(v) == 1:
        return v[0], v[0], v[0], v[0], v[0]
    q1, q2, q3 = statistics.quantiles(v, n=4, method='inclusive')
    return v[0], q1, q2, q3, v[-1]


def _err_bars(ser_el, plus=None, minus=None, color=HEX['navy']):
    """Пользовательские «усы» (планки погрешностей) у ряда столбцов."""
    eb = etree.Element(qn('c:errBars'))
    _sub(eb, 'c:errBarType', 'both' if plus and minus else ('plus' if plus else 'minus'))
    _sub(eb, 'c:errValType', 'cust')
    _sub(eb, 'c:noEndCap', '0')
    for tag, vals in (('c:plus', plus), ('c:minus', minus)):
        if not vals:
            continue
        p = _sub(eb, tag)
        nl = _sub(p, 'c:numLit')
        fc = _sub(nl, 'c:formatCode')
        fc.text = 'General'
        _sub(nl, 'c:ptCount', len(vals))
        for i, v in enumerate(vals):
            pt = _sub(nl, 'c:pt', idx=i)
            ve = _sub(pt, 'c:v')
            ve.text = repr(float(v))
    sp = _sub(eb, 'c:spPr')
    ln = _sub(sp, 'a:ln', w='15875')
    sf = _sub(ln, 'a:solidFill')
    _sub(sf, 'a:srgbClr', color)
    _insert_before(ser_el, eb, ('c:cat', 'c:val'))


def _r_boxplot(sl, ch, box):
    unit = ch.get('unit') or ''
    groups = [(s['name'], five_numbers(s['values'])) for s in ch['series'] if any(v is not None for v in s['values'])]
    names = [g[0] for g in groups]
    q1 = [g[1][1] for g in groups]
    low = [g[1][2] - g[1][1] for g in groups]
    up = [g[1][3] - g[1][2] for g in groups]
    allv = [x for g in groups for x in g[1]]
    fmt = _fmt(allv, unit)
    neg = min(allv) < 0
    data = [{'name': 'Нижний квартиль', 'values': q1}, {'name': 'До медианы', 'values': low}, {'name': 'После медианы', 'values': up}]
    gf = _add(sl, XL_CHART_TYPE.COLUMN_STACKED, _cat_data(names, data, fmt), box)
    c = gf.chart
    _style_text(c)
    _legend(c, False)
    _axes(c, fmt)
    plot = c.plots[0]
    plot.gap_width = 120
    s0, s1, s2 = plot.series
    s0.format.fill.background()
    s0.format.line.fill.background()
    for sr, col in ((s1, BLUE), (s2, GREEN)):
        sr.format.fill.solid()
        sr.format.fill.fore_color.rgb = col
        sr.format.line.color.rgb = WHITE
        sr.format.line.width = Pt(1.5)
    _err_bars(s0._element, minus=[g[1][1] - g[1][0] for g in groups])     # нижний «ус»: от Q1 вниз до минимума
    _err_bars(s2._element, plus=[g[1][4] - g[1][3] for g in groups])      # верхний «ус»: от Q3 вверх до максимума
    from .data import _nice_step
    step = _nice_step(max(allv) - min(allv) or abs(max(allv)) or 1, 6)
    lo = math.floor(min(allv) / step) * step
    c.value_axis.minimum_scale = max(0.0, lo) if not neg else lo
    c.value_axis.maximum_scale = math.ceil(max(allv) / step + 0.25) * step       # «усы» не обрезаются краем
    c.value_axis.major_unit = step
    for k, g in enumerate(groups):                          # медиана — подписью на границе синей и зелёной частей
        _point_label(s1, k, _num_txt(g[1][2], unit), WHITE, 10.5)
        try:
            s1.points[k].data_label.position = XL_LABEL_POSITION.INSIDE_END
        except Exception:                                  # noqa: BLE001
            pass
    return gf


def _r_funnel(sl, ch, box):
    cats, unit = ch['categories'], ch.get('unit') or ''
    vals = [v or 0 for v in ch['series'][0]['values']]
    mx = max(vals) or 1
    pad = [(mx - v) / 2 for v in vals]
    fmt = _fmt(vals, unit)
    gf = _add(sl, XL_CHART_TYPE.BAR_STACKED,
              _cat_data(cats, [{'name': 'Отступ', 'values': pad}, {'name': ch['series'][0]['name'], 'values': vals}], fmt), box)
    c = gf.chart
    _style_text(c)
    _legend(c, False)
    c.value_axis.visible = False
    c.value_axis.has_major_gridlines = False
    ca = c.category_axis
    ca.reverse_order = True
    ca.format.line.fill.background()
    ca.tick_labels.font.size = Pt(12)
    ca.tick_labels.font.color.rgb = NAVY
    plot = c.plots[0]
    plot.gap_width = 18
    s0, s1 = plot.series
    s0.format.fill.background()
    s0.format.line.fill.background()
    ramp = [NAVY, DBLUE, BLUE, DGREEN, GREEN, LGREEN]
    for k in range(len(cats)):
        pt = s1.points[k]
        pt.format.fill.solid()
        pt.format.fill.fore_color.rgb = ramp[min(len(ramp) - 1, round(k * (len(ramp) - 1) / max(1, len(cats) - 1)))]
    _labels(plot, fmt, WHITE, 12, XL_LABEL_POSITION.CENTER)
    from .data import _hide_label
    for k in range(len(cats)):
        _hide_label(s0, k)
    return gf




def _r_sunburst(sl, ch, box):
    """«Солнечные лучи» — кольцевая из двух колец: внутреннее — группы (подписи «Группа / Элемент»), внешнее — элементы.
    Сегменты одной группы во внутреннем кольце окрашены одним цветом без границ — выглядят одним сектором."""
    cats, unit = ch['categories'], ch.get('unit') or ''
    vals = ch['series'][0]['values']
    rows = [(split_path(c), v) for c, v in zip(cats, vals) if v is not None and v > 0]
    groups = []
    for (g, leaf), v in [((p[0], p[-1]), v) for p, v in rows]:
        if g not in groups:
            groups.append(g)
    rows.sort(key=lambda r: groups.index(r[0][0]))
    leaves = [r[0][-1] for r in rows]
    lv = [r[1] for r in rows]
    gof = [r[0][0] for r in rows]
    fmt = _fmt(lv, unit)
    data = [{'name': 'Группы', 'values': lv}, {'name': ch['series'][0]['name'] or 'Элементы', 'values': lv}]
    gf = _add(sl, XL_CHART_TYPE.DOUGHNUT, _cat_data(leaves, data, fmt), box)
    c = gf.chart
    _style_text(c)
    _legend(c, False)
    dn = c._chartSpace.find('.//' + qn('c:doughnutChart'))
    hs = dn.find(qn('c:holeSize'))
    if hs is not None:
        hs.set('val', '25')
    plot = c.plots[0]
    inner, outer = plot.series
    tints = {}
    for gi, g in enumerate(groups):
        tints[g] = rgb(PALETTE[gi % 6])
    light = ['3D6AA3', '7BD077', '3FA3D1', 'BEDE8F', '3A84BF', '45B865']
    for k, g in enumerate(gof):
        p = inner.points[k]
        p.format.fill.solid()
        p.format.fill.fore_color.rgb = tints[g]
        p.format.line.color.rgb = tints[g]
        q = outer.points[k]
        q.format.fill.solid()
        q.format.fill.fore_color.rgb = rgb(light[groups.index(g) % 6])
        q.format.line.color.rgb = WHITE
        q.format.line.width = Pt(1.5)
    tot = sum(lv) or 1
    # подписи: группа — у средней точки своей группы во внутреннем кольце; элемент — во внешнем (если доля ≥ 3 %)
    for g in groups:
        idx = [k for k, x in enumerate(gof) if x == g]
        if g and sum(lv[k] for k in idx) / tot >= 0.04:
            _point_label(inner, idx[len(idx) // 2], g, WHITE, 11)
    for k in range(len(leaves)):
        if lv[k] / tot >= 0.03:
            _point_label(outer, k, leaves[k], NAVY if False else WHITE, 10)
    return gf


# --------------------------------------------------------------------------------------
# Фигурами PowerPoint
# --------------------------------------------------------------------------------------
def squarify_rects(values, x, y, w, h):
    """Прямоугольники «дерева» (squarified treemap). Библиотека squarify, без неё — своя реализация того же
    алгоритма. values — по убыванию, положительные. → [(x, y, w, h)]."""
    try:
        import squarify
        norm = squarify.normalize_sizes(values, w, h)
        return [(r['x'], r['y'], r['dx'], r['dy']) for r in squarify.squarify(norm, x, y, w, h)]
    except ImportError:
        pass
    tot = sum(values) or 1
    vals = [v * w * h / tot for v in values]
    out = []

    def worst(row, side):
        s = sum(row)
        return max(max(side * side * r / (s * s), (s * s) / (side * side * r)) for r in row)

    def place(row, x, y, w, h):
        s = sum(row)
        if w >= h:
            dw = s / h
            yy = y
            for r in row:
                out.append((x, yy, dw, r / dw))
                yy += r / dw
            return x + dw, y, w - dw, h
        dh = s / w
        xx = x
        for r in row:
            out.append((xx, y, r / dh, dh))
            xx += r / dh
        return x, y + dh, w, h - dh
    row = []
    i = 0
    while i < len(vals):
        side = min(w, h)
        if not row or worst(row + [vals[i]], side) <= worst(row, side):
            row.append(vals[i])
            i += 1
        else:
            x, y, w, h = place(row, x, y, w, h)
            row = []
    if row:
        place(row, x, y, w, h)
    return out


def _r_treemap(ctx, sl, ch, box):
    from ..textfit import clip
    x, y, w, h = box
    cats, unit = ch['categories'], ch.get('unit') or ''
    vals = ch['series'][0]['values']
    rows = [(split_path(c), v) for c, v in zip(cats, vals) if v is not None and v > 0]
    tot = sum(v for _, v in rows) or 1
    groups = {}
    for p, v in rows:
        groups.setdefault(p[0], []).append((p[-1], v))
    gl = sorted(groups.items(), key=lambda kv: -sum(v for _, v in kv[1]))
    g = group(sl)
    rects = squarify_rects([sum(v for _, v in items) for _, items in gl], x, y, w, h)
    light = ['3D6AA3', '7BD077', '3FA3D1', 'BEDE8F', '3A84BF', '45B865', '9CCBE5', 'C6E7C4']
    for gi, ((gname, items), (gx, gy, gw, gh)) in enumerate(zip(gl, rects)):
        items = sorted(items, key=lambda t: -t[1])
        head = 0.32 if gname and gh > 0.9 and gw > 1.2 else 0
        if gname and len(groups) > 1:
            hb = rect(g, gx, gy, gw, gh, fill=rgb(PALETTE[gi % 6]), line=WHITE, lw=2)
            if head:
                text(g, gx + 0.08, gy, gw - 0.16, head, clip(gname, gw - 0.16, head, 11, 'b', 1), size=11, color=WHITE,
                     font='b', anchor=MSO_ANCHOR.MIDDLE)
        sub = squarify_rects([v for _, v in items], gx + (0.04 if head else 0), gy + head, gw - (0.08 if head else 0),
                             gh - head - (0.04 if head else 0)) if items else []
        for k, ((name, v), (rx, ry, rw, rh)) in enumerate(zip(items, sub)):
            col = rgb(PALETTE[(gi if len(groups) > 1 else k) % 6]) if not (len(groups) > 1) else rgb(light[gi % len(light)] if k % 2 else PALETTE[gi % 6])
            r = rect(g, rx, ry, rw, rh, fill=col, line=WHITE, lw=1.5)
            if rw > 0.7 and rh > 0.45:
                sz = 13 if rw * rh > 3 else (11 if rw * rh > 1 else 9)
                share = v / tot
                body = [[(clip(name, rw - 0.16, rh * 0.6, sz, 'b', 2), {'font': 'b', 'color': WHITE})],
                        [(f'{_num_txt(v, unit)} · {share:.0%}'.replace('.', ','), {'size': sz - 1, 'color': WHITE})]]
                text(g, rx + 0.08, ry + 0.05, rw - 0.16, rh - 0.1, body, size=sz, color=WHITE, anchor=MSO_ANCHOR.TOP)
            del r
    return g


def _r_waffle(ctx, sl, ch, box):
    """Вафельная: 10 × 10 квадратов, доли рядов — цветом (ровно 100 клеток, округление — по наибольшим остаткам)."""
    x, y, w, h = box
    cats, unit = ch['categories'], ch.get('unit') or ''
    vals = [max(0.0, v or 0) for v in ch['series'][0]['values']]
    tot = sum(vals) or 1
    raw = [v * 100 / tot for v in vals]
    cells = [int(r) for r in raw]
    for k in sorted(range(len(raw)), key=lambda k: -(raw[k] - cells[k]))[:100 - sum(cells)]:
        cells[k] += 1
    side = min(h, w * 0.55)
    gap = side * 0.012
    cs = (side - 9 * gap) / 10
    g = group(sl)
    k, used = 0, 0
    for i in range(100):
        while k < len(cells) and used >= cells[k]:
            k += 1
            used = 0
        col = rgb(PALETTE[k % len(PALETTE)]) if k < len(cells) else rgb(HEX['soft'])
        r, cc = divmod(i, 10)
        rect(g, x + cc * (cs + gap), y + (9 - r) * (cs + gap) + (h - side) / 2, cs, cs, fill=col,
             shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.18)
        used += 1
    lx = x + side + 0.5
    lw = x + w - lx
    rowh = min(0.62, h / max(1, len(cats)))
    for j, (c, v) in enumerate(zip(cats, vals)):
        yy = y + (h - rowh * len(cats)) / 2 + j * rowh
        rect(g, lx, yy + rowh / 2 - 0.13, 0.26, 0.26, fill=rgb(PALETTE[j % len(PALETTE)]), shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.2)
        body = [[(f'{cells[j]} %  ', {'font': 'b', 'color': NAVY, 'size': 16}), (str(c), {'color': GRAY, 'size': 13})]]
        text(g, lx + 0.4, yy, lw - 0.4, rowh, body, size=13, color=GRAY, anchor=MSO_ANCHOR.MIDDLE)
    return g




def _r_network(ctx, sl, ch, box):
    """Схема связей: узлы — круги, связи — линии (толщина — по числу). Раскладка — networkx (пружинная, без случайности),
    без неё — по кругу. Все элементы — фигуры PowerPoint."""
    x, y, w, h = box
    edges = []
    for c, v in zip(ch['categories'], ch['series'][0]['values']):
        e = _edge(c)
        if e:
            edges.append((e[0], e[1], abs(v) if v is not None else 1.0))
    nodes = []
    for a, b, _ in edges:
        for n in (a, b):
            if n not in nodes:
                nodes.append(n)
    deg = {n: sum(wt for a, b, wt in edges if n in (a, b)) for n in nodes}
    try:
        import networkx as nx
        G = nx.Graph()
        G.add_weighted_edges_from(edges)
        pos = nx.kamada_kawai_layout(G) if len(nodes) <= 40 else nx.spring_layout(G, seed=7)
        pos = {n: (float(p[0]), float(p[1])) for n, p in pos.items()}
    except Exception:                                      # noqa: BLE001 — без networkx: по кругу
        pos = {n: (math.cos(2 * math.pi * i / len(nodes)), math.sin(2 * math.pi * i / len(nodes))) for i, n in enumerate(nodes)}
    xs = [p[0] for p in pos.values()]
    ys = [p[1] for p in pos.values()]
    mx, Mx, my, My = min(xs), max(xs), min(ys), max(ys)
    rmax = min(0.62, 0.9 * min(w, h) / max(4, math.sqrt(len(nodes)) * 2.2))
    dmax = max(deg.values()) or 1

    def P(n):
        px = x + rmax + (pos[n][0] - mx) / ((Mx - mx) or 1) * (w - 2 * rmax)
        py = y + rmax + (pos[n][1] - my) / ((My - my) or 1) * (h - 2 * rmax)
        return px, py
    g = group(sl)
    wmax = max(wt for _, _, wt in edges) or 1
    for a, b, wt in edges:
        (x1, y1), (x2, y2) = P(a), P(b)
        ln = g.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, I(x1), I(y1), I(x2), I(y2))
        ln.line.color.rgb = rgb('9DB3CC')
        ln.line.width = Pt(1 + 5 * wt / wmax)
    for i, n in enumerate(nodes):
        cx, cy = P(n)
        r = rmax * (0.55 + 0.45 * deg[n] / dmax)
        col = NAVY if deg[n] >= 0.6 * dmax else (BLUE if deg[n] >= 0.3 * dmax else GREEN)
        circ = rect(g, cx - r, cy - r, 2 * r, 2 * r, fill=col, line=WHITE, lw=2, shape=MSO_SHAPE.OVAL)
        from ..nts.effects import shadow
        shadow(circ, 8, 2, 18)
        from ..textfit import clip
        sz = 11 if r > 0.4 else 9
        text(g, cx - r * 1.6, cy - r, r * 3.2, 2 * r, clip(n, r * 3.0, 2 * r, sz, 'b', 2), size=sz, color=WHITE,
             font='b', align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    return g


# --------------------------------------------------------------------------------------
# Картинкой: matplotlib / seaborn / wordcloud
# --------------------------------------------------------------------------------------
def _mpl():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    fam = 'DejaVu Sans'
    for f in ('TT Bluescreens Pro', 'TT Bluescreens Pro Normal', 'Segoe UI', 'Arial'):
        try:
            if font_manager.findfont(f, fallback_to_default=False):
                fam = f
                break
        except Exception:                                  # noqa: BLE001
            continue
    plt.rcParams.update({'font.family': fam, 'font.size': 11, 'axes.edgecolor': '#C5CDD8', 'axes.labelcolor': '#00326E',
                         'xtick.color': '#5B6B7F', 'ytick.color': '#5B6B7F', 'axes.titlecolor': '#00326E',
                         'axes.spines.top': False, 'axes.spines.right': False, 'figure.dpi': 100,
                         'axes.prop_cycle': matplotlib.cycler(color=['#' + c for c in PALETTE])})
    return plt


def _cmap():
    from matplotlib.colors import LinearSegmentedColormap
    return LinearSegmentedColormap.from_list('zn', ['#00326E', '#0078AE', '#4BAF46', '#C9E3A6'])


def _cmap_light():
    from matplotlib.colors import LinearSegmentedColormap
    return LinearSegmentedColormap.from_list('znl', ['#F2F5F9', '#9CCBE5', '#0078AE', '#00326E'])


def _grid(ch):
    import numpy as np
    z = np.array([[(s['values'][i] if s['values'][i] is not None else np.nan) for s in ch['series']]
                  for i in range(len(ch['categories']))], dtype=float)
    return z


def _axis_vals(labels):
    nums = [to_num(c) for c in labels]
    return nums if all(v is not None for v in nums) else list(range(len(labels)))


def image_png(ch, w, h):
    """PNG (байты) диаграммы-картинки размером w × h дюймов (200 точек на дюйм)."""
    t = ch['type']
    cats, series, unit = ch['categories'], ch['series'], ch.get('unit') or ''
    if t == 'wordcloud':
        return _wordcloud_png(ch, w, h)
    plt = _mpl()
    import numpy as np
    fig = plt.figure(figsize=(w, h), dpi=200)
    try:
        if t in ('surface_img', 'scatter3d', 'trajectory3d'):
            ax = fig.add_subplot(111, projection='3d')
            ax.set_facecolor('white')
            for a in (ax.xaxis, ax.yaxis, ax.zaxis):
                a.pane.set_facecolor('#F2F5F9')
                a.pane.set_edgecolor('#E3E8EF')
            if t == 'surface_img':
                z = _grid(ch)
                X, Y = np.meshgrid(_axis_vals([s['name'] for s in series]), _axis_vals(cats))
                surf = ax.plot_surface(X, Y, z, cmap=_cmap(), linewidth=0.3, edgecolor='white', antialiased=True)
                fig.colorbar(surf, ax=ax, shrink=0.6, pad=0.08, label=unit or None)
                ax.set_xlabel('')
                if not all(to_num(s['name']) is not None for s in series):
                    ax.set_xticks(range(len(series)))
                    ax.set_xticklabels([s['name'] for s in series], fontsize=8)
                if not all(to_num(c) is not None for c in cats):
                    ax.set_yticks(range(len(cats)))
                    ax.set_yticklabels(cats, fontsize=8)
            elif t == 'scatter3d':
                xs, ys, zs = (np.array([v if v is not None else np.nan for v in s['values']], dtype=float) for s in series[:3])
                ax.scatter(xs, ys, zs, c=zs, cmap=_cmap(), s=36, depthshade=True, edgecolors='white', linewidths=0.4)
                ax.set_xlabel(series[0]['name'])
                ax.set_ylabel(series[1]['name'])
                ax.set_zlabel(series[2]['name'])
            else:
                wells = {}
                for c, xv, yv, zv in zip(cats, *(s['values'] for s in series[:3])):
                    if None not in (xv, yv, zv):
                        wells.setdefault(str(c), []).append((xv, yv, zv))
                for i, (name, pts) in enumerate(wells.items()):
                    a = np.array(pts)
                    col = '#' + PALETTE[i % 6]
                    ax.plot(a[:, 0], a[:, 1], a[:, 2], color=col, linewidth=2.4, label=name)
                    ax.scatter(a[-1, 0], a[-1, 1], a[-1, 2], color=col, s=30)
                    ax.scatter(a[0, 0], a[0, 1], a[0, 2], color=col, s=30, marker='^')
                zs = [p[2] for pts in wells.values() for p in pts]
                if zs and all(z >= 0 for z in zs):                  # глубина — вниз
                    ax.invert_zaxis()
                ax.set_xlabel(series[0]['name'])
                ax.set_ylabel(series[1]['name'])
                ax.set_zlabel(series[2]['name'])
                if len(wells) <= 12:
                    ax.legend(loc='upper left', fontsize=9, frameon=False)
            ax.view_init(elev=24, azim=-58)
            try:
                ax.set_box_aspect(None, zoom=0.9)           # подписи осей не обрезаются краем картинки
            except TypeError:
                pass
            fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
        else:
            ax = fig.add_subplot(111)
            if t == 'heatmap':
                z = _grid(ch)
                try:
                    import seaborn as sns
                    ann = np.array([[_num_txt(v) if v == v else '' for v in row] for row in z]) if z.size <= 120 else False
                    sns.heatmap(z, ax=ax, cmap=_cmap_light(), annot=ann, fmt='', linewidths=1, linecolor='white',
                                cbar_kws={'label': unit} if unit else None, xticklabels=[s['name'] for s in series],
                                yticklabels=cats, annot_kws={'fontsize': 9})
                except ImportError:
                    im = ax.imshow(z, cmap=_cmap_light(), aspect='auto')
                    fig.colorbar(im, ax=ax)
                    ax.set_xticks(range(len(series)))
                    ax.set_xticklabels([s['name'] for s in series])
                    ax.set_yticks(range(len(cats)))
                    ax.set_yticklabels(cats)
                ax.tick_params(axis='x', rotation=0 if len(series) <= 6 else 45)
                ax.tick_params(axis='y', rotation=0)
            elif t == 'contour_img':
                z = _grid(ch)
                X, Y = np.meshgrid(_axis_vals([s['name'] for s in series]), _axis_vals(cats))
                cf = ax.contourf(X, Y, z, levels=10, cmap=_cmap())
                cs = ax.contour(X, Y, z, levels=10, colors='white', linewidths=0.6)
                ax.clabel(cs, fontsize=8, fmt=lambda v: _num_txt(v))
                fig.colorbar(cf, ax=ax, label=unit or None)
                ax.set_aspect('auto')
            elif t in ('violin', 'kde'):
                data = [[v for v in s['values'] if v is not None] for s in series]
                names = [s['name'] for s in series]
                try:
                    import seaborn as sns
                    import pandas as pd
                    df = pd.DataFrame([(n, v) for n, d in zip(names, data) for v in d], columns=['Группа', 'Значение'])
                    if t == 'violin':
                        sns.violinplot(data=df, x='Группа', y='Значение', hue='Группа', ax=ax, inner='quart',
                                       palette=['#' + PALETTE[i % 6] for i in range(len(names))], legend=False, cut=0)
                    else:
                        sns.kdeplot(data=df, x='Значение', hue='Группа' if len(names) > 1 else None, ax=ax, fill=True,
                                    alpha=0.35, linewidth=2, palette=['#' + PALETTE[i % 6] for i in range(len(names))] if len(names) > 1 else None,
                                    color='#0078AE' if len(names) == 1 else None, common_norm=False)
                    ax.set_xlabel(unit if t == 'kde' and unit else ('' if t == 'violin' else 'Значение'))
                    ax.set_ylabel(unit if t == 'violin' and unit else ('Плотность' if t == 'kde' else ''))
                except ImportError:
                    if t == 'violin':
                        ax.violinplot(data, showmedians=True)
                        ax.set_xticks(range(1, len(names) + 1))
                        ax.set_xticklabels(names)
                    else:
                        for i, d in enumerate(data):
                            ax.hist(d, bins=15, density=True, alpha=0.5, label=names[i])
                ax.grid(axis='y', color='#E3E8EF')
            elif t == 'rose':
                fig.clf()
                ax = fig.add_subplot(111, projection='polar')
                dirs = {'с': 0, 'ссв': 22.5, 'св': 45, 'всв': 67.5, 'в': 90, 'вюв': 112.5, 'юв': 135, 'ююв': 157.5, 'ю': 180,
                        'ююз': 202.5, 'юз': 225, 'зюз': 247.5, 'з': 270, 'зсз': 292.5, 'сз': 315, 'ссз': 337.5}
                ang = []
                for i, c in enumerate(cats):
                    k = str(c).strip().lower().replace('ё', 'е').replace('-', '')
                    a = dirs.get(k)
                    if a is None:
                        a = to_num(c)
                    ang.append(math.radians(a if a is not None else i * 360 / len(cats)))
                width = 2 * math.pi / max(len(cats), 8) * 0.85
                bottom = np.zeros(len(cats))
                for i, s in enumerate(series):
                    v = np.array([x or 0 for x in s['values']], dtype=float)
                    ax.bar(ang, v, width=width, bottom=bottom, color='#' + PALETTE[i % 6], edgecolor='white', label=s['name'], alpha=0.92)
                    bottom += v
                ax.set_theta_zero_location('N')
                ax.set_theta_direction(-1)
                ax.set_xticks(ang)
                ax.set_xticklabels(cats)
                if len(series) > 1:
                    ax.legend(loc='upper right', bbox_to_anchor=(1.25, 1.05), frameon=False)
        fig.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=200, facecolor='white', bbox_inches='tight', pad_inches=0.08)
        return _trim(buf.getvalue())
    finally:
        plt.close(fig)


def _trim(png, pad=16):
    """Срезает белые поля картинки (у объёмных видов matplotlib оставляет много пустого места), чтобы
    диаграмма заняла всё отведённое ей место на слайде."""
    try:
        from PIL import Image, ImageChops
        im = Image.open(io.BytesIO(png)).convert('RGB')
        box = ImageChops.difference(im, Image.new('RGB', im.size, (255, 255, 255))).point(lambda p: 255 if p > 12 else 0).getbbox()
        if not box:
            return png
        l, t, r, b = box
        im = im.crop((max(0, l - pad), max(0, t - pad), min(im.width, r + pad), min(im.height, b + pad)))
        out = io.BytesIO()
        im.save(out, 'PNG', optimize=True)
        return out.getvalue()
    except Exception:                                      # noqa: BLE001
        return png


def _wordcloud_png(ch, w, h):
    from wordcloud import WordCloud
    freqs = {}
    for c, v in zip(ch['categories'], ch['series'][0]['values']):
        if c and v is not None and v > 0:
            freqs[str(c)] = freqs.get(str(c), 0) + float(v)
    font = None
    try:
        from matplotlib import font_manager
        for f in ('TT Bluescreens Pro', 'Segoe UI', 'Arial', 'DejaVu Sans'):
            try:
                font = font_manager.findfont(f, fallback_to_default=False)
                break
            except Exception:                              # noqa: BLE001
                continue
    except ImportError:
        pass
    cols = ['#00326E', '#0078AE', '#4BAF46', '#0A8F2D', '#005491']

    def color(word, font_size, position, orientation, random_state=None, **kw):
        return cols[(len(word) + int(font_size)) % len(cols)]
    wc = WordCloud(width=int(w * 200), height=int(h * 200), background_color='white', font_path=font, prefer_horizontal=0.92,
                   color_func=color, random_state=7, margin=6, max_words=120, relative_scaling=0.5, collocations=False)
    wc.generate_from_frequencies(freqs)
    buf = io.BytesIO()
    wc.to_image().save(buf, 'PNG')
    return buf.getvalue()


def notes_text(s):
    """Данные диаграммы-картинки для заметок докладчика (их можно поправить и построить заново)."""
    ch = s.get('chart') or {}
    if ch.get('type') not in IMAGE_TYPES:
        return ''
    head = ['Подпись'] + [x['name'] for x in ch.get('series') or []]
    rows = ['\t'.join(head)]
    for i, c in enumerate(ch.get('categories') or []):
        rows.append('\t'.join([str(c)] + [_num_txt(x['values'][i]) if i < len(x['values']) else '' for x in ch['series']]))
    return f'Данные диаграммы «{TYPES[ch["type"]][0]}»' + (f', {ch["unit"]}' if ch.get('unit') else '') + ':\n' + '\n'.join(rows[:60])


# --------------------------------------------------------------------------------------
# Точка входа
# --------------------------------------------------------------------------------------
NATIVE = {**{k: _r_line for k in LINE_XL}, **{k: _r_area for k in AREA_XL}, 'bar_stacked100': _r_bar100,
          **{k: _r_3d for k in list(BAR3D) + ['line3d', 'area3d', 'pie3d']},
          'pie_exploded': _r_pie, 'pie_of_pie': _r_pie, 'bar_of_pie': _r_pie,
          **{k: _r_xy for k in XY_TYPES}, 'radar_lines': _r_radar, 'radar_markers': _r_radar,
          'stock_hlc': _r_stock, 'stock_ohlc': _r_stock,
          **{k: _r_surface for k in ('surface3d', 'surface_wire', 'contour', 'contour_wire')},
          'waterfall': _r_waterfall, 'histogram': _r_histogram, 'pareto': _r_pareto, 'boxplot': _r_boxplot,
          'funnel_chart': _r_funnel, 'sunburst': _r_sunburst}
SHAPES = {'treemap': _r_treemap, 'waffle': _r_waffle, 'network': _r_network}


def available(t):
    """Есть ли библиотека, которой рисуется вид (matplotlib, seaborn, wordcloud — для картинок)."""
    if t not in IMAGE_TYPES:
        return True
    try:
        if t == 'wordcloud':
            import wordcloud  # noqa: F401
        import matplotlib  # noqa: F401
        return True
    except ImportError:
        return False


def missing_note(t):
    """Пояснение в заметки докладчика, когда вид-картинку нечем нарисовать и показана обычная диаграмма."""
    lib = 'wordcloud и matplotlib' if t == 'wordcloud' else 'matplotlib'
    return (f'Вид «{TYPES[t][0]}» рисуется библиотекой {lib}, а её нет на этом компьютере, поэтому показана '
            'обычная диаграмма. Библиотеку ставит установка (setup_windows.bat).')


def fallback(t):
    """Обычный вид вместо картинки, если рисовать нечем."""
    return {'heatmap': 'column', 'contour_img': 'line', 'surface_img': 'line', 'violin': 'column', 'kde': 'column',
            'scatter3d': 'column', 'trajectory3d': 'line', 'rose': 'radar', 'wordcloud': 'bar'}.get(t, 'column')


def render(ctx, sl, s, x, y, w, h):
    """Рисует диаграмму слайда s в прямоугольник (дюймы). Возвращает фигуру для анимации и вид анимации."""
    ch = s['chart']
    t = ch['type']
    if t in NATIVE:
        gf = NATIVE[t](sl, ch, (x, y, w, h))
        return gf, ('zoom' if t in PIE_TYPES + ('sunburst',) else 'wipe_l' if t not in ('funnel_chart',) else 'wipe_t')
    if t in SHAPES:
        return SHAPES[t](ctx, sl, ch, (x, y, w, h)), 'fade'
    png = image_png(ch, w, h)
    pic = sl.shapes.add_picture(io.BytesIO(png), I(x), I(y))
    k = min(w / (pic.width / 914400), h / (pic.height / 914400))
    pw, ph = pic.width * k, pic.height * k
    pic.width, pic.height = int(pw), int(ph)
    pic.left = int(I(x) + (I(w) - pw) / 2)
    pic.top = int(I(y) + (I(h) - ph) / 2)
    pic._element.nvPicPr.cNvPr.set('descr', f'{TYPES[t][0]}: {s.get("title") or ""}'[:250])
    return pic, 'fade'
