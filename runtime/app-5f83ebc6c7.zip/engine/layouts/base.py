# -*- coding: utf-8 -*-
"""
base.py — ОБЩИЕ ФУНКЦИИ УНИВЕРСАЛЬНЫХ МАКЕТОВ
============================================

Каждый макет (cards.py, chart.py …) — функция render(ctx, s), где
    ctx — контекст сборки (Ctx): презентация, мета-данные, реестр анимаций;
    s   — описание слайда из спецификации (dict).

Здесь — то, что нужно всем макетам:
  * Ctx               — контекст одной сборки (анимации хранятся ПО-СБОРОЧНО, чтобы два
                        пользователя, собирающие презентации одновременно, не мешали друг другу);
  * content_slide()   — новый контентный слайд: заголовок/подзаголовок с подгонкой кегля,
                        подпись раздела в подвале, заметки докладчика; возвращает рабочую
                        область (верх и низ, куда можно рисовать);
  * conclusion()      — нижний баннер-вывод с подгонкой текста;
  * ftext()           — текстовое поле с автоподбором кегля и сокращением «…»;
  * PALETTE / pair()  — последовательность цветов для элементов (от синего к зелёному).

Геометрия контентного слайда (дюймы):
    заголовок y 0,40–1,05; подзаголовок y 1,06–1,47;
    рабочая область: верх 1,65 (с подзаголовком) или 1,35 (без), низ 6,85;
    если есть баннер-вывод: низ рабочей области 5,95, баннер на y 6,12.
"""
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

from ..nts import config as C
from ..nts.animation import finalize_slide_fx
from ..nts.effects import flatten_gradients
from ..nts.shapes import bottom_banner, text
from ..nts.config import (BLUE, DBLUE, DGREEN, GRAY, GREEN, LGREEN, NAVY, WHITE, rgb)
from ..textfit import clip, fit_size_many, one_line_size, text_height, text_width

TOP_SUB, TOP_NOSUB, BOTTOM, BOTTOM_BANNER = 1.65, 1.35, 6.85, 5.95
TITLE_W = 11.46

# Пары цветов (основной, второй цвет градиента) для элементов по порядку: синий → зелёный
PALETTE = [(NAVY, DBLUE), (DBLUE, BLUE), (BLUE, rgb('2E95C4')), (DGREEN, rgb('2FA046')),
           (rgb('2FA046'), GREEN), (GREEN, LGREEN)]


def pair(i, n):
    """Цвета i-го элемента из n: равномерно по палитре от синего к зелёному."""
    if n <= 1:
        return PALETTE[0]
    k = round(i * (len(PALETTE) - 1) / (n - 1))
    return PALETTE[k]


class Ctx:
    """Контекст одной сборки."""

    def __init__(self, deck, meta):
        self.d = deck
        self.meta = meta
        self.anims = {}                       # slide_id → (slide, [(shape_id, вид, задержка, длительность)])
        self.use_anim = bool(meta.get('animations', True))
        self.use_grad = meta.get('gradients', True) is not False   # галочка «Градиент в фигурах» (1.9)
        self.tpl = getattr(deck, 'theme', None)   # свой шаблон пользователя (nts/theme.py) или None
        self.tpl_marks = {}                   # slide_id → (верх рабочей полосы, есть подзаголовок) — для переноса
        self.fill_marks = {}                  # slide_id → (верх, низ рабочей области, макет) — слайд заполняется (1.9)
        self.use_fill = meta.get('fill', True) is not False

    def anim(self, sl, shp, kind='fade', delay=0, dur=500):
        if self.use_anim:
            self.anims.setdefault(sl.slide_id, (sl, []))[1].append((shp.shape_id, kind, delay, dur))

    def finalize(self):
        """Свой шаблон: перенос нарисованного в его поля и цвета. Переходы «Выцветание» для всех
        слайдов и анимации (если включены). Без градиентов — сплошная заливка фигур."""
        if self.use_fill:                     # элементы — на всю рабочую область, текст крупнее (fill.py)
            from .fill import fill_slide
            for sl in self.d.prs.slides:
                mark = self.fill_marks.get(sl.slide_id)
                if mark:
                    try:
                        fill_slide(sl, *mark)
                    except Exception:             # noqa: BLE001 — слайд остаётся как нарисован макетом
                        import logging
                        logging.getLogger(__name__).exception('fill failed')
        if self.tpl is not None:
            self.tpl.finish(self)
        for sl in self.d.prs.slides:
            _drop_empty_placeholders(sl)
            if not self.use_grad and sl._element.find(qn('p:cSld')).get('name') != 'zn:own':   # свои слайды — как есть
                flatten_gradients(sl)
            items = self.anims.get(sl.slide_id, (sl, []))[1] if self.use_anim else []
            finalize_slide_fx(sl, items, 'fade')


def _drop_empty_placeholders(sl):
    """Пустые поля-заполнители убираются: в PowerPoint они показывают «Текст слайда» / «Щёлкните, чтобы добавить
    текст» (например, подпись раздела в подвале, когда раздела нет). Поля с картинкой, таблицей, диаграммой остаются."""
    for ph in list(sl.placeholders):
        el = ph._element
        if el.tag != qn('p:sp') or el.find('.//' + qn('a:blipFill')) is not None:
            continue
        if ph.has_text_frame and not ph.text_frame.text.strip():
            el.getparent().remove(el)


def _set_runs_size(ph, size):
    for p in ph.text_frame.paragraphs:
        for r in p.runs:
            r.font.size = Pt(size)


def content_slide(ctx, s, dark=False):
    """Новый контентный слайд. Возвращает (slide, top, bottom) — границы рабочей области."""
    if ctx.tpl is not None:
        from .tplframe import content_slide as tpl_content_slide
        return tpl_content_slide(ctx, s)
    d = ctx.d
    layout = d.L_DARK if dark else d.L_WHITE
    title = s.get('title') or ''
    sub = s.get('subtitle') or ''
    sl = d.prs.slides.add_slide(layout)
    two_line_sub = False
    for ph in list(sl.placeholders):
        idx = ph.placeholder_format.idx
        if idx == C.PH_TITLE:
            # заголовок — в одну строку: кегль от 40 до 24 пт, если и так не влезает — сокращаем
            size = one_line_size(title, TITLE_W, 40, 24, 'mj')
            ph.text_frame.text = title if size > 24 else clip(title, TITLE_W, 0.6, 24, 'mj', max_lines=1)
            _set_runs_size(ph, size)
        elif idx == C.PH_SUBTITLE:
            if sub:
                size = one_line_size(sub, TITLE_W, 20, 15, 'mn')
                if size > 15 or text_width(sub, 15, 'mn') <= TITLE_W * 0.95:
                    ph.text_frame.text = sub
                    _set_runs_size(ph, size)
                else:
                    # длинный подзаголовок — в две строки по 15 пт, рабочая область сдвигается вниз
                    ph.text_frame.text = clip(sub, TITLE_W, 0.56, 15, 'mn', max_lines=2)
                    ph.text_frame.word_wrap = True
                    _set_runs_size(ph, 15)
                    # у заполнителя нет своих координат (они наследуются от макета) —
                    # задаём все четыре, иначе ширина станет нулевой
                    l_, t_, w_ = ph.left, ph.top, ph.width
                    ph.left, ph.top, ph.width, ph.height = l_, t_, w_, Inches(0.62)
                    two_line_sub = True
            else:
                ph._element.getparent().remove(ph._element)
        elif idx == C.PH_FOOTER:
            ph.text_frame.text = s.get('section') or ''
    if s.get('notes'):
        sl.notes_slide.notes_text_frame.text = s['notes']
    top = (TOP_SUB + 0.25 if two_line_sub else TOP_SUB) if sub else TOP_NOSUB
    bottom = BOTTOM_BANNER if s.get('conclusion') else BOTTOM
    ctx.fill_marks[sl.slide_id] = (top, bottom, s.get('layout') or '')
    return sl, top, bottom


def conclusion(ctx, sl, s, delay=1500):
    """Нижний баннер-вывод (если в слайде задан conclusion)."""
    txt = s.get('conclusion')
    if not txt:
        return
    from ..nts.shapes import group
    lead = s.get('conclusion_lead') or ctx.meta.get('conclusion_lead') or 'Вывод: '
    g = group(sl)
    g.name = 'zn-banner'                      # баннер — не часть содержимого при заполнении слайда (fill.py)
    w = C.CW * 0.7
    full = lead + txt
    size = fit_size_many([full], w, 0.66, 14.5, 10.5, 'mn', max_lines=2)
    clipped = clip(full, w, 0.66, size, 'mn', max_lines=2)
    body = clipped[len(lead):] if clipped.startswith(lead) else txt
    bottom_banner(g, lead, body, size=size)
    ctx.anim(sl, g, 'wipe_l', delay, 700)


def ftext(sl, x, y, w, h, content, max_size, min_size, font='mn', color=GRAY, align=PP_ALIGN.LEFT,
          anchor=MSO_ANCHOR.TOP, max_lines=None, size=None):
    """Текстовое поле с автоподбором кегля (или заданным size) и сокращением текста «…».

    content — строка или «кусочки» [[(текст, настройки), …]] (тогда подгонка — по склеенному тексту).
    Возвращает (фигура, кегль).
    """
    if isinstance(content, str):
        plain = content
    else:
        plain = ''.join(t for para in content for t, _ in para)
    if size is None:
        size = fit_size_many([plain], w, h, max_size, min_size, font, max_lines=max_lines)
    if isinstance(content, str):
        content = clip(content, w, h, size, font, max_lines)
    tb = text(sl, x, y, w, h, content, size=size, color=color, font=font, align=align, anchor=anchor)
    return tb, size


def common_size(texts, w, h, max_size, min_size, font='mn', max_lines=None):
    """Один кегль для группы однотипных текстов (все карточки слайда)."""
    return fit_size_many([t for t in texts if t], w, h, max_size, min_size, font, max_lines=max_lines)


def stack_fit(texts, w, avail, max_size, min_size, font='mn', pad=0.12, gap=0.2, min_h=0.0):
    """Блоки текста друг под другом на высоте avail: общий кегль — наибольший, при котором ВСЕ блоки
    вместе помещаются (а не каждый в свою долю высоты), и высоты блоков по их тексту. Оставшееся место
    делится между блоками поровну — колонка заполнена до низа, без пустых полос.
    Возвращает (кегль, [высоты])."""
    n = len(texts)
    if not n:
        return min_size, []
    s = max_size
    while True:
        need = [max(min_h, text_height(t, w, s, font) + pad) if t else min_h for t in texts]
        if sum(need) + gap * (n - 1) <= avail + 1e-6 or s <= min_size:
            break
        s = max(min_size, s - 0.5)
    extra = max(0.0, avail - sum(need) - gap * (n - 1)) / n
    return s, [h + extra for h in need]


def grid(n, max_cols):
    """Раскладка n элементов по строкам: [число элементов в строке, …] (например, 5 → [3, 2])."""
    if n <= max_cols:
        return [n]
    rows = -(-n // max_cols)
    base = n // rows
    extra = n % rows
    return [base + (1 if r < extra else 0) for r in range(rows)]


__all__ = ['Ctx', 'content_slide', 'conclusion', 'ftext', 'common_size', 'stack_fit', 'grid', 'pair', 'PALETTE',
           'TOP_SUB', 'TOP_NOSUB', 'BOTTOM', 'BOTTOM_BANNER', 'WHITE', 'NAVY', 'GREEN', 'DGREEN', 'BLUE',
           'DBLUE', 'LGREEN', 'GRAY']
