# -*- coding: utf-8 -*-
"""
tplframe.py — «РАМКА» СЛАЙДА НА СВОЁМ ШАБЛОНЕ: заголовок, подзаголовок, титул, раздел, финал
==========================================================================================

Когда выбран свой шаблон пользователя (engine/templates.py), слайды создаются по его
макетам, а заголовки пишутся в ЕГО заполнители: шрифт, цвет, место и кегль по умолчанию
задаёт шаблон. Кегль уменьшается, только если текст не помещается.

    content_slide(ctx, s)  — контентный слайд: заголовок, подзаголовок (заполнитель шаблона
                             или надпись под заголовком), номер слайда, светлая подложка на
                             тёмном фоне; возвращает рабочую полосу в координатах макетов
                             (как обычный content_slide), перенос в поля шаблона — nts/theme.py;
    frame_slide(ctx, role, title, lines) — титульный, раздел, финал: заголовок и строки текста
                             в заполнители макета этой роли.
"""
import copy

from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.shapes import PP_PLACEHOLDER as PH
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

from ..nts.shapes import rect, text
from ..templates import apply_decor
from ..textfit import clip, fit_size

TITLES = (PH.TITLE, PH.CENTER_TITLE, PH.VERTICAL_TITLE)
TOP_SUB, TOP_NOSUB, BOTTOM, BOTTOM_BANNER = 1.65, 1.35, 6.85, 5.95


def _rgb(hexv, default='1F1F1F'):
    try:
        return RGBColor.from_string((hexv or default).upper())
    except ValueError:
        return RGBColor.from_string(default)


def _ink(th, role):
    """Цвет надписей на фоне макета роли (тёмный фон — светлые буквы)."""
    key = '%d:%d' % tuple(th.roles.get(role) or th.roles['content'])
    dark = next((x.get('dark') for x in th.info.get('layouts') or [] if x.get('key') == key), False)
    c = th.colors
    if dark:
        return _rgb(c.get('lt1'), 'FFFFFF')
    return _rgb(c.get('dk2') if role == 'content' and not th.panel else c.get('dk1'), '1F1F1F')


def _fill(ph, content, slot, font, min_ratio=0.55, max_lines=None, bullets=None):
    """Текст в заполнитель шаблона; кегль шаблона уменьшается, только если текст не помещается."""
    w, h, size0 = slot[2] - 0.2, slot[3] - 0.1, slot[4] or 24
    lines = [content] if isinstance(content, str) else [x for x in content if x]
    if not lines:
        return
    lo = max(10.0, round(size0 * min_ratio))
    size = fit_size(lines if len(lines) > 1 else lines[0], w, h, size0, lo, font, max_lines=max_lines)
    if len(lines) == 1:
        lines = [clip(lines[0], w, h, size, font, max_lines)]
    tf = ph.text_frame
    tf.text = lines[0]
    for line in lines[1:]:
        tf.add_paragraph().text = line
    if bullets is False:                                     # строки титула и финала — без маркеров списка
        for p in tf.paragraphs:
            ppr = p._p.get_or_add_pPr()
            ppr.set('marL', '0')
            ppr.set('indent', '0')
            for old in ppr.findall(qn('a:buNone')) + ppr.findall(qn('a:buChar')) + ppr.findall(qn('a:buAutoNum')):
                ppr.remove(old)
            after = next((c for c in ppr if c.tag in (qn('a:tabLst'), qn('a:defRPr'), qn('a:extLst'))), None)
            bu = ppr.makeelement(qn('a:buNone'), {})
            if after is None:
                ppr.append(bu)
            else:
                after.addprevious(bu)
    if size < size0 - 0.01:
        for p in tf.paragraphs:
            for r in p.runs:
                r.font.size = Pt(size)


def _box(sl, rect_, content, size0, font, color, name, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, max_lines=None):
    """Надпись вместо заполнителя, которого нет в макете шаблона."""
    x, y, w, h = rect_[:4]
    lines = [content] if isinstance(content, str) else [t for t in content if t]
    size = fit_size(lines if len(lines) > 1 else lines[0], w, h, size0, max(10, size0 * 0.55), font, max_lines=max_lines)
    if len(lines) == 1:
        lines = clip(lines[0], w, h, size, font, max_lines)
    tb = text(sl, x, y, w, h, lines, size=size, color=color, font=font, align=align, anchor=anchor)
    tb.name = name
    return tb


def _slide_number(sl, layout):
    """Номер слайда, если он есть в макете шаблона (python-pptx сам его не переносит)."""
    for ph in layout.placeholders:
        try:
            if ph.placeholder_format.type != PH.SLIDE_NUMBER:
                continue
        except Exception:                                    # noqa: BLE001
            continue
        el = copy.deepcopy(ph._element)
        el.find('.//' + qn('p:cNvPr')).set('id', str(sl.shapes._next_shape_id))
        sl.shapes._spTree.append(el)
        return


def content_slide(ctx, s):
    th, d = ctx.tpl, ctx.d
    layout = th.layout(d.prs, 'content')
    sl = d.prs.slides.add_slide(layout)
    apply_decor(sl, getattr(d, 'decor', {}).get('content'))
    f = th.frame
    title = s.get('title') or ''
    sub = s.get('subtitle') or ''
    tph = sph = None
    for ph in list(sl.placeholders):
        try:
            t, idx = ph.placeholder_format.type, ph.placeholder_format.idx
        except Exception:                                    # noqa: BLE001
            t, idx = None, None
        if t in TITLES and tph is None:
            tph = ph
        elif sub and f.get('sub_idx') is not None and idx == f['sub_idx'] and sph is None:
            sph = ph
        else:
            ph._element.getparent().remove(ph._element)
    if th.panel:                                             # тёмный фон — светлая подложка под содержимым
        top = f['top_sub'] if sub else f['top']
        p = rect(sl, f['L'] - 0.12, top - 0.08, f['R'] - f['L'] + 0.24, f['bottom'] - top + 0.16,
                 fill=_rgb(th.colors.get('lt1'), 'FFFFFF'), shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.03, name='zn-tpl-panel')
        p.shadow.inherit = False
    tslot = list(f.get('title_safe') or f['title']) + [th.title_size]
    if f.get('title_safe') and tph is not None:           # логотип справа — поле заголовка сужается до него
        tph.left, tph.top, tph.width, tph.height = (Inches(v) for v in f['title_safe'])
    two = tslot[3] >= 2 * max(16, th.title_size * 0.6) * 1.22 / 72 + 0.1
    if title:
        if tph is not None:
            _fill(tph, title, tslot, 'mj', 0.6, max_lines=2 if two else 1)
        else:
            _box(sl, tslot, title, th.title_size, 'mj', _ink(th, 'content'), 'zn-tpl-title', anchor=MSO_ANCHOR.MIDDLE,
                 max_lines=2 if two else 1)
    elif tph is not None:
        tph._element.getparent().remove(tph._element)
    if sub:
        if sph is not None:
            _fill(sph, sub, f['sub'] + [18], 'mn', 0.7, max_lines=2)
        else:
            _box(sl, f['sub'], sub, 18, 'mn', _ink(th, 'content'), 'zn-tpl-sub', max_lines=1)
    _slide_number(sl, layout)
    if s.get('notes'):
        sl.notes_slide.notes_text_frame.text = s['notes']
    top_c = TOP_SUB if sub else TOP_NOSUB
    ctx.tpl_marks[sl.slide_id] = (top_c, bool(sub))
    ctx.fill_marks[sl.slide_id] = (top_c, BOTTOM_BANNER if s.get('conclusion') else BOTTOM, s.get('layout') or '')
    return sl, top_c, BOTTOM_BANNER if s.get('conclusion') else BOTTOM


def frame_slide(ctx, role, title, lines, notes=None):
    """Титульный, раздел или финал: слайд по макету роли, заголовок и строки — в его заполнители."""
    th, prs = ctx.tpl, ctx.d.prs
    sl = prs.slides.add_slide(th.layout(prs, role))
    apply_decor(sl, getattr(ctx.d, 'decor', {}).get(role))
    slot = (th.info.get('slots') or {}).get(role) or {}
    ts, bs = slot.get('title'), slot.get('body')
    lines = [x for x in lines if x]
    tph = bph = None
    for ph in list(sl.placeholders):
        idx = ph.placeholder_format.idx
        if ts and idx == ts[5] and tph is None:
            tph = ph
        elif bs and lines and idx == bs[5] and bph is None:
            bph = ph
        else:
            ph._element.getparent().remove(ph._element)
    sw, sh = th.w, th.h
    ink = _ink(th, role)
    for ph, sl_ in ((tph, ts), (bph, bs)):                 # логотип справа — поле текста сужается до него
        if ph is not None and len(sl_) > 6 and sl_[6]:
            ph.left, ph.top, ph.width, ph.height = (Inches(v) for v in sl_[:4])
    if tph is not None:
        _fill(tph, title, ts, 'mj', 0.55, max_lines=3)
        ctx.anim(sl, tph, 'rise', 0, 700)
    elif title:
        tb = _box(sl, [sw * 0.08, sh * 0.3, sw * 0.84, sh * 0.22], title, 40, 'mj', ink, 'zn-tpl-title',
                  anchor=MSO_ANCHOR.BOTTOM, max_lines=3)
        ctx.anim(sl, tb, 'rise', 0, 700)
    if lines:
        if bph is not None:
            _fill(bph, lines, bs, 'mn', 0.6, bullets=False)
            ctx.anim(sl, bph, 'fade', 400, 700)
        else:
            y = (ts[1] + ts[3] + 0.15) if ts else sh * 0.55
            tb = _box(sl, [ts[0] if ts else sw * 0.08, y, ts[2] if ts else sw * 0.84, min(1.6, sh - y - 0.4)], lines,
                      20, 'mn', ink, 'zn-tpl-sub')
            ctx.anim(sl, tb, 'fade', 400, 700)
    if notes:
        sl.notes_slide.notes_text_frame.text = notes
    return sl
