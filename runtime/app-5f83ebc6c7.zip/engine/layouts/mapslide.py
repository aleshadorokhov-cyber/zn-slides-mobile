# -*- coding: utf-8 -*-
"""
mapslide.py — СХЕМА «КАРТА»: страны из пунктов выделены на карте мира, справа — пояснения
========================================================================================

Пункты — страны (или текст, в котором названа страна): items [{'title': 'Вьетнам', 'text': '…',
'value', 'unit'}]. Страна ищется в заголовке пункта, затем в тексте (engine/geo.py). Карта сама
выбирает область: одна страна или соседние — крупно, страны на разных континентах — весь мир.
Каждая страна — отдельная фигура PowerPoint (её можно перекрасить или удалить), номера на карте
совпадают с номерами пояснений.
"""
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR
from pptx.util import Pt

from .. import geo
from ..nts import config as C
from ..nts.config import rgb
from ..nts.effects import grad, shadow
from ..nts.shapes import group, line, rect, shape_text, text
from ..textfit import clip, text_height
from .base import GRAY, NAVY, WHITE, common_size, conclusion, content_slide, pair

OCEAN1, OCEAN2 = rgb('F3F7FB'), rgb('E4EDF5')
LAND = rgb('D3DCE6')


def map_ok(items):
    """Схема подходит: 2–8 пунктов, у большинства названа страна, стран не меньше двух."""
    items = [it for it in items or [] if isinstance(it, dict)]
    if not 2 <= len(items) <= 8:
        return False
    cs = geo.item_countries(items)
    have = [c for c in cs if c]
    return len(have) >= max(2, -(-len(items) * 3 // 5)) and len(set(have)) >= 2


def _title(it):
    t = it.get('title') or ''
    v = f"{it.get('value') or ''} {it.get('unit') or ''}".strip()
    if v and str(it.get('value')) not in t:
        t = f'{t} · {v}' if t else v
    return t


def render_map(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = [it for it in s.get('items') or [] if isinstance(it, dict)][:8]
    n = len(items)
    cs = geo.item_countries(items)
    ids = []
    for c in cs:
        if c and c not in ids:
            ids.append(c)
    has_text = any(it.get('text') for it in items)
    leg_w = C.CW * (0.36 if has_text else 0.27)
    map_w = C.CW - leg_w - 0.35
    map_h = bottom - top
    mx, my = C.L, top
    view = geo.map_view(ids, map_w / map_h)
    W, H = geo.size()
    if view[3] > H * 1.02:                                   # весь мир: рамка по пропорциям карты, без пустот
        nh = max(2.2, map_w * H / W)
        my, map_h = top + (map_h - nh) / 2, nh
        view = (0.0, 0.0, W, H)
    # «океан» — скруглённая подложка
    g = group(sl)
    sea = rect(g, mx, my, map_w, map_h, fill=OCEAN1, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.04)
    grad(sea, OCEAN1, OCEAN2, 90)
    colors = {}
    for i, c in enumerate(cs):
        if c and c not in colors:
            colors[c] = pair(i, n)
    pad = 0.12
    geo.draw_map(g, mx + pad, my + pad, map_w - 2 * pad, map_h - 2 * pad, view, colors=colors, land=LAND,
                 border=WHITE, border_w=0.6)
    ctx.anim(sl, g, 'fade', 0, 700)
    # номера на карте
    placed = []
    for i, c in enumerate(cs):
        if not c or c in [p[0] for p in placed]:
            continue
        pt = geo.label_point(c, view)
        if not pt:
            continue
        d = 0.42
        ax = mx + pad + pt[0] * (map_w - 2 * pad)
        ay = my + pad + pt[1] * (map_h - 2 * pad)
        px, py = ax - d / 2, ay - d / 2
        b0 = geo.country_box(c)
        small = b0 and max((b0[2] - b0[0]) * (map_w - 2 * pad) / view[2], (b0[3] - b0[1]) * (map_h - 2 * pad) / view[3]) < 0.7
        if small:                                            # маленькая страна: номер над ней, к стране — выноска
            py = ay - d - 0.38
            if py < my + 0.05:
                py = ay + 0.38
        for _, ox, oy in placed:                                # не накладываем номера друг на друга
            if abs(ox - px) < d and abs(oy - py) < d:
                py = oy + d + 0.04
        px = min(max(mx + 0.05, px), mx + map_w - d - 0.05)
        py = min(max(my + 0.05, py), my + map_h - d - 0.05)
        placed.append((c, px, py))
        nums = [str(k + 1) for k, cc in enumerate(cs) if cc == c]
        gm = group(sl)
        c1, c2 = pair(i, n)
        if small:
            line(gm, ax, ay, px + d / 2, py + (d if py < ay else 0), color=NAVY, w=1.25, head=False)
            dot = rect(gm, ax - 0.06, ay - 0.06, 0.12, 0.12, fill=WHITE, shape=MSO_SHAPE.OVAL)
            dot.line.color.rgb = NAVY
            dot.line.width = Pt(1.75)
        b = rect(gm, px, py, d, d, fill=c1, shape=MSO_SHAPE.OVAL)
        grad(b, c1, c2, 45)
        b.line.color.rgb = WHITE
        b.line.width = Pt(2)
        shadow(b, 10, 2, 30)
        shape_text(b, ','.join(nums[:2]), size=12 if len(nums) == 1 else 9, color=WHITE, font='b', margins=(0, 0, 0, 0))
        ctx.anim(sl, gm, 'zoom', 500 + i * 150, 400)
    # пояснения справа
    lx = C.L + map_w + 0.35
    titles = [_title(it) for it in items]
    texts = [it.get('text') or '' for it in items]
    rh = (bottom - top) / max(n, 1)
    tw = leg_w - 0.55
    ts = common_size(titles, tw, min(0.55, rh * 0.45), 17 if n <= 3 else (15 if n <= 5 else 13), 10.5, 'mj', max_lines=2)
    xs = common_size(texts, tw, max(0.25, rh - 0.5), 13 if n <= 3 else 12, 9, 'mn') if has_text else 11
    hs = []
    for t_, x_ in zip(titles, texts):
        th = text_height(clip(t_, tw, rh, ts, 'mj', 2), tw, ts, 'mj') + 0.05 if t_ else 0
        bh = text_height(clip(x_, tw, max(0.2, rh - th - 0.1), xs, 'mn'), tw, xs, 'mn') if x_ else 0
        hs.append(th + bh)
    total = sum(hs) + 0.22 * (n - 1)
    y = top + max(0.0, (bottom - top - total) / 2)
    for i, it in enumerate(items):
        c1, c2 = pair(i, n)
        gi = group(sl)
        b = rect(gi, lx, y + 0.02, 0.36, 0.36, fill=c1, shape=MSO_SHAPE.OVAL)
        grad(b, c1, c2, 45)
        shape_text(b, str(i + 1), size=11, color=WHITE, font='b', margins=(0, 0, 0, 0))
        yy = y
        if titles[i]:
            tt = clip(titles[i], tw, rh, ts, 'mj', 2)
            th = text_height(tt, tw, ts, 'mj')
            text(gi, lx + 0.5, yy, tw, th + 0.04, tt, size=ts, color=NAVY, font='mj', anchor=MSO_ANCHOR.TOP)
            yy += th + 0.05
        if texts[i]:
            bt = clip(texts[i], tw, max(0.2, rh - (yy - y) - 0.1), xs, 'mn')
            text(gi, lx + 0.5, yy, tw, text_height(bt, tw, xs, 'mn') + 0.05, bt, size=xs, color=GRAY)
        ctx.anim(sl, gi, 'fade', 600 + i * 150, 400)
        y += hs[i] + 0.22
    conclusion(ctx, sl, s, 700 + n * 150)
    return sl


RENDERERS_MAP = {'map': render_map}
