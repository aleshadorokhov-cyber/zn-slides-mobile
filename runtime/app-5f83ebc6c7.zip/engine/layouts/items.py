# -*- coding: utf-8 -*-
"""
items.py — МАКЕТЫ ДЛЯ СПИСКОВ ЭЛЕМЕНТОВ (любое число элементов в пределах макета)
================================================================================

    cards        1–6  карточки: иконка + заголовок + пояснение (1 или 2 ряда)
    list         2–10 пункты в 1–2 колонки
    process      2–6  шаги-шевроны слева направо + карточки с пояснениями
    timeline     3–8  этапы на линии времени (≤ 4 — карточки снизу; больше — сверху/снизу по очереди)
    cycle        3–6  узлы на окружности вокруг центральной идеи, дуги-стрелки
    target       3–6  «мишень»: цель в центре, задачи слева и справа
    kpi          1–6  плитки с крупными числами
    conclusions  2–6  плитки-выводы с крупными полупрозрачными номерами

Элемент: {'title', 'text', 'icon', 'label' (срок для таймлайна), 'value' и 'unit' (для KPI)}.
Все размеры вычисляются от числа элементов и рабочей области слайда; кегль подбирается
общий для однотипных текстов (textfit), длинный текст сокращается «…» (полный — в заметках).
"""
import math

from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN

from ..nts import config as C
from ..nts.effects import glow, grad, no_shadow, set_av, shadow, text_alpha
from ..nts.shapes import circ_icon, grect, group, line, rect, shape_text, text
from ..nts.config import PALEG, PALEG2, SOFT, rgb
from ..textfit import clip, text_height
from ..textutil import short_title
from .base import (DGREEN, GRAY, LGREEN, NAVY, WHITE, common_size, conclusion, content_slide,
                   grid, pair, stack_fit)

from lxml import etree
from pptx.oxml.ns import qn
from pptx.util import Inches as I
from pptx.util import Pt


def _tt(it):
    return it.get('title') or '', it.get('text') or ''


# ======================================================================================
# КАРТОЧКИ
# ======================================================================================
def render_cards(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    avg = sum(len(it.get('text') or '') for it in items) / max(1, n)
    if n == 4 and avg > 130:
        rows = [2, 2]
    elif n == 5 and avg < 70:
        rows = [5]
    else:
        rows = grid(n, 4 if n == 4 else 3)
    gap = 0.22
    avail = bottom - top - 0.05
    rh_max = (avail - gap * (len(rows) - 1)) / len(rows)     # карточки — на всю высоту рабочей области (1.9)
    maxk = max(rows)
    cw = (C.CW - gap * (maxk - 1)) / maxk
    vertical = len(rows) == 1 and n > 1

    # геометрия текстовых зон (одинакова для всех карточек слайда)
    if n == 1:
        d_ = 1.1
        tx, tw, ty0 = 0.35 + d_ + 0.35, cw - (0.35 + d_ + 0.35) - 0.35, 0.4
        title_h, lines_t = 1.0, 2
    elif vertical:
        d_ = min(0.82, rh_max * 0.2)
        tx, tw, ty0 = 0.25, cw - 0.45, 0.3 + d_ + 0.2
        short_t = all(len(_tt(it)[0]) <= 26 for it in items)
        title_h, lines_t = (0.62, 1) if short_t else (1.15, 3)
    else:
        d_ = min(0.68, rh_max * 0.38)
        tx, tw, ty0 = 0.25 + d_ + 0.22, cw - (0.25 + d_ + 0.22) - 0.2, 0.24
        title_h, lines_t = 0.66, 2
    text_h = rh_max - ty0 - title_h - 0.1 - 0.25
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    any_title = any(titles)
    wide = cw > 5.0                                     # 1–2 широкие карточки — крупнее шрифт
    # короткие тексты — крупнее (карточки занимают всю высоту, мелкий текст оставил бы пустоту)
    ts = common_size(titles, tw, title_h, 28 if n == 1 else (26 if wide else (24 if n <= 3 else (22 if n == 4 else 19))),
                     12.5, 'mj', max_lines=lines_t) if any_title else 0
    if any_title:
        xs = common_size(texts, tw, text_h, 24 if n == 1 else (21 if wide else (20 if n <= 3 else (18 if n == 4 else 16))),
                         10.5, 'mn')
    else:   # нет заголовков — текст занимает и место заголовка, крупнее
        xs = common_size(texts, tw, text_h + title_h, 26 if wide else (22 if n <= 3 else (20 if n == 4 else 18)), 11, 'mn')
    solid = s.get('variant') == 'solid'                 # вариант: карточки на градиентной подложке
    # фактическая высота текста → высота карточки по содержимому (без пустых «хвостов»)
    th_act = max([text_height(clip(t_, tw, title_h, ts, 'mj', lines_t), tw, ts, 'mj') for t_ in titles if t_] or [0])
    xh_act = max([text_height(clip(t_, tw, text_h + (0 if any_title else title_h), xs, 'mn'), tw, xs, 'mn')
                  for t_ in texts if t_] or [0])
    body_h = (th_act + 0.12 if any_title else 0) + xh_act
    need = ty0 + (body_h if n == 1 or vertical else max(body_h, d_)) + 0.32
    # карточки занимают всю рабочую область — без пустых полос сверху и снизу (1.9)
    rh = rh_max
    y0 = top
    oy = max(0.0, (rh - need) / 2) if n == 1 else 0.0  # одна карточка: значок и текст — по середине её высоты

    k = 0
    for r, cnt in enumerate(rows):
        row_w = cnt * cw + (cnt - 1) * gap
        x0 = C.L + (C.CW - row_w) / 2
        y = y0 + r * (rh + gap)
        for j in range(cnt):
            it = items[k]
            c1, c2 = pair(k, n)
            x = x0 + j * (cw + gap)
            g = group(sl)
            if solid:
                body = grect(g, x, y, cw, rh, c1, c2, 45)
                shadow(body, 14, 4, 24)
            else:
                body = rect(g, x, y, cw, rh, fill=WHITE)
                grad(body, WHITE, rgb('F4F7FA'), 90)
                shadow(body, 12, 3, 16)
                stripe = rect(g, x, y, cw, 0.08, fill=c1)             # цветная полоска-акцент сверху
                grad(stripe, c1, c2, 0)
            big = text(g, x + cw - 1.2, y + rh - 1.05, 1.1, 1.0, str(k + 1), size=60, color=WHITE if solid else c1,
                       font='b', align=PP_ALIGN.RIGHT)
            text_alpha(big, 18 if solid else 9)
            title, txt = _tt(it)
            ix, iy = (0.35, 0.4) if n == 1 else ((0.25, 0.3) if vertical else (0.25, 0.26))
            ci = circ_icon(g, it['icon'], x + ix, y + iy + oy, d_, fill=WHITE if solid else c1, fill2=None if solid else c2,
                           ic='n' if solid else 'w')
            shadow(ci, 8, 2, 22)
            ty = y + ty0 + oy
            if title:
                tclip = clip(title, tw, title_h, ts, 'mj', lines_t)
                text(g, x + tx, ty, tw, th_act + 0.05, tclip, size=ts, color=WHITE if solid else NAVY, font='mj')
                yy = ty + th_act + 0.12
                text(g, x + tx, yy, tw, max(0.3, y + rh - yy - 0.15), clip(txt, tw, text_h, xs, 'mn'), size=xs,
                     color=WHITE if solid else GRAY)
            else:
                text(g, x + tx, ty, tw, max(0.3, y + rh - ty - 0.15), clip(txt, tw, text_h + title_h, xs, 'mn'),
                     size=xs, color=WHITE if solid else NAVY)
            ctx.anim(sl, g, 'rise', 100 + k * 150, 450)
            k += 1
    conclusion(ctx, sl, s, 300 + n * 150)
    return sl


# ======================================================================================
# СПИСОК
# ======================================================================================
def render_list(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    cols = 1 if n <= 5 else 2
    per = -(-n // cols)
    gap_x = 0.45
    cw = (C.CW - (cols - 1) * gap_x) / cols
    avail = bottom - top - 0.05
    tiles = s.get('variant') == 'tiles'
    d_ = 0.5 if avail / per > 0.9 else 0.44
    tw = cw - d_ - 0.45
    plain = [((it.get('title') + '. ') if it.get('title') else '') + (it.get('text') or '') for it in items]
    # строки — по высоте своего текста, общий кегль — наибольший, при котором колонка заполнена до низа
    cols_ix = [list(range(c * per, min(n, (c + 1) * per))) for c in range(cols)]
    mx = 21 if n <= 4 else 18
    size = min(stack_fit([plain[i] for i in ix], tw, avail, mx, 10.5, 'mn', pad=0.2, gap=0, min_h=d_ + 0.16)[0]
               for ix in cols_ix)
    rhs, ys = [0.0] * n, [0.0] * n
    for ix in cols_ix:
        need = [max(d_ + 0.16, text_height(plain[i], tw, size, 'mn') + 0.2) for i in ix]
        extra = max(0.0, avail - sum(need)) / len(ix)
        y_ = top
        for i, h_ in zip(ix, need):
            rhs[i], ys[i] = h_ + extra, y_
            y_ += h_ + extra
    for i, it in enumerate(items):
        c, r = divmod(i, per)
        x = C.L + c * (cw + gap_x)
        y, rh = ys[i], rhs[i]
        g = group(sl)
        c1, c2 = pair(i, n)
        if tiles:                                           # вариант «плитки»: каждая строка — градиентная плашка
            band = rect(g, x, y + 0.05, cw, rh - 0.1, fill=c1, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.12)
            grad(band, c1, c2, 0)
            shadow(band, 8, 2, 16)
        elif r % 2 == 0:
            zb = rect(g, x, y + 0.03, cw, rh - 0.06, fill=SOFT)
            grad(zb, SOFT, WHITE, 0)
        circ = rect(g, x + 0.14, y + (rh - d_) / 2, d_, d_, fill=WHITE if tiles else c1, shape=MSO_SHAPE.OVAL)
        if not tiles:
            grad(circ, c1, c2, 45)
        shadow(circ, 6, 2, 18)
        shape_text(circ, str(i + 1), size=13, color=c1 if tiles else WHITE, font='b', margins=(0, 0, 0, 0))
        full = clip(plain[i], tw, rh - 0.12, size, 'mn')
        title = it.get('title') or ''
        if title and full.startswith(title):
            content = [[(title + '. ', {'font': 'b', 'color': WHITE if tiles else NAVY}), (full[len(title) + 2:], {})]]
        else:
            content = full
        text(g, x + d_ + 0.35, y, tw, rh, content, size=size, color=WHITE if tiles else GRAY, anchor=MSO_ANCHOR.MIDDLE)
        ctx.anim(sl, g, 'wipe_l', 100 + i * 110, 400)
    conclusion(ctx, sl, s, 300 + n * 110)
    return sl


# ======================================================================================
# ПРОЦЕСС: шевроны-шаги + карточки под ними
# ======================================================================================
def render_process(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    depth = 0.3
    gap = 0.06
    chw = (C.CW + (n - 1) * (depth - gap)) / n             # шевроны заходят друг в друга на depth
    chh = 0.95
    # пункт без заголовка: в шеврон — короткое начало фразы, полный текст — в карточку
    # (иначе длинная фраза мелко ужимается в узком шевроне, а карточка пустует)
    titles, texts = [], []
    for it in items:
        ti, tx = it.get('title') or '', it.get('text') or ''
        if not ti and tx:
            if len(tx) <= 45:
                ti, tx = tx, ''
            else:
                ti = short_title(tx, 4, 36)
        titles.append(ti)
        texts.append(tx)
    tw_head = chw - depth * 2 - 0.55
    ts = common_size(titles, tw_head, chh - 0.12, 16, 11, 'mj', max_lines=3)
    card_y = top + 0.15 + chh + 0.22
    card_h = bottom - card_y - 0.05
    cw = chw - depth - 0.1
    has_text = any(texts)
    d_ = 0.62
    x_max = 21 if n <= 3 else (18 if n == 4 else 16)       # мало шагов — крупный текст, карточки до низа
    xs = common_size(texts, cw - 0.4, card_h - d_ - 0.55, x_max, 10.5, 'mn') if has_text else 0
    if not has_text:
        card_h = min(card_h, 1.2)
    for i, it in enumerate(items):
        x = C.L + i * (chw - depth + gap)
        c1, c2 = pair(i, n)
        g = group(sl)
        shp = rect(g, x, top + 0.15, chw, chh, fill=c1, shape=MSO_SHAPE.PENTAGON if i == 0 else MSO_SHAPE.CHEVRON)
        grad(shp, c1, c2, 0)
        shp.adjustments[0] = depth / chh
        shadow(shp, 8, 2, 20)
        tx0 = x + (0.2 if i == 0 else depth + 0.12)
        text(g, tx0, top + 0.15, 0.5, chh, f'{i + 1:02d}', size=18, color=LGREEN if i < n - 1 else WHITE, font='b',
             anchor=MSO_ANCHOR.MIDDLE)
        text(g, tx0 + 0.5, top + 0.15, tw_head, chh, clip(titles[i], tw_head, chh - 0.12, ts, 'mj', 3), size=ts,
             color=WHITE, font='mj', anchor=MSO_ANCHOR.MIDDLE)
        ctx.anim(sl, g, 'wipe_l', 100 + i * 250, 450)
        if has_text or True:
            g2 = group(sl)
            cx = x + (0 if i == 0 else depth) + 0.02
            body = rect(g2, cx, card_y, cw, card_h, fill=SOFT)
            grad(body, SOFT, WHITE, 90)
            shadow(body, 10, 2, 14)
            stripe = rect(g2, cx, card_y, cw, 0.07, fill=c1)
            grad(stripe, c1, c2, 0)
            ci = circ_icon(g2, it['icon'], cx + 0.2, card_y + 0.25, d_, fill=c1, fill2=c2)
            glow(ci, 'CEE1A5', 4, 40)
            big = text(g2, cx + cw - 1.15, card_y + card_h - 1.0, 1.05, 0.95, str(i + 1), size=54, color=c1,
                       font='b', align=PP_ALIGN.RIGHT)
            text_alpha(big, 10)
            if texts[i]:
                text(g2, cx + 0.2, card_y + 0.25 + d_ + 0.18, cw - 0.4, card_h - d_ - 0.55,
                     clip(texts[i], cw - 0.4, card_h - d_ - 0.55, xs, 'mn'), size=xs, color=GRAY)
            ctx.anim(sl, g2, 'rise', 250 + i * 250, 450)
    conclusion(ctx, sl, s, 400 + n * 250)
    return sl


# ======================================================================================
# ТАЙМЛАЙН
# ======================================================================================
def render_timeline(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    alternate = n >= 5
    nd = 0.62 if n <= 6 else 0.54
    if alternate:
        # карточки через одну сверху/снизу: соседние на одной стороне не должны пересекаться
        cw = min(3.7, (2 * C.CW - 0.25 * (n - 1)) / (n + 1))   # соседи на одной стороне — через одну, место есть
        ly = (top + bottom) / 2
        chh_max = (bottom - top) / 2 - nd / 2 - 0.3
    else:
        gap = 0.25
        cw = (C.CW - gap * (n - 1)) / n
        ly = top + 0.45
        chh_max = bottom - ly - nd / 2 - 0.3
    step = (C.CW - cw) / (n - 1) if n > 1 else 0
    xs_ = [C.L + cw / 2 + i * step for i in range(n)]          # узлы — по центрам карточек
    head_h = 0.5
    heads = [(it.get('label') or it.get('title') or '') for it in items]
    bodies = [(it.get('title') + ': ' if it.get('label') and it.get('title') else '') + (it.get('text') or '') for it in items]
    hs = common_size(heads, cw - 0.25, head_h - 0.04, 16, 10.5, 'mj', max_lines=1)
    body_h_max = chh_max - head_h - 0.2
    bs = common_size(bodies, cw - 0.25, body_h_max, 18 if n <= 4 else 16, 10, 'mn')
    bh = max([text_height(clip(b_, cw - 0.25, body_h_max, bs, 'mn'), cw - 0.25, bs, 'mn') for b_ in bodies if b_] or [0.3])
    chh = chh_max                                # карточки — до края рабочей области, без пустой полосы (1.9)
    # линия времени: отрезки цветами элементов, на конце — стрелка
    gl = group(sl)
    for i in range(n):
        a = C.L if i == 0 else (xs_[i - 1] + xs_[i]) / 2
        b = C.R if i == n - 1 else (xs_[i] + xs_[i + 1]) / 2
        line(gl, a, ly, b, ly, color=pair(i, n)[0], w=5, head=(i == n - 1))
    ctx.anim(sl, gl, 'wipe_l', 0, 1000)
    for i, it in enumerate(items):
        x = xs_[i]
        c1, c2 = pair(i, n)
        gn = group(sl)
        node = circ_icon(gn, it['icon'], x - nd / 2, ly - nd / 2, nd, fill=c1, fill2=c2)
        shadow(node, 8, 2, 25)
        ctx.anim(sl, gn, 'zoom', 200 + i * 140, 400)
        gc = group(sl)
        cx = x - cw / 2
        if alternate and i % 2 == 0:
            cy = ly - nd / 2 - 0.25 - chh
            line(gc, x, cy + chh, x, ly - nd / 2, color=c1, w=1.25, head=False)
        else:
            cy = ly + nd / 2 + 0.25
            line(gc, x, ly + nd / 2, x, cy, color=c1, w=1.25, head=False)
        body = rect(gc, cx, cy, cw, chh, fill=SOFT)
        shadow(body, 10, 2, 16)
        grect(gc, cx, cy, cw, head_h, c1, c2, 0)
        text(gc, cx + 0.13, cy, cw - 0.25, head_h, clip(heads[i], cw - 0.25, head_h, hs, 'mj', 1), size=hs,
             color=WHITE, font='mj', anchor=MSO_ANCHOR.MIDDLE)
        text(gc, cx + 0.13, cy + head_h + 0.1, cw - 0.25, chh - head_h - 0.15,
             clip(bodies[i], cw - 0.25, body_h_max, bs, 'mn'), size=bs, color=GRAY)
        ctx.anim(sl, gc, 'rise', 350 + i * 140, 450)
    conclusion(ctx, sl, s, 500 + n * 140)
    return sl


# ======================================================================================
# ЦИКЛ
# ======================================================================================
def render_cycle(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    cx, cy = (C.L + C.R) / 2, (top + bottom) / 2 + 0.05
    Rorb = min(1.95, (bottom - top) / 2 - 0.45)
    Rc = Rorb * 0.58
    nd = 0.74
    # ядро
    gc = group(sl)
    core = rect(gc, cx - Rc, cy - Rc, 2 * Rc, 2 * Rc, fill=NAVY, shape=MSO_SHAPE.OVAL)
    grad(core, NAVY, C.BLUE, 45)
    glow(core, 'CEE1A5', 10, 60)
    center = s.get('center') or s.get('title') or ''
    cs = common_size([center], 2 * Rc * 0.78, 2 * Rc * 0.6, 20, 11, 'mj')
    text(gc, cx - Rc * 0.78, cy - Rc * 0.6, 2 * Rc * 0.78, 2 * Rc * 0.6 * 2,
         clip(center, 2 * Rc * 0.78, Rc * 1.2, cs, 'mj'), size=cs, color=WHITE, font='mj', align=PP_ALIGN.CENTER,
         anchor=MSO_ANCHOR.MIDDLE)
    ctx.anim(sl, gc, 'zoom', 0, 600)
    angs = [i * 360 / n for i in range(n)]
    pos = [(cx + Rorb * math.sin(math.radians(a)), cy - Rorb * math.cos(math.radians(a))) for a in angs]
    # дуги-стрелки между узлами
    gap_deg = math.degrees((nd / 2 + 0.1) / Rorb)
    ga = group(sl)
    for i in range(n):
        a1 = angs[i] + gap_deg
        a2 = (angs[i + 1] if i < n - 1 else 360) - gap_deg
        arc = ga.shapes.add_shape(MSO_SHAPE.ARC, I(cx - Rorb), I(cy - Rorb), I(2 * Rorb), I(2 * Rorb))
        arc.fill.background()
        no_shadow(arc)
        arc.line.color.rgb = NAVY
        arc.line.width = Pt(1.75)
        set_av(arc, {'adj1': ((a1 - 90) % 360) * 60000, 'adj2': ((a2 - 90) % 360) * 60000})
        t = etree.SubElement(arc.line._get_or_add_ln(), qn('a:tailEnd'))
        t.set('type', 'triangle')
    # подписи — в боковых колонках (справа и слева от окружности), к ним — тонкие выноски
    col_r = cx + Rorb + nd / 2 + 0.45
    col_l_end = cx - Rorb - nd / 2 - 0.45
    lw = min(C.R - col_r, col_l_end - C.L)
    titles = [it.get('title') or '' for it in items]
    texts = [it.get('text') or '' for it in items]
    per_side = -(-n // 2)
    lab_h = min(1.5, (bottom - top) / per_side - 0.1)
    ts = common_size(titles, lw, 0.6, 17, 12, 'mj', max_lines=2)
    xs = common_size(texts, lw, lab_h - 0.62, 14, 10, 'mn')
    # раскладка подписей по колонкам без наложений: желаемая высота — на уровне узла,
    # при конфликте подпись сдвигается вниз, а если не хватает места — вся колонка вверх
    sides = []
    for i, (px, py) in enumerate(pos):
        dx = px - cx
        sides.append(dx > 0.3 or (abs(dx) <= 0.3 and py < cy))   # верхний узел → вправо, нижний → влево
    th_ = 0.62 if any(titles) else 0
    hts = [th_ + (text_height(clip(texts[i], lw, lab_h - th_, xs, 'mn'), lw, xs, 'mn') + 0.06 if texts[i] else 0)
           for i in range(n)]
    lab_y = [0.0] * n
    for side in (True, False):
        idx = sorted([i for i in range(n) if sides[i] == side], key=lambda i: pos[i][1])
        prev_end = top
        for i in idx:
            want = pos[i][1] - th_ - 0.02 if th_ else pos[i][1] - hts[i] / 2
            lab_y[i] = max(want, prev_end + 0.1 if prev_end > top else top)
            prev_end = lab_y[i] + hts[i]
        over = prev_end - bottom
        if idx and over > 0:
            for i in idx:
                lab_y[i] = max(top, lab_y[i] - over)
    for i, ((px, py), it) in enumerate(zip(pos, items)):
        c1, c2 = pair(i, n)
        g = group(sl)
        right = sides[i]
        ly_ = lab_y[i] + (th_ if th_ else hts[i] / 2)            # уровень выноски — граница заголовка и текста
        if right:
            line(g, px + nd / 2 + 0.04, py, col_r - 0.1, ly_, color=c1, w=1.25, head=False)
            lx, al = col_r, PP_ALIGN.LEFT
        else:
            line(g, px - nd / 2 - 0.04, py, col_l_end + 0.1, ly_, color=c1, w=1.25, head=False)
            lx, al = col_l_end - lw, PP_ALIGN.RIGHT
        ci = circ_icon(g, it['icon'], px - nd / 2, py - nd / 2, nd, fill=c1, fill2=c2)
        shadow(ci, 8, 2, 25)
        bd = rect(g, px + nd / 2 - 0.2, py - nd / 2 - 0.1, 0.3, 0.3, fill=WHITE, line=c1, lw=1.5, shape=MSO_SHAPE.OVAL)
        shape_text(bd, str(i + 1), size=10.5, color=c1, font='b', margins=(0, 0, 0, 0))
        ty = lab_y[i]
        if titles[i]:
            text(g, lx, ty, lw, 0.6, clip(titles[i], lw, 0.6, ts, 'mj', 2), size=ts, color=c1, font='mj',
                 align=al, anchor=MSO_ANCHOR.BOTTOM)
        if texts[i]:
            text(g, lx, ty + th_ + 0.04, lw, max(0.3, hts[i] - th_), clip(texts[i], lw, lab_h - th_, xs, 'mn'),
                 size=xs, color=GRAY, align=al)
        ctx.anim(sl, g, 'zoom', 300 + i * 250, 450)
    ctx.anim(sl, ga, 'fade', 400 + n * 250, 700)
    conclusion(ctx, sl, s, 800 + n * 250)
    return sl


# ======================================================================================
# МИШЕНЬ: цель в центре, задачи слева и справа
# ======================================================================================
def render_target(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    cx, cy = (C.L + C.R) / 2, (top + bottom) / 2
    Rmax = min(2.25, (bottom - top) / 2 - 0.05)
    rcore = Rmax * 0.67
    g = group(sl)
    for r_, f_ in ((Rmax, PALEG), (Rmax * 0.83, PALEG2)):
        rect(g, cx - r_, cy - r_, 2 * r_, 2 * r_, fill=f_, shape=MSO_SHAPE.OVAL)
    ctx.anim(sl, g, 'zoom', 0, 600)
    gc = group(sl)
    core = rect(gc, cx - rcore, cy - rcore, 2 * rcore, 2 * rcore, fill=NAVY, shape=MSO_SHAPE.OVAL)
    grad(core, NAVY, C.BLUE, 45)
    shadow(core, 14, 4, 28)
    glow(core, 'FFFFFF', 4, 40)
    from ..nts.shapes import icon
    icon(gc, 'TbTargetArrow', 'g', cx - 0.25, cy - rcore + 0.18, 0.5)
    text(gc, cx - 1.0, cy - rcore + 0.7, 2.0, 0.32, 'ЦЕЛЬ', size=16, color=LGREEN, font='mj', align=PP_ALIGN.CENTER)
    center = s.get('center') or ''
    cw_, ch_ = rcore * 1.6, rcore * 1.05
    cs = common_size([center], cw_, ch_, 15, 9.5, 'mn')
    text(gc, cx - cw_ / 2, cy - rcore + 1.05, cw_, ch_, clip(center, cw_, ch_, cs, 'mn'), size=cs, color=WHITE,
         align=PP_ALIGN.CENTER)
    ctx.anim(sl, gc, 'zoom', 250, 600)
    # раскладка задач: справа ⌈n/2⌉ сверху вниз, слева остальные снизу вверх (по часовой стрелке)
    nr = -(-n // 2)
    nl = n - nr
    spread = Rmax * 0.72

    def col(k):
        return [0.0] if k == 1 else [-spread + 2 * spread * i / (k - 1) for i in range(k)]
    pts = [(+1, dy) for dy in col(nr)] + [(-1, dy) for dy in reversed(col(nl))]
    nd = 0.98 if n <= 4 else 0.9
    lab_h = min(1.9 if n <= 4 else 1.3, (bottom - top) / max(nr, 1) - 0.1)
    label_texts = [(it.get('title') + '. ' if it.get('title') else '') + (it.get('text') or '') for it in items]
    # геометрия узлов: средний узел колонки дальше от центра (по дуге), крайние — ближе
    geo = []
    for side, dy in pts:
        dx = side * (Rmax + 1.15 - 0.8 * (dy / max(spread, 0.01)) ** 2)
        px, py = cx + dx, cy + dy
        if side > 0:
            lx = px + nd / 2 + 0.15
            lw = C.R - lx
            al = PP_ALIGN.LEFT
        else:
            lw = (px - nd / 2 - 0.15) - C.L
            lx = C.L
            al = PP_ALIGN.RIGHT
        geo.append((dx, dy, px, py, lx, lw, al))
    # общий кегль подписей: минимальный из подходящих для каждой (у подписей разная ширина)
    ls = min(common_size([t_], g_[5] - 0.45, lab_h, 18 if n <= 4 else 15, 10.5, 'mn') for t_, g_ in zip(label_texts, geo))
    for i, (it, (dx, dy, px, py, lx, lw, al)) in enumerate(zip(items, geo)):
        c1, c2 = pair(i, n)
        gk = group(sl)
        dist = math.hypot(dx, dy)
        ux, uy = dx / dist, dy / dist
        line(gk, cx + ux * rcore, cy + uy * rcore, px - ux * nd / 2, py - uy * nd / 2, color=c1, w=2, head=False)
        ci = circ_icon(gk, it['icon'], px - nd / 2, py - nd / 2, nd, fill=c1, fill2=c2, ratio=0.52)
        shadow(ci, 10, 3, 25)
        content_txt = clip(label_texts[i], lw - 0.45, lab_h, ls, 'mn')
        text(gk, lx, py - lab_h / 2, lw, lab_h,
             [[(f'{i + 1:02d}  ', {'font': 'b', 'color': c1, 'size': ls + 3}), (content_txt, {})]],
             size=ls, color=NAVY, align=al, anchor=MSO_ANCHOR.MIDDLE)
        ctx.anim(sl, gk, 'zoom', 600 + i * 200, 450)
    conclusion(ctx, sl, s, 800 + n * 200)
    return sl


# ======================================================================================
# КЛЮЧЕВЫЕ ПОКАЗАТЕЛИ (KPI)
# ======================================================================================
def _aside(ctx, sl, x, top, w, h, lines, delay=600):
    """Боковая панель с тезисами (градиент NAVY → BLUE, белый текст, галочки)."""
    lines = [l_ for l_ in lines if l_][:4]
    if not lines:
        return
    g = group(sl)
    panel = grect(g, x, top, w, h, NAVY, C.BLUE, 90, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    set_av(panel, {'adj': 6000})
    shadow(panel, 14, 4, 24)
    deco = rect(g, x + w - 1.6, top + h - 1.6, 2.2, 2.2, fill=WHITE, shape=MSO_SHAPE.OVAL)
    from ..nts.effects import alpha_fill
    alpha_fill(deco, 'FFFFFF', 7)
    from ..nts.shapes import icon as _icon
    pad = 0.3
    rh = (h - 2 * pad) / len(lines)
    tw = w - 2 * pad - 0.5
    sz = common_size(lines, tw, rh - 0.12, 20, 10.5, 'mn')
    for i, l_ in enumerate(lines):
        y = top + pad + i * rh
        th = text_height(clip(l_, tw, rh - 0.12, sz, 'mn'), tw, sz, 'mn')
        _icon(g, 'TbCircleCheck', 'g', x + pad, y + max(0, (min(th, rh) - 0.36) / 2), 0.36)
        text(g, x + pad + 0.5, y, tw, rh, clip(l_, tw, rh - 0.12, sz, 'mn'), size=sz, color=WHITE,
             anchor=MSO_ANCHOR.TOP)
        if i < len(lines) - 1 and th + 0.25 < rh:
            sep = rect(g, x + pad + 0.5, y + rh - 0.12, tw, 0.012, fill=WHITE)
            alpha_fill(sep, 'FFFFFF', 25)
    ctx.anim(sl, g, 'wipe_l', delay, 600)


def _titles_h(titles, w, size, hmax, font='mj'):
    """Высота самой высокой подписи при кегле size (не больше hmax) — остальное место отдаётся пояснению."""
    hs = [text_height(clip(t, w, hmax, size, font), w, size, font) for t in titles if t]
    return min(hmax, max(hs) + 0.05) if hs else 0.0


def _opt_clip(t, w, h, size, font='mn'):
    """Пояснение под числом необязательно: если оно не помещается даже после сокращения по смыслу,
    его лучше не показывать, чем показывать обрывок с «…»."""
    c = clip(t, w, h, size, font)
    return '' if c != t and c.endswith('…') else c


def render_kpi(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    aside = [a_ for a_ in (s.get('aside') or []) if a_]
    if aside and sum(len(a_) for a_ in aside) < 110:      # короткое пояснение — в подзаголовок, плитки на всю ширину
        aside = []
    ring = s.get('variant') == 'ring' and not aside and n <= 4
    area_w = C.CW * (0.6 if aside else 1.0)
    max_cols = (2 if n >= 3 else n) if aside else (4 if n <= 4 else 3)
    rows = grid(n, max_cols)
    gap = 0.24
    avail = bottom - top - 0.05
    rh = (avail - gap * (len(rows) - 1)) / len(rows)     # плитки — на всю высоту
    maxk = max(rows)
    cw = (area_w - gap * (maxk - 1)) / maxk
    pad = 0.3
    vals = [(it.get('value') or '—') for it in items]
    units = [it.get('unit') or '' for it in items]
    titles = [it.get('title') or '' for it in items]
    texts = [it.get('text') or '' for it in items]
    has_txt = any(texts)
    total = rh * len(rows) + gap * (len(rows) - 1)
    y0 = top + max(0.0, (avail - total) / 2)

    horiz = ring and rh < 2.6                       # низкие плитки: кольцо слева, подпись справа
    if ring:
        # вариант «кольца»: белая карточка, число в градиентном кольце, подпись под ним (или справа)
        D = min(rh - 0.36, cw * 0.42, 2.0) if horiz else min(cw - 0.6, rh * (0.58 if has_txt else 0.66), 3.0 if has_txt else 3.4)
        vs = common_size([v.replace('до ', '') for v in vals], D * 0.74, D * 0.34, 40 if n <= 3 else 32, 11, 'b',
                         max_lines=1)
        if horiz:
            lw_ = cw - D - 0.75
            th = rh - 0.3
            ts = common_size(titles, lw_, th * (0.55 if has_txt else 1), 20, 10.5, 'mj')
            tth = _titles_h(titles, lw_, ts, th * 0.55) if has_txt else th
            xh = th - tth - 0.06
            xs = common_size(texts, lw_, xh, 15, 9.5, 'mn') if has_txt else 0
        else:
            th = rh - 0.25 - D - 0.25 - 0.15
            ts = common_size(titles, cw - 2 * pad, th * (0.55 if has_txt else 1), 18, 10.5, 'mj')
            tth = _titles_h(titles, cw - 2 * pad, ts, th * 0.55) if has_txt else th
            xh = th - tth - 0.08
            xs = common_size(texts, cw - 2 * pad, xh, 14, 9.5, 'mn') if has_txt else 0
            # кольцо с подписью — по середине высоты карточки, без пустого низа
            hh_ = max([text_height(clip(t_, cw - 2 * pad, th * (0.55 if has_txt else 1), ts, 'mj'), cw - 2 * pad, ts, 'mj')
                       for t_ in titles if t_] or [0])
            xh_m = max([text_height(_opt_clip(t_, cw - 2 * pad, xh, xs, 'mn'), cw - 2 * pad, xs, 'mn')
                        for t_ in texts if t_] or [0]) if has_txt else 0
            ring_oy = max(0.0, (rh - 0.5 - D - 0.22 - hh_ - (xh_m + 0.08 if has_txt else 0)) / 2)
    low = (not ring) and rh < 2.0                  # низкие плитки: число слева, подпись справа
    if low:
        vw = min(cw * 0.45, 2.6)
        lw_ = cw - vw - 0.5
        vs = common_size(vals, vw - 0.2, rh * 0.5, 44, 16, 'b', max_lines=1)
        ts = common_size(titles, lw_, rh * (0.55 if has_txt else 0.85), 18, 10.5, 'mj')
        xh = rh * 0.85 - _titles_h(titles, lw_, ts, rh * 0.55) - 0.06 if has_txt else 0
        xs = common_size(texts, lw_, xh, 14, 9.5, 'mn') if has_txt else 0
    elif not ring:
        unit_h = 0.38 if any(units) else 0
        need_rest = 0.95 if has_txt else 0.7
        show_icon = True
        val_h = max(0.6, min(1.25, rh * 0.32))
        for _ in range(3):
            icon_h = 0.56 + 0.14 if show_icon else 0
            rest = rh - 0.28 - icon_h - val_h - unit_h - 0.2 - 0.2
            if rest >= need_rest:
                break
            if show_icon:
                show_icon = False
            else:
                val_h = 0.6
        th = rest * (0.6 if has_txt else 1)
        vs = common_size(vals, cw - 2 * pad, val_h, 64 if n <= 2 else (54 if n <= 3 else 44), 20, 'b', max_lines=1)
        us = common_size(units, cw - 2 * pad, unit_h, 17, 10, 'mn', max_lines=1) if unit_h else 0
        ts = common_size(titles, cw - 2 * pad, th, 20 if n <= 3 else 17, 10.5, 'mj')
        if has_txt:                                  # пояснению — всё место под подписью, а не фиксированная доля
            th = _titles_h(titles, cw - 2 * pad, ts, th)
        xs = common_size(texts, cw - 2 * pad, rest - th - 0.05, 16 if n <= 3 else 14, 9.5, 'mn') if has_txt else 0
    k = 0
    cw0 = cw
    for r, cnt in enumerate(rows):
        # неполный последний ряд (5 = 3 + 2, 3 = 2 + 1) — плитки шире, без пустых мест по бокам
        cw = cw0 if (cnt == maxk or ring) else (area_w - gap * (cnt - 1)) / cnt
        if low:
            lw_ = cw - vw - 0.5
        row_w = cnt * cw + (cnt - 1) * gap
        x0 = C.L + (area_w - row_w) / 2
        y = y0 + r * (rh + gap)
        for j in range(cnt):
            it = items[k]
            c1, c2 = pair(k, n)
            x = x0 + j * (cw + gap)
            g = group(sl)
            if ring:
                card = rect(g, x, y, cw, rh, fill=WHITE)
                grad(card, WHITE, rgb('F2F5F9'), 90)
                shadow(card, 12, 3, 16)
                cx_, cy_ = (x + 0.25 + D / 2, y + rh / 2) if horiz else (x + cw / 2, y + 0.25 + ring_oy + D / 2)
                halo = rect(g, cx_ - D / 2 - 0.08, cy_ - D / 2 - 0.08, D + 0.16, D + 0.16, fill=PALEG, shape=MSO_SHAPE.OVAL)
                ring_ = rect(g, cx_ - D / 2, cy_ - D / 2, D, D, fill=c1, shape=MSO_SHAPE.DONUT)
                grad(ring_, c1, c2, 45)
                set_av(ring_, {'adj': 9000})
                glow(ring_, 'CEE1A5', 6, 45)
                vtxt = vals[k].replace('до ', '')
                text(g, cx_ - D * 0.37, cy_ - D * 0.26, D * 0.74, D * 0.36, clip(vtxt, D * 0.74, D * 0.36, vs, 'b', 1),
                     size=vs, color=c1, font='b', align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.BOTTOM)
                ut = (('до ' if vals[k].startswith('до ') else '') + units[k]).strip()
                if ut:
                    text(g, cx_ - D * 0.37, cy_ + D * 0.1, D * 0.74, 0.3, clip(ut, D * 0.74, 0.3, 11, 'mn', 1),
                         size=11 if D > 1.2 else 9, color=DGREEN, font='mj', align=PP_ALIGN.CENTER)
                if horiz:
                    lx_ = x + 0.25 + D + 0.3
                    tt = clip(titles[k], lw_, th * (0.55 if has_txt else 1), ts, 'mj')
                    hh = text_height(tt, lw_, ts, 'mj')
                    xx_ = _opt_clip(texts[k], lw_, xh, xs, 'mn') if texts[k] else ''
                    xh_ = text_height(xx_, lw_, xs, 'mn') if xx_ else 0
                    yy = y + (rh - hh - (xh_ + 0.06 if xx_ else 0)) / 2
                    text(g, lx_, yy, lw_, hh + 0.05, tt, size=ts, color=NAVY, font='mj')
                    if xx_:
                        text(g, lx_, yy + hh + 0.06, lw_, xh_ + 0.05, xx_, size=xs, color=GRAY)
                    ctx.anim(sl, g, 'zoom', 100 + k * 180, 450)
                    k += 1
                    continue
                yy = y + 0.25 + ring_oy + D + 0.22
                tt = clip(titles[k], cw - 2 * pad, th * (0.55 if has_txt else 1), ts, 'mj')
                hh = text_height(tt, cw - 2 * pad, ts, 'mj')
                text(g, x + pad, yy, cw - 2 * pad, hh + 0.05, tt, size=ts, color=NAVY, font='mj', align=PP_ALIGN.CENTER)
                if texts[k]:
                    text(g, x + pad, yy + hh + 0.08, cw - 2 * pad, y + rh - (yy + hh + 0.08) - 0.1,
                         _opt_clip(texts[k], cw - 2 * pad, xh, xs, 'mn'), size=xs, color=GRAY, align=PP_ALIGN.CENTER)
            elif low:
                tile = grect(g, x, y, cw, rh, c1, c2, 45)
                shadow(tile, 14, 4, 22)
                text(g, x + 0.25, y + 0.1, vw - 0.2, rh * 0.62, clip(vals[k], vw - 0.2, rh * 0.5, vs, 'b', 1), size=vs,
                     color=WHITE, font='b', anchor=MSO_ANCHOR.BOTTOM)
                if units[k]:
                    text(g, x + 0.25, y + rh * 0.62 + 0.12, vw - 0.2, 0.32, clip(units[k], vw - 0.2, 0.3, 13, 'mn', 1),
                         size=13, color=WHITE)
                sep = rect(g, x + vw + 0.1, y + 0.25, 0.03, rh - 0.5, fill=LGREEN)
                tt = clip(titles[k], lw_, rh * (0.55 if has_txt else 0.85), ts, 'mj')
                hh = text_height(tt, lw_, ts, 'mj')
                xx_ = _opt_clip(texts[k], lw_, xh, xs, 'mn') if texts[k] else ''
                xh_ = text_height(xx_, lw_, xs, 'mn') if xx_ else 0
                yy = y + (rh - hh - (xh_ + 0.06 if xx_ else 0)) / 2
                text(g, x + vw + 0.3, yy, lw_, hh + 0.05, tt, size=ts, color=WHITE, font='mj')
                if xx_:
                    text(g, x + vw + 0.3, yy + hh + 0.06, lw_, xh_ + 0.05, xx_, size=xs, color=WHITE)
            else:
                tile = grect(g, x, y, cw, rh, c1, c2, 45)
                shadow(tile, 14, 4, 22)
                deco = rect(g, x + cw - 1.45, y - 0.5, 1.8, 1.8, fill=WHITE, shape=MSO_SHAPE.OVAL)   # не за краем слайда
                from ..nts.effects import alpha_fill
                alpha_fill(deco, 'FFFFFF', 8)
                yy = y + 0.28
                if show_icon:
                    circ_icon(g, it.get('icon') or 'TbGauge', x + pad, yy, 0.56, fill=WHITE, ic='n', ratio=0.6)
                    yy += icon_h
                text(g, x + pad, yy, cw - 2 * pad, val_h, clip(vals[k], cw - 2 * pad, val_h, vs, 'b', 1), size=vs,
                     color=WHITE, font='b', anchor=MSO_ANCHOR.BOTTOM)
                yy += val_h
                if unit_h and units[k]:
                    text(g, x + pad, yy + 0.02, cw - 2 * pad, unit_h, clip(units[k], cw - 2 * pad, unit_h, us, 'mn', 1),
                         size=us, color=WHITE)
                yy += unit_h + 0.1
                bar = rect(g, x + pad, yy, 0.7, 0.04, fill=LGREEN)
                yy += 0.12
                text(g, x + pad, yy, cw - 2 * pad, th, clip(titles[k], cw - 2 * pad, th, ts, 'mj'), size=ts,
                     color=WHITE, font='mj')
                if texts[k]:
                    text(g, x + pad, yy + th + 0.05, cw - 2 * pad, rest - th - 0.05,
                         _opt_clip(texts[k], cw - 2 * pad, rest - th - 0.05, xs, 'mn'), size=xs, color=WHITE)
            ctx.anim(sl, g, 'zoom', 100 + k * 180, 450)
            k += 1
    if aside:
        ax = C.L + area_w + 0.3
        _aside(ctx, sl, ax, y0, C.R - ax, total, aside, 300 + n * 180)
    conclusion(ctx, sl, s, 500 + n * 180)
    return sl


# ======================================================================================
# ВЫВОДЫ: плитки с крупными полупрозрачными номерами
# ======================================================================================
def render_conclusions(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    rows = [2, 2] if n == 4 else grid(n, 3)
    gap = 0.2
    avail = bottom - top - 0.05
    rh_max = (avail - gap * (len(rows) - 1)) / len(rows)
    maxk = max(rows)
    cw = (C.CW - gap * (maxk - 1)) / maxk
    pad = 0.28
    d_ = 0.56
    titles = [it.get('title') or '' for it in items]
    texts = [it.get('text') or '' for it in items]
    any_title = any(titles)
    # строка 1: иконка + заголовок справа от неё; ниже — текст на всю ширину плитки
    tw_t = cw - 2 * pad - d_ - 0.18 - 1.0               # справа место под крупную цифру
    head_h = max(d_, 0.7)
    text_h = rh_max - 0.22 - head_h - 0.14 - 0.22
    big_ = 24 if cw > 5 else (22 if n <= 3 else 18)     # широкие плитки (1–2 в ряд) — крупнее
    ts = common_size(titles, tw_t, head_h, big_, 12, 'mj', max_lines=2) if any_title else 0
    xs = common_size(texts, cw - 2 * pad, text_h, big_, 10.5, 'mn')
    xh = max([text_height(clip(t_, cw - 2 * pad, text_h, xs, 'mn'), cw - 2 * pad, xs, 'mn') for t_ in texts if t_] or [0])
    need = 0.22 + head_h + 0.14 + xh + 0.3
    rh = min(rh_max, max(1.6, need, rh_max * 0.85))       # плитки — почти на всю высоту области
    total = rh * len(rows) + gap * (len(rows) - 1)
    y0 = top + max(0.0, (avail - total) / 2.5)
    k = 0
    for r, cnt in enumerate(rows):
        row_w = cnt * cw + (cnt - 1) * gap
        x0 = C.L + (C.CW - row_w) / 2
        y = y0 + r * (rh + gap)
        for j in range(cnt):
            it = items[k]
            c1, c2 = pair(k, n)
            x = x0 + j * (cw + gap)
            g = group(sl)
            tile = grect(g, x, y, cw, rh, c1, c2, 45 if k == n - 1 else 0)
            shadow(tile, 14, 4, 22)
            big = text(g, x + cw - 1.3, y + 0.02, 1.2, 1.0, str(k + 1), size=60, color=WHITE, font='b',
                       align=PP_ALIGN.RIGHT)
            text_alpha(big, 22)
            circ_icon(g, it['icon'], x + pad, y + 0.22 + (head_h - d_) / 2, d_, fill=WHITE, ic='n')
            if titles[k]:
                text(g, x + pad + d_ + 0.18, y + 0.22, tw_t, head_h, clip(titles[k], tw_t, head_h, ts, 'mj', 2),
                     size=ts, color=WHITE, font='mj', anchor=MSO_ANCHOR.MIDDLE)
            ty = y + 0.22 + head_h + 0.14
            text(g, x + pad, ty, cw - 2 * pad, y + rh - ty - 0.1, clip(texts[k], cw - 2 * pad, text_h, xs, 'mn'),
                 size=xs, color=WHITE)
            ctx.anim(sl, g, 'zoom', 100 + k * 180, 450)
            k += 1
    conclusion(ctx, sl, s, 300 + n * 180)
    return sl