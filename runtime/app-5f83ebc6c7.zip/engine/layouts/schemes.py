# -*- coding: utf-8 -*-
"""
schemes.py — СХЕМЫ И ИНФОГРАФИКА: пирамида, воронка, ступени, матрица, сеть связей, соты,
слои, опоры, дорожная карта, шестерёнки, пересечение, спидометры, полосы, пузыри, дерево
=====================================================================================

Все схемы рисуются стандартными фигурами PowerPoint (их можно править вручную) в
фирменной палитре: градиенты синий → зелёный (pair), мягкие тени (shadow), свечение
ключевых узлов (glow), полупрозрачные крупные номера (text_alpha). Текст подгоняется по
метрикам шрифтов (common_size / clip), содержимое растягивается на всю рабочую область.

Общий формат данных — items: [{'title', 'text', 'icon', 'value', 'unit', 'label'}];
center — текст в центре (сеть, пересечение) или «крыша» (опоры).
"""
import math
import re

from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches as I
from pptx.util import Pt

from ..nts import config as C
from ..nts.config import LGRAY, PALEG, PALEG2, SOFT
from ..nts.effects import alpha_fill, glow, grad, set_av, shadow, text_alpha
from ..nts.shapes import circ_icon, freeform, grect, group, icon, line, rect, shape_text, text
from ..textfit import clip, text_height
from ..textutil import parse_number
from .base import (BLUE, DGREEN, GRAY, GREEN, LGREEN, NAVY, WHITE, common_size, conclusion, content_slide,
                   pair, stack_fit)

LEGEND_W = 5.4          # ширина правой колонки с подписями у «рисуночных» схем


def _tt(it):
    return it.get('title') or '', it.get('text') or ''


def _legend(ctx, sl, items, x, top, bottom, w, delay=400, numbers=True, align_centers=None):
    """Колонка подписей справа от рисунка: номер/квадрат цвета + заголовок + текст.
    align_centers — список y-центров, к которым привязать строки (если None — равномерно)."""
    n = len(items)
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    avail = bottom - top
    rh = avail / n
    tw = w - 0.55
    only_titles = any(titles) and not any(texts)
    th_ = (min(1.0, rh - 0.1) if only_titles else 0.5) if any(titles) else 0
    ts = common_size(titles, tw, th_, (20 if n <= 4 else 17) if only_titles else (17 if n <= 4 else 15), 11, 'mj',
                     max_lines=3 if only_titles else 2) if th_ else 0
    xs = common_size(texts, tw, rh - th_ - 0.14, 17 if n <= 4 else 14, 10, 'mn') if any(texts) else 0
    for i, it in enumerate(items):
        c1, c2 = pair(i, n)
        cy = align_centers[i] if align_centers else top + rh * (i + 0.5)
        th = text_height(clip(titles[i], tw, th_, ts, 'mj', 3 if only_titles else 2), tw, ts, 'mj') if titles[i] else 0
        xh = text_height(clip(texts[i], tw, rh - th_ - 0.14, xs, 'mn'), tw, xs, 'mn') if texts[i] else 0
        hh = th + (0.06 if th and xh else 0) + xh
        y = max(top, min(bottom - hh, cy - hh / 2))
        g = group(sl)
        if numbers:
            bd = rect(g, x, y + 0.02, 0.36, 0.36, fill=c1, shape=MSO_SHAPE.OVAL)
            grad(bd, c1, c2, 45)
            shape_text(bd, str(i + 1), size=11, color=WHITE, font='b', margins=(0, 0, 0, 0))
        else:
            sq = rect(g, x, y + 0.06, 0.28, 0.28, fill=c1, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.3)
            grad(sq, c1, c2, 45)
        if titles[i]:
            text(g, x + 0.55, y, tw, th + 0.02, clip(titles[i], tw, th_, ts, 'mj', 3 if only_titles else 2), size=ts,
                 color=NAVY, font='mj')
        if texts[i]:
            text(g, x + 0.55, y + th + (0.06 if th else 0), tw, xh + 0.05,
                 clip(texts[i], tw, rh - th_ - 0.14, xs, 'mn'), size=xs, color=GRAY)
        ctx.anim(sl, g, 'wipe_l', delay + i * 150, 400)


def _num_label(g, x, y, w, h, i, color=WHITE, size=16):
    text(g, x, y, w, h, f'{i + 1:02d}', size=size, color=color, font='b', align=PP_ALIGN.CENTER,
         anchor=MSO_ANCHOR.MIDDLE)


# ======================================================================================
# ПИРАМИДА: уровни сверху вниз (иерархия, приоритеты, основа)
# ======================================================================================
def render_pyramid(ctx, s, inverted=False):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    H = bottom - top - 0.15
    W = 5.9
    x0 = C.L + 0.2
    gapv = 0.07
    lh = (H - gapv * (n - 1)) / n
    titles = [_tt(it)[0] for it in items]
    centers = []
    for i in range(n):
        y1 = top + 0.05 + i * (lh + gapv)
        y2 = y1 + lh
        k1, k2 = i / n, (i + 1) / n                     # доля высоты от вершины
        if inverted:                                   # воронка: широкая сверху, узкая снизу (не до точки)
            w1 = W * (1 - 0.68 * k1)
            w2 = W * (1 - 0.68 * k2)
        else:
            w1, w2 = W * k1, W * k2
        cx = x0 + W / 2
        pts = [(cx - w1 / 2, y1), (cx + w1 / 2, y1), (cx + w2 / 2, y2), (cx - w2 / 2, y2)]
        if w1 < 0.05:
            pts = [(cx, y1), (cx + w2 / 2, y2), (cx - w2 / 2, y2)]
        c1, c2 = pair(i, n)
        g = group(sl)
        shp = freeform(g, pts, fill=c1)
        grad(shp, c1, c2, 0)
        shadow(shp, 10, 3, 22)
        wmid = (w1 + w2) / 2
        # внутри уровня: число (если у элементов есть value) или номер; у широких — ещё и заголовок
        if items[i].get('value') and wmid >= 0.9:
            val = str(items[i]['value'])
            vs = common_size([val], max(0.8, wmid - 0.4), lh - 0.1, 30 if lh > 0.9 else 22, 12, 'b', max_lines=1)
            text(g, cx - wmid / 2 + 0.1, y1, wmid - 0.2, lh, val, size=vs, color=WHITE, font='b',
                 align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        elif wmid >= 1.2:
            tw = wmid - 1.6
            if tw > 2.2 and titles[i]:
                _num_label(g, cx - wmid / 2 + 0.25, y1, 0.8, lh, i, WHITE, 18 if lh > 0.8 else 14)
                ts = common_size([titles[i]], tw, lh - 0.1, 15, 10, 'mj', max_lines=2)
                big = text(g, cx - wmid / 2 + 1.1, y1, tw, lh, clip(titles[i], tw, lh - 0.1, ts, 'mj', 2), size=ts,
                           color=WHITE, font='mj', anchor=MSO_ANCHOR.MIDDLE)
                text_alpha(big, 92)
            else:
                _num_label(g, cx - 0.5, y1, 1.0, lh, i, WHITE, 20 if lh > 0.8 else 15)
        ctx.anim(sl, g, 'zoom', 100 + i * 180, 450)
        centers.append((y1 + y2) / 2)
        # выноска к подписи справа
        gl = group(sl)
        line(gl, cx + max(w1, w2) / 2 + 0.05, (y1 + y2) / 2, x0 + W + 0.5, (y1 + y2) / 2, color=c1, w=1.0,
             head=False, dash='sysDot')
        ctx.anim(sl, gl, 'fade', 300 + i * 180, 300)
    _legend(ctx, sl, items, x0 + W + 0.6, top, bottom, C.R - (x0 + W + 0.6), 350, numbers=False,
            align_centers=centers)
    if inverted:                                       # у воронки внизу — стрелка результата
        g = group(sl)
        ar = rect(g, x0 + W / 2 - 0.22, bottom - 0.12, 0.44, 0.3, fill=GREEN, shape=MSO_SHAPE.DOWN_ARROW)
        grad(ar, DGREEN, GREEN, 90)
        ctx.anim(sl, g, 'fade', 300 + n * 180, 400)
    conclusion(ctx, sl, s, 400 + n * 180)
    return sl


def render_funnel(ctx, s):
    return render_pyramid(ctx, s, inverted=True)


# ======================================================================================
# СТУПЕНИ: рост слева направо (этапы развития, уровни зрелости)
# ======================================================================================
def render_stairs(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    avail = bottom - top
    sw = C.CW / n
    h_max = avail * 0.5                                  # самая высокая ступень — половина области
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    tw = sw - 0.3
    ts = common_size(titles, tw, 0.75, 17 if n <= 4 else 15, 11, 'mj', max_lines=2) if any(titles) else 0
    text_h = avail - h_max - 0.85 - 0.6
    xs = common_size(texts, tw, text_h, 14.5 if n <= 4 else 13, 10, 'mn') if any(texts) else 0
    # «дорожка» подъёма: пунктирная стрелка над ступенями
    for i, it in enumerate(items):
        c1, c2 = pair(i, n)
        x = C.L + i * sw
        h = h_max * (i + 1) / n
        y = bottom - h
        g = group(sl)
        step = rect(g, x, y, sw - 0.06, h, fill=c1)
        grad(step, c1, c2, 90)
        shadow(step, 10, 3, 20)
        rect(g, x, y, sw - 0.06, 0.07, fill=WHITE)      # светлая кромка ступени
        _num_label(g, x + 0.1, y + 0.08, 0.9, 0.5, i, WHITE, 18)
        if i == n - 1:
            icon(g, 'TbFlag', 'w', x + sw - 0.06 - 0.6, y + 0.12, 0.42)
        # текст над ступенью: иконка в круге, заголовок, пояснение
        ty = y - 0.1
        d_ = 0.56
        if texts[i]:
            xh = text_height(clip(texts[i], tw, text_h, xs, 'mn'), tw, xs, 'mn')
            ty -= xh
            text(g, x + 0.12, ty, tw, xh + 0.05, clip(texts[i], tw, text_h, xs, 'mn'), size=xs, color=GRAY)
            ty -= 0.08
        if titles[i]:
            th = text_height(clip(titles[i], tw, 0.75, ts, 'mj', 2), tw, ts, 'mj')
            ty -= th
            text(g, x + 0.12, ty, tw, th + 0.05, clip(titles[i], tw, 0.75, ts, 'mj', 2), size=ts, color=NAVY, font='mj')
            ty -= 0.1
        ci = circ_icon(g, it['icon'], x + 0.12, max(top, ty - d_), d_, fill=c1, fill2=c2)
        shadow(ci, 8, 2, 25)
        ctx.anim(sl, g, 'rise', 100 + i * 170, 450)
    conclusion(ctx, sl, s, 400 + n * 170)
    return sl


# ======================================================================================
# МАТРИЦА 2×2 (SWOT, важно/срочно, квадранты)
# ======================================================================================
def render_matrix(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:4]
    n = len(items)
    gap = 0.18
    axes = s.get('axes') or {}
    ax_w = 0.45 if axes else 0
    qw = (C.CW - ax_w - gap) / 2
    qh = (bottom - top - ax_w - gap) / 2
    head_h = 0.62
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    ts = common_size(titles, qw - 1.2, head_h - 0.1, 18, 12, 'mj', max_lines=1)
    xs = common_size(texts, qw - 0.5, qh - head_h - 0.35, 16, 10.5, 'mn')
    fills = [PALEG, SOFT, SOFT, PALEG2]
    for i, it in enumerate(items):
        r, c = divmod(i, 2)
        x = C.L + ax_w + c * (qw + gap)
        y = top + r * (qh + gap)
        c1, c2 = pair(i, 4)
        g = group(sl)
        body = rect(g, x, y, qw, qh, fill=fills[i], shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.06)
        shadow(body, 10, 3, 16)
        head = grect(g, x, y, qw, head_h, c1, c2, 0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
        set_av(head, {'adj': 12000})
        sq = rect(g, x, y + head_h - 0.2, qw, 0.2, fill=c1)   # прямые нижние углы шапки
        grad(sq, c1, c2, 0)
        circ_icon(g, it['icon'], x + 0.14, y + (head_h - 0.42) / 2, 0.42, fill=WHITE, ic='n')
        text(g, x + 0.7, y, qw - 0.9, head_h, clip(titles[i], qw - 1.2, head_h - 0.1, ts, 'mj', 1), size=ts,
             color=WHITE, font='mj', anchor=MSO_ANCHOR.MIDDLE)
        text(g, x + 0.25, y + head_h + 0.18, qw - 0.5, qh - head_h - 0.3,
             clip(texts[i], qw - 0.5, qh - head_h - 0.35, xs, 'mn'), size=xs, color=GRAY)
        big = text(g, x + qw - 1.2, y + qh - 1.0, 1.1, 0.95, str(i + 1), size=56, color=c1, font='b',
                   align=PP_ALIGN.RIGHT)
        text_alpha(big, 14)
        ctx.anim(sl, g, 'zoom', 100 + i * 180, 450)
    if axes:
        gx = group(sl)
        text(gx, C.L + ax_w, bottom - ax_w + 0.08, C.CW - ax_w, ax_w - 0.1, axes.get('x') or '', size=12, color=NAVY,
             font='mj', align=PP_ALIGN.CENTER)
        tb = text(gx, C.L - 2.2, (top + bottom - ax_w) / 2 - 0.2, 4.8, 0.4, axes.get('y') or '', size=12, color=NAVY,
                  font='mj', align=PP_ALIGN.CENTER)
        tb.rotation = -90
        ctx.anim(sl, gx, 'fade', 100, 400)
    conclusion(ctx, sl, s, 400 + n * 180)
    return sl


# ======================================================================================
# СЕТЬ СВЯЗЕЙ: центр и связанные элементы вокруг
# ======================================================================================
def render_hub(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    cx, cy = (C.L + C.R) / 2, (top + bottom) / 2
    Rc = min(1.15, (bottom - top) * 0.22)
    rx, ry = 3.3, (bottom - top) / 2 - 0.75
    nd = 0.86 if n <= 4 else 0.76
    # центр
    gc = group(sl)
    halo = rect(gc, cx - Rc - 0.25, cy - Rc - 0.25, 2 * Rc + 0.5, 2 * Rc + 0.5, fill=PALEG, shape=MSO_SHAPE.OVAL)
    alpha_fill(halo, 'CEE1A5', 55)
    core = rect(gc, cx - Rc, cy - Rc, 2 * Rc, 2 * Rc, fill=NAVY, shape=MSO_SHAPE.OVAL)
    grad(core, NAVY, BLUE, 45)
    glow(core, 'CEE1A5', 12, 60)
    center = s.get('center') or s.get('title') or ''
    cs = common_size([center], 2 * Rc * 0.8, 2 * Rc * 0.7, 18, 10.5, 'mj')
    text(gc, cx - Rc * 0.8, cy - Rc * 0.7, 2 * Rc * 0.8, 2 * Rc * 1.4 * 0.5 + 0.2,
         clip(center, 2 * Rc * 0.8, Rc * 1.4, cs, 'mj'), size=cs, color=WHITE, font='mj', align=PP_ALIGN.CENTER,
         anchor=MSO_ANCHOR.MIDDLE)
    ctx.anim(sl, gc, 'zoom', 0, 600)
    # узлы по эллипсу: при n ≤ 4 — по диагоналям, чтобы подписи были сбоку
    start = 45 if n <= 4 else (90 - 180 / n)
    angs = [start + i * 360 / n for i in range(n)]
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    lw = 2.75 if n <= 4 else 2.45
    lab_h = 1.15 if n <= 4 else 1.0
    # подписи не выходят за рабочую область (свой шаблон 4:3 — она уже): сначала уже подписи, потом меньше эллипс
    mc = max(abs(math.cos(math.radians(a))) for a in angs)
    over = rx * mc + nd / 2 + 0.12 + lw - (C.R - C.L) / 2
    if over > 0:
        cut = min(over, lw - 1.8)
        lw, over = lw - cut, over - cut
        if over > 0:
            rx = max(1.6, rx - over / max(mc, 0.3))
    ts = common_size(titles, lw, 0.5, 16 if n <= 4 else 14, 11, 'mj', max_lines=2) if any(titles) else 0
    xs = common_size(texts, lw, lab_h - 0.5, 13.5 if n <= 4 else 12, 9.5, 'mn') if any(texts) else 0
    for i, (a, it) in enumerate(zip(angs, items)):
        c1, c2 = pair(i, n)
        px = cx + rx * math.cos(math.radians(a))
        py = cy - ry * math.sin(math.radians(a))
        g = group(sl)
        ux, uy = px - cx, py - cy
        dist = math.hypot(ux, uy)
        ux, uy = ux / dist, uy / dist
        ln = line(g, cx + ux * Rc, cy + uy * Rc, px - ux * nd / 2, py - uy * nd / 2, color=c1, w=2.25, head=False)
        ci = circ_icon(g, it['icon'], px - nd / 2, py - nd / 2, nd, fill=c1, fill2=c2)
        shadow(ci, 10, 3, 25)
        glow(ci, 'FFFFFF', 3, 35)
        # подпись — всегда сбоку от узла (снаружи), по вертикали — по центру узла
        right = px >= cx - 0.01
        lx = px + nd / 2 + 0.12 if right else px - nd / 2 - 0.12 - lw
        ly = max(top, min(bottom - lab_h, py - lab_h / 2))
        al = PP_ALIGN.LEFT if right else PP_ALIGN.RIGHT
        yy = ly
        if titles[i]:
            th = text_height(clip(titles[i], lw, 0.5, ts, 'mj', 2), lw, ts, 'mj')
            text(g, lx, yy, lw, th + 0.04, clip(titles[i], lw, 0.5, ts, 'mj', 2), size=ts, color=c1, font='mj', align=al)
            yy += th + 0.05
        if texts[i]:
            text(g, lx, yy, lw, max(0.3, ly + lab_h - yy), clip(texts[i], lw, lab_h - 0.5, xs, 'mn'), size=xs,
                 color=GRAY, align=al)
        ctx.anim(sl, g, 'zoom', 300 + i * 200, 450)
    conclusion(ctx, sl, s, 600 + n * 200)
    return sl


# ======================================================================================
# СОТЫ: равноправные элементы-шестиугольники
# ======================================================================================
def render_honeycomb(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    has_text = any(texts)
    if has_text:            # рядом колонка подписей — соты компактнее, в 2–3 ряда
        rows = [n] if n <= 2 else ([2, n - 2] if n <= 4 else ([3, n - 3] if n <= 6 else [4, n - 4]))
    else:
        rows = [n] if n <= 4 else ([3, n - 3] if n <= 6 else [4, n - 4])
    area_w = 6.4 if has_text else C.CW
    avail = bottom - top - 0.1
    hw = min(2.6, (area_w - 0.15 * (max(rows) - 1) - (0.6 if len(rows) > 1 else 0)) / max(rows),
             avail / (1 + 0.78 * (len(rows) - 1)) / 0.87)
    hh = hw * 0.87
    total_h = hh + (len(rows) - 1) * hh * 0.78
    y0 = top + (bottom - top - total_h) / 2
    x_area = C.L
    k = 0
    tsz = common_size(titles, hw * 0.72, hh * 0.42, 15, 10, 'mj', max_lines=2) if any(titles) else 0
    for r, cnt in enumerate(rows):
        row_w = cnt * hw + (cnt - 1) * 0.15
        x0 = x_area + (area_w - row_w) / 2
        y = y0 + r * hh * 0.78
        for j in range(cnt):
            it = items[k]
            c1, c2 = pair(k, n)
            x = x0 + j * (hw + 0.15)
            g = group(sl)
            hx = rect(g, x, y, hw, hh, fill=c1, shape=MSO_SHAPE.HEXAGON)
            grad(hx, c1, c2, 45)
            shadow(hx, 12, 3, 22)
            hx.line.color.rgb = WHITE
            hx.line.width = Pt(1.5)
            d_ = hh * 0.3
            icon(g, it['icon'], 'w', x + hw / 2 - d_ / 2, y + hh * 0.14, d_)
            text(g, x + hw * 0.14, y + hh * 0.48, hw * 0.72, hh * 0.42,
                 clip(titles[k], hw * 0.72, hh * 0.42, tsz, 'mj', 2), size=tsz, color=WHITE, font='mj',
                 align=PP_ALIGN.CENTER)
            if has_text:
                bd = rect(g, x + hw * 0.5 - 0.15, y + hh - 0.36, 0.3, 0.3, fill=WHITE, shape=MSO_SHAPE.OVAL)
                shape_text(bd, str(k + 1), size=10, color=c1, font='b', margins=(0, 0, 0, 0))
            ctx.anim(sl, g, 'zoom', 100 + k * 150, 450)
            k += 1
    if has_text:
        _legend(ctx, sl, items, C.L + area_w + 0.35, top, bottom, C.R - (C.L + area_w + 0.35), 400)
    conclusion(ctx, sl, s, 400 + n * 150)
    return sl


# ======================================================================================
# СЛОИ: стек уровней (архитектура, уровни системы)
# ======================================================================================
def render_layers(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    gap = 0.12
    avail = bottom - top - 0.05
    lh = (avail - gap * (n - 1)) / n
    inset = min(0.45, 1.6 / n)
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    tw_title = 3.4
    ts = common_size(titles, tw_title, lh - 0.2, 18 if n <= 4 else 15, 11, 'mj', max_lines=2)
    for i, it in enumerate(items):
        c1, c2 = pair(i, n)
        ins = inset * (n - 1 - i)
        x, w = C.L + ins, C.CW - 2 * ins
        y = top + i * (lh + gap)
        g = group(sl)
        band = rect(g, x, y, w, lh, fill=c1, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.18)
        grad(band, c1, c2, 0)
        shadow(band, 10, 3, 20)
        d_ = min(0.6, lh - 0.2)
        ci = circ_icon(g, it['icon'], x + 0.22, y + (lh - d_) / 2, d_, fill=WHITE, ic='n', ratio=0.58)
        _num_label(g, x + 0.22 + d_ + 0.1, y, 0.5, lh, i, WHITE, 14)
        text(g, x + 0.22 + d_ + 0.65, y, tw_title, lh, clip(titles[i], tw_title, lh - 0.2, ts, 'mj', 2), size=ts,
             color=WHITE, font='mj', anchor=MSO_ANCHOR.MIDDLE)
        tx = x + 0.22 + d_ + 0.65 + tw_title + 0.3
        tw = x + w - tx - 0.25
        if texts[i] and tw > 1.5:
            xs = common_size([texts[i]], tw, lh - 0.2, 14.5, 10, 'mn')
            tb = text(g, tx, y, tw, lh, clip(texts[i], tw, lh - 0.2, xs, 'mn'), size=xs, color=WHITE,
                      anchor=MSO_ANCHOR.MIDDLE)
            text_alpha(tb, 90)
        ctx.anim(sl, g, 'rise' if i == n - 1 else 'fade', 100 + (n - 1 - i) * 150, 450)
    conclusion(ctx, sl, s, 400 + n * 150)
    return sl


# ======================================================================================
# ОПОРЫ: «крыша» (цель) на колоннах (принципы, направления)
# ======================================================================================
def render_pillars(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    roof_h = 0.78
    base_h = 0.22
    gap = 0.22
    avail = bottom - top
    cw = (C.CW - gap * (n - 1)) / n
    ch = avail - roof_h - 0.18 - base_h - 0.1
    center = s.get('center') or s.get('subtitle') or s.get('title') or ''
    g = group(sl)
    roof = grect(g, C.L, top, C.CW, roof_h, NAVY, BLUE, 0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    set_av(roof, {'adj': 25000})
    shadow(roof, 12, 3, 22)
    icon(g, 'TbTargetArrow', 'w', C.L + 0.3, top + (roof_h - 0.46) / 2, 0.46)
    rs = common_size([center], C.CW - 1.2, roof_h - 0.16, 20, 12, 'mj', max_lines=2)
    text(g, C.L + 0.95, top, C.CW - 1.2, roof_h, clip(center, C.CW - 1.2, roof_h - 0.16, rs, 'mj', 2), size=rs,
         color=WHITE, font='mj', anchor=MSO_ANCHOR.MIDDLE)
    ctx.anim(sl, g, 'rise', 0, 500)
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    tw = cw - 0.4
    d_ = min(0.8, cw * 0.32)
    ts = common_size(titles, tw, 0.75, 18 if n <= 3 else 16, 11, 'mj', max_lines=2) if any(titles) else 0
    text_h = ch - 0.25 - d_ - 0.2 - 0.75 - 0.2
    xs = common_size(texts, tw, text_h, 15 if n <= 3 else 13.5, 10, 'mn') if any(texts) else 0
    for i, it in enumerate(items):
        c1, c2 = pair(i, n)
        x = C.L + i * (cw + gap)
        y = top + roof_h + 0.18
        g = group(sl)
        col = rect(g, x, y, cw, ch, fill=SOFT)
        grad(col, SOFT, WHITE, 90)
        shadow(col, 10, 3, 16)
        cap = rect(g, x, y, cw, 0.1, fill=c1)
        grad(cap, c1, c2, 0)
        ci = circ_icon(g, it['icon'], x + (cw - d_) / 2, y + 0.3, d_, fill=c1, fill2=c2)
        shadow(ci, 8, 2, 25)
        yy = y + 0.3 + d_ + 0.2
        if titles[i]:
            th = text_height(clip(titles[i], tw, 0.75, ts, 'mj', 2), tw, ts, 'mj')
            text(g, x + 0.2, yy, tw, th + 0.04, clip(titles[i], tw, 0.75, ts, 'mj', 2), size=ts, color=NAVY,
                 font='mj', align=PP_ALIGN.CENTER)
            yy += th + 0.15
        if texts[i]:
            text(g, x + 0.2, yy, tw, y + ch - yy - 0.15, clip(texts[i], tw, y + ch - yy - 0.15, xs, 'mn'), size=xs,
                 color=GRAY, align=PP_ALIGN.CENTER)
        ctx.anim(sl, g, 'rise', 250 + i * 170, 450)
    gb = group(sl)
    base = grect(gb, C.L, bottom - base_h, C.CW, base_h, DGREEN, GREEN, 0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    set_av(base, {'adj': 50000})
    ctx.anim(sl, gb, 'wipe_l', 200, 600)
    conclusion(ctx, sl, s, 500 + n * 170)
    return sl


# ======================================================================================
# ДОРОЖНАЯ КАРТА: «дорога» с вехами, подписи сверху и снизу
# ======================================================================================
def render_roadmap(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    ly = (top + bottom) / 2 + 0.1
    road_h = 0.56
    g = group(sl)
    road = rect(g, C.L, ly - road_h / 2, C.CW, road_h, fill=NAVY, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.5)
    grad(road, NAVY, BLUE, 0)
    shadow(road, 10, 3, 20)
    line(g, C.L + 0.4, ly, C.R - 0.6, ly, color=LGREEN, w=2, head=True, dash='dash')
    ctx.anim(sl, g, 'wipe_l', 0, 900)
    nd = 0.64 if n <= 6 else 0.54
    cw = min(2.9, (2 * C.CW - 0.25 * (n - 1)) / (n + 1))
    step = (C.CW - cw) / (n - 1) if n > 1 else 0
    xs_ = [C.L + cw / 2 + i * step for i in range(n)]
    labels = [(it.get('label') or '') for it in items]
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    zone_h = (bottom - top) / 2 - road_h / 2 - 0.3
    pill_h = 0.34 if any(labels) else 0
    tw = cw - 0.1
    ts = common_size(titles, tw, 0.7, 19, 10.5, 'mj', max_lines=2) if any(titles) else 0       # крупнее (1.9)
    xs = common_size(texts, tw, zone_h - pill_h - 0.85, 16, 9.5, 'mn') if any(texts) else 0
    for i, it in enumerate(items):
        x = xs_[i]
        c1, c2 = pair(i, n)
        up = i % 2 == 0
        g = group(sl)
        node = rect(g, x - nd / 2, ly - nd / 2, nd, nd, fill=WHITE, shape=MSO_SHAPE.OVAL)
        node.line.color.rgb = c1
        node.line.width = Pt(3)
        shadow(node, 8, 2, 25)
        glow(node, 'CEE1A5', 6, 45)
        shape_text(node, str(i + 1), size=13, color=c1, font='b', margins=(0, 0, 0, 0))
        # вертикальная ножка к подписи
        if up:
            line(g, x, ly - nd / 2, x, ly - nd / 2 - 0.22, color=c1, w=1.5, head=False)
            yb = ly - nd / 2 - 0.26
        else:
            line(g, x, ly + nd / 2, x, ly + nd / 2 + 0.22, color=c1, w=1.5, head=False)
            yt = ly + nd / 2 + 0.26
        # блок подписи: [плашка с датой] заголовок, текст
        th = text_height(clip(titles[i], tw, 0.7, ts, 'mj', 2), tw, ts, 'mj') if titles[i] else 0
        xh = text_height(clip(texts[i], tw, zone_h - pill_h - 0.85, xs, 'mn'), tw, xs, 'mn') if texts[i] else 0
        bh = pill_h + (0.08 if pill_h else 0) + th + (0.06 if th and xh else 0) + xh
        y = (yb - bh) if up else yt
        y = max(top, min(bottom - bh, y))
        xx = x - cw / 2
        yy = y
        if labels[i]:
            pill = rect(g, xx, yy, min(cw, 1.6), pill_h, fill=c1, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.5)
            grad(pill, c1, c2, 0)
            shape_text(pill, labels[i], size=11, color=WHITE, font='b', margins=(0.08, 0, 0.08, 0))
            yy += pill_h + 0.08
        if titles[i]:
            text(g, xx, yy, tw, th + 0.04, clip(titles[i], tw, 0.7, ts, 'mj', 2), size=ts, color=NAVY, font='mj')
            yy += th + 0.06
        if texts[i]:
            text(g, xx, yy, tw, xh + 0.05, clip(texts[i], tw, zone_h - pill_h - 0.85, xs, 'mn'), size=xs, color=GRAY)
        ctx.anim(sl, g, 'rise', 250 + i * 150, 450)
    conclusion(ctx, sl, s, 400 + n * 150)
    return sl


# ======================================================================================
# ШЕСТЕРЁНКИ: взаимосвязанные процессы
# ======================================================================================
def render_gears(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    avail = bottom - top
    # раскладка 2–4 шестерёнок «в зацеплении» в левой части слайда
    base = min(2.5, avail * 0.46)
    lay = {2: [(0.0, 0.0, 1.0), (1.02, -0.55, 0.78)],
           3: [(0.0, 0.0, 1.0), (1.02, -0.6, 0.72), (0.98, 0.62, 0.66)],
           4: [(0.0, 0.0, 1.0), (1.02, -0.6, 0.7), (0.98, 0.62, 0.64), (1.86, 0.0, 0.58)]}[max(2, min(4, n))]
    ox, oy = C.L + base * 0.75, (top + bottom) / 2 + 0.15
    for i, it in enumerate(items[:4]):
        dx, dy, k = lay[i]
        d = base * k
        cx, cy = ox + dx * base, oy + dy * base
        c1, c2 = pair(i, n)
        g = group(sl)
        gear = rect(g, cx - d / 2, cy - d / 2, d, d, fill=c1, shape=MSO_SHAPE.GEAR_9)
        grad(gear, c1, c2, 45)
        shadow(gear, 12, 3, 22)
        gear.rotation = 20 * i
        hub = rect(g, cx - d * 0.26, cy - d * 0.26, d * 0.52, d * 0.52, fill=WHITE, shape=MSO_SHAPE.OVAL)
        shadow(hub, 6, 1, 18)
        icon(g, it['icon'], 'n', cx - d * 0.15, cy - d * 0.15, d * 0.3)
        bd = rect(g, cx + d * 0.08, cy + d * 0.1, 0.32, 0.32, fill=c1, shape=MSO_SHAPE.OVAL)
        shape_text(bd, str(i + 1), size=10.5, color=WHITE, font='b', margins=(0, 0, 0, 0))
        ctx.anim(sl, g, 'zoom', 100 + i * 220, 500)
    lx = C.L + base * 2.4 + (0.5 if n >= 4 else 0.2)
    _legend(ctx, sl, items, lx, top, bottom, C.R - lx, 500)
    conclusion(ctx, sl, s, 500 + n * 220)
    return sl


# ======================================================================================
# ПЕРЕСЕЧЕНИЕ: 2–3 круга (синергия, «на стыке»)
# ======================================================================================
def render_venn(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:3]
    n = len(items)
    texts = [_tt(it)[1] for it in items]
    has_text = any(texts)
    area_w = 6.4 if has_text else 9.0
    cx = C.L + area_w / 2
    cy = (top + bottom) / 2
    R = min(2.0, (bottom - top) * 0.36, area_w * 0.3)
    off = R * 0.6
    if n == 2:
        centers = [(cx - off, cy), (cx + off, cy)]
    else:
        centers = [(cx, cy - off * 0.75), (cx - off, cy + off * 0.55), (cx + off, cy + off * 0.55)]
    cols = [('00326E', NAVY), ('0078AE', BLUE), ('4BAF46', GREEN)]
    titles = [_tt(it)[0] for it in items]
    ts = common_size(titles, R * 1.1, 0.8, 16, 11, 'mj', max_lines=2)
    for i, ((px, py), it) in enumerate(zip(centers, items)):
        hexc, col = cols[i]
        g = group(sl)
        circ = rect(g, px - R, py - R, 2 * R, 2 * R, fill=col, shape=MSO_SHAPE.OVAL)
        alpha_fill(circ, hexc, 62)
        circ.line.color.rgb = WHITE
        circ.line.width = Pt(2)
        # заголовок — в «своей» части круга (от центра пересечения наружу)
        ux, uy = px - cx, py - cy
        dist = math.hypot(ux, uy) or 1
        tx, ty = px + ux / dist * R * 0.42, py + uy / dist * R * 0.42
        icon(g, it['icon'], 'w', tx - 0.22, ty - 0.62, 0.44)
        text(g, tx - R * 0.55, ty - 0.12, R * 1.1, 0.8, clip(titles[i], R * 1.1, 0.8, ts, 'mj', 2), size=ts,
             color=WHITE, font='mj', align=PP_ALIGN.CENTER)
        ctx.anim(sl, g, 'zoom', 100 + i * 220, 500)
    center = s.get('center') or ''
    if center:
        g = group(sl)
        pw, ph = min(2.4, R * 1.3), 0.62
        pcx = cx if n == 2 else cx
        pcy = cy if n == 2 else cy + off * 0.12
        pill = rect(g, pcx - pw / 2, pcy - ph / 2, pw, ph, fill=WHITE, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.5)
        shadow(pill, 12, 3, 28)
        csz = common_size([center], pw - 0.3, ph - 0.1, 14, 9.5, 'mj', max_lines=2)
        shape_text(pill, clip(center, pw - 0.3, ph - 0.1, csz, 'mj', 2), size=csz, color=NAVY, font='mj',
                   margins=(0.15, 0.03, 0.15, 0.03))
        ctx.anim(sl, g, 'zoom', 300 + n * 220, 500)
    if has_text:
        _legend(ctx, sl, items, C.L + area_w + 0.3, top, bottom, C.R - (C.L + area_w + 0.3), 500)
    conclusion(ctx, sl, s, 600 + n * 220)
    return sl


# ======================================================================================
# СПИДОМЕТРЫ: показатели в процентах
# ======================================================================================
def _frac(it, vmax):
    v = parse_number(str(it.get('value') or ''))
    if v is None:
        return 0.0
    return max(0.0, min(1.0, v / vmax)) if vmax else 0.0


def _vmax(items):
    vals = [parse_number(str(it.get('value') or '')) for it in items]
    vals = [v for v in vals if v is not None]
    if any('%' in str(it.get('unit') or '') for it in items) and vals and max(vals) <= 100:
        return 100.0
    for it in items:
        m = parse_number(str(it.get('max') or ''))
        if m:
            return m
    return max(vals) if vals else 1.0


def render_gauge(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items'][:4]
    n = len(items)
    vmax = _vmax(items)
    gap = 0.3
    cw = (C.CW - gap * (n - 1)) / n
    avail = bottom - top
    D = min(cw - 0.6, avail * 0.78, 3.6)                # диаметр дуги
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    tw = cw - 0.5
    ts = common_size(titles, tw, 0.75, 20 if n <= 3 else 16, 11, 'mj', max_lines=2)
    xs = common_size(texts, tw, avail - D / 2 - 1.1, 16 if n <= 3 else 14, 9.5, 'mn') if any(texts) else 0
    th_m = max([text_height(clip(t_, tw, 0.75, ts, 'mj', 2), tw, ts, 'mj') for t_ in titles if t_] or [0])
    xh_m = max([text_height(clip(t_, tw, avail - D / 2 - 1.1, xs, 'mn'), tw, xs, 'mn') for t_ in texts if t_] or [0])
    lab_need = 0.22 + th_m + (0.1 + xh_m if any(texts) else 0)
    y_off = max(0.3, (avail - (D / 2 + lab_need)) / 2)            # блок по центру карточки по высоте
    for i, it in enumerate(items):
        c1, c2 = pair(i, n)
        x = C.L + i * (cw + gap)
        cx = x + cw / 2
        cy = top + y_off + D / 2
        g = group(sl)
        card = rect(g, x, top, cw, avail - 0.05, fill=WHITE)      # карточка под шкалой — на всю высоту области (1.9)
        grad(card, WHITE, SOFT, 90)
        shadow(card, 12, 3, 16)
        track = rect(g, cx - D / 2, cy - D / 2, D, D, fill=LGRAY, shape=MSO_SHAPE.BLOCK_ARC)
        set_av(track, {'adj1': 10800000, 'adj2': 0, 'adj3': 22000})
        f = _frac(it, vmax)
        if f > 0.005:
            end = (180 + 180 * f) % 360
            arc = rect(g, cx - D / 2, cy - D / 2, D, D, fill=c1, shape=MSO_SHAPE.BLOCK_ARC)
            grad(arc, c1, c2, 0)
            set_av(arc, {'adj1': 10800000, 'adj2': int(end * 60000), 'adj3': 22000})
            shadow(arc, 8, 2, 20)
        val = str(it.get('value') or '—')
        unit = it.get('unit') or ''
        vs = common_size([val], D * 0.6, D * 0.22, 40 if n <= 2 else 30, 16, 'b', max_lines=1)
        text(g, cx - D * 0.35, cy - D * 0.26, D * 0.7, D * 0.24, val, size=vs, color=NAVY, font='b',
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.BOTTOM)
        if unit:
            text(g, cx - D * 0.35, cy - D * 0.02, D * 0.7, 0.3, unit, size=12, color=DGREEN, font='mj',
                 align=PP_ALIGN.CENTER)
        yy = cy + 0.22
        th = text_height(clip(titles[i], tw, 0.75, ts, 'mj', 2), tw, ts, 'mj') if titles[i] else 0
        text(g, x + 0.25, yy, tw, th + 0.05, clip(titles[i], tw, 0.75, ts, 'mj', 2), size=ts, color=NAVY, font='mj',
             align=PP_ALIGN.CENTER)
        if texts[i]:
            text(g, x + 0.25, yy + th + 0.1, tw, bottom - (yy + th + 0.1) - 0.15,
                 clip(texts[i], tw, bottom - (yy + th + 0.1) - 0.15, xs, 'mn'), size=xs, color=GRAY,
                 align=PP_ALIGN.CENTER)
        ctx.anim(sl, g, 'zoom', 100 + i * 200, 500)
    conclusion(ctx, sl, s, 400 + n * 200)
    return sl


# ======================================================================================
# ПОЛОСЫ: горизонтальная инфографика «показатель — значение»
# ======================================================================================
def render_bars(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    vmax = _vmax(items)
    avail = bottom - top - 0.05
    rh = avail / n
    label_w = 3.3
    val_w = 1.5
    bar_x = C.L + label_w + 0.2
    bar_w = C.CW - label_w - 0.2 - val_w
    bh = min(0.5, rh * 0.42)
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    ts = common_size(titles, label_w - 0.1, rh - 0.1, 16 if n <= 5 else 14, 10.5, 'mj', max_lines=2)
    xs = common_size(texts, bar_w, rh - bh - 0.14, 12.5, 9.5, 'mn') if any(texts) else 0
    vals = [f'{it.get("value") or "—"} {it.get("unit") or ""}'.strip() for it in items]
    vs = common_size(vals, val_w - 0.1, bh + 0.1, 18 if n <= 5 else 15, 10.5, 'b', max_lines=1)
    for i, it in enumerate(items):
        c1, c2 = pair(i, n)
        y = top + i * rh
        g = group(sl)
        if i % 2 == 0:
            rect(g, C.L, y + 0.02, C.CW, rh - 0.04, fill=SOFT)
        text(g, C.L + 0.1, y, label_w - 0.1, rh, clip(titles[i], label_w - 0.1, rh - 0.1, ts, 'mj', 2), size=ts,
             color=NAVY, font='mj', anchor=MSO_ANCHOR.MIDDLE)
        by = y + (rh - bh) / 2 - (0.12 if texts[i] else 0)
        track = rect(g, bar_x, by, bar_w, bh, fill=LGRAY, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.5)
        f = _frac(it, vmax)
        if f > 0.01:
            fill = rect(g, bar_x, by, max(bh, bar_w * f), bh, fill=c1, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.5)
            grad(fill, c1, c2, 0)
            shadow(fill, 6, 2, 18)
        text(g, bar_x + bar_w + 0.1, by - 0.05, val_w - 0.1, bh + 0.1, vals[i], size=vs, color=c1, font='b',
             anchor=MSO_ANCHOR.MIDDLE)
        if texts[i]:
            text(g, bar_x, by + bh + 0.06, bar_w + val_w, rh - bh - 0.14,
                 clip(texts[i], bar_w, rh - bh - 0.14, xs, 'mn'), size=xs, color=GRAY)
        ctx.anim(sl, g, 'wipe_l', 100 + i * 150, 500)
    conclusion(ctx, sl, s, 400 + n * 150)
    return sl


# ======================================================================================
# ПУЗЫРИ: круги, площадь которых пропорциональна значению
# ======================================================================================
def render_bubbles(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    vals = [parse_number(str(it.get('value') or '')) or 0 for it in items]
    vmax = max(vals) or 1
    avail = bottom - top
    Dmax = min(avail * 0.66, C.CW / n - 0.2, 3.6)
    Dmin = Dmax * 0.42
    ds = [max(Dmin, Dmax * math.sqrt(v / vmax)) for v in vals]
    gap = (C.CW - sum(ds)) / (n + 1)
    label_h = 0.75 + (1.0 if any((it.get('text') or '') for it in items) else 0)
    baseline = top + max(0.1, (avail - Dmax - label_h) / 2) + Dmax     # группа по центру области
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    tw = max(ds) + gap * 0.9
    ts = common_size(titles, tw, 0.62, 19 if n <= 4 else 16, 10.5, 'mj', max_lines=2)
    xs = common_size(texts, tw, bottom - baseline - 0.85, 15 if n <= 4 else 13.5, 9.5, 'mn') if any(texts) else 0
    x = C.L + gap
    for i, it in enumerate(items):
        c1, c2 = pair(i, n)
        d = ds[i]
        cx = x + d / 2
        g = group(sl)
        bub = rect(g, cx - d / 2, baseline - d, d, d, fill=c1, shape=MSO_SHAPE.OVAL)
        grad(bub, c1, c2, 45)
        shadow(bub, 14, 4, 26)
        glow(bub, 'FFFFFF', 4, 30)
        val = str(it.get('value') or '')
        unit = it.get('unit') or ''
        vs = common_size([val], d * 0.8, d * 0.32, 34, 12, 'b', max_lines=1)
        text(g, cx - d * 0.4, baseline - d / 2 - d * 0.2, d * 0.8, d * 0.3, val, size=vs, color=WHITE, font='b',
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        if unit and d > 1.0:
            text(g, cx - d * 0.4, baseline - d / 2 + d * 0.1, d * 0.8, 0.3, unit, size=11, color=WHITE,
                 align=PP_ALIGN.CENTER)
        yy = baseline + 0.18
        th = text_height(clip(titles[i], tw, 0.62, ts, 'mj', 2), tw, ts, 'mj') if titles[i] else 0
        text(g, cx - tw / 2, yy, tw, th + 0.05, clip(titles[i], tw, 0.62, ts, 'mj', 2), size=ts, color=NAVY,
             font='mj', align=PP_ALIGN.CENTER)
        if texts[i]:
            text(g, cx - tw / 2, yy + th + 0.08, tw, bottom - (yy + th + 0.08),
                 clip(texts[i], tw, bottom - (yy + th + 0.08) - 0.05, xs, 'mn'), size=xs, color=GRAY,
                 align=PP_ALIGN.CENTER)
        ctx.anim(sl, g, 'zoom', 100 + i * 180, 500)
        x += d + gap
    conclusion(ctx, sl, s, 400 + n * 180)
    return sl


# ======================================================================================
# ДЕРЕВО: корень → ветви → листья (структура, состав)
# ======================================================================================
def _leaves(it):
    txt = it.get('text') or ''
    parts = [p.strip(' •-–—') for p in re.split(r'[;\n]|\s•\s', txt) if p.strip(' •-–—')]
    return parts[:4]


def render_tree(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = s['items']
    n = len(items)
    root = s.get('center') or s.get('title') or ''
    root_h = 0.7
    gap = 0.2
    cw = (C.CW - gap * (n - 1)) / n
    g = group(sl)
    rw = min(5.0, C.CW)
    rb = grect(g, (C.L + C.R) / 2 - rw / 2, top, rw, root_h, NAVY, BLUE, 0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    set_av(rb, {'adj': 30000})
    shadow(rb, 12, 3, 22)
    rs = common_size([root], rw - 0.4, root_h - 0.14, 18, 12, 'mj', max_lines=2)
    shape_text(rb, clip(root, rw - 0.4, root_h - 0.14, rs, 'mj', 2), size=rs, color=WHITE, font='mj',
               margins=(0.2, 0.04, 0.2, 0.04))
    # шина и отводы к ветвям
    bus_y = top + root_h + 0.3
    line(g, (C.L + C.R) / 2, top + root_h, (C.L + C.R) / 2, bus_y, color=NAVY, w=1.75, head=False)
    xs_ = [C.L + cw / 2 + i * (cw + gap) for i in range(n)]
    if n > 1:
        line(g, xs_[0], bus_y, xs_[-1], bus_y, color=NAVY, w=1.75, head=False)
    ctx.anim(sl, g, 'fade', 0, 500)
    child_h = 0.62
    cy = bus_y + 0.3
    titles = [_tt(it)[0] or _tt(it)[1] for it in items]
    ts = common_size(titles, cw - 0.35, child_h - 0.12, 15 if n <= 4 else 13, 10, 'mj', max_lines=2)
    leaves = [_leaves(it) if it.get('title') else [] for it in items]
    lh_max = (bottom - (cy + child_h + 0.2)) / 4
    for i, it in enumerate(items):
        c1, c2 = pair(i, n)
        x = xs_[i]
        g = group(sl)
        line(g, x, bus_y, x, cy, color=c1, w=1.75, head=False)
        box = grect(g, x - cw / 2, cy, cw, child_h, c1, c2, 0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
        set_av(box, {'adj': 20000})
        shadow(box, 10, 3, 20)
        d_ = 0.4
        icon(g, it['icon'], 'w', x - cw / 2 + 0.12, cy + (child_h - d_) / 2, d_)
        text(g, x - cw / 2 + 0.6, cy, cw - 0.72, child_h, clip(titles[i], cw - 0.35, child_h - 0.12, ts, 'mj', 2),
             size=ts, color=WHITE, font='mj', anchor=MSO_ANCHOR.MIDDLE)
        lv = leaves[i]
        if lv:
            lh = min(lh_max, max(0.5, (bottom - cy - child_h - 0.25) / len(lv)))
            lsz = common_size(lv, cw - 0.55, lh - 0.12, 13, 9.5, 'mn')
            ly = cy + child_h + 0.22
            for j, leaf in enumerate(lv):
                line(g, x - cw / 2 + 0.25, cy + child_h, x - cw / 2 + 0.25, ly + lh / 2, color=LGRAY, w=1.25, head=False)
                lb = rect(g, x - cw / 2 + 0.25, ly + lh / 2 - 0.005, 0.18, 0.012, fill=LGRAY)
                box2 = rect(g, x - cw / 2 + 0.45, ly + 0.04, cw - 0.45, lh - 0.08, fill=SOFT,
                            shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.15)
                rect(g, x - cw / 2 + 0.45, ly + 0.04, 0.06, lh - 0.08, fill=c1)
                text(g, x - cw / 2 + 0.6, ly + 0.04, cw - 0.75, lh - 0.08, clip(leaf, cw - 0.55, lh - 0.12, lsz, 'mn'),
                     size=lsz, color=GRAY, anchor=MSO_ANCHOR.MIDDLE)
                ly += lh
        ctx.anim(sl, g, 'rise', 300 + i * 170, 450)
    conclusion(ctx, sl, s, 500 + n * 170)
    return sl


# ======================================================================================
# РИСУНОК: картинки из документа (схемы, фото) + тезисы
# ======================================================================================
def _img_size(im):
    """Размер рисунка в условных единицах: (ширина, высота). SVG — по viewBox, картинка — в пикселях."""
    if im.get('svg'):
        from ..svgdraw import aspect
        a = aspect(im['svg'])
        return 1000.0 * a, 1000.0
    from PIL import Image as PILImage
    with PILImage.open(im['path']) as pi:
        return pi.size


def _place(g, im, x, y, w, h, fx=None):
    """Рисунок в прямоугольник: SVG модели — фигурами PowerPoint, картинка — как есть, с эффектом fx
    (effect, tone, сторона осветления) — как «Формат рисунка» в PowerPoint (engine/photofx)."""
    if im.get('svg'):
        from ..svgdraw import SvgError, draw
        try:
            draw(g, im['svg'], x, y, w, h)
        except SvgError:
            pass
        return
    path = str(im['path'])
    if fx:
        from ..photofx import fit_box, toned_path
        x, y, w, h = fit_box(fx[0], x, y, w, h)
        path = toned_path(path, fx[1])
    pic = g.shapes.add_picture(path, I(x), I(y), I(w), I(h))
    name = str(im.get('name') or im.get('caption') or '').strip()
    if name:                                             # замещающий текст: название по содержанию (1.7)
        pic._element.nvPicPr.cNvPr.set('descr', name[:250])
    if fx:
        from ..photofx import apply
        apply(g, pic, fx[0], fx[1], fx[2], (x, y, w, h))
    if im.get('live3d') and (not fx or (fx[0] == 'none' and not fx[1])):
        from ..model3d import register                   # картинка 3D-модели → вращаемая модель при сохранении (1.7)
        register(pic, im)


def render_image(ctx, s):
    from pathlib import Path
    sl, top, bottom = content_slide(ctx, s)
    from ..pictures import resolve                       # библиотека, карта страны, своя картинка → svg / path
    imgs = [im for im in map(resolve, s.get('images') or [])
            if im and (im.get('svg') or (im.get('path') and Path(im['path']).exists()))][:3]
    items = [it for it in (s.get('items') or []) if (it.get('text') or it.get('title'))]
    avail = bottom - top
    if s.get('illustration') and imgs:
        return _render_illustration(ctx, sl, s, imgs[0], items, top, bottom)
    area_w = C.CW * (0.6 if items else 1.0)
    sizes = []
    for im in imgs:
        try:
            sizes.append(_img_size(im))
        except Exception:
            sizes.append(None)
    n = max(1, len(imgs))
    gap = 0.25
    cap_h = 0.45 if any(im.get('caption') for im in imgs) else 0
    # сетка, в которой картинки занимают больше всего места; ряд — по умолчанию, лишний ряд — только если
    # картинки станут заметно крупнее (две широкие на узком месте — одна под другой)
    best = None
    for cols in range(n, 0, -1):
        rows = math.ceil(n / cols)
        cw = (area_w - gap * (cols - 1)) / cols
        ch = (avail - rows * (cap_h + 0.1) - gap * (rows - 1)) / rows
        if cw <= 0.3 or ch <= 0.3:
            continue
        area = sum(min(cw / w, ch / h) ** 2 * w * h for w, h in filter(None, sizes))
        if best is None or area > best[0] * 1.15:
            best = (area, cols, rows, cw, ch)
    _, cols, rows, cell_w, cell_h = best or (0, n, 1, (area_w - gap * (n - 1)) / n, avail - cap_h - 0.1)
    for i, im in enumerate(imgs):
        if not sizes[i]:
            continue
        w_px, h_px = sizes[i]
        r, c = divmod(i, cols)
        in_row = min(cols, n - r * cols)                   # неполный последний ряд — по центру
        x0 = C.L + (area_w - in_row * cell_w - gap * (in_row - 1)) / 2 + c * (cell_w + gap)
        y0 = top + r * (cell_h + cap_h + 0.1 + gap)
        k = min(cell_w / w_px, cell_h / h_px)
        w, h = w_px * k, h_px * k
        x = x0 + (cell_w - w) / 2
        y = y0 + (cell_h - h) / 2
        g = group(sl)
        fx = None
        if not im.get('svg'):                              # эффект фото: выбранный в плане или по снимку (1.7)
            from ..photofx import choose
            fx = choose(s, i, im)
        _place(g, im, x, y, w, h, fx)
        c1, c2 = pair(i, n)
        if im.get('caption'):
            cs = common_size([im['caption']], cell_w - 0.6, cap_h, 13, 9.5, 'mj', max_lines=2)
            bd = rect(g, x0, y0 + cell_h + 0.12, 0.34, 0.34, fill=c1, shape=MSO_SHAPE.OVAL)
            grad(bd, c1, c2, 45)
            shape_text(bd, str(i + 1), size=10, color=WHITE, font='b', margins=(0, 0, 0, 0))
            text(g, x0 + 0.45, y0 + cell_h + 0.08, cell_w - 0.5, cap_h,
                 clip(im['caption'], cell_w - 0.6, cap_h, cs, 'mj', 2), size=cs, color=NAVY, font='mj',
                 anchor=MSO_ANCHOR.MIDDLE)
        ctx.anim(sl, g, 'zoom', 100 + i * 200, 500)
    if items:
        x = C.L + area_w + 0.35
        w = C.R - x
        _legend(ctx, sl, items, x, top, bottom, w, 400 + n * 200, numbers=True)
    conclusion(ctx, sl, s, 600 + n * 200)
    return sl


def _render_illustration(ctx, sl, s, im, items, top, bottom):
    """Иллюстрация справа (без рамки, вписана в область), тезисы слева — крупно.
    Рисунок модели ИИ (SVG) строится обычными фигурами PowerPoint — его можно править."""
    avail = bottom - top
    pic_w = C.CW * 0.46
    w_px, h_px = _img_size(im)
    k = min(pic_w / w_px, avail / h_px)
    w, h = w_px * k, h_px * k
    x = C.R - w
    y = top + (avail - h) / 2
    g = group(sl)
    fx = None
    if not im.get('svg'):                                  # эффект фото: выбранный в плане или по снимку (1.7)
        from ..photofx import choose
        fx = choose(s, 0, im)
    _place(g, im, x, y, w, h, fx)
    ctx.anim(sl, g, 'zoom', 100, 600)
    if items:
        lx = C.L
        lw = x - 0.4 - lx
        n = len(items)
        texts = [(it.get('title') + '. ' if it.get('title') else '') + (it.get('text') or '') for it in items]
        if n == 1:
            gq = group(sl)
            bar = grect(gq, lx, top + 0.2, 0.12, avail - 0.4, GREEN, NAVY, 90)
            sz = common_size(texts, lw - 0.5, avail - 0.6, 30, 15, 'mj')
            text(gq, lx + 0.45, top, lw - 0.5, avail, clip(texts[0], lw - 0.5, avail - 0.6, sz, 'mj'), size=sz, color=NAVY,
                 font='mj', anchor=MSO_ANCHOR.MIDDLE)
            ctx.anim(sl, gq, 'fade', 300, 600)
        else:
            # строки — по высоте текста, кегль — наибольший, при котором все тезисы занимают колонку
            sz, rhs = stack_fit(texts, lw - 0.75, avail, 22 if n <= 3 else 18, 11, 'mn', pad=0.2, gap=0, min_h=0.6)
            yy = top
            for i, t_ in enumerate(texts):
                c1, c2 = pair(i, n)
                gi = group(sl)
                rh = rhs[i]
                if i % 2 == 0:
                    zb = rect(gi, lx, yy + 0.04, lw, rh - 0.08, fill=SOFT, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.1)
                    grad(zb, SOFT, WHITE, 0)
                bd = rect(gi, lx + 0.15, yy + (rh - 0.42) / 2, 0.42, 0.42, fill=c1, shape=MSO_SHAPE.OVAL)
                grad(bd, c1, c2, 45)
                shape_text(bd, str(i + 1), size=12, color=WHITE, font='b', margins=(0, 0, 0, 0))
                text(gi, lx + 0.75, yy, lw - 0.85, rh, clip(t_, lw - 0.75, rh - 0.18, sz, 'mn'), size=sz, color=GRAY,
                     anchor=MSO_ANCHOR.MIDDLE)
                ctx.anim(sl, gi, 'wipe_l', 300 + i * 150, 400)
                yy += rh
    conclusion(ctx, sl, s, 600)
    return sl
