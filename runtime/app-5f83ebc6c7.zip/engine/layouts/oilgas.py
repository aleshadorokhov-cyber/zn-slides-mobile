# -*- coding: utf-8 -*-
"""
oilgas.py — НЕФТЕГАЗОВЫЕ СХЕМЫ: цепочка создания стоимости, скважина по интервалам,
обустройство месторождения
=====================================================================================

value_chain — «Цепочка создания стоимости»: 3–7 этапов слева направо (разведка → бурение → добыча →
              подготовка → транспорт → переработка → сбыт). Над этапом — картинка из библиотеки
              (assets/pictures, нефтегазовые разделы), подобранная по словам этапа (без повторов на слайде);
              картинки соединены «трубопроводом», ниже — шевроны с названиями и карточки с пояснениями.
              Своя картинка этапа — поле picture (код картинки библиотеки).
well        — «Скважина по интервалам»: слева разрез скважины (буровая на поверхности, пласты горных пород,
              обсадные колонны сужаются с глубиной, продуктивный пласт внизу; при словах «горизонтальный»,
              «МГРП», «боковой ствол» — горизонтальный участок), справа 3–6 пунктов на нарастающей глубине,
              от ствола к ним — выноски с номерами. label — глубина, интервал или срок (короткие метки
              ставятся на разрезе слева от ствола, длинные — в карточки).
field       — «Обустройство месторождения»: схема-план (кусты скважин → нефтесборные трубопроводы → ДНС →
              УПН → резервуарный парк → напорный нефтепровод → терминал; дорога, ЛЭП от ГТЭС, факел, вахтовый
              посёлок) и до 6 номеров на объектах (объект подбирается по словам пункта), справа пояснения.

Всё нарисовано стандартными фигурами PowerPoint в фирменной палитре (картинки библиотеки svgdraw тоже
переводит в фигуры). Рисунок и подписи растягиваются на всю рабочую область, кегль подбирается по длине
текстов: короткие — крупнее, длинные — мельче (не меньше 11 пт), сокращение «…» — только в крайнем случае.

oilgas_scheme(title, items) — какая из трёх схем подходит содержанию (или None); oilgas_ok(slide, layout) —
та же проверка для одного макета (варианты слайда, разнообразие схем).
"""
import math
import re

from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches as I
from pptx.util import Pt

from ..nts import config as C
from ..nts.config import LGRAY, SOFT, rgb
from ..nts.effects import alpha_fill, grad, no_shadow, shadow
from ..nts.shapes import circ_icon, freeform, group, icon, line, rect, shape_text, text
from ..textfit import clip, fits, text_height
from ..textutil import short_title
from .base import BLUE, DBLUE, DGREEN, GRAY, GREEN, LGREEN, NAVY, WHITE, common_size, conclusion, content_slide, pair

MIDBLUE = rgb('2E95C4')
STEEL = rgb('7C8A9C')
CEMENT = rgb('C5CDD8')
HOLE = rgb('F7FAFC')
SKY = rgb('DCEAF5')
STRATA = ['E9EEF3', 'DCE4EC', 'E8ECDD', 'D9E2CD', 'E2E8EF', 'D3DDE7', 'E4E9D8']
DASH = rgb('B9C5D2')
SAFE = 0.88     # запас по ширине для надписей в фигурах (если на компьютере нет фирменного шрифта)
OG_CATS = ('Нефть и газ', 'Разведка и добыча', 'Шельф', 'Переработка и сбыт', 'Низкоуглеродное развитие')


def _tt(it):
    return it.get('title') or '', it.get('text') or ''


def _items(s, n_max):
    return [it for it in s.get('items') or [] if isinstance(it, dict)
            and (it.get('title') or it.get('text') or it.get('value'))][:n_max]


def _blob(*parts):
    return ' '.join(str(p or '') for p in parts).lower().replace('ё', 'е')


def _poly(g, pts, color, w=1.5, dash=None, head=False):
    """Ломаная линия по точкам (дюймы) со скруглёнными стыками; head — стрелка на конце."""
    pts = [p for k, p in enumerate(pts) if k == 0 or abs(p[0] - pts[k - 1][0]) + abs(p[1] - pts[k - 1][1]) > 1e-3]
    if len(pts) < 2:
        return None
    if len(pts) == 2:
        return line(g, pts[0][0], pts[0][1], pts[1][0], pts[1][1], color=color, w=w, head=head, dash=dash)
    fb = g.shapes.build_freeform(I(pts[0][0]), I(pts[0][1]), scale=1.0)
    fb.add_line_segments([(I(x), I(y)) for x, y in pts[1:]], close=False)
    shp = fb.convert_to_shape()
    shp.fill.background()
    shp.line.color.rgb = color
    shp.line.width = Pt(w)
    ln = shp.line._get_or_add_ln()
    ln.set('cap', 'rnd')
    from lxml import etree
    if dash:
        etree.SubElement(ln, qn('a:prstDash')).set('val', dash)
    etree.SubElement(ln, qn('a:round'))
    if head:
        t = etree.SubElement(ln, qn('a:tailEnd'))
        t.set('type', 'triangle')
        t.set('w', 'med')
        t.set('len', 'med')
    no_shadow(shp)
    return shp


def _badge(g, cx, cy, d, i, n, size=None, border=2.0):
    """Круглый номер элемента (градиент из палитры, белая обводка)."""
    c1, c2 = pair(i, n)
    b = rect(g, cx - d / 2, cy - d / 2, d, d, fill=c1, shape=MSO_SHAPE.OVAL)
    grad(b, c1, c2, 45)
    b.line.color.rgb = WHITE
    b.line.width = Pt(border)
    shadow(b, 8, 2, 28)
    shape_text(b, str(i + 1), size=size or max(9, min(16, d * 30)), color=WHITE, font='b', margins=(0, 0, 0, 0))
    return b


def _accent(it):
    """Метка элемента для карточки: срок/глубина (label) или число (value + unit)."""
    lab = str(it.get('label') or '').strip()
    if lab:
        return lab
    v = f"{it.get('value') or ''} {it.get('unit') or ''}".strip()
    return v if it.get('value') and str(it.get('value')) not in (it.get('title') or '') else ''


# ======================================================================================
# Колонка карточек справа от рисунка (скважина, месторождение)
# ======================================================================================
def _fit_cards(titles, texts, tw, inner, lh, n):
    """Кегли заголовка и текста карточки: текст — как можно крупнее (без сокращения), заголовок — крупнее текста.
    Возвращает (ts, xs, inline): inline — заголовок и текст одним абзацем (когда карточка совсем низкая)."""
    only_titles = any(titles) and not any(texts)
    tt_w = tw * SAFE                                       # заголовки — с запасом по ширине
    if only_titles:
        return common_size(titles, tt_w, inner - lh, 26 if n <= 3 else (22 if n <= 4 else 19), 12, 'mj', max_lines=3), 0, False
    if not any(titles):
        return 0, common_size(texts, tw, inner - lh, 20 if n <= 3 else (17 if n <= 4 else 15), 11, 'mn'), False
    tmax = 24 if n <= 2 else (21 if n <= 3 else (19 if n <= 4 else 17))
    xmax = 20 if n <= 2 else (18 if n <= 3 else (16.5 if n <= 4 else (15 if n <= 5 else 14)))
    best = None
    ts = tmax
    while ts >= 11.5 - 1e-9:
        t_room = max(0.25, (inner - lh) * 0.5)
        th = max(text_height(clip(t, tt_w, t_room, ts, 'mj', 2), tt_w, ts, 'mj') for t in titles if t)
        room = inner - lh - th - 0.06
        if room > 0.15 and any(texts):
            xs = common_size(texts, tw, room, min(xmax, ts - 1.5), 11, 'mn')
            ok = all(fits(t, tw, room, xs, 'mn') for t in texts if t)
            if ok:
                sc = 2 * xs + ts
                if best is None or sc > best[0]:
                    best = (sc, ts, xs)
        ts -= 0.5
    if best:
        return best[1], best[2], False
    # не помещается и при мелком кегле — заголовок и текст одним абзацем (текст продолжает строку заголовка)
    joined = [f'{t}. {x}' if t and x else (t or x) for t, x in zip(titles, texts)]
    return 0, common_size(joined, tw, inner - lh, 14, 11, 'mn'), True


def _inline(title, body, w, h, size):
    """Заголовок и текст одним абзацем в рамке w×h: сокращается только текст (заголовок остаётся целым)."""
    if not title or not body:
        return title, clip(body, w, h, size, 'mn') if body else ''
    hh = h
    while hh > 0.05:
        cut = clip(body, w, hh, size, 'mn')
        if fits(f'{title}. {cut}', w, h, size, 'mn', strict_words=False):
            return title, cut
        hh -= size / 72 * 1.22
    return clip(title, w, h, size, 'mn'), ''


def _cards_column(ctx, sl, items, x, top, bottom, w, delay=400, labels=None):
    """Карточки на всю высоту области: номер, метка (срок, глубина), заголовок, текст — по центру карточки.
    Кегль общий для всех карточек и подбирается по самому длинному тексту. Возвращает y-центры карточек."""
    n = len(items)
    if not n:
        return []
    gap = 0.12 if n <= 4 else 0.09
    rh = (bottom - top - gap * (n - 1)) / n
    titles = [_tt(it)[0] for it in items]
    texts = [_tt(it)[1] for it in items]
    labels = labels or [''] * n
    bd = min(0.5, max(0.34, rh * 0.36))
    tx = x + 0.2 + bd + 0.2
    tw = x + w - tx - 0.18
    pad = 0.08 if rh < 0.9 else 0.14
    inner = rh - 2 * pad
    ls = common_size(labels, tw, 0.4, 14 if n <= 4 else 12.5, 10.5, 'b', max_lines=1) if any(labels) else 0
    lh = ls / 72 * 1.22 + 0.03 if ls else 0
    ts, xs, inline = _fit_cards(titles, texts, tw, inner, lh, n)
    only_titles = any(titles) and not any(texts)
    t_lines = 3 if only_titles else 2
    t_room = inner - lh if only_titles else max(0.25, (inner - lh) * 0.5)
    tt_w = tw * SAFE
    ths = [text_height(clip(t, tt_w, t_room, ts, 'mj', t_lines), tt_w, ts, 'mj') if t and ts else 0 for t in titles]
    x_room = max(0.2, inner - lh - (max(ths) + 0.06 if any(ths) else 0))
    centers = []
    for i, it in enumerate(items):
        c1, c2 = pair(i, n)
        y = top + i * (rh + gap)
        g = group(sl)
        card = rect(g, x, y, w, rh, fill=SOFT, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=min(0.2, 0.12 / max(rh, 0.3)))
        grad(card, SOFT, WHITE, 0)
        shadow(card, 8, 2, 14)
        bar = rect(g, x, y + 0.06, 0.08, rh - 0.12, fill=c1, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.5)
        grad(bar, c1, c2, 90)
        _badge(g, x + 0.2 + bd / 2, y + rh / 2, bd, i, n, size=min(16, 10 + bd * 10))
        lab = clip(labels[i], tw, 0.4, ls, 'b', 1) if labels[i] else ''
        lc = c1 if c1 != LGREEN else DGREEN
        if inline:
            t_, body = _inline(titles[i], texts[i], tw, inner - lh, xs)
            full = f'{t_}. {body}' if t_ and body else (t_ or body)
            hh = (lh if lab else 0) + text_height(full, tw, xs, 'mn')
            yy = y + max(pad * 0.5, (rh - hh) / 2)
            if lab:
                text(g, tx, yy, tw, lh, lab, size=ls, color=lc, font='b')
                yy += lh
            runs = [(t_ + ('. ' if body else ''), {'font': 'mj', 'color': NAVY})] if t_ else []
            text(g, tx, yy, tw, hh + 0.05, [runs + ([(body, {})] if body else [])], size=xs, color=GRAY)
        else:
            tt = clip(titles[i], tt_w, t_room, ts, 'mj', t_lines) if titles[i] and ts else ''
            bt = clip(texts[i], tw, x_room, xs, 'mn') if texts[i] and xs else ''
            xh = text_height(bt, tw, xs, 'mn') if bt else 0
            hh = (lh if lab else 0) + ths[i] + (0.06 if ths[i] and xh else 0) + xh
            yy = y + max(pad * 0.5, (rh - hh) / 2)
            if lab:
                text(g, tx, yy, tw, lh, lab, size=ls, color=lc, font='b')
                yy += lh
            if tt:
                text(g, tx, yy, tw, ths[i] + 0.04, tt, size=ts, color=NAVY, font='mj')
                yy += ths[i] + 0.06
            if bt:
                text(g, tx, yy, tw, xh + 0.05, bt, size=xs, color=GRAY)
        ctx.anim(sl, g, 'wipe_l', delay + i * 150, 400)
        centers.append(y + rh / 2)
    return centers


def _side_share(items, lo, hi):
    """Доля ширины под рисунок: короткие тексты — рисунок шире (hi), длинные — уже (lo)."""
    vol = [len(_tt(it)[0]) + len(_tt(it)[1]) + len(str(it.get('label') or '')) for it in items] or [0]
    avg = sum(vol) / len(vol) * (0.8 + 0.05 * len(vol))
    f = max(0.0, min(1.0, (avg - 40) / 110))
    return hi - (hi - lo) * f


# ======================================================================================
# Подбор картинок к этапам цепочки
# ======================================================================================
# этапы цепочки: ключ, основы слов, картинка этапа «по умолчанию»
STAGES = [
    ('explore', r'разведк|геолог|сейсм|поиск|лиценз|геофиз|запас', 'seismic'),
    ('drill', r'бурени|буров|строительств\w* скважин|скважин|заканчиван', 'drilling_rig'),
    ('produce', r'добыч|разработк|эксплуатац|промысл|нефтеотдач', 'pump_jack'),
    ('treat', r'подготовк|сепарац|обезвож|обессол|\bупн\b|\bцпс\b|упсв', 'oil_treatment'),
    ('transport', r'транспорт|трубопровод|нефтепровод|газопровод|прокачк|логист|перевоз', 'pipeline'),
    ('store', r'хранени|резервуар|терминал|перевалк|отгрузк|налив', 'tank_farm'),
    ('refine', r'переработ|нпз|нефтехим|газохим|\bгпз\b|крекинг|нефтепродукт', 'refinery'),
    ('sell', r'сбыт|реализац|продаж|\bазс\b|розниц|экспорт|маркетинг|трейдинг|потребител|клиент|рын', 'fuel_station'),
]
STAGE_PIC = {k: p for k, _, p in STAGES}
# запасные картинки по порядку цепочки (если по словам ничего не нашлось)
CHAIN_DEFAULT = ['seismic', 'drilling_rig', 'pump_jack', 'oil_treatment', 'pipeline', 'refinery', 'fuel_station',
                 'tank_farm', 'oil_terminal', 'well_pad', 'gas_processing', 'tanker', 'offshore_platform', 'oil_barrels',
                 'oil_drop', 'reservoir_section']


def _stage(t):
    """Этап цепочки по тексту: тот, чьё слово встречается раньше всех (или None)."""
    t = _blob(t)
    best = None
    for k, rx, _ in STAGES:
        m = re.search(rx, t)
        if m and (best is None or m.start() < best[0]):
            best = (m.start(), k)
    return best[1] if best else None


def pick_pictures(items):
    """Коды картинок библиотеки для этапов: своя (поле picture) → по словам этапа (заголовок важнее текста)
    среди нефтегазовых разделов → запасная по месту этапа в цепочке. Картинки на слайде не повторяются."""
    from .. import pictures as P
    try:
        cat = [e for e in P.catalog() if e['cat'] in OG_CATS]
    except Exception:                                        # noqa: BLE001
        cat = []
    ids = {e['id'] for e in cat}
    n = len(items)
    out, used = [None] * n, set()
    for i, it in enumerate(items):
        pid = str(it.get('picture') or '')
        if pid and pid not in used and P.get(pid):
            out[i] = pid
            used.add(pid)
    cand = []
    for i, it in enumerate(items):
        if out[i]:
            continue
        title, body = it.get('title') or '', it.get('text') or ''
        tt, bt = P._tokens(title), P._tokens(body)
        st_t, st_b = _stage(title), _stage(body)
        for e in cat:
            th = P._hits(e['tags'], tt)
            sc = 3 * len(th) + len(P._hits(e['tags'], bt) - th)
            if st_t and STAGE_PIC.get(st_t) == e['id']:
                sc += 2.9                                 # этап по названию — чуть слабее прямого совпадения
            elif not st_t and st_b and STAGE_PIC.get(st_b) == e['id']:
                sc += 1.5
            if e['id'].startswith('fe_'):
                sc *= 0.4                                    # пиктограммы — после сюжетных картинок
            if sc:
                cand.append((sc, i, e['id']))
    for sc, i, pid in sorted(cand, key=lambda c: (-c[0], c[1])):
        if out[i] is None and pid not in used:
            out[i] = pid
            used.add(pid)
    base = CHAIN_DEFAULT[:7]
    for i in range(n):
        if out[i] is None:
            k = round(i * (len(base) - 1) / (n - 1)) if n > 1 else 2
            order = [base[k]] + CHAIN_DEFAULT + sorted(ids)
            out[i] = next((p for p in order if p in ids and p not in used), None)
            if out[i]:
                used.add(out[i])
    return out


# ======================================================================================
# ЦЕПОЧКА СОЗДАНИЯ СТОИМОСТИ
# ======================================================================================
PREP = {'на', 'в', 'во', 'с', 'со', 'к', 'ко', 'по', 'для', 'из', 'от', 'до', 'за', 'и', 'или', 'при', 'под', 'над',
        'о', 'об', 'а', 'но', 'через', 'между'}


def _head(t, max_words=4, max_chars=34):
    """Короткое название этапа из начала фразы — без «висящего» предлога в конце."""
    ws = short_title(t, max_words, max_chars).split()
    while len(ws) > 1 and (len(ws[-1]) <= 2 or ws[-1].lower() in PREP):
        ws.pop()
    return ' '.join(ws)


def render_value_chain(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = _items(s, 7)
    n = len(items)
    if not n:
        conclusion(ctx, sl, s, 300)
        return sl
    H = bottom - top
    accents = [_accent(it) for it in items]
    raw = [_tt(it) for it in items]
    no_titles = not any(t for t, _ in raw)
    titles, texts = [], []
    for i, (ti, tx) in enumerate(raw):                    # нет заголовка — в шеврон начало фразы
        if not ti and tx and not no_titles:
            ti, tx = (tx, '') if len(tx) <= 40 else (_head(tx), tx)
        titles.append(ti or ('' if no_titles and tx else (accents[i] or f'Этап {i + 1}')))
        texts.append(tx)
    has_text = any(texts)
    # в шевронах — номера, если у пунктов нет заголовков (тогда в карточках полный текст)
    # или нет пояснений (тогда в карточках крупно названия этапов)
    head_numbers = no_titles or not has_text
    depth = 0.2 if n >= 6 else 0.26
    gap = 0.05
    chw = (C.CW + (n - 1) * (depth - gap)) / n
    xs_ = [C.L + i * (chw - depth + gap) for i in range(n)]
    col_x = [x + (0 if i == 0 else depth) + 0.02 for i, x in enumerate(xs_)]
    col_w = chw - depth - 0.06
    cxs = [cx + col_w / 2 for cx in col_x]
    tw_head = chw - 2 * depth - 0.12
    tw = col_w - 0.3
    d_w = min(col_w * 0.92, 2.6)                          # круг картинки — не шире колонки
    ts, t_lines = 12, 2
    if not head_numbers:                                  # шеврон: высота по длине названий (2 строки, при длинных — 3)
        tmax = 17 if n <= 3 else (15.5 if n <= 5 else 13.5)
        for hh, ml in ((0.62 if n >= 5 else 0.7, 2), (0.8, 2), (0.98, 3)):
            chh, t_lines = hh, ml
            ts = common_size(titles, tw_head * SAFE, chh - 0.12, tmax, 10.5, 'mj', max_lines=ml)
            if ts >= 12:
                break
    else:
        chh = 0.56 if n >= 5 else 0.62
    xmax = 18 if n <= 3 else (16 if n == 4 else (14.5 if n == 5 else 13.5))
    lh_ = 0
    xs = 0

    def need_h(size, room):
        """Высота самого длинного текста карточки (с меткой) при кегле size."""
        lh = (size + 1) / 72 * 1.25 + 0.04 if any(accents) else 0
        if has_text:
            hs = [text_height(clip(t, tw, max(0.3, room - lh), size, 'mn'), tw, size, 'mn') if t else 0 for t in texts]
        else:
            hs = [text_height(clip(t, tw * SAFE, max(0.3, room - lh), size, 'mj', 3), tw * SAFE, size, 'mj') for t in titles]
        return lh, max(hs) + lh

    PADS = 0.17 + 0.12                                    # поля карточки сверху и снизу
    fixed = chh + 0.14 + 0.08                             # шеврон и зазоры
    if has_text:
        room = H - fixed - (min(d_w, H * 0.42) + 0.06) - PADS
        xs = common_size(texts, tw, max(0.3, room - (xmax + 1) / 72 * 1.3), xmax, 11, 'mn')
        if not all(fits(t, tw, max(0.3, room - (xs + 1) / 72 * 1.3), xs, 'mn') for t in texts if t):
            room = H - fixed - (min(d_w, max(0.9, H * 0.24)) + 0.06) - PADS   # длинные тексты — картинки меньше
            xs = common_size(texts, tw, max(0.3, room - (xmax + 1) / 72 * 1.3), xmax, 11, 'mn')
        lh_, need = need_h(xs, room)
        card_h = max(need + PADS, min(1.0, H * 0.22))
        if H - fixed - card_h - d_w > 0.35:               # картинка упёрлась в ширину колонки — текст крупнее
            room = H - fixed - d_w - 0.06 - PADS
            xs = common_size(texts, tw, max(0.3, room - (xmax + 4) / 72 * 1.3), xmax + 3, 11, 'mn')
            lh_, need = need_h(xs, room)
            card_h = max(need + PADS, min(1.0, H * 0.22))
    else:
        room = H - fixed - min(d_w, H * 0.5) - PADS
        xs = common_size(titles, tw * SAFE, max(0.3, room), 28 if n <= 4 else (24 if n <= 5 else 20), 12, 'mj',
                         max_lines=3)
        lh_, need = need_h(xs, room)
        card_h = max(need + PADS, H - fixed - d_w - 0.06)
    zone = H - fixed - card_h
    left = zone - min(d_w, zone)
    if left > 0.3:                                        # остаток — поровну карточке и воздуху вокруг картинок
        card_h += left * 0.5
        zone = H - fixed - card_h
    d = max(0.6, min(d_w, zone - 0.04))
    cy = top + zone / 2
    ch_y = top + zone + 0.08
    card_y = ch_y + chh + 0.14
    # «трубопровод» за картинками: от первой к последней, с фланцами и стрелками потока
    gp = group(sl)
    pb = max(0.12, min(0.2, d * 0.12))
    end_x = min(C.R - pb * 1.6, cxs[-1] + d * 0.62)
    pipe = rect(gp, cxs[0], cy - pb / 2, max(0.1, end_x - cxs[0]), pb, fill=NAVY)
    grad(pipe, NAVY, GREEN, 0)
    shadow(pipe, 6, 2, 18)
    hl = rect(gp, cxs[0], cy - pb / 2 + pb * 0.18, max(0.1, end_x - cxs[0]), pb * 0.16, fill=WHITE)
    alpha_fill(hl, 'FFFFFF', 35)
    freeform(gp, [(end_x, cy - pb * 1.3), (end_x + pb * 1.6, cy), (end_x, cy + pb * 1.3)], fill=GREEN)
    for i in range(n - 1):
        mx = (cxs[i] + cxs[i + 1]) / 2
        fl = rect(gp, mx - 0.035, cy - pb * 0.9, 0.07, pb * 1.8, fill=DBLUE, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.3)
        grad(fl, DBLUE, NAVY, 90)
        free = cxs[i + 1] - cxs[i] - d * 1.08
        if free > 0.45:
            for side in (-1, 1):
                ax = mx + side * free / 4
                ar = rect(gp, ax - pb * 0.25, cy - pb * 0.32, pb * 0.5, pb * 0.64, fill=WHITE, shape=MSO_SHAPE.CHEVRON)
                alpha_fill(ar, 'FFFFFF', 80)
    ctx.anim(sl, gp, 'wipe_l', 0, 900)
    pics = pick_pictures(items)
    from .. import pictures as P
    from ..svgdraw import draw
    for i, it in enumerate(items):
        c1, c2 = pair(i, n)
        lc = c1 if c1 != LGREEN else DGREEN
        g = group(sl)
        cx = cxs[i]
        ring = rect(g, cx - d * 0.54, cy - d * 0.54, d * 1.08, d * 1.08, fill=WHITE, shape=MSO_SHAPE.OVAL)
        shadow(ring, 12, 3, 22)
        drawn = False
        if pics[i]:
            hb = d / 0.85
            try:
                draw(g, P.svg(pics[i]), cx - hb * 2 / 3, cy - hb / 2, hb * 4 / 3, hb)
                drawn = True
            except Exception:                            # noqa: BLE001  (нет файла, испорченный SVG)
                drawn = False
        if not drawn:
            ci = circ_icon(g, it.get('icon') or 'TbDroplet', cx - d / 2, cy - d / 2, d, fill=c1, fill2=c2, ratio=0.5)
            shadow(ci, 8, 2, 20)
        bd = max(0.34, min(0.5, d * 0.24))
        if not head_numbers:
            _badge(g, cx - d * 0.36, cy + d * 0.36, bd, i, n, size=min(16, 9 + bd * 12))
        # шеврон: название этапа (или номер, если пояснений нет)
        x = xs_[i]
        shp = rect(g, x, ch_y, chw, chh, fill=c1, shape=MSO_SHAPE.PENTAGON if i == 0 else MSO_SHAPE.CHEVRON)
        grad(shp, c1, c2, 0)
        shp.adjustments[0] = depth / chh
        shadow(shp, 8, 2, 20)
        hx = x + (0.14 if i == 0 else depth + 0.06)
        hw_ = tw_head + (depth - 0.08 if i == 0 else 0)
        if not head_numbers:
            text(g, hx, ch_y, hw_, chh, clip(titles[i], tw_head * SAFE, chh - 0.12, ts, 'mj', t_lines), size=ts,
                 color=WHITE, font='mj', align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        else:
            text(g, hx, ch_y, hw_, chh, f'{i + 1:02d}', size=min(20, chh * 30), color=LGREEN if i < n - 1 else WHITE,
                 font='b', align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        # карточка: метка и пояснение (или крупное название этапа)
        body = rect(g, col_x[i], card_y, col_w, bottom - card_y, fill=SOFT)
        grad(body, SOFT, WHITE, 90)
        shadow(body, 10, 2, 14)
        stripe = rect(g, col_x[i], card_y, col_w, 0.06, fill=c1)
        grad(stripe, c1, c2, 0)
        yy = card_y + 0.17
        avail = bottom - card_y - PADS
        if has_text:
            if accents[i]:
                text(g, col_x[i] + 0.15, yy, tw, lh_, clip(accents[i], tw, 0.4, xs + 1, 'b', 1), size=xs + 1, color=lc,
                     font='b')
            if any(accents):
                yy += lh_
            if texts[i]:
                bt = clip(texts[i], tw, max(0.25, avail - lh_), xs, 'mn')
                text(g, col_x[i] + 0.15, yy, tw, max(0.25, bottom - yy - 0.1), bt, size=xs, color=GRAY)
        else:
            acc = accents[i] if accents[i] != titles[i] else ''
            tt = clip(titles[i], tw * SAFE, max(0.3, avail - lh_), xs, 'mj', 3)
            hh = text_height(tt, tw * SAFE, xs, 'mj') + (lh_ if acc else 0)
            yy = card_y + 0.06 + max(0.08, (bottom - card_y - 0.06 - hh) / 2)
            if acc:
                text(g, col_x[i] + 0.15, yy, tw, lh_, clip(acc, tw, 0.4, 13, 'b', 1), size=13, color=lc, font='b',
                     align=PP_ALIGN.CENTER)
                yy += lh_
            text(g, col_x[i] + 0.15, yy, tw, hh + 0.05, tt, size=xs, color=NAVY, font='mj', align=PP_ALIGN.CENTER)
        ctx.anim(sl, g, 'rise', 250 + i * 180, 450)
    conclusion(ctx, sl, s, 500 + n * 180)
    return sl


# ======================================================================================
# СКВАЖИНА ПО ИНТЕРВАЛАМ
# ======================================================================================
HORIZ_RX = re.compile(r'горизонтальн|\bгс\b|мгрп|многостад|боков\w* ствол|\bзбс\b|\bгрп\b')


def _wave(x0, w, y, amp, phase, n=26, hump=None):
    """Граница пласта: синусоида (amp, phase); hump = (x_center, height, width) — свод антиклинали."""
    pts = []
    for k in range(n + 1):
        x = x0 + w * k / n
        yy = y + amp * math.sin(2 * math.pi * k / n * 1.35 + phase)
        if hump:
            yy -= hump[1] * math.exp(-((x - hump[0]) / hump[2]) ** 2)
        pts.append((x, yy))
    return pts


def _rig(g, wx, ground, h):
    """Буровая вышка на поверхности: основание, мачта с раскосами, кронблок, культбудка, приёмный мост."""
    bw = h * 0.62
    sub_h = h * 0.16
    top_y = ground - h
    sub = rect(g, wx - bw / 2, ground - sub_h, bw, sub_h, fill=NAVY)
    grad(sub, DBLUE, NAVY, 90)
    for k in range(3):                                     # раскосы основания
        x1 = wx - bw / 2 + bw * k / 3
        line(g, x1 + 0.03, ground - sub_h + 0.03, x1 + bw / 3 - 0.03, ground - 0.03, color=MIDBLUE, w=0.75, head=False)
        line(g, x1 + 0.03, ground - 0.03, x1 + bw / 3 - 0.03, ground - sub_h + 0.03, color=MIDBLUE, w=0.75, head=False)
    yb, yt = ground - sub_h, top_y + h * 0.07
    xl0, xl1 = wx - bw * 0.34, wx - bw * 0.07
    xr0, xr1 = wx + bw * 0.34, wx + bw * 0.07
    m = 5
    for k in range(m):                                     # раскосы мачты
        f0, f1 = k / m, (k + 1) / m
        ya, yb2 = yb + (yt - yb) * f0, yb + (yt - yb) * f1
        la, lb = xl0 + (xl1 - xl0) * f0, xl0 + (xl1 - xl0) * f1
        ra, rb = xr0 + (xr1 - xr0) * f0, xr0 + (xr1 - xr0) * f1
        line(g, la, ya, rb, yb2, color=BLUE, w=0.75, head=False)
        line(g, ra, ya, lb, yb2, color=BLUE, w=0.75, head=False)
        line(g, lb, yb2, rb, yb2, color=BLUE, w=0.75, head=False)
    line(g, xl0, yb, xl1, yt, color=NAVY, w=2.25, head=False)
    line(g, xr0, yb, xr1, yt, color=NAVY, w=2.25, head=False)
    crown = rect(g, wx - bw * 0.13, top_y, bw * 0.26, h * 0.075, fill=NAVY)
    grad(crown, BLUE, NAVY, 90)
    line(g, wx, top_y + h * 0.075, wx, top_y + h * 0.42, color=GRAY, w=0.75, head=False)
    blk = rect(g, wx - bw * 0.05, top_y + h * 0.42, bw * 0.1, h * 0.09, fill=DGREEN, shape=MSO_SHAPE.ROUNDED_RECTANGLE,
               adj=0.3)
    grad(blk, GREEN, DGREEN, 90)
    dog_w, dog_h = bw * 0.5, h * 0.2                        # культбудка
    dog = rect(g, wx - bw / 2 - dog_w - 0.04, ground - dog_h, dog_w, dog_h, fill=BLUE)
    grad(dog, MIDBLUE, DBLUE, 90)
    for k in range(2):
        rect(g, wx - bw / 2 - dog_w + 0.02 + k * dog_w * 0.42, ground - dog_h * 0.72, dog_w * 0.26, dog_h * 0.3,
             fill=WHITE)
    pr_w, pr_h = bw * 0.75, h * 0.1                         # приёмный мост и трубы
    pr = rect(g, wx + bw / 2 + 0.04, ground - pr_h, pr_w, pr_h, fill=LGRAY)
    grad(pr, LGRAY, STEEL, 90)
    for k in range(3):
        line(g, wx + bw / 2 + 0.08, ground - pr_h - 0.025 - k * 0.035, wx + bw / 2 + 0.04 + pr_w * 0.92,
             ground - pr_h - 0.025 - k * 0.035, color=DGREEN, w=1.25, head=False)


def _draw_well(ctx, sl, x0, top, w, bottom, n, horizontal, frac, delay=0):
    """Разрез скважины в прямоугольнике (x0, top, w, bottom). Возвращает (точки уровней [(x, y)] для номеров,
    x оси скважины, левая граница ствола)."""
    H = bottom - top
    ground = top + max(0.85, min(1.45, H * 0.24))
    res_bot = bottom - max(0.1, H * 0.03)
    res_h = max(0.42, min(0.75, H * 0.13))
    res_top = res_bot - res_h
    res_mid = (res_top + res_bot) / 2
    wx = x0 + w * (0.46 if horizontal else 0.5)
    hump = (wx, min(0.14, res_h * 0.28), w * 0.42)
    # уровни пунктов: n-1 — в интервалах над пластом (середины полос), последний — в продуктивном пласте
    m = max(1, n - 1)
    bounds = [ground + (res_top - ground) * j / m for j in range(m + 1)]
    levels = [(bounds[j] + bounds[j + 1]) / 2 for j in range(m)][:n - 1] + [res_mid]
    if n == 1:
        levels = [res_mid]
    # ---- небо и поверхность
    gs = group(sl)
    sky = rect(gs, x0, top, w, ground - top, fill=WHITE)
    grad(sky, WHITE, SKY, 90)
    for cxf, cyf, cw_ in ((0.14, 0.3, 0.55), (0.82, 0.22, 0.45)):
        cl = rect(gs, x0 + w * cxf, top + (ground - top) * cyf, cw_, cw_ * 0.32, fill=WHITE, shape=MSO_SHAPE.OVAL)
        alpha_fill(cl, 'FFFFFF', 90)
        cl2 = rect(gs, x0 + w * cxf + cw_ * 0.25, top + (ground - top) * cyf - cw_ * 0.12, cw_ * 0.5, cw_ * 0.34,
                   fill=WHITE, shape=MSO_SHAPE.OVAL)
        alpha_fill(cl2, 'FFFFFF', 90)
    for k, (amp, col) in enumerate(((0.32, 'DCE8D2'), (0.2, 'CFE1BE'))):    # холмы на горизонте
        hill = [(x0 + w * j / 24, ground - 0.02 - amp * (0.55 + 0.45 * math.sin(j / 24 * math.pi * (2.2 + k) + k * 1.3)))
                for j in range(25)]
        freeform(gs, [(x0, ground)] + hill + [(x0 + w, ground)], fill=rgb(col))
    # ---- пласты горных пород (волнистые границы), продуктивный пласт — свод антиклинали
    nb = max(m, 4)
    sb = [ground + (res_top - ground) * j / nb for j in range(nb + 1)]
    for j in range(nb):
        y1, y2 = sb[j], sb[j + 1] if j < nb - 1 else bottom
        upper = _wave(x0, w, y1, 0 if j == 0 else 0.035, j * 1.7)
        lower = _wave(x0, w, y2, 0.035, (j + 1) * 1.7) if j < nb - 1 else [(x0 + w, bottom), (x0, bottom)][::-1]
        col = rgb(STRATA[j % len(STRATA)])
        band = freeform(gs, upper + lower[::-1], fill=col)
        grad(band, col, rgb(STRATA[(j + 3) % len(STRATA)]), 90)
        # штрихи породы
        seed = 7 + j * 13
        yy1, yy2 = y1 + 0.08, (y2 if j < nb - 1 else res_top) - 0.08
        if yy2 - yy1 > 0.12:
            for k in range(9):
                seed = (seed * 1103515245 + 12345) % 2147483648
                fx = (seed % 1000) / 1000
                seed = (seed * 1103515245 + 12345) % 2147483648
                fy = (seed % 1000) / 1000
                px = x0 + 0.12 + fx * (w - 0.5)
                if abs(px - wx) < 0.55 or abs(px + 0.18 - wx) < 0.55:
                    continue
                py = yy1 + fy * (yy2 - yy1)
                if j % 2:
                    rect(gs, px, py, 0.045, 0.045, fill=DASH, shape=MSO_SHAPE.OVAL)
                    rect(gs, px + 0.11, py + 0.03, 0.035, 0.035, fill=DASH, shape=MSO_SHAPE.OVAL)
                else:
                    line(gs, px, py, px + 0.2, py, color=DASH, w=1.0, head=False)
    res_up = _wave(x0, w, res_top, 0.02, 0.6, hump=hump)
    res_lo = _wave(x0, w, res_bot, 0.02, 1.4, hump=(hump[0], hump[1] * 0.6, hump[2]))
    res = freeform(gs, res_up + res_lo[::-1], fill=NAVY)
    grad(res, DBLUE, NAVY, 90)
    seed = 99
    for k in range(26):                                    # «нефтенасыщенный песчаник» — точки
        seed = (seed * 1103515245 + 12345) % 2147483648
        fx = (seed % 1000) / 1000
        seed = (seed * 1103515245 + 12345) % 2147483648
        fy = (seed % 1000) / 1000
        px = x0 + 0.1 + fx * (w - 0.25)
        py = res_top + res_h * (0.25 + 0.55 * fy) - hump[1] * math.exp(-((px - wx) / hump[2]) ** 2) * 0.8
        dt = rect(gs, px, py, 0.05, 0.05, fill=LGREEN, shape=MSO_SHAPE.OVAL)
        alpha_fill(dt, '9AC854', 55)
    base = freeform(gs, res_lo + [(x0 + w, bottom), (x0, bottom)], fill=rgb('D3DBE4'))
    grad(base, rgb('D9E0E8'), rgb('C8D1DC'), 90)
    grass = rect(gs, x0, ground - 0.035, w, 0.07, fill=GREEN)
    grad(grass, LGREEN, DGREEN, 90)
    ctx.anim(sl, gs, 'fade', delay, 600)
    # ---- обсадные колонны: шире у поверхности, уже с глубиной; цвет колонны — цвет пункта
    gw = group(sl)
    hw0 = max(0.22, min(0.36, w * 0.072))
    hwmin = 0.09
    cem = 0.055
    hws = [hw0 - (hw0 - hwmin) * k / max(1, n - 1) for k in range(n)]
    kop = None
    if horizontal and n >= 2:
        rb = max(0.3, min(0.85, (res_mid - levels[-2]) * 0.85, w * 0.2))
        kop = res_mid - rb
    x_end = x0 + w - 0.55
    for k in range(n):
        c1, c2 = pair(k, n)
        last = k == n - 1
        y_shoe = levels[k] if not last else (kop if kop else res_bot - 0.06)
        hw = hws[k]
        y0 = ground - (0.06 if k == 0 else 0)
        rect(gw, wx - hw - cem, y0, 2 * (hw + cem), y_shoe - y0, fill=CEMENT)
        rect(gw, wx - hw, y0, 2 * hw, y_shoe - y0, fill=HOLE)
        for side in (-1, 1):
            xw = wx + side * hw - (0.055 if side > 0 else 0)
            wall = rect(gw, xw, y0, 0.055, y_shoe - y0, fill=c1)
            grad(wall, c1, c2, 0)
            if not (last and kop):                        # башмак колонны
                xo = wx + side * (hw + cem)
                freeform(gw, [(xo, y_shoe), (wx + side * hw, y_shoe), (wx + side * hw, y_shoe - 0.12)], fill=c1)
    if kop:                                                # горизонтальный участок: изгиб и хвостовик
        c1, c2 = pair(n - 1, n)
        hw = hws[-1]
        rb = res_mid - kop
        cl = [(wx + rb - rb * math.cos(math.radians(a)), kop + rb * math.sin(math.radians(a))) for a in range(0, 91, 6)]
        cl.append((x_end, res_mid))
        upper, lower = [], []
        for k_, (px, py) in enumerate(cl):
            if k_ < len(cl) - 1:
                a = math.radians(min(90, k_ * 6))
                nx, ny = math.cos(a), -math.sin(a)          # нормаль к оси: наружу (вправо-вверх)
            else:
                nx, ny = 0, -1
            upper.append((px + nx * hw, py + ny * hw))
            lower.append((px - nx * hw, py - ny * hw))
        liner = freeform(gw, lower + upper[::-1], fill=HOLE, line_=c1, lw=3)
        no_shadow(liner)
        hx0 = wx + rb + 0.25
        cnt = max(3, int((x_end - hx0) / 0.32))
        for k_ in range(cnt):                              # перфорация / трещины ГРП
            px = hx0 + (x_end - 0.15 - hx0) * k_ / max(1, cnt - 1)
            if frac:
                fr = rect(gw, px - 0.07, res_mid - res_h * 0.42, 0.14, res_h * 0.84, fill=LGREEN, shape=MSO_SHAPE.OVAL)
                alpha_fill(fr, '9AC854', 70)
            line(gw, px, res_mid - hw - 0.1, px, res_mid - hw, color=LGREEN, w=1.75, head=False)
            line(gw, px, res_mid + hw + 0.1, px, res_mid + hw, color=LGREEN, w=1.75, head=False)
        line(gw, x_end, res_mid - hw, x_end, res_mid + hw, color=c1, w=3, head=False)
    else:                                                  # вертикальный ствол: приток из пласта
        hw = hws[-1]
        for k_ in range(3):
            py = res_top + res_h * (0.28 + 0.24 * k_)
            for side in (-1, 1):
                line(gw, wx + side * (hw + 0.42), py, wx + side * (hw + 0.06), py, color=LGREEN, w=2.0, head=True)
    line(gw, wx, ground - 0.02, wx, (kop or res_top) - 0.05, color=STEEL, w=1.0, head=False)   # НКТ
    ctx.anim(sl, gw, 'wipe_b', delay + 300, 900)
    # ---- буровая на поверхности
    gr = group(sl)
    _rig(gr, wx, ground - 0.035, min(1.9, ground - top - 0.08))
    ctx.anim(sl, gr, 'rise', delay + 150, 500)
    pts = [(wx + hws[k], levels[k]) for k in range(n)]
    if kop:
        pts[-1] = (x_end, res_mid)
    return pts, wx, hws[0] + cem, levels


def render_well(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = _items(s, 6)
    n = len(items)
    if not n:
        conclusion(ctx, sl, s, 300)
        return sl
    blob = _blob(s.get('title'), s.get('subtitle'), *[_tt(it)[0] + ' ' + _tt(it)[1] for it in items])
    horizontal = bool(s.get('horizontal')) or bool(HORIZ_RX.search(blob))
    frac = bool(re.search(r'грп|гидроразрыв', blob))
    labels = [str(it.get('label') or '').strip() for it in items]
    DW = C.CW * _side_share(items, 0.35, 0.47)
    x0 = C.L
    pts, wx, half, levels = _draw_well(ctx, sl, x0, top, DW, bottom, n, horizontal, frac)
    # метки глубины (label) — слева от ствола, если короткие; иначе — в карточках
    tag_r = wx - half - 0.14
    tag_w = tag_r - (x0 + 0.06)
    on_drawing = False
    if any(labels) and tag_w > 0.9:
        lsz = common_size(labels, tag_w - 0.18, 0.5, 12.5, 10, 'b', max_lines=2)
        on_drawing = lsz >= 10.5 and all(fits(lb, tag_w - 0.18, 0.5, lsz, 'b', max_lines=2) for lb in labels if lb)
        if on_drawing:
            for k, lb in enumerate(labels):
                if not lb:
                    continue
                c1, _ = pair(k, n)
                gt = group(sl)
                ww = min(tag_w, max(0.7, _tw(lb, lsz) * 1.18 + 0.3))
                hh = text_height(lb, tag_w - 0.18, lsz, 'b') + 0.1
                y = levels[k] - hh / 2
                line(gt, tag_r, levels[k], wx - half + 0.02, levels[k], color=c1 if c1 != LGREEN else DGREEN, w=1.0,
                     head=False, dash='sysDot')
                tg = rect(gt, tag_r - ww, y, ww, hh, fill=WHITE, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.3)
                tg.line.color.rgb = c1 if c1 != LGREEN else DGREEN
                tg.line.width = Pt(1.25)
                shadow(tg, 6, 1, 18)
                shape_text(tg, lb, size=lsz, color=c1 if c1 != LGREEN else DGREEN, font='b', margins=(0.08, 0.02, 0.08, 0.02))
                ctx.anim(sl, gt, 'fade', 900 + k * 150, 300)
    # карточки справа и выноски от ствола
    cx_ = x0 + DW + 0.5
    card_labels = [_accent(dict(it, label='')) if on_drawing else _accent(it) for it in items]   # метки на разрезе не дублируем
    centers = _cards_column(ctx, sl, items, cx_, top, bottom, C.R - cx_, 600, labels=card_labels)
    d = 0.36 if n >= 5 else 0.4
    col_x = wx + half + 0.16 + d / 2
    for k, ((px, py), cy) in enumerate(zip(pts, centers)):
        c1, _ = pair(k, n)
        gl = group(sl)
        mx = col_x if not (horizontal and k == n - 1 and n >= 2) else px + 0.1 + d / 2
        lc = c1 if c1 != LGREEN else DGREEN
        line(gl, px, py, mx - d / 2, py, color=lc, w=1.25, head=False)
        _poly(gl, [(mx + d / 2, py), (x0 + DW + 0.1, py), (cx_ - 0.16, cy), (cx_ - 0.02, cy)], lc, w=1.25, dash='sysDot')
        dot = rect(gl, cx_ - 0.07, cy - 0.05, 0.1, 0.1, fill=lc, shape=MSO_SHAPE.OVAL)
        no_shadow(dot)
        _badge(gl, mx, py, d, k, n, size=12 if d >= 0.4 else 11)
        ctx.anim(sl, gl, 'zoom', 700 + k * 150, 350)
    conclusion(ctx, sl, s, 800 + n * 150)
    return sl


def _tw(t, size):
    from ..textfit import text_width
    return max(text_width(x, size, 'b') for x in str(t).split('\n')) / 0.95


# ======================================================================================
# ОБУСТРОЙСТВО МЕСТОРОЖДЕНИЯ
# ======================================================================================
# объекты схемы: ключ, основы слов (по ним пункт «садится» на объект)
FIELD_KEYS = [
    ('terminal', r'терминал|причал|танкер|налив|\bпорт|отгрузк'),
    ('export', r'напорн|магистрал|внешн\w* транспорт|экспорт|сдач|\bпсп|сикн|нефтепровод|газопровод'),
    ('tanks', r'резервуар|\bрвс|товарн\w* парк|хранени'),
    ('upn', r'\bупн|упсв|\bцпс|подготовк|сепарац|обезвож|обессол|установк\w* подготов'),
    ('dns', r'\bднс|дожимн|\bкнс|бкнс|\bппд|закачк|нагнетат|заводнен|водовод|насосн'),
    ('flowlines', r'нефтесбор|выкидн|сборн\w* (?:сет|трубопр|коллект)|промыслов\w* трубопровод|трубопровод|коллектор'),
    ('power', r'\bлэп|электр|энерг|подстанц|гтэс|гпэс|генерац|\bпс\b|кабел'),
    ('flare', r'факел|\bпнг|попутн|газ'),
    ('road', r'дорог|мост|проезд|подъезд'),
    ('camp', r'вахт|посел|жил|общежит|\bбаз[аыу]\b|персонал|офис'),
    ('pads', r'куст|скважин|бурени|площадк|устьев|устье'),
]
FIELD_DEFAULT = ['pads', 'upn', 'tanks', 'export', 'power', 'road', 'dns', 'flowlines', 'flare', 'camp', 'terminal']


def field_slots(items):
    """Объект схемы для каждого пункта: по самому раннему слову в заголовке (затем в тексте), без повторов;
    пункт без совпадений — на свободный объект по порядку FIELD_DEFAULT."""
    used, out = set(), []
    for it in items:
        key = None
        for part in (it.get('title'), it.get('text')):
            t = _blob(part)
            hits = sorted((m.start(), k) for k, rx in FIELD_KEYS for m in [re.search(rx, t)] if m and k not in used)
            if hits:
                key = hits[0][1]
                break
        out.append(key)
        if key:
            used.add(key)
    for i, k in enumerate(out):
        if not k:
            out[i] = next((x for x in FIELD_DEFAULT if x not in used), FIELD_DEFAULT[i % len(FIELD_DEFAULT)])
            used.add(out[i])
    return out


def _caption(g, x, y, w, t, size, color=NAVY, align=PP_ALIGN.CENTER):
    text(g, x, y, w, size / 72 * 1.3, t, size=size, color=color, font='mj', align=align)


def _draw_field(ctx, sl, x0, y0, w, h, delay=0):
    """Схема-план месторождения в прямоугольнике (x0, y0, w, h). Возвращает {ключ объекта: (x, y)} — точки
    для номеров (правый верхний угол объекта или середина линии)."""
    X = lambda u: x0 + u * w                               # noqa: E731
    Y = lambda v: y0 + v * h                               # noqa: E731
    S = min(w / 7.2, h / 4.6)                              # масштаб значков
    cap = max(8.5, min(11, 10 * S))
    A = {}
    # ---- местность: подложка, лес, озеро, море с берегом
    gb = group(sl)
    land = rect(gb, x0, y0, w, h, fill=rgb('EEF3E8'), shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.03)
    grad(land, rgb('F1F5EC'), rgb('E5EDF2'), 90)
    for u, v, rw, rh_ in ((0.04, 0.84, 0.13, 0.12), (0.43, 0.04, 0.09, 0.08), (0.66, 0.80, 0.15, 0.14),
                          (0.18, 0.37, 0.07, 0.07), (0.79, 0.06, 0.08, 0.1)):
        f = rect(gb, X(u), Y(v), rw * w, rh_ * h, fill=rgb('CEE1A5'), shape=MSO_SHAPE.OVAL)
        alpha_fill(f, 'CEE1A5', 60)
        f2 = rect(gb, X(u) + rw * w * 0.35, Y(v) - rh_ * h * 0.25, rw * w * 0.6, rh_ * h * 0.8, fill=rgb('CEE1A5'),
                  shape=MSO_SHAPE.OVAL)
        alpha_fill(f2, 'CEE1A5', 60)
    lake = rect(gb, X(0.42), Y(0.83), 0.09 * w, 0.08 * h, fill=rgb('CFE3F0'), shape=MSO_SHAPE.OVAL)
    grad(lake, rgb('DCEBF5'), rgb('B9D7EA'), 90)
    shore = [(X(1.0) - 0.0, Y(0.0) + 0.02)] + [(X(0.885 + 0.018 * math.sin(k * 0.9)), Y(k / 12)) for k in range(13)] \
        + [(X(1.0), Y(1.0) - 0.02)]
    sea = freeform(gb, shore, fill=rgb('BFDCEE'))
    grad(sea, rgb('D3E7F3'), rgb('9CC8E3'), 0)
    for k in range(4):                                     # волны
        vy = Y(0.12 + k * 0.22)
        line(gb, X(0.93), vy, X(0.975), vy, color=WHITE, w=1.0, head=False)
    ctx.anim(sl, gb, 'fade', delay, 600)
    # ---- геометрия объектов
    ps = min(0.15 * w, 0.2 * h)                            # сторона кустовой площадки
    pads = [(0.12, 0.18), (0.12, 0.56), (0.35, 0.18)]
    padbox = [(X(u) - ps / 2, Y(v) - ps * 0.4, ps, ps * 0.8) for u, v in pads]
    dns = (X(0.35) - 0.055 * w, Y(0.56) - 0.075 * h, 0.11 * w, 0.15 * h)
    upn = (X(0.56) - 0.085 * w, Y(0.43) - 0.13 * h, 0.17 * w, 0.26 * h)
    rp = (X(0.745) - 0.065 * w, Y(0.43) - 0.15 * h, 0.13 * w, 0.30 * h)
    gtes = (X(0.56) - 0.06 * w, Y(0.1) - 0.065 * h, 0.12 * w, 0.13 * h)
    flare_c = (X(0.6), Y(0.84))
    camp = (X(0.27) - 0.06 * w, Y(0.86) - 0.06 * h, 0.12 * w, 0.11 * h)
    road_y = Y(0.72)
    jetty_y = Y(0.43)
    # ---- дороги (под трубопроводами)
    gr = group(sl)
    rw_ = max(5.5, 8 * S)

    def road(pts):
        _poly(gr, pts, LGRAY, w=rw_)
        _poly(gr, pts, WHITE, w=0.75, dash='dash')

    road([(x0 + 0.02, road_y), (X(0.9), road_y)])
    xr = X(0.235)
    road([(xr, road_y), (xr, padbox[0][1] + padbox[0][3] / 2)])
    road([(padbox[0][0] + ps, padbox[0][1] + padbox[0][3] / 2), (padbox[2][0], padbox[2][1] + padbox[2][3] / 2)])
    road([(xr, padbox[1][1] + padbox[1][3] / 2), (padbox[1][0] + ps, padbox[1][1] + padbox[1][3] / 2)])
    for bx in (dns, rp):
        road([(bx[0] + bx[2] / 2, road_y), (bx[0] + bx[2] / 2, bx[1] + bx[3])])
    road([(upn[0] + upn[2] * 0.25, road_y), (upn[0] + upn[2] * 0.25, upn[1] + upn[3])])
    road([(camp[0] + camp[2] / 2, road_y), (camp[0] + camp[2] / 2, camp[1])])
    A['road'] = (xr, Y(0.37))
    ctx.anim(sl, gr, 'fade', delay + 150, 500)
    # ---- трубопроводы: нефтесборные (от кустов), ДНС → УПН → резервуарный парк → напорный нефтепровод
    gpl = group(sl)
    fw = max(2.0, 2.75 * S)
    k1, k2, k3 = padbox
    _poly(gpl, [(k1[0] + ps * 0.35, k1[1] + k1[3]), (k1[0] + ps * 0.35, k2[1])], BLUE, w=fw)
    _poly(gpl, [(k2[0] + ps, k2[1] + k2[3] * 0.3), (dns[0], k2[1] + k2[3] * 0.3)], BLUE, w=fw)
    _poly(gpl, [(k3[0] + ps * 0.5, k3[1] + k3[3]), (k3[0] + ps * 0.5, dns[1])], BLUE, w=fw)
    A['flowlines'] = ((k2[0] + ps + dns[0]) / 2, k2[1] + k2[3] * 0.3 - 0.02)
    ym = dns[1] + dns[3] * 0.3
    _poly(gpl, [(dns[0] + dns[2], ym), (upn[0], ym)], BLUE, w=fw + 0.75, head=True)
    _poly(gpl, [(upn[0] + upn[2], Y(0.43)), (rp[0], Y(0.43))], DBLUE, w=fw + 0.75, head=True)
    ex = [(rp[0] + rp[2], jetty_y), (X(0.905), jetty_y)]
    _poly(gpl, ex, NAVY, w=fw + 2.5)
    A['export'] = (ex[0][0] + 0.3, jetty_y - 0.03)
    # газ на факел
    fy = upn[1] + upn[3]
    _poly(gpl, [(upn[0] + upn[2] * 0.75, fy), (upn[0] + upn[2] * 0.75, flare_c[1] - 0.25 * S)], DGREEN, w=1.5,
          dash='dash')
    ctx.anim(sl, gpl, 'wipe_l', delay + 300, 800)
    # ---- ЛЭП от ГТЭС: к УПН и к кустам (опоры — ромбики)
    gp = group(sl)
    pl1 = [(gtes[0] + gtes[2] / 2, gtes[1] + gtes[3]), (gtes[0] + gtes[2] / 2, upn[1])]
    pl2 = [(gtes[0], gtes[1] + gtes[3] / 2), (k3[0] + ps, gtes[1] + gtes[3] / 2)]
    for pl in (pl1, pl2):
        _poly(gp, pl, DGREEN, w=1.25)
        (ax, ay), (bx_, by_) = pl
        L_ = math.hypot(bx_ - ax, by_ - ay)
        for k in range(1, max(2, int(L_ / 0.38))):
            f = k / max(2, int(L_ / 0.38))
            tx_, ty_ = ax + (bx_ - ax) * f, ay + (by_ - ay) * f
            tw_ = rect(gp, tx_ - 0.05, ty_ - 0.05, 0.1, 0.1, fill=WHITE, shape=MSO_SHAPE.DIAMOND)
            tw_.line.color.rgb = DGREEN
            tw_.line.width = Pt(1)
    ctx.anim(sl, gp, 'fade', delay + 450, 500)
    # ---- объекты
    go = group(sl)
    for i, (bx, by, bw, bh) in enumerate(padbox):          # кусты скважин
        pad = rect(go, bx, by, bw, bh, fill=rgb('E3E1D6'), shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.12)
        grad(pad, rgb('ECEAE0'), rgb('D6D3C4'), 90)
        pad.line.color.rgb = rgb('BDB8A3')
        pad.line.width = Pt(0.75)
        shadow(pad, 6, 2, 16)
        cols, rows = 4, 2
        dd = min(bw / (cols * 2.1), bh / (rows * 2.6))
        for r in range(rows):
            for c in range(cols):
                wx_ = bx + bw * (c + 0.5) / cols - dd / 2
                wy_ = by + bh * 0.2 + (bh * 0.42) * r - dd / 2 + dd * 0.5
                wl = rect(go, wx_, wy_, dd, dd, fill=NAVY, shape=MSO_SHAPE.OVAL)
                wl.line.color.rgb = WHITE
                wl.line.width = Pt(1)
        rect(go, bx + bw * 0.08, by + bh * 0.8, bw * 0.84, bh * 0.08, fill=STEEL)
        _caption(go, bx - 0.2, by + bh + 0.03, bw + 0.4, f'Куст {i + 1}', cap)
    A['pads'] = (padbox[0][0] + ps, padbox[0][1])

    def block(bx, by, bw, bh, c1, c2, ic, label, cap_below=True):
        b = rect(go, bx, by, bw, bh, fill=c1, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.12)
        grad(b, c1, c2, 90)
        shadow(b, 8, 2, 22)
        isz = min(bw, bh) * 0.5
        icon(go, ic, 'w', bx + (bw - isz) / 2, by + (bh - isz) / 2, isz)
        if cap_below:
            _caption(go, bx - 0.3, by + bh + 0.03, bw + 0.6, label, cap)
        return b

    block(*dns, BLUE, DBLUE, 'TbGauge', 'ДНС / КНС')
    A['dns'] = (dns[0] + dns[2], dns[1])
    # УПН: корпус + колонны и сепараторы
    ub = rect(go, *upn, fill=NAVY, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.08)
    grad(ub, DBLUE, NAVY, 90)
    shadow(ub, 10, 3, 24)
    bx, by, bw, bh = upn
    for k in range(3):
        cc = rect(go, bx + bw * (0.12 + 0.17 * k), by + bh * 0.14, bw * 0.12, bh * 0.5, fill=WHITE,
                  shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.5)
        grad(cc, WHITE, rgb('C9DCEB'), 0)
    for k in range(2):
        sp = rect(go, bx + bw * 0.62, by + bh * (0.16 + 0.26 * k), bw * 0.3, bh * 0.17, fill=WHITE,
                  shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.5)
        grad(sp, WHITE, rgb('C9DCEB'), 90)
    text(go, bx, by + bh * 0.7, bw, bh * 0.26, 'УПН', size=max(10, min(16, bh * 14)), color=WHITE, font='b',
         align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    A['upn'] = (bx + bw, by)
    # резервуарный парк: обвалование и резервуары
    bx, by, bw, bh = rp
    bund = rect(go, bx, by, bw, bh, fill=rgb('F4F6F8'), shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.06)
    bund.line.color.rgb = STEEL
    bund.line.width = Pt(1.25)
    bund.line.dash_style = MSO_LINE_DASH_STYLE.DASH
    td = min(bw * 0.4, bh * 0.36)
    for r in range(2):
        for c in range(2):
            tx_ = bx + bw * (0.27 + 0.46 * c) - td / 2
            ty_ = by + bh * (0.27 + 0.46 * r) - td / 2
            tk = rect(go, tx_, ty_, td, td, fill=WHITE, shape=MSO_SHAPE.OVAL)
            grad(tk, WHITE, rgb('C9D3DE'), 45)
            tk.line.color.rgb = NAVY
            tk.line.width = Pt(1.5)
            shadow(tk, 6, 2, 20)
            inn = rect(go, tx_ + td * 0.3, ty_ + td * 0.3, td * 0.4, td * 0.4, fill=None, shape=MSO_SHAPE.OVAL)
            inn.line.color.rgb = rgb('9AABBE')
            inn.line.width = Pt(0.75)
    _caption(go, bx - 0.3, by + bh + 0.03, bw + 0.6, 'Резервуарный парк', cap)
    A['tanks'] = (bx + bw, by)
    block(*gtes, GREEN, DGREEN, 'TbBolt', 'ГТЭС')
    A['power'] = (gtes[0] + gtes[2], gtes[1])
    # факел
    fd = 0.42 * S + 0.1
    fl = rect(go, flare_c[0] - fd / 2, flare_c[1] - fd / 2, fd, fd, fill=DGREEN, shape=MSO_SHAPE.OVAL)
    grad(fl, GREEN, DGREEN, 45)
    shadow(fl, 8, 2, 22)
    icon(go, 'TbFlame', 'w', flare_c[0] - fd * 0.3, flare_c[1] - fd * 0.3, fd * 0.6)
    _caption(go, flare_c[0] - 0.6, flare_c[1] + fd / 2 + 0.02, 1.2, 'Факел', cap)
    A['flare'] = (flare_c[0] + fd * 0.4, flare_c[1] - fd * 0.4)
    block(*camp, MIDBLUE, BLUE, 'TbHome2', 'Вахтовый посёлок')
    A['camp'] = (camp[0] + camp[2], camp[1])
    # терминал: причал и танкер
    jx0, jx1 = X(0.905), X(0.965)
    jt = rect(go, jx0, jetty_y - 0.05, jx1 - jx0, 0.1, fill=STEEL)
    grad(jt, LGRAY, STEEL, 90)
    term = rect(go, jx0 - 0.12, jetty_y - 0.14, 0.24, 0.28, fill=NAVY, shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.2)
    grad(term, DBLUE, NAVY, 90)
    sx, sw_, s_top, s_bot = X(0.95), 0.042 * w, jetty_y + 0.1, min(Y(0.97), jetty_y + 0.1 + 0.42 * h)
    hull = freeform(go, [(sx, s_top), (sx + sw_ / 2, s_top + sw_ * 0.9), (sx + sw_ / 2, s_bot), (sx - sw_ / 2, s_bot),
                         (sx - sw_ / 2, s_top + sw_ * 0.9)], fill=NAVY)
    grad(hull, BLUE, NAVY, 0)
    shadow(hull, 8, 2, 24)
    for k in range(3):
        rect(go, sx - sw_ * 0.3, s_top + (s_bot - s_top) * (0.25 + 0.18 * k), sw_ * 0.6, sw_ * 0.25, fill=LGREEN,
             shape=MSO_SHAPE.ROUNDED_RECTANGLE, adj=0.5)
    rect(go, sx - sw_ * 0.38, s_bot - sw_ * 0.9, sw_ * 0.76, sw_ * 0.6, fill=WHITE)
    _caption(go, jx0 - 1.3, jetty_y + 0.12, 1.25, 'Терминал', cap, align=PP_ALIGN.RIGHT)
    A['terminal'] = (jx0 + 0.12, jetty_y - 0.14)
    ctx.anim(sl, go, 'zoom', delay + 500, 600)
    return A


def render_field(ctx, s):
    sl, top, bottom = content_slide(ctx, s)
    items = _items(s, 6)
    n = len(items)
    DW = C.CW * _side_share(items, 0.5, 0.63 if n > 2 else 0.68)
    A = _draw_field(ctx, sl, C.L, top, DW, bottom - top)
    slots = field_slots(items)
    d = 0.42 if n <= 4 else 0.38
    for i, key in enumerate(slots):
        ax, ay = A.get(key, A['pads'])
        gm = group(sl)
        px = min(C.L + DW - d / 2 - 0.04, max(C.L + d / 2 + 0.04, ax))
        py = min(bottom - d / 2 - 0.04, max(top + d / 2 + 0.04, ay))
        _badge(gm, px, py, d, i, n, size=13 if d >= 0.42 else 12)
        ctx.anim(sl, gm, 'zoom', 900 + i * 150, 350)
    if n:
        x = C.L + DW + 0.3
        _cards_column(ctx, sl, items, x, top, bottom, C.R - x, 1000, labels=[_accent(it) for it in items])
    conclusion(ctx, sl, s, 1100 + n * 150)
    return sl


# ======================================================================================
# Когда схемы уместны (планировщик, варианты слайда, смена макета)
# ======================================================================================
WELL_T = re.compile(r'скважин|ствол|забо[йея]|обсадн|колонн|конструкци|интервал|горизонт(?!альн)|пласт')
WELL_STRONG = re.compile(r'скважин|ствол|забо[йея]|обсадн|колонн')
WELL_I = re.compile(r'направлени|кондуктор|колонн|хвостовик|обсадн|цемент|долот|забо[йея]|интервал|горизонт|пласт|'
                    r'перфорац|глубин|ствол|башмак|освоени|\bгрп\b|\d\s*(?:–|-|—)\s*\d[\d\s]*м\b|\d\s*м\b')
FIELD_T = re.compile(r'обустройств|инфраструктур|объект\w* (?:месторожд|промысл|обустр)|наземн\w* объект|'
                     r'площадочн|линейн\w* объект|промысл')
FIELD_I = re.compile(r'куст|\bупн|\bднс|\bкнс|бкнс|\bцпс|упсв|резервуар|\bрвс|нефтесбор|напорн|трубопровод|водовод|'
                     r'\bлэп|подстанц|гтэс|гпэс|электростанц|факел|автодорог|дорог|вахтов|терминал|причал|\bппд|насосн')
CHAIN_T = re.compile(r'цепочк|стоимост|value chain|upstream|downstream|от скважины|от недр|полн\w* цикл|'
                     r'вертикальн\w* интегр|бизнес-?модел')
LIMITS = {'value_chain': (3, 7), 'well': (3, 6), 'field': (2, 6)}


def _item_texts(items):
    return [_blob(it.get('title'), it.get('text'), it.get('label')) for it in items if isinstance(it, dict)]


def well_fit(title, items):
    """Скважина: в заголовке — скважина/ствол/колонна, в пунктах — интервалы, колонны, пласты, глубины."""
    ts, tt = _item_texts(items), _blob(title)
    lo, hi = LIMITS['well']
    if not lo <= len(ts) <= hi:
        return False
    hits = sum(bool(WELL_I.search(t)) for t in ts)
    if WELL_STRONG.search(tt):
        return hits >= 1
    if WELL_T.search(tt):
        return hits >= max(2, len(ts) // 2)
    return hits >= max(3, -(-len(ts) * 2 // 3)) and sum(bool(WELL_STRONG.search(t)) for t in ts) >= 2


def field_fit(title, items):
    """Месторождение: заголовок про обустройство/инфраструктуру, в пунктах — объекты (кусты, УПН, ДНС, РВС…)."""
    ts, tt = _item_texts(items), _blob(title)
    lo, hi = LIMITS['field']
    if not lo <= len(ts) <= hi:
        return False
    hits = sum(bool(FIELD_I.search(t)) for t in ts)
    if FIELD_T.search(tt):
        return hits >= 1 or 'обустройств' in tt
    if 'месторожд' in tt:
        return hits >= 2
    return hits >= max(3, -(-len(ts) * 3 // 5)) and len(set(field_slots(items))) >= 3


def chain_fit(title, items):
    """Цепочка: пункты — разные звенья (разведка, бурение, добыча, подготовка, транспорт, переработка, сбыт)."""
    ts, tt = _item_texts(items), _blob(title)
    lo, hi = LIMITS['value_chain']
    if not lo <= len(ts) <= hi:
        return False
    stages = [_stage(t) for t in ts]
    have = [x for x in stages if x]
    if CHAIN_T.search(tt):
        return len(set(have)) >= 2
    return len(set(have)) >= 3 and len(have) >= -(-len(ts) * 3 // 5)


FITS = {'well': well_fit, 'field': field_fit, 'value_chain': chain_fit}


def oilgas_scheme(title, items):
    """Нефтегазовая схема для содержания: 'well' | 'field' | 'value_chain' | None (порядок — от более частной)."""
    try:
        items = [it for it in items or [] if isinstance(it, dict)]
        for lay in ('well', 'field', 'value_chain'):
            if FITS[lay](title, items):
                return lay
    except Exception:                                    # noqa: BLE001
        pass
    return None


def oilgas_ok(s, lay):
    """Подходит ли слайду s нефтегазовая схема lay (для вариантов и смены макета). Для других макетов — True."""
    if lay not in FITS:
        return True
    try:
        return bool(FITS[lay](s.get('title') or '', [it for it in s.get('items') or [] if isinstance(it, dict)]))
    except Exception:                                    # noqa: BLE001
        return False


RENDERERS_OILGAS = {'value_chain': render_value_chain, 'well': render_well, 'field': render_field}
