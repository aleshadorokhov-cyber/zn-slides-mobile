# -*- coding: utf-8 -*-
"""
smart.py — СХЕМА ВМЕСТО «ПРОСТЫНИ» ТЕКСТА
========================================

Что делает с разделом документа, в котором только абзацы (или абзацы + рисунки):

  1. Рисунки из Word                     → слайд «Рисунок»: картинки с подписями + тезисы;
  2. «Достоинства: …/Недостатки: …»       → матрица 2×2 (два объекта) или сравнение (один);
  3. строки «Параметр = значение»         → показатели (KPI) + остальные тезисы сбоку;
  4. числа, вложенные друг в друга        → воронка (236 отказов → 25 «Клин» → 8 малодебитных);
     числа с единицами                    → показатели (KPI) + тезисы сбоку;
     проценты                             → спидометры; одна единица у всех → полосы;
  5. «Перед…», «Далее…», «После…»         → процесс по шагам;
  6. ситуация → проблема → решение        → цепочка из трёх шагов;
  7. варианты «Рис. 1 …», «Рис. 2 …»      → карточки вариантов;
  8. иначе                                → тезисы: текст с ключевой мыслью или список.

Кроме того, scheme_for_items() подбирает схему для СПИСКА по смыслу заголовка
(уровни → пирамида, отбор → воронка, участники → сеть связей, принципы → опоры…).
Выделенные автором фрагменты (mark) идут первыми: в подзаголовок, ключевую мысль, вывод.
"""
import re

from .condense import despeech, facts, funnel_facts, params, pros_cons, sents, steps, theses
from .digest import _ANAPHOR2, clean_sentence, enumeration, junk, paragraph_points, subject_title
from .digest import points as digest_points
from .textutil import cap, shorten, split_title_text

# --------------------------------------------------------------------------------------
# Схема для списка по смыслу заголовка раздела
# --------------------------------------------------------------------------------------
SCHEME_RX = [
    ('swot',      r'swot|сильн\w* и слаб|сильные стороны'),
    ('risk',      r'риск'),
    ('fishbone',  r'причин|исикав|факторы (возникнов|отказ|аварий)'),
    ('gantt',     r'план-график|календарн\w* план|график (работ|реализац|выполнен)|сроки (работ|выполнен)'),
    ('checklist', r'статус|ход (работ|реализац|выполнен)|чек-лист|выполнен\w* мероприят|исполнени\w* (план|поручен)'),
    ('iceberg',   r'скрыт|айсберг|невидим|неочевидн'),
    ('converge',  r'факторы успеха|ключевые факторы|предпосылк|условия (успеха|достижения|реализации)'),
    ('puzzle',    r'составляющ|из чего состоит|слагаем'),
    ('mindmap',   r'ментальн|карта (идей|направлений|тем)'),
    ('petals',    r'ценност|аспект|грани\b'),
    ('path',      r'путь|история (компании|развития|предприятия)|этапы развития'),
    ('matrix',    r'swot|сильн\w* и слаб|сильные стороны|важно.{0,10}срочно|квадрант|матриц'),
    ('pyramid',   r'иерарх|пирамид|уров\w+ (управлен|приоритет)|приоритет\w*|основа\b|фундамент'),
    ('funnel',    r'воронк|отбор|фильтрац|конверси|скрининг'),
    ('stairs',    r'зрелост|ступен|уровни развития|рост компетен|развити\w+ по этапам|эволюци'),
    ('layers',    r'архитектур|слои|уровни системы|стек|платформ'),
    ('pillars',   r'принцип|опор\w|столп|направлени\w+ (стратег|развит|работ)|стратегическ'),
    ('hub',       r'участник|взаимодейств|экосистем|партн[её]р|стейкхолдер|заинтересованн|связ\w+ с'),
    ('roadmap',   r'дорожн\w* карт|план-график|график (работ|реализац)|вех|сроки реализац'),
    ('gears',     r'механизм|взаимосвяз|как это работает|синхрониз'),
    ('venn',      r'синерг|на стыке|пересечени|сочетани'),
    ('tree',      r'структур\w+ (программ|проект|организац|работ)|состав (программ|проект|работ)|декомпозиц'),
    ('honeycomb', r'компонент|модул|состав\b|элемент\w+ систем|виды|типы|классификац|набор'),
    ('cycle',     r'цикл|жизненн|круговорот|pdca|непрерывн'),
]
SCHEME_RX = [(k, re.compile(p, re.I)) for k, p in SCHEME_RX]
LIMITS = {'matrix': (4, 4), 'pyramid': (3, 5), 'funnel': (3, 5), 'stairs': (3, 6), 'layers': (3, 6),
          'pillars': (2, 5), 'hub': (3, 6), 'roadmap': (3, 8), 'gears': (2, 4), 'venn': (2, 3), 'tree': (2, 6),
          'honeycomb': (3, 7), 'cycle': (3, 6), 'swot': (4, 4), 'risk': (2, 9), 'fishbone': (3, 6), 'gantt': (2, 10),
          'checklist': (3, 12), 'iceberg': (2, 8), 'converge': (2, 6), 'puzzle': (2, 6), 'mindmap': (2, 6),
          'petals': (3, 6), 'path': (3, 8)}
# схемы, которым кроме заголовка нужны особые данные — их проверяет планировщик (variety._ok);
# если данных нет, берётся следующая подходящая по смыслу схема
DATA_SCHEMES = ('swot', 'risk', 'gantt', 'checklist')
CHECKED_SCHEMES = DATA_SCHEMES + ('fishbone', 'petals', 'puzzle', 'mindmap')


def scheme_for_items(title, n, has_dates=False, skip=()):
    """Схема для n пунктов по смыслу заголовка (или None); схемы из skip пропускаются."""
    for k, rx in SCHEME_RX:
        lo, hi = LIMITS[k]
        if k not in skip and rx.search(title or '') and lo <= n <= hi:
            if k in ('roadmap', 'gantt') and not has_dates:
                continue
            return k
    return None


# --------------------------------------------------------------------------------------
# Вспомогательные
# --------------------------------------------------------------------------------------
_INTRO_LINE = re.compile(r'(?i)(следующ\w+|ниже|таки[ех]|основн\w+)\s*\w*\s*:?$|:$|^в результате (проделанной )?работы')
_DEF_RX = re.compile(r'(?i)^это\s+[\wё-]+(?:\s[\wё-]+)?,\s*(которые|который|которая|которое)\s+')


def definition(sentence):
    """«Это муфты, которые при необходимости ограничивают момент…» → «При необходимости ограничивают момент…»."""
    s = despeech(sentence)
    return cap(_DEF_RX.sub('', s)) if s else ''


def clean_item(text):
    """Пункт списка: без «во-первых», без скобок вокруг пояснения."""
    t = re.sub(r'(?i)^(во-первых|во-вторых|в-третьих|в-четв[её]ртых|в-пятых|во-первых|первое|второе|третье)[,:\s]+',
               '', text.strip())
    # длинное пояснение в скобках в конце пункта → через тире (скобки посреди фразы не трогаем — сломается синтаксис)
    t = re.sub(r'\s*\(\s*([^()]{20,})\s*\)(\.?)$', r' — \1\2', t)
    return cap(t.strip())


def item_from(text, bold=''):
    t, x = split_title_text(clean_item(text), bold)
    if x.startswith('(') and re.search(r'\)\.?$', x) and x.count('(') == 1:
        x = re.sub(r'^\(\s*|\s*\)\.?$', '', x).strip()     # пояснение целиком в скобках
    return {'title': t, 'text': cap(x) if x else '', '_raw': text}


def _marked_texts(sec):
    out = []
    for b in sec.blocks:
        if b.kind == 'para' and (b.mark or b.mark_text):
            out.append(b.mark_text or b.text)
        if b.kind == 'list':
            out.extend(i.text for i in b.items if i.mark)
    return out


_VARIANT_RX = re.compile(r'(?i)\b(рис\.?|рисунк\w*|схем\w*|вариант\w*)\s*№?\s*(\d+)|\bна (первой|второй|третьей|четв[её]ртой) схеме')
_ORD = {'первой': 1, 'второй': 2, 'третьей': 3, 'четвертой': 4, 'четвёртой': 4}


def variants(paras):
    """Абзацы «На Рис. 1 …», «На Рис. 2 …», «На третьей схеме …» → карточки вариантов."""
    out = []
    for p in paras:
        m = _VARIANT_RX.search(p[:70])
        if not m:
            continue
        num = m.group(2) or _ORD.get((m.group(3) or '').lower(), len(out) + 1)
        th = theses(p, 2, 150)
        if not th:
            continue
        out.append({'title': f'Вариант {num}', 'text': ' '.join(th)[:260], 'label': f'Рис. {num}'})
    return out if len(out) >= 2 else None


_PROBLEM = re.compile(r'(?i)привод\w* к|привести к|может привести|вызыва|не ограничива|не позволя|проблем|недостат|'
                      r'риск|износ|отказ|заклинива|слом')
_SOLUTION = re.compile(r'(?i)предлага|предложен|решени|позволя|использовать .{0,40}(муфт|устройств|систем|технолог)|'
                       r'внедр|применени')


def chain(ths):
    """Ситуация → проблема → решение (три тезиса с явной проблемой и решением)."""
    if not 2 <= len(ths) <= 4:
        return None
    pi = next((i for i, t in enumerate(ths) if _PROBLEM.search(t)), None)
    si = next((i for i, t in enumerate(ths) if _SOLUTION.search(t) and i != pi), None)
    if pi is None or si is None or si < pi:
        return None
    items = []
    if pi > 0:
        items.append({'title': 'Сейчас', 'text': ths[0], 'icon': 'TbInfoCircle'})
    items.append({'title': 'Проблема', 'text': ths[pi], 'icon': 'TbAlertTriangle'})
    items.append({'title': 'Решение', 'text': ths[si], 'icon': 'TbBulb'})
    return items if len(items) >= 2 else None


def _kpi_items(fs, ctx=True):
    """ctx — пояснение к числу из его предложения (для плиток без бокового текста)."""
    out, seen = [], set()
    for f in fs:
        key = (f['title'] or '').lower()
        if key and key in seen:
            continue                                  # одна подпись — один показатель
        seen.add(key)
        out.append({'value': f['value'], 'unit': f['unit'], 'title': f['title'],
                    'text': f.get('text') or (f.get('_ctx') or '' if ctx else '')})
    return out


def _numeric_layout(fs):
    """Подходящая инфографика для набора чисел."""
    units = {f['unit'] for f in fs}
    if all(f['unit'] == '%' for f in fs) and len(fs) <= 4:
        return 'gauge'
    if len(units) == 1 and len(fs) >= 3 and not any(str(f['value']).startswith('до') or '–' in str(f['value'])
                                                   for f in fs):
        return 'bars'
    return 'kpi'


_STAGE = re.compile(r'(?i)^(этап|стадия|фаза|шаг|очередь)\s+(\d+|[IVX]+)\b[.:)]?\s*')
_PAREN_DATE = re.compile(r'\s*\(([^()]*(?:\d{4}|кв\.|квартал|месяц|год)[^()]*)\)')


def stage_items(paras):
    """Абзацы «Этап 1. Подготовительный (I кв. 2026 — II кв. 2026). Текст…» → пункты шкалы времени
    [{'label': сроки, 'title': название этапа, 'text': главное}], подзаголовок (из вводного абзаца)
    и вывод (из абзаца после этапов). Меньше трёх этапов — None."""
    idx = [i for i, p in enumerate(paras) if _STAGE.match(p.bold or p.text)]
    if len(idx) < 3:
        return None
    items = []
    for i in idx:
        p = paras[i]
        head = (p.bold or '').strip()
        if not head or not p.text.startswith(head[:12]):
            ss = sents(p.text)
            head = ss[0] if ss else p.text
        body = p.text[len(head):].strip() if p.text.startswith(head) else p.text
        m = _STAGE.match(head)
        num = m.group(2) if m else str(len(items) + 1)
        name = head[m.end():] if m else head
        dm = _PAREN_DATE.search(name)
        label = dm.group(1).strip() if dm else ''
        name = _PAREN_DATE.sub('', name).strip(' .:;—–')
        pts = paragraph_points(body, 2, 200, joint=False) if body else []
        items.append({'label': label or f'Этап {num}', 'title': cap(name) or f'Этап {num}',
                      'text': shorten(pts[0], 150) if pts else '',          # на шкале места мало — главное
                      '_full': shorten(' '.join(pts), 300) if pts else ''})
    intro = [p for p in paras[:idx[0]] if not _STAGE.match(p.bold or p.text)]
    tail = [p for p in paras[idx[-1] + 1:] if not _STAGE.match(p.bold or p.text)]
    ipts = [t for p in intro for t in paragraph_points(p.text, 3, 170, joint=False)]
    tpts = [t for p in tail for t in paragraph_points(p.text, 1, 190)]
    sub = ipts[0] if ipts else ''
    # вывод не должен начинаться ссылкой на предыдущее («На каждой из них…») — вне контекста непонятно
    alone = [t for t in tpts + ipts[1:] if not _ANAPHOR2.search(t[:40])]
    concl = alone[0] if alone else ''
    return items, sub, concl


def titled_items(paras):
    """Абзацы «каждый про своё» (риски, направления, меры): «Геологический риск связан с тем, что X.
    Чтобы снизить его, …» → карточка «Геологический риск» с сутью и главной мыслью остального.
    Нужны ≥ 3 абзацев, у большинства — заголовок из подлежащего первой фразы. Иначе None."""
    if len(paras) < 3:
        return None
    items, n_def = [], 0
    for p in paras:
        ss = sents(p.text)
        if not ss:
            continue
        title, rest, d = subject_title(ss[0])
        if title:
            n_def += d
            more = paragraph_points(' '.join(ss[1:]), 1, 200) if len(ss) > 1 else []
            txt = ' '.join([shorten(rest, 220)] + more)
        else:
            txt = ' '.join(paragraph_points(p.text, 2, 210, joint=False))
        if txt:
            items.append({'title': title, 'text': txt})
    titles = [i['title'].lower() for i in items if i['title']]
    if n_def < max(2, len(items) * 0.5) or len(titles) < len(items) * 0.6 or len(set(titles)) < len(titles):
        return None
    return items


# --------------------------------------------------------------------------------------
# Главная функция
# --------------------------------------------------------------------------------------
def prose_candidates(doc, sec, title, label, notes, prio, paras=None):
    """ВСЕ подходящие способы показать раздел из абзацев — в порядке уместности:
    [(подпись варианта, [(слайд, приоритет), …]), …]. Первый — основной, остальные —
    варианты на выбор (отличаются и содержанием, и формой). paras — абзацы (по умолчанию — все абзацы раздела)."""
    if paras is None:
        paras = [b for b in sec.blocks if b.kind == 'para']
    paras = [p for p in paras if not junk(p.text)]
    images = [b for b in sec.blocks if b.kind == 'image' and b.image_id in doc.images]
    texts = [p.text for p in paras]
    full = ' '.join(texts)
    marked = _marked_texts(sec)
    base = {'title': title, 'section': label, 'notes': notes}
    C = []                                   # кандидаты

    pts = digest_points(paras)               # главные мысли каждого абзаца: [(абзац, тезис, вес)]
    ths_all = [t for _, t, _ in pts]
    if marked:                               # выделенное автором — первым
        mths = [shorten(clean_sentence(m) or m, 220) for m in marked]
        ths_all = mths + [t for t in ths_all if not any(t[:40] in m_ or m_[:40] in t for m_ in mths)]
    fs = facts(full, 8)
    def _has_fact(t):
        return any(re.search(r'(?<![\d,])' + re.escape(str(f['value']).replace('до ', '').split('–')[0]) + r'(?![\d,])', t)
                   for f in fs)
    non_fact = [t for t in ths_all if not _has_fact(t)]       # тезисы без чисел — пояснения к показателям
    st = steps(full)
    vs = variants(texts)

    # ---- рисунки ---------------------------------------------------------------------------
    if images:
        imgs = [{'path': doc.images[b.image_id]['path'], 'caption': b.text} for b in images[:3]]
        group_ = [(dict(base, layout='image', images=imgs, items=[{'title': '', 'text': t} for t in ths_all[:4]]),
                   prio['image'])]
        if st and len(st) >= 3:
            group_.append((dict(base, layout='process' if len(st) <= 4 else 'list', title=title + ': порядок действий',
                                items=st[:6], variant='' if len(st) <= 4 else 'tiles'), prio['process']))
        C.append(('Рисунок и тезисы', group_))

    # ---- этапы «Этап 1. Название (сроки). …» → шкала времени -------------------------------------
    stg = stage_items(paras)
    if stg:
        items, sub, concl = stg
        lay = 'timeline' if len(items) <= 8 else 'list'
        C.append(('Этапы на шкале времени', [(dict(base, layout=lay, items=items, subtitle=shorten(sub, 150),
                                                   conclusion=shorten(concl, 190)), prio['timeline'])]))
        full = [{'title': f"{it['title']} ({it['label']})" if it['label'] != it['title'] else it['title'],
                 'text': it['_full']} for it in items]
        for it in items:
            it.pop('_full', None)
        C.append(('Этапы списком (подробно)', [(dict(base, layout='list', items=full, subtitle=shorten(sub, 150)),
                                                prio['list'])]))
        if len(items) <= 6:
            C.append(('Этапы по шагам', [(dict(base, layout='process', items=items, subtitle=shorten(sub, 150),
                                               conclusion=shorten(concl, 190)), prio['process'])]))

    # ---- абзацы «каждый про своё» → карточки с заголовками ---------------------------------------
    tit = None if stg else titled_items(paras)
    if tit:
        lay = 'cards' if len(tit) <= 4 else 'list'
        C.append(('Карточки по абзацам', [(dict(base, layout=lay, items=tit), prio[lay])]))

    # ---- достоинства / недостатки --------------------------------------------------------------
    pc = pros_cons(texts)
    if pc:
        if len(pc) >= 2:
            items = []
            for g in pc[:2]:
                nm = g['name'] or 'Вариант'
                items.append({'title': f'{nm}: достоинства', 'text': '; '.join(g['pros']) or '—', 'icon': 'TbThumbUp'})
                items.append({'title': f'{nm}: недостатки', 'text': '; '.join(g['cons']) or '—', 'icon': 'TbThumbDown'})
            C.append(('Матрица 2×2', [(dict(base, layout='matrix', items=items,
                                             axes={'x': 'Достоинства ← → Недостатки', 'y': ''}), prio['compare'])]))
            rows = [[g['name'] or 'Вариант', '; '.join(g['pros']), '; '.join(g['cons'])] for g in pc]
            C.append(('Таблица сравнения', [(dict(base, layout='table', columns=['Вид', 'Достоинства', 'Недостатки'],
                                                   rows=rows), prio['table'])]))
            for g in pc[:2]:
                C.append((f'Сравнение: {g["name"] or "вариант"}', [(dict(
                    base, layout='compare', style='pros_cons', subtitle=g['name'],
                    left={'title': 'Достоинства', 'items': g['pros']},
                    right={'title': 'Недостатки', 'items': g['cons']}), prio['compare'])]))
        else:
            g = pc[0]
            C.append(('Плюсы и минусы', [(dict(base, layout='compare', style='pros_cons',
                                                left={'title': 'Достоинства', 'items': g['pros']},
                                                right={'title': 'Недостатки', 'items': g['cons']}), prio['compare'])]))

    # ---- параметры «X = значение» ---------------------------------------------------------------
    pr = params(texts)
    if pr:
        rest = [t for t in texts if not re.match(r'^\s*[^=:]{2,40}?\s*(?:=|[-–—:])\s*\d', t)]
        aside = [shorten(despeech(t) or t, 150) for t in rest][:3]
        C.append(('Параметры и условия', [(dict(base, layout='kpi', items=pr[:6], aside=aside), prio['kpi'])]))
        C.append(('Таблица параметров', [(dict(base, layout='table', columns=['Параметр', 'Значение'],
                                               rows=[[p_['title'], f"{p_['value']} {p_['unit']}".strip()] for p_ in pr],
                                               conclusion=shorten(aside[-1], 180) if aside else ''), prio['table'])]))
        if aside:
            C.append(('Условия и вывод', [(dict(base, layout='text', lead=aside[0], paragraphs=aside[1:3]),
                                          prio['text'])]))

    # ---- вложенные числа → воронка -------------------------------------------------------------
    fun = funnel_facts(fs)
    good = [f for f in fs if f['unit'] or f.get('_count')]
    if fun:
        def _ft(f):
            lb = f['title']
            if re.match(r'(?i)(число|количество|кол-во|доля|сумма)\b', lb):
                return f"{lb}: {f['value']}"                 # «Число отказов по малодебитным скважинам: 8»
            return f"{f['value']} {lb[:1].lower()}{lb[1:]}".strip()   # «236 отказов погружного оборудования»
        items = [{'title': _ft(f), 'text': '', 'value': f['value']} for f in fun[:5]]
        other = [f for f in fs if f not in fun][:2]
        sub = ' · '.join(f"{f['title']}: {f['value']} {f['unit']}".strip() for f in other)
        concl = non_fact[-1] if non_fact else ''
        C.append(('Воронка чисел', [(dict(base, layout='funnel', items=items, subtitle=shorten(sub, 120),
                                          conclusion=concl), prio['kpi'] + 1)]))

    # ---- шаги и варианты -----------------------------------------------------------------------
    if st and len(st) >= 3 and not images:
        intro = [t for t in ths_all if t not in [x['text'] for x in st]][:1]
        sub = shorten(intro[0], 130) if intro else ''
        grp = [(dict(base, layout='process' if len(st) <= 4 else 'list', items=st[:6], subtitle=sub,
                     variant='' if len(st) <= 4 else 'tiles'), prio['process'])]
        if vs:
            grp.append((dict(base, layout='cards', title=title + ': варианты компоновки', items=vs[:4]), prio['cards']))
        C.append(('Порядок действий', grp))
        if len(st) >= 4:
            C.append(('Шаги на таймлайне', [(dict(base, layout='timeline', items=st[:8], subtitle=sub), prio['process'])]))
    if vs:
        C.append(('Варианты компоновки', [(dict(base, layout='cards', items=vs[:4]), prio['cards'])]))

    # ---- пересказ по абзацам и перечни внутри текста --------------------------------------------
    good = [f for f in fs if f['title'] and (f['unit'] or f.get('_count'))]     # числа с понятной подписью
    enum = None
    for k, p_ in enumerate(paras):
        e = enumeration(p_.text)
        if e and (e[2] in ('ord', 'count') or len(e[1]) >= 3):
            enum = (k, e[:2])
            break
    group_ = []
    if enum:
        k_e, (intro, items) = enum
        group_.append((dict(base, layout='list' if len(items) > 4 or sum(map(len, items)) > 520 else 'cards',
                            subtitle=shorten(intro, 140) if intro else '',
                            items=[item_from(t) for t in items]), prio['list'] + 1))
        rest = [x for x in pts if x[0] != k_e]
    else:
        rest = pts
    ps = points_slide(base, rest, prio)
    if ps:
        if enum and len(rest) >= 2:
            ps = dict(ps, title=title + ': главное') if group_ else ps
            group_.insert(0, (ps, prio['text']))
        elif not enum:
            group_.append((ps, prio['text']))
    if len(good) >= 3:                       # отдельный слайд с цифрами — только если их хотя бы три
        g6 = good[:6]
        group_.append((dict(base, layout='kpi', title=title + ': ключевые цифры', items=_kpi_items(g6)), prio['kpi']))
    # короткий текст с крепкими числами — показатели и пояснения на одном слайде
    compact = len(good) >= 2 and len(paras) <= 2 and len(non_fact) <= 3
    if group_ and not compact:
        C.append(('Главное по абзацам' if not enum else 'Перечень и главное', group_))

    # ---- числа ---------------------------------------------------------------------------------
    if len(good) >= 2 or (len(good) == 1 and len(non_fact) >= 1):
        g6 = good[:6]
        aside = non_fact[:3]
        wide = sum(len(a) for a in aside) >= 110
        s = dict(base, layout='kpi', items=_kpi_items(g6[:4] if wide else g6, ctx=not wide))
        if sum(len(a) for a in aside) >= 110:
            s['aside'] = aside
        elif aside:
            s['subtitle'] = shorten(aside[0], 130)
        C.append(('Показатели и пояснения' if s.get('aside') else 'Ключевые показатели', [(s, prio['kpi'])]))
        lay2 = _numeric_layout(g6)
        if lay2 != 'kpi':
            C.append(({'bars': 'Полосы-индикаторы', 'gauge': 'Спидометры'}.get(lay2, lay2),
                      [(dict(base, layout=lay2, items=_kpi_items(g6), subtitle=shorten(aside[0], 130) if aside else ''),
                        prio['kpi'])]))
        if len(g6) >= 2:
            C.append(('Кольца показателей', [(dict(base, layout='kpi', variant='ring', items=_kpi_items(g6[:4]),
                                                   subtitle=shorten(aside[0], 130) if aside else ''), prio['kpi'])]))
    if group_ and compact:
        C.append(('Главное по абзацам', group_))

    # ---- ситуация → проблема → решение ------------------------------------------------------------
    ch = chain(ths_all[:4])
    if ch:
        C.append(('Цепочка «проблема → решение»', [(dict(base, layout='process', items=ch), prio['process'])]))

    # ---- тезисы ------------------------------------------------------------------------------------
    if ths_all:
        if len(ths_all) >= 3:
            items = [{'title': '', 'text': t} for t in ths_all[:6]]
            C.append(('Тезисы списком', [(dict(base, layout='list', variant='tiles' if len(items) <= 4 else '',
                                               items=items), prio['list'])]))
        C.append(('Кратко: главная мысль', [(dict(base, layout='text', variant='quote', lead=_main_thesis(ths_all),
                                                 paragraphs=[]), prio['text'])]))
    return C


def points_slide(base, pts, prio=None, lead_max=240):
    """Пересказ раздела по абзацам: главная мысль крупно (lead) и по тезису из каждого абзаца.
    До 4 абзацев — «текст с тезисом», больше — список плитками (длинный делится на продолжения)."""
    if not pts:
        return None
    li = max(range(len(pts)), key=lambda i: (pts[i][2], -i))
    if pts[0][2] >= pts[li][2] - 1.0:
        li = 0                                    # первая мысль раздела почти так же важна — она и главная
    lead = pts[li][1]
    if len(lead) > lead_max:
        lead = shorten(lead, lead_max)
    groups = {}
    for i, (k, t, _) in enumerate(pts):
        if i == li:
            continue
        groups.setdefault(k, []).append(t)
    paras = [' '.join(v) for v in groups.values()]
    if not paras:
        return dict(base, layout='text', variant='quote', lead=lead, paragraphs=[])
    if len(paras) <= 4:
        return dict(base, layout='text', lead=lead, paragraphs=paras)
    groups = {}                                   # списком — все тезисы в порядке документа
    for k, t, _ in pts:
        groups.setdefault(k, []).append(t)
    items = [{'title': '', 'text': ' '.join(v)} for v in groups.values()]
    return dict(base, layout='list', variant='tiles' if len(items) <= 4 else '', items=items)


_KEY = re.compile(r'(?i)проблем|цел[ьи]|решени|позволя|предлага|эффект|результат|вывод|итог|\d')


def _main_thesis(ths):
    """Главная мысль: первый тезис с ключевым словом (проблема, цель, решение, эффект, число)."""
    for t in ths:
        if _KEY.search(t):
            return t
    return ths[0]


def prose_slides(doc, sec, title, label, notes, prio):
    """Раздел из абзацев (и, возможно, рисунков) → [(слайд, приоритет)] или [].
    У первого слайда в поле _cands — другие способы показать тот же материал (варианты на выбор)."""
    C = prose_candidates(doc, sec, title, label, notes, prio)
    if not C:
        return []
    label0, group0 = C[0]
    first = dict(group0[0][0], _alt_label=label0)
    first['_cands'] = [dict(g[0][0], _alt_label=lb) for lb, g in C[1:]]
    return [(first, group0[0][1])] + group0[1:]


def intro_and_tail(paras_before, paras_after):
    """Подзаголовок из абзаца перед списком (кроме вводных «…следующие задачи:» и вопросов)
    и вывод из абзаца после списка."""
    sub = ''
    for p in paras_before:
        t = p.text.strip()
        if t.endswith('?') or _INTRO_LINE.search(t):
            continue
        d = definition(sents(t)[0]) if sents(t) else ''
        if d:
            sub = shorten(d, 140)
            break
    concl = ''
    for p in paras_after:
        th = theses(p.text, 1, 160)
        if th:
            concl = th[0]
            break
    return sub, concl
