# -*- coding: utf-8 -*-
"""
textfit.py — ОЦЕНКА РАЗМЕРА ТЕКСТА И АВТОПОДБОР КЕГЛЯ
====================================================

Задача: универсальные макеты получают текст ЛЮБОЙ длины, а рамки на слайде имеют
фиксированный размер. Чтобы текст не «вылезал» за карточку, перед отрисовкой мы
оцениваем, сколько места он займёт, и подбираем кегль (а в крайнем случае — сокращаем
текст с многоточием; полный текст при этом остаётся в заметках докладчика).

Как оценивается ширина текста: для корпоративных шрифтов TT Bluescreens Pro заранее
сняты ширины всех символов (кириллица, латиница, цифры, знаки) — файл font_metrics.json
(ширины в долях кегля, «em»). Сами шрифты для этого не нужны. Ширина строки =
сумма ширин символов × кегль. Перенос строк моделируется так же, как в PowerPoint:
по словам, «жадно» (слово переносится целиком, если не помещается).

Ключи шрифтов — как в nts/config.py:  'mn' (основной), 'mj' (заголовочный), 'b' (жирный).
Все размеры — в дюймах, кегль — в пунктах (1 дюйм = 72 пт).
"""
import json
from functools import lru_cache
from pathlib import Path

from .nts.theme import ACTIVE as _ACTIVE

_M = json.loads(Path(__file__).with_name('font_metrics.json').read_text(encoding='utf8'))
_EXTRA = {}                 # метрики шрифтов своих шаблонов: ключ темы → {'mn', 'mj', 'b'} (templates.theme_for)

LINE_FACTOR = 1.22      # высота строки ≈ 1,22 кегля (одинарный интервал PowerPoint для этого шрифта)
WIDTH_SAFETY = 0.95     # запас по ширине 5 % (кернинг, различия рендеринга PowerPoint/LibreOffice)
NBSP = ' '


def register_metrics(key, metrics):
    """Ширины символов шрифтов своего шаблона (сборка на нём меряет текст ими)."""
    _EXTRA[key] = metrics


@lru_cache(maxsize=40000)
def _word_em_k(word, font, key):
    base = _EXTRA.get(key, _M) if key else _M
    m = base.get(font) or base.get('mn') or _M['mn']
    w, d = m['widths'], m['default']
    return sum(w.get(ch, d) for ch in word)


def _word_em(word, font):
    """Ширина слова в долях кегля (em) — шрифтом корпоративного шаблона или выбранного своего."""
    th = _ACTIVE.get()
    return _word_em_k(word, font, th.metrics_key if th is not None else '')


def text_width(text, size, font='mn'):
    """Ширина однострочного текста, дюймы."""
    return _word_em(text, font) * size / 72.0


def wrap_lines(text, width, size, font='mn'):
    """Разбивает текст на строки так, как это сделал бы PowerPoint (перенос по пробелам).

    Неразрывный пробел (\\u00a0) не разрывает строку. Слово длиннее строки
    разбивается по символам. Возвращает список строк.
    """
    max_em = width * WIDTH_SAFETY * 72.0 / size
    space = _word_em(' ', font)
    lines = []
    for para in str(text).split('\n'):
        words = para.split(' ')
        cur, cur_w = '', 0.0
        for w in words:
            ww = _word_em(w, font)
            if ww > max_em:                       # очень длинное слово — режем по символам
                if cur:
                    lines.append(cur)
                    cur, cur_w = '', 0.0
                chunk, cw = '', 0.0
                for ch in w:
                    chw = _word_em(ch, font)
                    if cw + chw > max_em and chunk:
                        lines.append(chunk)
                        chunk, cw = '', 0.0
                    chunk += ch
                    cw += chw
                cur, cur_w = chunk, cw
                continue
            add = ww if not cur else space + ww
            if cur and cur_w + add > max_em:
                lines.append(cur)
                cur, cur_w = w, ww
            else:
                cur = w if not cur else cur + ' ' + w
                cur_w += add
        lines.append(cur)
    return lines


def text_height(content, width, size, font='mn', space_after=0, line=LINE_FACTOR):
    """Высота текста (строка или список абзацев) в рамке шириной width, дюймы."""
    paras = [content] if isinstance(content, str) else list(content)
    total = 0.0
    for i, p in enumerate(paras):
        n = len(wrap_lines(p, width, size, font))
        total += n * size * line / 72.0
        if i < len(paras) - 1:
            total += space_after / 72.0
    return total


def longest_word_ok(content, width, size, font='mn'):
    """Самое длинное слово помещается в строку (иначе PowerPoint разорвёт слово посередине)."""
    paras = [content] if isinstance(content, str) else list(content)
    lim = width * WIDTH_SAFETY * 72.0 / size
    return all(_word_em(w, font) <= lim for p in paras for w in str(p).replace('\n', ' ').split(' '))


def fits(content, width, height, size, font='mn', space_after=0, max_lines=None, strict_words=True):
    """Помещается ли текст в рамку width × height при кегле size (и ни одно слово не рвётся)."""
    if strict_words and not longest_word_ok(content, width, size, font):
        return False
    if max_lines is not None:
        paras = [content] if isinstance(content, str) else list(content)
        if sum(len(wrap_lines(p, width, size, font)) for p in paras) > max_lines:
            return False
    return text_height(content, width, size, font, space_after) <= height + 1e-6


def fit_size(content, width, height, max_size, min_size, font='mn', step=0.5, space_after=0, max_lines=None):
    """Наибольший кегль из диапазона [min_size; max_size], при котором текст content
    (строка или список абзацев) помещается в рамку width × height.
    Если не помещается даже min_size — возвращает min_size (дальше текст сокращают clip()).
    """
    s = max_size
    while s >= min_size - 1e-9:
        if fits(content, width, height, s, font, space_after, max_lines):
            return round(s, 1)
        s -= step
    return min_size


def fit_size_many(texts, width, height, max_size, min_size, font='mn', step=0.5, max_lines=None):
    """То же, что fit_size, но для списка ОТДЕЛЬНЫХ строк (каждая — своя рамка одного размера)."""
    s = max_size
    texts = [t for t in texts if t]
    while s >= min_size - 1e-9:
        if all(fits(t, width, height, s, font, 0, max_lines) for t in texts):
            return round(s, 1)
        s -= step
    return min_size


def clip(text, width, height, size, font='mn', max_lines=None):
    """Сокращает текст (по словам, с «…»), чтобы он поместился в рамку при кегле size."""
    if not text or fits(text, width, height, size, font, 0, max_lines, strict_words=False):
        return text
    if len(text) > 50:                   # сначала — по смыслу: целые предложения, без второстепенных частей
        from .textutil import shorten
        n = len(text)
        k = n - 4
        while k >= max(36, int(n * 0.3)):
            cand = shorten(text, k)
            if not cand.endswith(('…', '...')) and len(cand) < n:
                if fits(cand, width, height, size, font, 0, max_lines, strict_words=False):
                    return cand
                k = min(k, len(cand)) - max(4, n // 14)
            else:
                k -= max(4, n // 14)
    words = text.split(' ')
    lo, hi = 0, len(words)
    while lo < hi:                       # двоичный поиск максимального числа слов
        mid = (lo + hi + 1) // 2
        cand = ' '.join(words[:mid]).rstrip(',;:—–-') + '…'
        if fits(cand, width, height, size, font, 0, max_lines, strict_words=False):
            lo = mid
        else:
            hi = mid - 1
    if lo == 0:                          # даже первое слово не влезает — режем по символам
        a, b = 0, len(text)
        while a < b:
            mid = (a + b + 1) // 2
            if fits(text[:mid] + '…', width, height, size, font, 0, max_lines, strict_words=False):
                a = mid
            else:
                b = mid - 1
        return (text[:a] + '…') if a else '…'
    return ' '.join(words[:lo]).rstrip(',;:—–- ') + '…'


def fit(text, width, height, max_size, min_size, font='mn', max_lines=None):
    """Подбирает кегль и при необходимости сокращает текст. Возвращает (кегль, текст)."""
    size = fit_size_many([text], width, height, max_size, min_size, font, max_lines=max_lines)
    return size, clip(text, width, height, size, font, max_lines)


def one_line_size(text, width, max_size, min_size, font='mj'):
    """Кегль, при котором текст помещается в ОДНУ строку шириной width (для заголовков)."""
    s = max_size
    while s >= min_size:
        if text_width(text, s, font) <= width * WIDTH_SAFETY:
            return s
        s -= 1
    return min_size
