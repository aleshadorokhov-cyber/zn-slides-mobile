# -*- coding: utf-8 -*-
"""
readers — ЧТЕНИЕ ВХОДНЫХ ФАЙЛОВ.

read_files([(путь, исходное_имя), ...]) читает все загруженные файлы по очереди
в ОДНУ модель Document: разделы Word/PDF и листы Excel идут в порядке загрузки.
Поддерживаются: .docx (Word), .pdf (PDF с текстовым слоем), .pptx (PowerPoint), .xlsx/.xlsm (Excel),
.csv, .json (данные; сохранённый план конструктора — его слайдами), .txt/.md (простой текст).
"""
import re
from pathlib import Path

from ..model import Block, Document, Section
from ..textutil import clean
from .docx_reader import read_docx
from .json_reader import read_json
from .pdf_reader import read_pdf
from .pptx_reader import read_pptx
from .xlsx_reader import read_csv, read_xlsx

SUPPORTED = {'.docx', '.pdf', '.pptx', '.xlsx', '.xlsm', '.csv', '.json', '.txt', '.md'}
TEXT_FIRST = ('.docx', '.pdf', '.pptx', '.txt', '.md', '.doc', '.ppt')     # «рассказ» — раньше таблиц с данными


def decode_text(raw):
    """Байты текстового файла → строка. Блокнот Windows сохраняет «Юникод» как UTF-16 (с BOM),
    обычно — UTF-8; старые файлы — Windows-1251."""
    if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return raw.decode('utf-16', errors='replace')
    try:
        return raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        return raw.decode('cp1251', errors='replace')


_MD_LINK = re.compile(r'!?\[([^\]]*)\]\([^)]*\)')
_MD_BOLD = re.compile(r'(\*\*|__)(?=\S)(.+?)(?<=\S)\1')
_MD_ITAL = re.compile(r'(?<![\w*])([*_])(?=[^\s*_])([^*_]+?)(?<=[^\s*_])\1(?![\w*])')
_MD_LIST = re.compile(r'^(\s*)([-*+•]|\d{1,3}[.)])\s+(?:\[[ xX]\]\s+)?')
_MD_RULE = re.compile(r'^\s*([-*_=])\s*(\1\s*){2,}$')
_MD_TROW = re.compile(r'^\s*\|.*\|\s*$')
_MD_TSEP = re.compile(r'^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$')


def md_inline(t):
    """Строка Markdown → (чистый текст, жирное начало): **жирный**, *курсив*, `код`, [ссылка](url), <br>."""
    t = re.sub(r'(?i)<br\s*/?>', ' ', t)
    t = re.sub(r'</?(?:b|i|u|em|strong|span|sup|sub)[^>]*>', '', t)
    t = _MD_LINK.sub(lambda m: m.group(1), t)
    t = t.replace('`', '')
    bold = ''
    m = re.match(r'^\s*(\*\*|__)(?=\S)(.+?)(?<=\S)\1', t)
    if m:
        bold = clean(m.group(2))
    t = _MD_BOLD.sub(lambda m: m.group(2), t)
    t = _MD_ITAL.sub(lambda m: m.group(2), t)
    t = t.replace('\\*', '*').replace('\\_', '_').replace('\\|', '|')
    return clean(t), bold


def _md_cells(line):
    s = line.strip()
    if s.startswith('|'):
        s = s[1:]
    if s.endswith('|'):
        s = s[:-1]
    return [md_inline(c)[0] for c in re.split(r'(?<!\\)\|', s)]


def read_text(path, model, name):
    """Простой текст / Markdown: «# …» — заголовки, «- …», «1. …» — пункты (с вложенностью по отступу),
    таблицы «| a | b |», **жирное начало** — заголовок пункта; разметка (**, *, `, ссылки) убирается.
    Строки одного абзаца, разбитые переносами, склеиваются."""
    from ..model import ListItem
    text = decode_text(Path(path).read_bytes())
    model.sources.append(name)
    cur = None
    lines = text.splitlines()
    joinable = False                         # предыдущая строка — абзац, который может продолжаться
    in_code = False
    i = 0

    def section():
        nonlocal cur
        if cur is None:                      # текст до первого раздела — вступление
            cur = Section(title='Введение' if model.title else 'Основное', level=1, source=name)
            model.sections.append(cur)
        return cur

    while i < len(lines):
        raw = lines[i].rstrip()
        i += 1
        if raw.strip().startswith('```'):
            in_code = not in_code
            joinable = False
            continue
        if in_code or not raw.strip() or _MD_RULE.match(raw):
            joinable = False
            continue
        if raw.lstrip().startswith('#'):
            lvl = min(3, len(raw.lstrip()) - len(raw.lstrip().lstrip('#')))
            title = md_inline(raw.lstrip().lstrip('#').strip().rstrip('#'))[0]
            joinable = False
            if not title:
                continue
            if lvl == 1 and not model.title and cur is None:
                model.title = title
                continue
            cur = Section(title=title, level=max(1, lvl - 1 if model.title else lvl), source=name)
            model.sections.append(cur)
            continue
        if _MD_TROW.match(raw):                             # таблица Markdown
            rows = [raw]
            while i < len(lines) and _MD_TROW.match(lines[i].rstrip()):
                rows.append(lines[i].rstrip())
                i += 1
            joinable = False
            body = [r for r in rows if not _MD_TSEP.match(r)]
            cells = [_md_cells(r) for r in body]
            w = max(len(r) for r in cells)
            cells = [(r + [''] * w)[:w] for r in cells]
            has_head = len(rows) >= 2 and _MD_TSEP.match(rows[1])
            if len(cells) >= 2 and w >= 2:
                header, data = (cells[0], cells[1:]) if has_head else ([f'Столбец {k + 1}' for k in range(w)], cells)
                tb = model.add_table(header, data, source=name)
                section().blocks.append(Block('table', table_id=tb.id))
            else:
                section().blocks.append(Block('para', text=' — '.join(c for c in cells[0] if c)))
            continue
        st = raw.lstrip()
        if st.startswith('>'):
            st = st.lstrip('> ').strip()
        mark = False
        if st.startswith('!') or st.startswith('[!]'):            # «!» в начале строки — выделено автором
            mark = True
            st = st.lstrip('![] ').strip()
        part = ''
        mm = re.search(r'==(.+?)==', st)                         # ==выделенный фрагмент== (Markdown)
        if mm:
            part = clean(md_inline(mm.group(1))[0])
            st = st.replace(mm.group(0), mm.group(1))
        ml = _MD_LIST.match(raw if not raw.lstrip().startswith('>') else st)
        sec = section()
        if ml:
            indent = len(ml.group(1).replace('\t', '    '))
            body = st[len(ml.group(0)) - len(ml.group(1)):] if ml.group(0).startswith(ml.group(1)) else st
            body = _MD_LIST.sub('', st, count=1)
            if body.startswith('!'):                             # «- ! важный пункт»
                mark, body = True, body.lstrip('! ')
            txt, bold = md_inline(body)
            if not txt:
                continue
            item = ListItem(txt, bold=bold, level=min(2, indent // 2), mark=mark or bool(part))
            ordered = ml.group(2)[0].isdigit()
            if sec.blocks and sec.blocks[-1].kind == 'list':
                sec.blocks[-1].items.append(item)
            else:
                sec.blocks.append(Block('list', items=[item], ordered=ordered))
            joinable = 'item'
            continue
        txt, bold = md_inline(st)
        if not txt:
            continue
        prev = sec.blocks[-1] if sec.blocks else None
        if joinable == 'item' and raw[:1] in ' \t' and prev is not None and prev.kind == 'list':
            it = prev.items[-1]                                  # продолжение пункта на следующей строке
            it.text = clean(it.text + ' ' + txt)
            continue
        if joinable is True and prev is not None and prev.kind == 'para' and not mark and \
                (not re.search(r'[.!?:;»")]$', prev.text) or txt[:1].islower()):
            prev.text = clean(prev.text + ' ' + txt)             # строка — продолжение абзаца
            continue
        sec.blocks.append(Block('para', text=txt, bold=bold, mark=mark, mark_text=part))
        joinable = True
    return model


def read_files(files, progress=None):
    """files — список пар (путь_к_временному_файлу, исходное_имя_файла).
    Порядок: сначала текстовые документы (Word, PDF, презентации, текст) — это «рассказ», затем
    таблицы (Excel, CSV, JSON) — это данные к нему; внутри группы — в порядке загрузки.
    progress(event) — ход чтения ({'phase': 'read', 'file': имя, …}); отмена (llm_client.Cancelled),
    брошенная из него, прерывает чтение и пробрасывается наверх."""
    from ..llm_client import Cancelled
    tick = progress or (lambda e: None)
    model = Document()
    text_first = sorted(files, key=lambda f: 0 if Path(f[1]).suffix.lower() in TEXT_FIRST else 1)
    for path, name in text_first:
        ext = Path(name).suffix.lower()
        tick({'phase': 'read', 'file': name})
        try:
            if ext == '.docx':
                read_docx(path, model, name)
            elif ext == '.pdf':
                read_pdf(path, model, name)
            elif ext == '.pptx':
                read_pptx(path, model, name, progress)
            elif ext == '.json':
                read_json(path, model, name)
            elif ext in ('.xlsx', '.xlsm'):
                read_xlsx(path, model, name)
            elif ext == '.csv':
                read_csv(path, model, name)
            elif ext in ('.txt', '.md'):
                read_text(path, model, name)
            elif ext in ('.doc', '.xls', '.ppt'):
                model.warnings.append(f'{name}: старый формат {ext} не поддерживается — пересохраните файл как '
                                      f'{ext}x (Файл → Сохранить как).')
            else:
                model.warnings.append(f'{name}: формат {ext or "без расширения"} не поддерживается.')
        except Cancelled:
            raise
        except Exception as e:                       # повреждённый файл не должен ронять всё
            model.warnings.append(f'{name}: не удалось прочитать файл ({type(e).__name__}: {e}).')
    return model
