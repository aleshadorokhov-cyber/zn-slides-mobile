# -*- coding: utf-8 -*-
"""
xlsx_reader.py — ЧТЕНИЕ EXCEL (.xlsx/.xlsm) И CSV В МОДЕЛЬ ДОКУМЕНТА
===================================================================

Каждый видимый лист Excel становится разделом. На листе ищутся блоки данных —
прямоугольные области, разделённые пустыми строками:
  * блок из ≥ 2 строк и ≥ 2 столбцов — ТАБЛИЦА (первая строка блока — шапка);
  * строка из одной ячейки над таблицей — НАЗВАНИЕ таблицы;
  * одиночные текстовые ячейки — АБЗАЦЫ (комментарии, выводы на листе).

Значения берутся «как видит пользователь»: для формул — последнее рассчитанное Excel
значение (если файл сохранён в Excel). Проценты (формат ячейки «0 %») переводятся
в проценты: 0,25 → 25 с единицей «%». Даты — в вид «ДД.ММ.ГГГГ» или «ГГГГ».
"""
import csv
import datetime as dt
import io
import os
import re

from openpyxl import load_workbook

from ..model import Block, Document, Section
from ..textutil import clean, fmt_number


def _cell_text(c):
    """Значение ячейки → (строка для показа, единица измерения или '')."""
    v = c.value
    if v is None:
        return '', ''
    fmt = (c.number_format or '').lower()
    if isinstance(v, bool):
        return ('Да' if v else 'Нет'), ''
    if isinstance(v, (int, float)):
        if float(v).is_integer() and 1900 <= v <= 2100 and ('general' in fmt or fmt in ('0', '')):
            return str(int(v)), ''                      # год — без разделителя разрядов
        if '%' in fmt:
            return fmt_number(v * 100), '%'
        m = re.search(r'0[.,](0+)', fmt)                 # «0.00» → 2 знака после запятой
        dec = min(len(m.group(1)), 4) if m else (0 if re.fullmatch(r'[#0, ]*0', fmt) else None)
        return fmt_number(float(v), dec), ''
    if isinstance(v, dt.datetime) or isinstance(v, dt.date):
        if isinstance(v, dt.datetime) and (v.hour or v.minute):
            return v.strftime('%d.%m.%Y %H:%M'), ''
        if 'yy' in fmt and 'd' not in fmt and 'm' not in fmt:
            return v.strftime('%Y'), ''
        if 'mmm' in fmt or ('m' in fmt and 'd' not in fmt):
            return v.strftime('%m.%Y'), ''
        return v.strftime('%d.%m.%Y'), ''
    return clean(str(v)), ''


MAX_ROWS, MAX_COLS = 2000, 60           # защита от «раздутых» листов
BIG_FILE = 4 * 1024 * 1024              # файлы больше 4 МБ читаются в экономном режиме


def _grid(ws, read_only=False):
    """Лист → (сетка текстов, сетка единиц, сетка «копий» объединённых ячеек).

    Объединённая по горизонтали ячейка повторяется во всех столбцах диапазона (так
    двухуровневая шапка «2023 → План | Факт» сохраняет год над каждым столбцом), но такие
    повторы помечаются как «копии» — при подсчёте заполненных ячеек они не учитываются
    (название таблицы, объединённое на всю ширину, остаётся «одной ячейкой»).
    По вертикали объединение не повторяется (ячейки ниже остаются пустыми).
    """
    rows, units, copies = [], [], []
    if read_only:                         # экономный режим: без обработки объединений
        for r in ws.iter_rows(min_row=1, max_row=MAX_ROWS, max_col=MAX_COLS):
            row, urow = [], []
            for c in r:
                txt, u = _cell_text(c) if getattr(c, 'value', None) is not None else ('', '')
                row.append(txt)
                urow.append(u)
            rows.append(row)
            units.append(urow)
            copies.append([False] * len(row))
        width = max((len(r) for r in rows), default=0)
        pad = lambda g, v: [r + [v] * (width - len(r)) for r in g]
        return pad(rows, ''), pad(units, ''), pad(copies, False)
    merged = {}
    for rng in ws.merged_cells.ranges:
        tl = ws.cell(rng.min_row, rng.min_col)
        for r in range(rng.min_row, rng.max_row + 1):
            for c in range(rng.min_col, rng.max_col + 1):
                if (r, c) != (rng.min_row, rng.min_col):
                    merged[(r, c)] = (rng.min_row, rng.min_col, tl)
    max_r, max_c = min(ws.max_row or 0, MAX_ROWS), min(ws.max_column or 0, MAX_COLS)
    for r in range(1, max_r + 1):
        row, urow, crow = [], [], []
        for c in range(1, max_c + 1):
            if (r, c) in merged:
                mr, mc, tl = merged[(r, c)]
                txt, u = _cell_text(tl) if mr == r else ('', '')
                crow.append(mr == r)                 # копия по горизонтали
            else:
                txt, u = _cell_text(ws.cell(r, c))
                crow.append(False)
            row.append(txt)
            urow.append(u)
        rows.append(row)
        units.append(urow)
        copies.append(crow)
    return rows, units, copies


def _blocks(rows):
    """Делит сетку на блоки, разделённые пустыми строками: [(первая строка, последняя)]."""
    out, start = [], None
    for i, r in enumerate(rows):
        empty = not any(x.strip() for x in r)
        if not empty and start is None:
            start = i
        if empty and start is not None:
            out.append((start, i - 1))
            start = None
    if start is not None:
        out.append((start, len(rows) - 1))
    return out


def _filled(row, crow):
    """Число заполненных ячеек строки без учёта «копий» объединённых ячеек."""
    return sum(1 for x, c in zip(row, crow) if x.strip() and not c)


def _is_num(s):
    from ..textutil import parse_number
    return parse_number(s) is not None


def _add_grid_to_section(model, sec, rows, units, source, title_hint='', copies=None):
    copies = copies or [[False] * len(r) for r in rows]
    blocks = _blocks(rows)
    for k, (a, b) in enumerate(blocks):
        # отдельная строка из одной ячейки перед таблицей (через пустую строку) — название таблицы
        if a == b and _filled(rows[a], copies[a]) == 1 and k + 1 < len(blocks):
            na, nb = blocks[k + 1]
            if nb > na and max(_filled(r, c) for r, c in zip(rows[na:nb + 1], copies[na:nb + 1])) >= 2:
                title_hint = next(x for x in rows[a] if x.strip())
                continue
        block, ublock, cblock = rows[a:b + 1], units[a:b + 1], copies[a:b + 1]
        keep = [j for j in range(len(block[0])) if any(j < len(r) and r[j].strip() for r in block)]
        block = [[r[j] for j in keep] for r in block]
        ublock = [[u[j] for j in keep] for u in ublock]
        cblock = [[c[j] for j in keep] for c in cblock]
        if not block:
            continue
        filled = [_filled(r, c) for r, c in zip(block, cblock)]
        # одиночные строки сверху — название таблицы или комментарий
        title = title_hint
        while block and filled[0] == 1 and len(block) > 2:
            t = next(x for x in block[0] if x.strip())
            if not title:
                title = t
            else:
                sec.blocks.append(Block('para', text=t))
            block, ublock, cblock, filled = block[1:], ublock[1:], cblock[1:], filled[1:]
        if len(block) >= 2 and max(filled) >= 2:
            header = list(block[0])
            start = 1
            # двухуровневая шапка: в 1-й строке объединения (год над «План | Факт»),
            # во 2-й — подписи, а ниже — числа → шапка «2023 План», «2023 Факт»
            if (len(block) >= 3 and any(cblock[0]) and
                    sum(1 for x in block[1] if x.strip() and not _is_num(x)) >= 2 and
                    any(_is_num(x) for x in block[2])):
                header = [' '.join(dict.fromkeys(p for p in (h.strip(), s.strip()) if p)) for h, s in zip(block[0], block[1])]
                start = 2
            body = [r for r in block[start:] if any(x.strip() for x in r)]
            if not any(h.strip() for h in header) or not body:
                continue
            header = [h if h.strip() else (f'Столбец {j + 1}' if j else '') for j, h in enumerate(header)]
            col_units = []
            for j in range(len(header)):
                us = {u[j] for u in ublock[start:] if j < len(u) and u[j]}
                col_units.append(us.pop() if len(us) == 1 else '')
            tb = model.add_table(header, body, title=title, source=source, units=col_units)
            sec.blocks.append(Block('table', table_id=tb.id))
            title_hint = ''
        else:
            for r in block:
                for x in dict.fromkeys(x for x in r if x.strip()):
                    sec.blocks.append(Block('para', text=x))


_MARK_FILLS = {'FFFFFF00', 'FFFFFF99', 'FFFFE699', 'FFFFD966', 'FFFFC000', 'FFFFF2CC', 'FF00FF00', 'FF92D050', 'FFC6EFCE',
               'FFFFEB9C', 'FFFFCCFF', 'FFFF99CC'}


def _marked_cells(ws, max_rows=300, max_cols=40):
    """Тексты ячеек, залитых «маркерными» цветами (жёлтый, салатовый, розовый)."""
    out = set()
    try:
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row or 0, max_rows), max_col=max_cols):
            for c in row:
                f = getattr(c, 'fill', None)
                col = getattr(getattr(f, 'fgColor', None), 'rgb', None) if f is not None and f.fill_type == 'solid' else None
                if isinstance(col, str) and ('FF' + col.upper()[-6:]) in _MARK_FILLS and c.value not in (None, ''):
                    out.add(clean(str(c.value)))
    except Exception:                                # noqa: BLE001
        pass
    return out


def read_xlsx(path, doc_model=None, name=None):
    """Читает .xlsx/.xlsm: каждый видимый лист → раздел с таблицами и абзацами."""
    model = doc_model or Document()
    name = name or str(path)
    model.sources.append(name)
    big = os.path.getsize(path) > BIG_FILE
    wb = load_workbook(path, data_only=True, read_only=big)
    if big:
        model.warnings.append(f'{name}: большой файл — прочитаны первые {MAX_ROWS} строк каждого листа, '
                              'объединённые ячейки не учитываются.')
    any_formula_none = False
    for ws in wb.worksheets:
        if getattr(ws, 'sheet_state', 'visible') != 'visible':
            continue
        rows, units, copies = _grid(ws, read_only=big)
        if not any(any(x.strip() for x in r) for r in rows):
            continue
        title = clean(ws.title)
        sheet_mark = title.startswith('!')
        sec = Section(title=title.lstrip('! ') or title, level=1, source=f'{name} / {ws.title}', mark=sheet_mark)
        _add_grid_to_section(model, sec, rows, units, sec.source, copies=copies)
        if not big:                     # таблица с ячейками, залитыми маркером (жёлтым и т. п.), — выделена
            marked_cells = _marked_cells(ws)
            if marked_cells:
                for b in sec.blocks:
                    if b.kind == 'table':
                        b.mark = True
                    elif b.kind == 'para' and b.text in marked_cells:
                        b.mark = True
        if sec.blocks:
            model.sections.append(sec)
            # «пустые» формулы: в файле нет сохранённых значений (файл не из Excel)
            for b in sec.blocks:
                if b.kind == 'table':
                    t = model.tables[b.table_id]
                    if t.rows and all(all(not c for c in r[1:]) for r in t.rows):
                        any_formula_none = True
    if big:
        wb.close()
    if any_formula_none:
        model.warnings.append(f'{name}: в некоторых таблицах нет значений — возможно, формулы не пересчитаны. '
                              'Откройте файл в Excel и сохраните его.')
    if not model.title and model.sections:
        model.title = clean(str(name).replace('\\', '/').split('/')[-1].rsplit('.', 1)[0]).replace('_', ' ')
    return model


class _Semicolon(csv.excel):
    delimiter = ';'


class _Tab(csv.excel):
    delimiter = '\t'


def _csv_dialect(text):
    """Разделитель CSV. Русский Excel сохраняет CSV через «;», а запятая — десятичный знак,
    поэтому «;» выбирается, если он есть в каждой непустой строке; затем табуляция; иначе «,»."""
    lines = [l for l in text.splitlines()[:200] if l.strip()]
    if lines and all(';' in l for l in lines):
        return _Semicolon
    if lines and all('\t' in l for l in lines):
        return _Tab
    return csv.excel


def read_csv(path, doc_model=None, name=None):
    """Читает .csv (разделитель определяется автоматически, кодировка UTF-8 или Windows-1251)."""
    model = doc_model or Document()
    name = name or str(path)
    from . import decode_text
    text = decode_text(open(path, 'rb').read())
    dialect = _csv_dialect(text)
    rows = [[clean(x) for x in r] for r in csv.reader(io.StringIO(text), dialect)]
    width = max((len(r) for r in rows), default=0)
    rows = [r + [''] * (width - len(r)) for r in rows]
    units = [[''] * width for _ in rows]
    title = clean(str(name).replace('\\', '/').split('/')[-1].rsplit('.', 1)[0]).replace('_', ' ')
    sec = Section(title=title, level=1, source=name)
    model.sources.append(name)
    _add_grid_to_section(model, sec, rows, units, name)
    if sec.blocks:
        model.sections.append(sec)
    if not model.title:
        model.title = title
    return model
