# -*- coding: utf-8 -*-
"""
json_reader.py — ЧТЕНИЕ ФАЙЛОВ JSON В МОДЕЛЬ ДОКУМЕНТА
=====================================================

JSON — данные из других систем (выгрузки, отчёты, справочники). Структура переводится в разделы,
пункты и таблицы так, как её прочитал бы человек:

  * «title» / «name» / «название» верхнего уровня — название документа, «subtitle» / «description» /
    «описание» — подзаголовок.
  * Простые значения («Добыча, тыс. т»: 3380) — пункты «Ключ: значение»; длинный текст — абзац.
  * Список объектов с простыми полями ([{"год": 2024, "план": 3250, "факт": 3310}, …]) — таблица;
    список «заголовок + текст» ([{"title": "…", "text": "…"}]) — пункты с жирным началом; список
    сложных объектов — подразделы.
  * Объект из чисел ({"2024": 3310, "2025": 3380}), объект объектов из чисел ({"План": {"2024": …},
    "Факт": {…}}) и столбцы одинаковой длины ({"год": […], "план": […]}) — таблицы: по ним строятся
    диаграммы.
  * Вложенный объект — подраздел (до 3-го уровня; глубже — пункты с путём ключей).
  * Список строк — пункты.
Сохранённый план конструктора ({"meta": …, "slides": [{"layout": …}]}) читается его слайдами: слайд —
раздел, карточки и показатели — пункты, таблицы и данные диаграмм — таблицы. В веб-интерфейсе такой
файл, брошенный в «Материалы», сразу открывается как план. Поддерживается и JSON Lines (объект в строке).
Числа переносятся как есть, без округления.
"""
import json
import re
from pathlib import Path

from ..model import Block, ListItem, Section
from ..textutil import clean, sentences
from .pdf_reader import WORD_RX, _add_item, _join_head

TITLE_KEYS = ('title', 'name', 'название', 'наименование', 'заголовок', 'тема', 'subject', 'caption')
SUB_KEYS = ('subtitle', 'description', 'описание', 'подзаголовок', 'summary', 'аннотация', 'annotation')
HEAD_KEYS = TITLE_KEYS + ('label', 'подпись', 'пункт', 'item', 'key', 'ключ')
TEXT_KEYS = ('text', 'текст', 'description', 'описание', 'body', 'content', 'содержание', 'details', 'value',
             'значение', 'comment', 'комментарий', 'note', 'примечание')
MAX_ROWS, MAX_COLS, MAX_SECS = 1000, 30, 300
RASTER = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tif', '.tiff'}


def _scalar(v):
    return v is None or isinstance(v, (str, int, float, bool))


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _fmt(v):
    """Значение → строка: числа без округления (десятичная запятая), да/нет, текст как есть."""
    if v is None:
        return ''
    if isinstance(v, bool):
        return 'да' if v else 'нет'
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        if v != v or v in (float('inf'), float('-inf')):
            return ''
        return str(int(v)) if v.is_integer() and abs(v) < 1e15 else repr(v).replace('.', ',')
    if isinstance(v, (list, tuple)):
        return '; '.join(_fmt(x) for x in v if _scalar(x) and _fmt(x))
    return clean(str(v))


KEY_RU = {'name': 'Название', 'title': 'Название', 'label': 'Подпись', 'value': 'Значение', 'year': 'Год',
          'date': 'Дата', 'month': 'Месяц', 'quarter': 'Квартал', 'period': 'Период', 'id': '№', 'unit': 'Единицы',
          'units': 'Единицы', 'total': 'Итого', 'plan': 'План', 'fact': 'Факт', 'actual': 'Факт', 'status': 'Статус',
          'description': 'Описание', 'text': 'Текст', 'comment': 'Комментарий', 'type': 'Тип', 'category': 'Категория'}


def _human(key):
    """Ключ → подпись: «production_plan» → «Production plan», «oilProduction» → «Oil production», «name» → «Название»."""
    k = str(key).strip()
    if k.lower() in KEY_RU:
        return KEY_RU[k.lower()]
    if re.fullmatch(r'[A-Za-z][A-Za-z0-9]*([A-Z][a-z0-9]+)+', k):
        k = re.sub(r'(?<=[a-z0-9])([A-Z])', r' \1', k).lower()
    k = clean(re.sub(r'[_]+', ' ', k))
    return k[:1].upper() + k[1:] if k else 'Без названия'


def _yearlike(keys):
    keys = [str(k).strip() for k in keys]
    return bool(keys) and all(re.fullmatch(r'(19|20)\d\d(\s*г\.?)?|[1-4]\s*кв\.?\s*(19|20)\d\d|q[1-4][\s-]*(19|20)\d\d|'
                                           r'(19|20)\d\d[-./]\d{1,2}', k, re.I) for k in keys)


def _pick(d, keys):
    """Первое короткое строковое значение по одному из ключей (без учёта регистра)."""
    low = {str(k).lower(): k for k in d}
    for k in keys:
        if k in low and isinstance(d[low[k]], str) and d[low[k]].strip():
            return low[k]
    return None


class _Reader:
    def __init__(self, model, name):
        self.model, self.name, self.count, self.cut = model, name, 0, False

    def sec(self, title, level, parent):
        self.count += 1
        s = Section(title=clean(title)[:120] or 'Без названия', level=min(level, 3), source=self.name)
        (parent.children if parent is not None else self.model.sections).append(s)
        return s

    def table(self, sec, columns, rows, title):
        if len(rows) > MAX_ROWS:
            self.model.warnings.append(f'{self.name}: в «{title}» {len(rows)} строк — взяты первые {MAX_ROWS}.')
            rows = rows[:MAX_ROWS]
        columns = [clean(str(c)) or f'Столбец {k + 1}' for k, c in enumerate(columns[:MAX_COLS])]
        w = len(columns)
        rows = [([_fmt(c) for c in r] + [''] * w)[:w] for r in rows]
        tb = self.model.add_table(columns, rows, title=title, source=self.name)
        sec.blocks.append(Block('table', table_id=tb.id))

    # --- виды значений
    @staticmethod
    def kind(v):
        if _scalar(v):
            return 'scalar'
        if isinstance(v, dict):
            vals = list(v.values())
            if len(vals) >= 2 and all(_num(x) or x is None for x in vals) and any(_num(x) for x in vals):
                return 'numdict'
            if vals and all(isinstance(x, dict) and x and all(_num(y) or y is None for y in x.values())
                            for x in vals):
                return 'dictdict'
            lists = [x for x in vals if isinstance(x, list)]
            if len(vals) >= 2 and len(lists) == len(vals) and len({len(x) for x in lists}) == 1 and \
                    len(lists[0]) >= 2 and all(_scalar(y) for x in lists for y in x):
                return 'columns'
            return 'dict'
        if isinstance(v, list):
            if not v:
                return 'empty'
            if all(_scalar(x) for x in v):
                return 'scalars'
            if all(isinstance(x, dict) for x in v):
                flat = all(all(_scalar(y) or (isinstance(y, list) and all(_scalar(z) for z in y)) or
                               (isinstance(y, dict) and all(_scalar(z) for z in y.values())) for y in x.values())
                           for x in v)
                if flat:
                    keys = {str(k).lower() for x in v for k in x}
                    head = any(k in keys for k in HEAD_KEYS)
                    longtext = [len(str(x.get(k) or '')) for x in v for k in x if str(k).lower() in TEXT_KEYS and
                                isinstance(x.get(k), str)]
                    if head and len(keys) <= 4 and longtext and sum(longtext) / len(longtext) >= 40:
                        return 'cards'
                    return 'records'
                return 'objects'
            return 'mixed'
        return 'scalar'

    def scalar_item(self, sec, key, v):
        t = _fmt(v)
        if not t:
            return
        k = _human(key)
        if isinstance(v, str) and len(t) > 150:
            sec.blocks.append(Block('para', text=_join_head(k, t), bold=k))
        else:
            _add_item(sec, ListItem(f'{k}: {t}', k), False)

    def value(self, key, v, level, parent, holder):
        """Значение ключа key → блоки раздела holder (простые) или новый раздел уровня level."""
        if self.count >= MAX_SECS:
            if not self.cut:
                self.model.warnings.append(f'{self.name}: файл очень большой — прочитаны первые {MAX_SECS} разделов.')
                self.cut = True
            return
        kind = self.kind(v)
        title = _human(key)
        if kind == 'scalar':
            self.scalar_item(holder(), key, v)
        elif kind == 'empty':
            return
        elif kind == 'scalars':
            vals = [_fmt(x) for x in v if _fmt(x)]
            if all(_num(x) for x in v if x is not None):
                _add_item(holder(), ListItem(f'{title}: {", ".join(vals)}', title), False)
                return
            s = self.sec(title, level, parent)
            for t in vals:
                _add_item(s, ListItem(t), False)
        elif kind == 'numdict':
            s = self.sec(title, level, parent)
            first = 'Год' if _yearlike(v.keys()) else 'Показатель'
            self.table(s, [first, title], [[str(k), x] for k, x in v.items()], title)
        elif kind == 'dictdict':
            s = self.sec(title, level, parent)
            inner = list(dict.fromkeys(k for x in v.values() for k in x))
            if _yearlike(inner) and not _yearlike(v.keys()):      # годы — подписи, объекты — ряды
                cols = ['Год'] + [str(k) for k in v]
                rows = [[k] + [x.get(k) for x in v.values()] for k in inner]
            else:
                cols = ['Год' if _yearlike(v.keys()) else 'Показатель'] + [str(k) for k in inner]
                rows = [[k] + [x.get(c) for c in inner] for k, x in v.items()]
            self.table(s, cols, rows, title)
        elif kind == 'columns':
            s = self.sec(title, level, parent)
            keys = list(v)
            self.table(s, [_human(k) for k in keys], [list(r) for r in zip(*[v[k] for k in keys])], title)
        elif kind == 'records':
            s = self.sec(title, level, parent)
            cols = []
            for rec in v:
                for k, x in rec.items():
                    names = [f'{k}.{kk}' for kk in x] if isinstance(x, dict) else [k]
                    for n in names:
                        if n not in cols:
                            cols.append(n)
            rows = []
            for rec in v:
                row = []
                for c in cols:
                    if c in rec:
                        row.append(rec[c])
                    elif '.' in c and isinstance(rec.get(c.split('.', 1)[0]), dict):
                        row.append(rec[c.split('.', 1)[0]].get(c.split('.', 1)[1]))
                    else:
                        row.append(None)
                rows.append(row)
            self.table(s, [_human(c) for c in cols], rows, title)
        elif kind == 'cards':
            s = self.sec(title, level, parent)
            for rec in v:
                hk, tk = _pick(rec, HEAD_KEYS), _pick(rec, TEXT_KEYS)
                head = _fmt(rec[hk]) if hk else ''
                body = _fmt(rec[tk]) if tk and tk != hk else ''
                rest = [f'{_human(k)}: {_fmt(x)}' for k, x in rec.items() if k not in (hk, tk) and _fmt(x)]
                body = clean(' '.join([body] + [r + '.' for r in rest])) if rest else body
                if head:
                    _add_item(s, ListItem(_join_head(head, body), head), False)
                elif body:
                    _add_item(s, ListItem(body), False)
        elif kind == 'objects':
            s = self.sec(title, level, parent)
            for n, rec in enumerate(v, 1):
                if not isinstance(rec, dict):
                    continue
                hk = _pick(rec, TITLE_KEYS)
                name = _fmt(rec[hk]) if hk else f'{title} {n}'
                self.obj({k: x for k, x in rec.items() if k != hk}, min(level + 1, 3), s, name)
        elif kind == 'mixed':
            s = self.sec(title, level, parent)
            for n, x in enumerate(v, 1):
                self.value(f'{title} {n}' if not _scalar(x) else title, x, min(level + 1, 3), s, lambda s=s: s)
        else:                                      # вложенный объект
            if level > 3:                          # глубже 3-го уровня — пункты с путём ключей
                for k, x in v.items():
                    self.value(f'{key} — {k}', x, 3, parent, holder)
                return
            s = self.sec(title, level, parent)
            self.obj(v, level + 1, s, None)

    def obj(self, d, level, sec, name):
        """Объект → блоки раздела sec (простые значения) и подразделы (сложные)."""
        target = {'s': sec}
        if name is not None:
            target['s'] = self.sec(name, min(level, 3), sec)

        def holder():
            return target['s']
        for k, x in d.items():
            self.value(k, x, min(level + (1 if name is not None else 0), 4), target['s'], holder)


# ---------------------------------------------------------------- план конструктора

def is_plan(data):
    """Сохранённый план конструктора: {"meta": {...}, "slides": [{"layout": …}, …]}."""
    return isinstance(data, dict) and isinstance(data.get('slides'), list) and \
        any(isinstance(s, dict) and isinstance(s.get('layout'), str) for s in data['slides'])


def _txt(v):
    if isinstance(v, dict):
        return clean(' '.join(str(v.get(k) or '') for k in ('title', 'text') if v.get(k)))
    return clean(str(v or ''))


def _new_lines(text, seen):
    """Заметки докладчика: предложения, в которых есть то, чего нет на слайде (по строкам заметок)."""
    out = []
    for line in str(text or '').splitlines():
        keep = []
        for t in sentences(line):
            words = [w.lower() for w in WORD_RX.findall(t) if len(w) > 2]
            if len(words) >= 3 and sum(1 for w in words if w not in seen) >= 0.3 * len(words):
                keep.append(t)
        if keep:
            out.append(clean(' '.join(keep)))
    return out if sum(len(t) for t in out) >= 40 else []


def _plan(data, model, name):
    meta = data.get('meta') if isinstance(data.get('meta'), dict) else {}
    if not model.title and clean(meta.get('title')):
        model.title = clean(meta.get('title'))
    if not model.subtitle and clean(meta.get('subtitle')):
        model.subtitle = clean(meta.get('subtitle'))
    prev = None
    for i, sl in enumerate(data['slides'], 1):
        if not isinstance(sl, dict):
            continue
        lay = sl.get('layout')
        if lay in ('title', 'end', 'agenda'):
            continue
        title = clean(sl.get('title')) or f'Слайд {i}'
        base = re.sub(r'\s*\(продолжение\)$', '', title)
        if prev is not None and base != title and prev.title == base:
            sec = prev                             # «(продолжение)» — в тот же раздел
        else:
            sec = Section(title=base, level=1, source=name)
            model.sections.append(sec)
        prev = sec
        if lay == 'section':
            continue
        for k in ('subtitle', 'lead', 'center', 'aside'):
            if clean(sl.get(k)) and clean(sl.get(k)) != base:
                sec.blocks.append(Block('para', text=clean(sl.get(k))))
        for p in sl.get('paragraphs') or []:
            if _txt(p):
                sec.blocks.append(Block('para', text=_txt(p)))
        ordered = lay in ('process', 'timeline', 'stairs', 'roadmap', 'path', 'gantt')
        for it in sl.get('items') or []:
            if not isinstance(it, dict):
                if _txt(it):
                    _add_item(sec, ListItem(_txt(it)), ordered)
                continue
            t, x = clean(it.get('title')), clean(it.get('text'))
            label, value, unit = clean(it.get('label')), clean(it.get('value')), clean(it.get('unit'))
            if value:
                head = t or x
                _add_item(sec, ListItem(clean(f'{head} — {value} {unit}') if head else clean(f'{value} {unit}')),
                          ordered)
                if t and x:
                    _add_item(sec, ListItem(x, '', 1), ordered)
                continue
            head = clean(f'{label}. {t}') if label and t else (t or label)
            if head and x:
                _add_item(sec, ListItem(_join_head(head, x), head), ordered)
            elif head or x:
                _add_item(sec, ListItem(head or x), ordered)
        for side in ('left', 'right'):
            v = sl.get(side)
            if isinstance(v, dict) and v.get('items'):
                h = clean(v.get('title')) or ('Было' if side == 'left' else 'Стало')
                _add_item(sec, ListItem(h, h), False)
                for x in v['items']:
                    if _txt(x):
                        _add_item(sec, ListItem(_txt(x), '', 1), False)
        if isinstance(sl.get('columns'), list) and isinstance(sl.get('rows'), list) and sl['columns']:
            cols = [clean(str(c)) for c in sl['columns']]
            w = len(cols)
            rows = [([_fmt(c) for c in r] + [''] * w)[:w] for r in sl['rows'] if isinstance(r, list)]
            tb = model.add_table(cols, rows, title=base, source=name)
            sec.blocks.append(Block('table', table_id=tb.id))
        ch = sl.get('chart')
        if isinstance(ch, dict) and ch.get('categories') and ch.get('series'):
            cats = [clean(str(c)) for c in ch['categories']]
            series = [s for s in ch['series'] if isinstance(s, dict)]
            unit, unit2 = clean(ch.get('unit')), clean(ch.get('unit2'))
            cols = ['Год' if _yearlike(cats) else 'Показатель'] + [clean(s.get('name')) or 'Ряд' for s in series]
            rows = [[c] + [_fmt((s.get('values') or [])[k]) if k < len(s.get('values') or []) else ''
                           for s in series] for k, c in enumerate(cats)]
            units = [''] + [unit2 if ch.get('type') == 'combo' and j == len(series) - 1 and unit2 else unit
                            for j in range(len(series))]
            tb = model.add_table(cols, rows, title=base, source=name, units=units)
            sec.blocks.append(Block('table', table_id=tb.id))
        for x in sl.get('insights') or []:
            if _txt(x):
                _add_item(sec, ListItem(_txt(x)), False)
        for im in sl.get('images') or []:
            if not isinstance(im, dict):
                continue
            path = im.get('path')
            if im.get('upload'):
                from ..pictures import upload_path
                path = upload_path(str(im['upload']))
            if path and Path(path).suffix.lower() in RASTER and Path(path).exists():
                sec.blocks.append(Block('image', image_id=model.add_image(path, caption=clean(im.get('caption')))))
        if clean(sl.get('conclusion')):
            c = clean(sl.get('conclusion'))
            sec.blocks.append(Block('para', text=c if re.match(r'(?i)вывод', c) else f'Вывод: {c}', bold='Вывод'))
        seen = {w.lower() for w in WORD_RX.findall(base + ' ' + sec.all_text(False))}
        for t in _new_lines(sl.get('notes'), seen):
            sec.blocks.append(Block('para', text=t))
    model.sections[:] = [s for s in model.sections if s.blocks or s.children or s.title]


# ---------------------------------------------------------------- главная функция

def load_json(raw):
    """Текст файла → данные JSON (или JSON Lines); ValueError, если это не JSON."""
    try:
        return json.loads(raw)
    except ValueError as e:
        lines = [ln for ln in raw.splitlines() if ln.strip()]
        if len(lines) >= 2:
            try:
                return [json.loads(ln) for ln in lines]
            except ValueError:
                pass
        raise e


def read_json(path, model, name):
    """Читает .json и добавляет его содержимое в модель Document."""
    from . import decode_text
    model.sources.append(name)
    raw = decode_text(Path(path).read_bytes())
    try:
        data = load_json(raw)
    except ValueError as e:
        where = f' (строка {e.lineno})' if hasattr(e, 'lineno') else ''
        model.warnings.append(f'{name}: это не JSON{where} — проверьте файл (например, откройте его в Блокноте).')
        return model
    if is_plan(data):
        _plan(data, model, name)
        return model
    r = _Reader(model, name)
    stem = _human(Path(name).stem)
    if isinstance(data, dict):
        tk, sk = _pick(data, TITLE_KEYS), _pick(data, SUB_KEYS)
        if tk and len(data[tk]) <= 160 and not model.title:
            model.title = clean(data[tk])
        if sk and len(data[sk]) <= 300 and not model.subtitle:
            model.subtitle = clean(data[sk])
        rest = {k: v for k, v in data.items() if k not in (tk, sk) or (k == sk and len(str(v)) > 300)}
        intro = {'s': None}

        def holder():
            if intro['s'] is None:
                intro['s'] = r.sec('Общие сведения' if model.title else stem, 1, None)
            return intro['s']
        for k, v in rest.items():
            r.value(k, v, 1, None, holder)
    elif isinstance(data, list):
        r.value(stem, data, 1, None, lambda: r.sec(stem, 1, None))
    else:
        s = r.sec(stem, 1, None)
        r.scalar_item(s, stem, data)
    if not model.title:
        model.title = stem
    if not any(s.source == name for s in model.sections):
        model.warnings.append(f'{name}: в файле JSON нет данных.')
    return model
