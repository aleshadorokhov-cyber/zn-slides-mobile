# -*- coding: utf-8 -*-
"""
pdf_reader.py — ЧТЕНИЕ PDF В МОДЕЛЬ ДОКУМЕНТА
============================================

В PDF нет стилей Word: есть только символы с координатами, шрифтом и цветом. Структура
восстанавливается по оформлению — и получается та же модель Document, что из Word:

  * Строки собираются из символов по положению на странице, а не по порядку в файле
    (Word и LibreOffice пишут кусочки одной строки разными шрифтами вперемешку).
  * Колонки: если на странице есть явный просвет между колонками текста, сначала читается
    левая колонка, затем правая (строки колонок не перемешиваются).
  * Абзацы — из строк с одинаковым шрифтом и обычным межстрочным расстоянием; новый абзац —
    по увеличенному интервалу, отступу первой строки или короткой строке с точкой. Абзац,
    перешедший на следующую страницу, склеивается. Переносы «энерго-|эффективность»
    убираются, настоящий дефис («глубинно-|насосного») остаётся.
  * Заголовки — короткие абзацы крупнее основного текста или целиком жирные (как
    «псевдозаголовки» Word), а также короткие строки с номером «2.1», «Раздел 3». Уровень —
    по кеглю (крупнее — выше); при равном кегле — по номеру («1.» выше «1.1»), по цвету и по тому,
    какой вид заголовка встретился раньше.
  * Списки — строки с маркером «•», «–», «1)», «1.», «а)» (и значки шрифтов Symbol/Wingdings);
    продолжение пункта — строки с отступом под текстом пункта. Жирное начало пункта сохраняется.
  * Колонтитулы и номера страниц — строки у верхнего/нижнего края, повторяющиеся на большинстве
    страниц, и «голые» номера («5», «- 5 -», «Стр. 5 из 12») — пропускаются.
  * Название документа — из свойств PDF (если похоже на название) или самая крупная строка
    первой страницы; в тексте оно не повторяется.
  * Таблицы — только с линиями сетки (таблицы Word с границами): ячейки по линиям, объединённые
    ячейки, продолжение таблицы на следующей странице. Таблицы без границ не распознаются —
    их текст идёт абзацами (ложная таблица хуже, чем никакой).
  * Пометки автора: маркер (заливка под текстом — так Word сохраняет выделение маркером),
    примечание-выделение PDF (Highlight), красный шрифт, «!» в начале абзаца или пункта.
  * Рисунки — растровые картинки от ~200 пикселей (в кэш output/cache, как рисунки Word);
    логотипы, повторяющиеся на страницах, и картинки во всю страницу (сканы, фон) пропускаются.
Скан без текстового слоя, PDF с паролем или без таблицы символов — понятное предупреждение.
Нужна только библиотека pypdfium2 (версии 4.x и 5.x): без интернета и других программ.
"""
import ctypes
import hashlib
import io
import math
import re
from bisect import bisect_right
from collections import Counter
from pathlib import Path

from ..model import Block, Document, ListItem, Section
from ..textutil import clean
from .docx_reader import MARK_PREFIX_RX, _promote, _save_image, _split_table

try:
    import pypdfium2 as pdfium
    import pypdfium2.raw as pdfium_c
except ImportError:                       # без библиотеки PDF не читается, остальное работает
    pdfium = pdfium_c = None

# Маркеры списков: значки (в т. ч. символы шрифтов Symbol/Wingdings из Word) — всегда пункт;
# тире, «1)», «1.», «а)» — только в начале абзаца (иначе это может быть перенос посреди фразы)
BULLETS = '•●▪■◦○‣⁃∙·►▸▶➢➤✓✔❖□☐' + '\uf0b7\uf0a7\uf076\uf0d8\uf0fc\uf0e8\uf0a8\uf06c\uf06e\uf075\uf0f0\uf0de\uf0d7'
LIST_RX = re.compile(r'^\s*(?:([%s])\s*|([-–—*])\s+|(\(?\d{1,2} ?[.)])\s+|(\(?[а-яёa-z][)])\s+)' % re.escape(BULLETS),
                     re.I)
TOC_RX = re.compile(r'(\.{4,}|…{2,}|(\s\.){3,}|_{4,})\s*\d{1,4}\s*$')         # строка оглавления «Глава … 5»
TOC_HEAD_RX = re.compile(r'(?i)^\s*(содержание|оглавление|contents)\s*$')
NUM_HEAD_RX = re.compile(r'^(\d{1,2}(?:\.\d{1,2}){0,3})\.?\s+\S')
PLAIN_HEAD_RX = re.compile(r'^(\d{1,2}(?:\.\d{1,2}){1,3}\.?|(?:раздел|глава|часть)\s+(?:\d{1,2}|[IVX]{1,5})\.?)'
                           r'\s+[А-ЯЁA-Z]', re.I)
PAGE_RX = re.compile(r'(?i)^[-–—\s]*(?:(?:стр\.?|страница|с\.|лист|page|p\.)\s*)?\d{1,4}\s*(?:(?:из|of|/)\s*\d{1,4})?'
                     r'[-–—\s]*$')
TABLE_CAP_RX = re.compile(r'(?i)^(таблица|табл\.)\s*\d*')
CAPTION_RX = re.compile(r'(?i)^(рис\.|рисунок|схема|фото|диаграмма|figure|fig\.)\s*№?\s*\d+')   # не «Риски…»
TABLE_CAP_CUT = re.compile(r'(?i)^(таблица|табл\.)\s*\d*\s*[.:—–-]?\s*')
FIG_CAP_CUT = re.compile(r'(?i)^(рисунок|рис\.?|схема|фото|диаграмма|figure|fig\.?)\s*№?\s*\d*\s*[.:—–-]?\s*')
JUNK_TITLE_RX = re.compile(r'(?i)^(microsoft\s+\w+\s*-|untitled|без\s+имени|безымянный|document\s*\d*$|документ\s*\d*$|'
                           r'презентация(\s+(microsoft\s+)?power\s*point)?\s*\d*$|(microsoft\s+)?power\s*point'
                           r'(\s+presentation)?\s*\d*$|presentation\s*\d*$|slide\s*\d*$|слайд\s*\d*$)|'
                           r'\.(docx?|pdf|pptx?|xlsx?|rtf|odt|txt)$')
# приставки, которые пишутся слитно: «энерго-|эффективность» → «энергоэффективность»
FUSED = {'энерго', 'электро', 'гидро', 'нефте', 'газо', 'нефтегазо', 'тепло', 'водо', 'авто', 'агро', 'теле', 'радио',
         'микро', 'макро', 'мини', 'мульти', 'много', 'полу', 'само', 'взаимо', 'сверх', 'супер', 'видео', 'фото', 'био',
         'гео', 'эко', 'аэро', 'термо', 'метео', 'ресурсо', 'техно'}
HYPHENS = '-‐\xad'
LETTER_RX = re.compile(r'[A-Za-zА-Яа-яЁё]')


class _Ch:
    """Символ страницы: координаты сверху вниз (t — верх, b — низ), кегль, жирность, цвет, пометка."""
    __slots__ = ('c', 'x0', 'x1', 't', 'b', 'size', 'bold', 'color', 'mark', 'sp', 'i', 'run')

    def __init__(self, c, x0, x1, t, b, size, bold, color, mark, sp, i):
        self.c, self.x0, self.x1, self.t, self.b = c, x0, x1, t, b
        self.size, self.bold, self.color, self.mark, self.sp = size, bold, color, mark, sp
        self.i, self.run = i, 0                  # номер в потоке PDF; номер «кусочка» строки


class _El:
    """Элемент страницы для порядка чтения: сегмент строки ('seg'), таблица или рисунок."""
    __slots__ = ('kind', 'x0', 'x1', 't', 'b', 'chars', 'line', 'data')

    def __init__(self, kind, x0, x1, t, b, chars=None, line=None, data=None):
        self.kind, self.x0, self.x1, self.t, self.b = kind, x0, x1, t, b
        self.chars, self.line, self.data = chars, line, data


class _Line:
    """Строка в порядке чтения (после разбора колонок): текст с пометками по символам."""
    __slots__ = ('page', 'col', 'x0', 'x1', 't', 'b', 'size', 'bold', 'color', 'text', 'bo', 'mk', 'xs',
                 'left', 'right', 'first', 'last', 'pfirst', 'plast', 'sizes')

    def __init__(self, chars, page, col):
        chars = sorted(chars, key=lambda c: c.x0)
        self.page, self.col = page, col
        self.x0, self.x1 = chars[0].x0, max(c.x1 for c in chars)
        sizes = Counter(c.size for c in chars)
        self.size = sizes.most_common(1)[0][0]
        self.sizes = {k: v / len(chars) for k, v in sizes.items()}       # доли символов по кеглю
        main = [c for c in chars if c.size >= self.size - 0.5] or chars
        self.t, self.b = min(c.t for c in main), max(c.b for c in main)
        self.bold = sum(c.bold for c in chars) / len(chars)
        color, k = Counter(c.color for c in chars).most_common(1)[0]
        self.color = color if k >= 0.7 * len(chars) else None    # None — цвет смешанный (выделено слово)
        self.text, self.bo, self.mk, self.xs = _compose(chars)
        self.left, self.right = self.x0, self.x1
        self.first = self.last = False           # первая/последняя строка колонки
        self.pfirst = self.plast = False         # первая/последняя строка страницы


class _Page:
    def __init__(self, no, w, h):
        self.no, self.w, self.h = no, w, h
        self.ratio = w / h if h else 1.0         # ширина/высота листа до поворота текста (альбомный > 1)
        self.slines = None       # строки слайда (_Line по сегментам) — только в режиме презентации
        self.lines = []          # [(верх, низ, кегль, [_El сегменты])] — строки вне таблиц
        self.tables = []         # _El('table'), data = (строки, копии, выделена, x линий)
        self.images = []         # _El('image'), data = (хэш, ширина EMU, высота EMU)
        self.chars = 0
        self.bad = False         # текст без таблицы символов
        self.scan = False        # картинка во всю страницу


# ---------------------------------------------------------------- символы страницы

def _is_bold(name, weight, flags):
    n = name.split('+')[-1].lower()
    return bool(re.search(r'bold|black|heavy|demi|semib|extrab|ultrab|,b$|-b$', n)) or weight >= 600 or \
        bool(flags & 0x40000)


def _marker_color(r, g, b):
    """Цвет маркера-выделителя: жёлтый, ярко-зелёный, бирюзовый, розовый (не серые/бледные заливки таблиц)."""
    return ((r >= 200 and g >= 200 and b <= 150) or (g >= 200 and r <= 150 and b <= 150) or
            (g >= 200 and b >= 200 and r <= 100) or (r >= 200 and b >= 200 and g <= 100))


def _quad_map(q, w, h):
    """Перевод координат PDF (y снизу вверх) в координаты «сверху вниз» с учётом поворота текста:
    → (функция (x, y) → (x, y), ширина, высота страницы в новом положении)."""
    if q == 3:                                   # текст идёт снизу вверх (альбомная страница)
        return (lambda x, y: (y, x)), h, w
    if q == 1:                                   # текст идёт сверху вниз
        return (lambda x, y: (h - y, w - x)), h, w
    if q == 2:                                   # вверх ногами
        return (lambda x, y: (w - x, y)), w, h
    return (lambda x, y: (x, h - y)), w, h


def _page_chars(tp, w, h, marks):
    """Символы страницы (без пробелов): координаты, кегль с учётом масштаба, жирность, цвет, пометка.
    marks — прямоугольники выделения в координатах PDF.
    → (символы, сколько «нечитаемых» символов, поворот текста 0–3, ширина, высота)."""
    raw = tp.raw
    n = pdfium_c.FPDFText_CountChars(raw)
    rect, mtx = pdfium_c.FS_RECTF(), pdfium_c.FS_MATRIX()
    cr, cg, cb, ca = (ctypes.c_uint() for _ in range(4))
    fbuf, flags = ctypes.create_string_buffer(256), ctypes.c_int()
    fonts = {}
    found, bad, space = [], 0, False
    skip = -1
    for i in range(n):
        if i == skip:
            continue
        u = pdfium_c.FPDFText_GetUnicode(raw, i)
        if 0xD800 <= u <= 0xDBFF:                # символ вне BMP (эмодзи) — пара суррогатов UTF-16
            lo = pdfium_c.FPDFText_GetUnicode(raw, i + 1) if i + 1 < n else 0
            if not 0xDC00 <= lo <= 0xDFFF:
                continue
            u, skip = 0x10000 + ((u - 0xD800) << 10) + (lo - 0xDC00), i + 1
        elif 0xDC00 <= u <= 0xDFFF:
            continue
        if u in (2, 0xAD):
            ch = '\xad'                          # мягкий перенос
        elif u <= 32 or u in (0xA0, 0x2028, 0x2029, 0xFEFF) or 0x2000 <= u <= 0x200B:
            space = True
            continue
        elif u == 0xFFFD or u > 0x10FFFF or (0xE000 <= u <= 0xF8FF and chr(u) not in BULLETS):
            bad += 1
            continue
        else:
            ch = chr(u)
        if not pdfium_c.FPDFText_GetLooseCharBox(raw, i, rect):
            continue
        l, r, b, t = rect.left, rect.right, rect.bottom, rect.top
        if r - l <= 0.01 and t - b <= 0.01:
            continue
        ang = pdfium_c.FPDFText_GetCharAngle(raw, i)
        deg = math.degrees(ang) % 360 if ang >= 0 else 0.0
        q = int(round(deg / 90.0)) % 4
        if 10 < abs(deg - q * 90) < 350:
            continue                             # наклонный текст (водяные знаки, подписи осей)
        hb = abs(r - l) if q % 2 else abs(t - b)
        size = pdfium_c.FPDFText_GetFontSize(raw, i)
        if pdfium_c.FPDFText_GetMatrix(raw, i, mtx):
            size *= math.hypot(mtx.c, mtx.d) or 1.0
        if not 0.55 * hb <= size <= 1.5 * hb:    # масштаб задан вне текста — берём высоту символа
            size = hb / 1.15
        pdfium_c.FPDFText_GetFontInfo(raw, i, fbuf, 256, flags)
        key = (fbuf.value, flags.value)
        if key not in fonts:
            fonts[key] = _is_bold(fbuf.value.decode('utf-8', 'replace'), pdfium_c.FPDFText_GetFontWeight(raw, i),
                                  flags.value)
        color = (0, 0, 0)
        if pdfium_c.FPDFText_GetFillColor(raw, i, cr, cg, cb, ca):
            color = (cr.value, cg.value, cb.value)
        cx, cy = (l + r) / 2, (b + t) / 2
        mark = ((color[0] >= 170 and color[1] <= 90 and color[2] <= 90) or
                any(x0 - 1 <= cx <= x1 + 1 and y0 - 1 <= cy <= y1 + 1 for x0, y0, x1, y1 in marks))
        found.append((q, l, r, b, t, _Ch(ch, 0, 0, 0, 0, round(size * 2) / 2, fonts[key], color, mark, space, i)))
        space = False
    if not found:
        return [], bad, 0, w, h
    # текст страницы повёрнут (например, альбомная таблица) — переводим в обычное положение
    q = Counter(f[0] for f in found).most_common(1)[0][0]
    fmap, w2, h2 = _quad_map(q, w, h)
    out, seen = [], set()
    for fq, l, r, b, t, c in found:
        if fq != q:
            continue
        (xa, ya), (xb, yb) = fmap(l, b), fmap(r, t)
        c.x0, c.x1, c.t, c.b = min(xa, xb), max(xa, xb), min(ya, yb), max(ya, yb)
        k = (c.c, round(c.x0), round(c.t))       # текст, напечатанный дважды (имитация жирного)
        if k not in seen:
            seen.add(k)
            out.append(c)
    return out, bad, q, w2, h2


# ---------------------------------------------------------------- строки и сегменты

def _band(r):
    big = max(c.size for c in r)
    main = [c for c in r if c.size >= 0.9 * big]
    return min(c.t for c in main), max(c.b for c in main), big


def _build_lines(chars):
    """Символы (в порядке потока PDF) → строки. Сначала «кусочки» — символы подряд на одной высоте,
    затем кусочки, перекрывающиеся по высоте, — в одну строку слева направо. Строка делится на
    сегменты по большим просветам (колонки, табуляция). → [(верх, низ, кегль, [_El сегменты])]."""
    runs = []
    for c in chars:
        if runs:
            p = runs[-1][-1]
            h = min(p.b - p.t, c.b - c.t)
            if (min(p.b, c.b) - max(p.t, c.t) >= 0.5 * h and
                    -0.3 * p.size <= c.x0 - p.x1 <= 0.8 * max(p.size, c.size)):
                runs[-1].append(c)
                continue
        runs.append([c])
    for k, r in enumerate(runs):
        for c in r:
            c.run = k
    lines = []                                   # [верх, низ, кегль, [(x0, x1, кусочек)], [x0 символов], [x1]]
    for r in sorted(runs, key=lambda r: _band(r)[0]):
        t, b, size = _band(r)
        x0, x1 = min(c.x0 for c in r), max(c.x1 for c in r)
        best, bov = None, 0.0
        for ln in lines[-12:]:
            ov = min(ln[1], b) - max(ln[0], t)
            if ov >= 0.5 * min(ln[1] - ln[0], b - t) and ov > bov and not _collides(ln, r):
                best, bov = ln, ov
        if best is None:
            best = [t, b, size, [], [], []]
            lines.append(best)
        elif size > best[2]:
            best[0], best[1], best[2] = t, b, size
        best[3].append((x0, x1, r))
        for c in r:                              # символы строки по x — для проверки наложений
            k = bisect_right(best[4], c.x0)
            best[4].insert(k, c.x0)
            best[5].insert(k, c.x1)
    out = []
    for t, b, size, parts, _, _ in sorted(lines, key=lambda ln: ln[0]):
        parts.sort(key=lambda p: p[0])
        segs, cur = [], []
        for x0, x1, r in parts:
            if cur and x0 - max(c.x1 for c in cur) > max(1.2 * size, 6) and \
                    not LIST_RX.match(''.join(c.c for c in cur) + ' x'):
                segs.append(cur)                 # большой просвет (маркер списка с табуляцией — не в счёт)
                cur = []
            cur = cur + sorted(r, key=lambda c: c.x0)
        if cur:
            segs.append(cur)
        line = (t, b, size, [])
        for s in segs:
            line[3].append(_El('seg', min(c.x0 for c in s), max(c.x1 for c in s), t, b, chars=s, line=line))
        out.append(line)
    return out


def _collides(ln, run):
    """Символы кусочка налезают на символы строки (тогда это другая строка, а не продолжение)."""
    x0s, x1s = ln[4], ln[5]
    for c in run:
        k = bisect_right(x0s, c.x0)
        for j in (k - 1, k):
            if 0 <= j < len(x0s) and min(c.x1, x1s[j]) - max(c.x0, x0s[j]) > 0.3 * max(0.5, min(c.x1 - c.x0,
                                                                                               x1s[j] - x0s[j])):
                return True
    return False


def _compose(chars):
    """Символы строки (слева направо) → (текст, жирность, пометки, x — по символам текста).
    Пробел ставится по просвету между символами (пробел из PDF без просвета не в счёт: LibreOffice пишет
    точку другим шрифтом сразу после пробела, хотя на странице она стоит вплотную к слову)."""
    s, bo, mk, xs = [], [], [], []
    p = None
    for c in chars:
        if p is not None:
            gap, sz = c.x0 - p.x1, max(p.size, c.size)
            if gap > 0.15 * sz or (c.sp and gap > 0.08 * sz):   # пробел из PDF вплотную к точке — не пробел
                s.append(' ')
                bo.append(p.bold and c.bold)
                mk.append(p.mark and c.mark)
                xs.append(c.x0)
        s.append(c.c)
        bo.append(c.bold)
        mk.append(c.mark)
        xs.append(c.x0)
        p = c
    return ''.join(s), bo, mk, xs


def _text_of(chars):
    """Текст произвольного набора символов (ячейки таблицы): строки сверху вниз, склейка переносов."""
    text = ''
    for _, _, _, segs in _build_lines(sorted(chars, key=lambda c: c.i)):
        part = _compose(sorted([c for s in segs for c in s.chars], key=lambda c: c.x0))[0]
        text = _glue(text, part)[0] if text else part
    return clean(text.replace('\xad', ''))


def _glue(left, right, words=None, hyphenates=False):
    """Склейка двух строк абзаца с учётом переноса → (текст, сколько символов убрано в конце left,
    вставленный разделитель). «энерго-» + «эффективность» → «энергоэффективность»;
    «глубинно-» + «насосного» → «глубинно-насосного»; «Газпромнефть-» + «Хантос» — дефис остаётся."""
    ls = left.rstrip()
    cut = len(left) - len(ls)
    if ls.endswith('\xad'):
        return ls[:-1] + right, cut + 1, ''
    if len(ls) >= 2 and ls[-1] in HYPHENS and ls[-2].isalnum() and right[:1].isalnum():
        wl = re.search(r'(\w+)$', ls[:-1]).group(1)
        wr = re.match(r'\w+', right).group(0)
        if ls[-2].isalpha() and right[:1].islower() and _dehyphen(wl, wr, words, hyphenates):
            return ls[:-1] + right, cut + 1, ''
        return ls + right, cut, ''               # «1-|2 мин» → «1-2 мин», «ЦДНГ-|3» → «ЦДНГ-3»
    return ls + ' ' + right, cut, ' '


def _dehyphen(wl, wr, words, hyphenates):
    """Перенос по слогам (дефис убрать) или настоящий дефис? Как слово написано в других местах
    документа; слитные приставки («энерго», «нефте»); есть ли в документе автоматические переносы."""
    low_l, low_r = wl.lower(), wr.lower()
    if words:
        if f'{low_l}-{low_r}' in words:
            return False
        if low_l + low_r in words:
            return True
    return low_l in FUSED or hyphenates


# ---------------------------------------------------------------- линии, выделения, рисунки

def _path_items(page, h):
    """Векторные фигуры страницы → (горизонтальные линии [(y, x0, x1)], вертикальные [(x, y0, y1)] —
    сверху вниз; прямоугольники маркера [(x0, y0, x1, y1)] — в координатах PDF)."""
    hs, vs, marks = [], [], []
    fill, stroke = ctypes.c_int(), ctypes.c_int()
    m = pdfium_c.FS_MATRIX()
    fx, fy = ctypes.c_float(), ctypes.c_float()
    cr, cg, cb, ca = (ctypes.c_uint() for _ in range(4))
    total = 0
    for obj in page.get_objects(filter=[pdfium_c.FPDF_PAGEOBJ_PATH], max_depth=0):
        raw = obj.raw
        nseg = pdfium_c.FPDFPath_CountSegments(raw)
        total += max(nseg, 0)
        if nseg <= 0 or nseg > 2000 or total > 40000:          # сложные рисунки и карты не разбираем
            continue
        if not pdfium_c.FPDFPath_GetDrawMode(raw, fill, stroke):
            continue
        fcol = scol = None
        if fill.value and pdfium_c.FPDFPageObj_GetFillColor(raw, cr, cg, cb, ca) and ca.value:
            fcol = (cr.value, cg.value, cb.value)
        if stroke.value and pdfium_c.FPDFPageObj_GetStrokeColor(raw, cr, cg, cb, ca) and ca.value:
            scol = (cr.value, cg.value, cb.value)
        ident = not pdfium_c.FPDFPageObj_GetMatrix(raw, m)
        subs, cur, curved = [], [], False
        for k in range(nseg):
            seg = pdfium_c.FPDFPath_GetPathSegment(raw, k)
            if not seg or not pdfium_c.FPDFPathSegment_GetPoint(seg, fx, fy):
                continue
            x, y = fx.value, fy.value
            if not ident:
                x, y = m.a * x + m.c * y + m.e, m.b * x + m.d * y + m.f
            typ = pdfium_c.FPDFPathSegment_GetType(seg)
            if typ == pdfium_c.FPDF_SEGMENT_MOVETO and cur:
                subs.append((cur, curved))
                cur, curved = [], False
            curved = curved or typ == pdfium_c.FPDF_SEGMENT_BEZIERTO
            cur.append((x, y))
            if pdfium_c.FPDFPathSegment_GetClose(seg):
                cur.append(cur[0])
        if cur:
            subs.append((cur, curved))
        for pts, curved in subs:
            if curved or len(pts) < 2:
                continue
            xs, ys = [p[0] for p in pts], [p[1] for p in pts]
            x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
            if fcol and _marker_color(*fcol) and 4 <= y1 - y0 <= 40 and x1 - x0 >= 4:
                marks.append((x0, y0, x1, y1))   # заливка-маркер под текстом
                continue
            visible = (scol and min(scol) < 235) or (fcol and min(fcol) < 235)
            if not visible:
                continue
            if x1 - x0 <= 3 and y1 - y0 >= 5:
                vs.append(((x0 + x1) / 2, h - y1, h - y0))
            elif y1 - y0 <= 3 and x1 - x0 >= 5:
                hs.append((h - (y0 + y1) / 2, x0, x1))
            elif fcol and min(fcol) < 235 and not scol and len(pts) in (4, 5, 6) and \
                    all(abs(ax - bx) <= 1 or abs(ay - by) <= 1 for (ax, ay), (bx, by) in zip(pts, pts[1:])):
                # залитый прямоугольник (заливка ячейки таблицы) — его края тоже линии сетки
                hs.extend([(h - y1, x0, x1), (h - y0, x0, x1)])
                vs.extend([(x0, h - y1, h - y0), (x1, h - y1, h - y0)])
            elif scol and min(scol) < 235:       # рамка или ломаная из отрезков
                for (ax, ay), (bx, by) in zip(pts, pts[1:]):
                    if abs(ax - bx) <= 1 and abs(ay - by) >= 5:
                        vs.append(((ax + bx) / 2, h - max(ay, by), h - min(ay, by)))
                    elif abs(ay - by) <= 1 and abs(ax - bx) >= 5:
                        hs.append((h - (ay + by) / 2, min(ax, bx), max(ax, bx)))
    return hs, vs, marks


def _annot_marks(page):
    """Прямоугольники выделений-примечаний (Highlight) в координатах PDF."""
    out = []
    try:
        n = pdfium_c.FPDFPage_GetAnnotCount(page.raw)
    except Exception:                            # noqa: BLE001
        return out
    for i in range(max(n, 0)):
        a = pdfium_c.FPDFPage_GetAnnot(page.raw, i)
        if not a:
            continue
        try:
            if pdfium_c.FPDFAnnot_GetSubtype(a) != pdfium_c.FPDF_ANNOT_HIGHLIGHT:
                continue
            k = pdfium_c.FPDFAnnot_CountAttachmentPoints(a)
            q = pdfium_c.FS_QUADPOINTSF()
            for j in range(k):
                if pdfium_c.FPDFAnnot_GetAttachmentPoints(a, j, q):
                    xs, ys = (q.x1, q.x2, q.x3, q.x4), (q.y1, q.y2, q.y3, q.y4)
                    out.append((min(xs), min(ys), max(xs), max(ys)))
            r = pdfium_c.FS_RECTF()
            if not k and pdfium_c.FPDFAnnot_GetRect(a, r):
                out.append((min(r.left, r.right), min(r.bottom, r.top), max(r.left, r.right), max(r.bottom, r.top)))
        finally:
            pdfium_c.FPDFPage_CloseAnnot(a)
    return out


def _page_images(page, pg, cache):
    """Растровые рисунки страницы → pg.images. cache: хэш → (байты, расширение) — каждый рисунок
    извлекается один раз, даже если он есть на каждой странице (логотип)."""
    w, h = pg.w, pg.h
    box = [ctypes.c_float() for _ in range(4)]
    for obj in page.get_objects(filter=[pdfium_c.FPDF_PAGEOBJ_IMAGE], max_depth=0):
        try:
            if not pdfium_c.FPDFPageObj_GetBounds(obj.raw, *box):   # get_pos()/get_bounds() — разные в 4.x и 5.x
                continue
            l, b, r, t = (v.value for v in box)
            bw, bh = r - l, t - b
            if bw * bh >= 0.6 * w * h:
                pg.scan = True                   # картинка во всю страницу — скан или фон
                continue
            if bw < 57 or bh < 40:               # мельче 0,8" — значки, а не рисунки (как в Word)
                continue
            md = obj.get_metadata()
            if max(md.width, md.height) < 200 or min(md.width, md.height) < 48:
                continue
            key = hashlib.sha1(bytes(obj.get_data(decode_simple=False))).hexdigest()
            if key not in cache:
                cache[key] = _image_blob(obj, md)
            if cache[key] is not None:
                pg.images.append(_El('image', l, r, h - t, h - b, data=(key, int(bw * 12700), int(bh * 12700))))
        except Exception:                        # noqa: BLE001 — нестандартный рисунок пропускаем
            continue


def _image_blob(obj, md):
    """Байты рисунка: JPEG — как есть, остальное — PNG через Pillow. None — не удалось."""
    try:
        filters = obj.get_filters()
        if filters and filters[-1] == 'DCTDecode' and md.bits_per_pixel in (8, 24):
            return bytes(obj.get_data(decode_simple=True)), '.jpg'
        pil = obj.get_bitmap(render=False).to_pil()
        if pil.mode not in ('RGB', 'RGBA', 'L'):
            pil = pil.convert('RGB')
        buf = io.BytesIO()
        pil.save(buf, 'PNG')
        return buf.getvalue(), '.png'
    except Exception:                            # noqa: BLE001
        return None


# ---------------------------------------------------------------- таблицы по линиям сетки

def _cluster(vals, tol=2.0):
    out = []
    for v in sorted(vals):
        if out and v - out[-1][-1] <= tol:
            out[-1].append(v)
        else:
            out.append([v])
    return [sum(g) / len(g) for g in out]


def _merge_rules(rules):
    """Соединяет кусочки одной линии: [(положение, начало, конец)]."""
    out = []
    for pos, a, b in sorted(rules):
        for r in out[-8:]:
            if abs(r[0] - pos) <= 1.5 and a <= r[2] + 2:
                r[2] = max(r[2], b)
                break
        else:
            out.append([pos, a, b])
    return out


def _grids(hs, vs):
    """Связные группы горизонтальных и вертикальных линий → сетки [(xs, ys, горизонтали, вертикали)]."""
    hs, vs = _merge_rules(hs), _merge_rules(vs)
    n = len(hs) + len(vs)
    if len(hs) < 3 or len(vs) < 3 or n > 3000:
        return []
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for i, (y, a, b) in enumerate(hs):
        for j, (x, c, d) in enumerate(vs):
            if a - 2 <= x <= b + 2 and c - 2 <= y <= d + 2:
                parent[find(i)] = find(len(hs) + j)
    groups = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(i)
    out = []
    for g in groups.values():
        gh = [hs[i] for i in g if i < len(hs)]
        gv = [vs[i - len(hs)] for i in g if i >= len(hs)]
        ys, xs = _cluster([r[0] for r in gh]), _cluster([r[0] for r in gv])
        if len(ys) >= 3 and len(xs) >= 3:        # хотя бы 2 строки и 2 столбца
            out.append((xs, ys, gh, gv))
    return out


def _table(grid, chars):
    """Сетка + символы страницы → (элемент-таблица, символы таблицы) или None, если это не таблица
    (рамка вокруг текста, пустая сетка диаграммы)."""
    xs, ys, gh, gv = grid
    nr, nc = len(ys) - 1, len(xs) - 1

    def vline(x, y):
        return any(abs(v[0] - x) <= 2 and v[1] - 2 <= y <= v[2] + 2 for v in gv)

    def hline(y, x):
        return any(abs(r[0] - y) <= 2 and r[1] - 2 <= x <= r[2] + 2 for r in gh)
    inside, rows_ch = [], [[] for _ in range(nr)]
    for ch in chars:
        cx, cy = (ch.x0 + ch.x1) / 2, (ch.t + ch.b) / 2
        if xs[0] - 1 <= cx <= xs[-1] + 1 and ys[0] - 1 <= cy <= ys[-1] + 1:
            inside.append(ch)
            rows_ch[min(max(bisect_right(ys, cy) - 1, 0), nr - 1)].append(ch)

    def crossed(r, x):                           # текст строки r пересекает границу x
        return any(ch.x0 < x - 1 and ch.x1 > x + 1 for ch in rows_ch[r])
    owner = {}                                   # ячейка сетки → «главная» ячейка объединения
    for r in range(nr):
        ym = (ys[r] + ys[r + 1]) / 2
        for c in range(nc):
            xm = (xs[c] + xs[c + 1]) / 2
            if c and not vline(xs[c], ym) and crossed(r, xs[c]):
                owner[r, c] = owner[r, c - 1]    # объединена с ячейкой слева (текст через границу)
            elif r and not hline(ys[r], xm):
                owner[r, c] = owner[r - 1, c]    # объединена с ячейкой сверху
            else:
                owner[r, c] = (r, c)
    cells = {}
    for r, group in enumerate(rows_ch):
        for ch in group:
            c = min(max(bisect_right(xs, (ch.x0 + ch.x1) / 2) - 1, 0), nc - 1)
            cells.setdefault(owner[r, c], []).append(ch)
    owners = set(owner.values())
    if len(owners) < 4 or len(cells) < max(3, 0.5 * len(owners)):
        return None
    texts = {}
    for k, v in cells.items():
        lines = _build_lines(sorted(v, key=lambda c: c.i))
        nums = sum(1 for ln in lines if re.fullmatch(r'[-+−–]?\d[\d\s.,]*%?', _line_text(ln).strip()))
        if nums >= 2:                            # в «ячейке» столбик чисел — значит, линий между строками нет
            return None
        texts[k] = _text_of(v)
    if sum(1 for k in owners if texts.get(k)) < max(3, 0.5 * len(owners)):
        return None
    rows, copies = [], []
    for r in range(nr):
        rows.append([texts.get(owner[r, c], '') for c in range(nc)])
        copies.append([owner[r, c][0] == r and owner[r, c][1] < c for c in range(nc)])
    first = cells.get(owner[0, 0]) or []
    marked = bool(first) and (sum(ch.mark for ch in first) >= 0.8 * len(first) or
                              bool(MARK_PREFIX_RX.match(texts.get(owner[0, 0], ''))))
    return _El('table', xs[0], xs[-1], ys[0], ys[-1], data=(rows, copies, marked, xs)), inside


# ---------------------------------------------------------------- страница целиком

def _read_page(pdf, i, cache):
    page = pdf[i]
    try:
        w, h = page.get_size()
        pg = _Page(i, w, h)
        hs, vs, marks = _path_items(page, h)
        marks += _annot_marks(page)
        tp = page.get_textpage()
        try:
            chars, bad, q, w2, h2 = _page_chars(tp, w, h, marks)
        finally:
            tp.close()
        pg.chars = len(chars)
        if bad > 20 and bad > 0.3 * (bad + len(chars)):
            pg.bad, chars = True, []
        _page_images(page, pg, cache)
        if q:                                    # повёрнутый текст: таблицы и рисунки не ищем
            pg.w, pg.h, pg.images = w2, h2, []
            hs = vs = []
        used = set()
        for grid in _grids(hs, vs):
            res = _table(grid, chars)
            if res:
                pg.tables.append(res[0])
                used.update(id(c) for c in res[1])
        if used:
            chars = [c for c in chars if id(c) not in used]
        pg.lines = _build_lines(chars)
        return pg
    finally:
        page.close()


def _line_text(ln):
    return _compose(sorted((c for s in ln[3] for c in s.chars), key=lambda c: c.x0))[0]


def _drop_logos(pages):
    """Логотип — одна и та же картинка на многих страницах: в текст не попадает."""
    img_pages = Counter(k for p in pages for k in {im.data[0] for im in p.images})
    for p in pages:
        p.images = [im for im in p.images
                    if not (len(pages) >= 2 and img_pages[im.data[0]] >= max(2, 0.5 * len(pages)))]


def _drop_running(pages):
    """Убирает колонтитулы (повторяются у края на большинстве страниц) и номера страниц."""
    n = len(pages)
    cands, count = {}, Counter()
    for pg in pages:
        seen = set()
        for k, ln in enumerate(pg.lines):
            top = k < 3 and ln[1] <= 0.12 * pg.h
            bot = k >= len(pg.lines) - 3 and ln[0] >= 0.88 * pg.h
            if not (top or bot):
                continue
            text = _line_text(ln)
            key = ('t' if top else 'b', re.sub(r'\d+', '#', text.lower()).strip(), round(ln[2]))
            near = k < 2 or k >= len(pg.lines) - 2
            cands.setdefault(pg.no, []).append((id(ln), key, near and bool(PAGE_RX.match(text))))
            if key not in seen:
                seen.add(key)
                count[key] += 1
    need = max(2, math.ceil(0.5 * n))
    for pg in pages:
        drop = {lid for lid, key, page_no in cands.get(pg.no, []) if page_no or (n >= 2 and count[key] >= need)}
        if drop:
            pg.lines = [ln for ln in pg.lines if id(ln) not in drop]


# ---------------------------------------------------------------- порядок чтения и колонки

def _fills(group, width):
    """Строки заполняют колонку (это текст, а не таблица «название — число»)."""
    ws = sorted(e.x1 - e.x0 for e in group)
    return width > 50 and ws[int(0.75 * (len(ws) - 1))] >= 0.6 * width


def _gutter(els):
    """Просвет между колонками текста: (x левого края просвета, x правого) или None."""
    segs = [e for e in els if e.kind == 'seg']
    if len(segs) < 8:
        return None
    X0, X1 = min(e.x0 for e in segs), max(e.x1 for e in segs)
    W = X1 - X0
    if W < 150:
        return None
    best, reach = None, X0
    for a, b in sorted((e.x0, e.x1) for e in segs if e.x1 - e.x0 < 0.6 * W):
        if a - reach >= 8 and X0 + 0.2 * W <= (a + reach) / 2 <= X1 - 0.2 * W:
            g0, g1 = reach, a
            L = [e for e in segs if e.x1 <= g0 + 1]
            R = [e for e in segs if e.x0 >= g1 - 1]
            C = [e for e in els if not (e.x1 <= g0 + 1 or e.x0 >= g1 - 1)]
            if len(L) >= 3 and len(R) >= 3 and len(C) <= 0.3 * (len(L) + len(R)):
                side = min(max(e.b for e in L), max(e.b for e in R)) - max(min(e.t for e in L), min(e.t for e in R))
                if side > 0 and _fills(L, g0 - min(e.x0 for e in L)) and _fills(R, max(e.x1 for e in R) - g1) and \
                        (best is None or len(L) + len(R) > best[2]):
                    best = (g0, g1, len(L) + len(R))
        reach = max(reach, b)
    return best[:2] if best else None


def _order(els, depth=0, col=''):
    """Порядок чтения элементов страницы: сверху вниз; при колонках — по «полосам» между
    элементами во всю ширину: сначала левая колонка полосы, затем правая. → [(элемент, колонка)]"""
    els = sorted(els, key=lambda e: (e.t, e.x0))
    g = _gutter(els) if depth < 2 else None
    if not g:
        return [(e, col) for e in els]
    out, left, right = [], [], []

    def flush():
        if left and right:
            # короткая строка во всю ширину под ровными колонками (заголовок после колонок) —
            # читается после правой колонки, а не как продолжение левой
            rb, tail, ls = max(e.b for e in right), [], sorted(left, key=lambda e: e.t)
            for k in range(1, len(ls)):
                if ls[k].t <= rb:
                    continue
                prev_b, h = max(e.b for e in ls[:k]), ls[k].b - ls[k].t
                if prev_b > rb + 2 * h:
                    break                        # левая колонка заметно длиннее правой — это не «хвост»
                if ls[k].t - prev_b >= 0.8 * h:
                    ls, tail = ls[:k], ls[k:]
                    break
            out.extend(_order(ls, depth + 1, col + 'L') + _order(right, depth + 1, col + 'R') +
                       [(e, col) for e in tail])
        else:                                    # в полосе текст только с одной стороны — это не колонки
            out.extend((e, col) for e in left or right)
        left.clear()
        right.clear()
    for e in els:
        if e.x1 <= g[0] + 1:
            left.append(e)
        elif e.x0 >= g[1] - 1:
            right.append(e)
        else:
            flush()
            out.append((e, col))
    flush()
    return out


def _page_flow(pg):
    """Строки, таблицы и рисунки страницы в порядке чтения: [_Line | _El]."""
    els = [s for ln in pg.lines for s in ln[3]] + pg.tables + pg.images
    flow, cur, cur_key = [], [], None
    for e, col in _order(els):
        if e.kind == 'seg' and (id(e.line), col) == cur_key:
            cur.extend(e.chars)                  # сегменты одной строки в одной колонке — снова вместе
            continue
        if cur:
            flow.append(_Line(cur, pg.no, cur_key[1]))
            cur, cur_key = [], None
        if e.kind == 'seg':
            cur, cur_key = list(e.chars), (id(e.line), col)
        else:
            flow.append(e)
    if cur:
        flow.append(_Line(cur, pg.no, cur_key[1]))
    # границы колонок: левый край — самый частый, правый — почти самый дальний
    lines = [x for x in flow if isinstance(x, _Line)]
    for col in {ln.col for ln in lines}:
        group = [ln for ln in lines if ln.col == col]
        lefts = Counter(round(ln.x0) for ln in group)
        left = min(k for k, v in lefts.items() if v == max(lefts.values()))
        rights = sorted(ln.x1 for ln in group)
        right = rights[int(0.9 * (len(rights) - 1))]
        for ln in group:
            ln.left, ln.right = left, max(right, left + 1)
        group[0].first = group[-1].last = True
    if lines:
        lines[0].pfirst = lines[-1].plast = True
    return flow


# ---------------------------------------------------------------- абзацы и списки

class _Par:
    """Абзац или пункт списка, собранный из строк."""

    def __init__(self, ln, kind='para', marker=None):
        self.kind, self.lines = kind, [ln]
        self.marker = marker                     # (текст маркера, нумерованный?, x маркера, x текста)
        self.text, self.bo, self.mk = ln.text, list(ln.bo), list(ln.mk)
        self.cont_dx = None                      # отступ строк-продолжений от края колонки

    def add(self, ln, words, hyphenates):
        text, cut, sep = _glue(self.text, ln.text, words, hyphenates)
        keep = len(self.text) - cut
        self.bo, self.mk = self.bo[:keep], self.mk[:keep]
        if sep:
            self.bo.append(False)
            self.mk.append(bool(self.mk) and self.mk[-1])
        self.text = text
        self.bo += ln.bo
        self.mk += ln.mk
        if self.cont_dx is None:
            self.cont_dx = ln.x0 - ln.left
        self.lines.append(ln)

    @property
    def size(self):
        cnt = Counter()
        for ln in self.lines:
            cnt[ln.size] += len(ln.text)
        return cnt.most_common(1)[0][0]

    @property
    def bold(self):
        return sum(ln.bold * len(ln.text) for ln in self.lines) / max(1, sum(len(ln.text) for ln in self.lines))

    @property
    def page(self):
        return self.lines[0].page


def _size_eq(a, b):
    """Кегль строк совпадает: основной или хотя бы у трети символов (строка с вставкой кода другим шрифтом)."""
    return abs(a.size - b.size) <= 0.6 or \
        any(abs(k - a.size) <= 0.6 and f >= 0.3 for k, f in b.sizes.items()) or \
        any(abs(k - b.size) <= 0.6 and f >= 0.3 for k, f in a.sizes.items())


def _tone(color):
    """Цвет строки для сравнения: тёмно-серые и чёрный — один «обычный» цвет текста ('text');
    'mixed' — в строке несколько цветов (выделено слово)."""
    if color is None:
        return 'mixed'
    if max(color) <= 110 and max(color) - min(color) <= 40:
        return 'text'
    return color


def _style_eq(a, b):
    ca, cb = _tone(a.color), _tone(b.color)
    same = 'mixed' in (ca, cb) or ca == cb or (isinstance(ca, tuple) and isinstance(cb, tuple) and
                                               all(abs(x - y) <= 20 for x, y in zip(ca, cb)))
    return _size_eq(a, b) and (a.bold >= 0.85) == (b.bold >= 0.85) and same


def _ends_par(ln):
    """Короткая строка с точкой в конце — последняя строка абзаца."""
    width = ln.right - ln.left
    return ln.x1 < ln.right - max(3 * ln.size, 0.15 * width) and ln.text.rstrip()[-1:] in '.!?:;'


def _gap_ok(prev, ln, pitch_k):
    return 0 < ln.b - prev.b <= ln.size * pitch_k * 1.3 + 1


def _continues(par, ln, pitch_k):
    """Продолжает ли строка ln абзац (пункт) par."""
    last = par.lines[-1]
    if not _style_eq(last, ln):
        return False
    if ln.page == last.page and ln.col == last.col:
        if not _gap_ok(last, ln, pitch_k):
            return False
    else:
        if ln.page == last.page:                 # переход из левой колонки в правую
            if not (last.col.endswith('L') and ln.col == last.col[:-1] + 'R' and last.last and ln.first):
                return False
        elif not (ln.page == last.page + 1 and last.plast and ln.pfirst):
            return False                         # переход на следующую страницу
        if last.text.rstrip()[-1:] in '.!?:' and ln.text[:1].isupper():
            return False                         # на границе страницы закончилось предложение — новый абзац
    hyph = last.text.rstrip()[-1:] in HYPHENS and ln.text[:1].islower()
    if not hyph and _ends_par(last):
        return False
    tol, dx = 0.6 * ln.size, ln.x0 - ln.left    # отступы — от левого края колонки
    if par.kind == 'item':
        return dx >= par.marker[3] - par.lines[0].left - tol     # строка под текстом пункта
    if ln.col == last.col and ln.page == last.page and last.x0 > last.left + 2 * ln.size and \
            abs((ln.x0 + ln.x1) / 2 - (last.x0 + last.x1) / 2) <= ln.size:
        return True                              # строки по центру (название, подпись)
    if par.cont_dx is None:
        return dx <= last.x0 - last.left + tol   # вторая строка не правее первой (красная строка)
    return abs(dx - par.cont_dx) <= tol


def _marker(ln, prev, par, pitch_k):
    """Маркер списка в начале строки → (текст маркера, нумерованный?, x маркера, x текста) или None."""
    m = LIST_RX.match(ln.text)
    if not m or m.end() >= len(ln.text):
        return None
    glyph, _, num, let = m.groups()
    if not glyph:
        # тире / «1)» / «а)» — пункт, только если строка начинает новый абзац
        new = (prev is None or par is None or par.kind == 'item' or prev.text.rstrip()[-1:] in '.!?:;' or
               ln.page != prev.page or ln.col != prev.col or not _style_eq(prev, ln) or not _gap_ok(prev, ln, pitch_k))
        if not new:
            return None
    return m.group(0), bool(num or let), ln.x0, ln.xs[m.end()]


def _paragraphs(flow, words, hyphenates, pitch_k):
    """Поток строк → абзацы, пункты списков, таблицы и рисунки (по порядку)."""
    out, par, prev = [], None, None
    for x in flow:
        if not isinstance(x, _Line):
            out.append(x)
            par = prev = None
            continue
        mk = _marker(x, prev, par, pitch_k)
        if mk:
            par = _Par(x, 'item', mk)
            out.append(par)
        elif par is not None and _continues(par, x, pitch_k):
            par.add(x, words, hyphenates)
        else:
            par = _Par(x)
            out.append(par)
        prev = x
    return out


def _bold_prefix(text, bo, start=0):
    """Жирное начало текста (как жирное начало абзаца в Word)."""
    k = start
    while k < len(text) and (bo[k] or text[k] == ' '):
        k += 1
    return clean(text[start:k].replace('\xad', '')) if any(bo[start:k]) else ''


def _mark_part(text, mk, start=0):
    """(выделен целиком, выделенная часть) по пометкам символов — как в docx_reader: ≥ 80 % — целиком."""
    pairs = list(zip(text[start:], mk[start:]))
    solid = [m for c, m in pairs if not c.isspace()]
    marked = sum(solid)
    if not marked:
        return False, ''
    if marked >= 0.8 * len(solid):
        return True, ''
    spans, cur = [], ''
    for c, m in pairs:
        if m or (c == ' ' and cur):
            cur += c
        else:
            if cur.strip():
                spans.append(cur.strip())
            cur = ''
    if cur.strip():
        spans.append(cur.strip())
    return False, clean(' '.join(spans).replace('\xad', ''))


# ---------------------------------------------------------------- заголовки и название

def _heading_key(p, nxt, body):
    """Вид заголовка (кегль, жирный, цвет, глубина номера) или None, если абзац — не заголовок."""
    if not isinstance(p, _Par) or len(p.lines) > 3:
        return None
    text = clean(p.text.replace('\xad', ''))
    if not text or not LETTER_RX.search(text):
        return None
    if p.kind == 'item' and not p.marker[1]:
        return None                              # пункт с «•» или «–» — не заголовок
    if CAPTION_RX.match(text) or TABLE_CAP_RX.match(text) or re.search(r'https?://|www\.|@', text):
        return None
    size, bold = p.size, p.bold >= 0.85
    raw = p.text.strip()
    if size >= body + 0.9 and size >= body * 1.08:
        if len(text) > 200 or len(text.split()) > 25 or text.endswith((',', ';')):
            return None
    elif bold:
        if len(text) > 90 or len(text.split()) > 12 or text.endswith(('.', ':', ';', ',')):
            return None
    elif PLAIN_HEAD_RX.match(raw) and len(p.lines) == 1 and len(text) <= 80 and len(text.split()) <= 10 and \
            not text.endswith(('.', ':', ';', ',')) and isinstance(nxt, _Par) and nxt.kind == 'para' and \
            not NUM_HEAD_RX.match(nxt.text.strip()):
        pass                                     # «2.1 Общие положения» обычным шрифтом перед текстом
    else:
        return None
    mm = NUM_HEAD_RX.match(raw)
    depth = mm.group(1).count('.') + 1 if mm else 1
    tone = _tone(p.lines[0].color)
    return size, bold, tuple(v // 40 for v in tone) if isinstance(tone, tuple) else (0, 0, 0), depth


def _heading_levels(keys):
    """Виды заголовков → уровни 1–3: крупнее — выше; при равном кегле — по глубине номера
    («1.» выше «1.1») и по тому, какой вид встретился раньше."""
    first = {}
    for i, k in enumerate(keys):
        if k:
            first.setdefault(k, i)
    order = sorted(first, key=lambda k: (-k[0], k[3], first[k]))
    return {k: min(3, i + 1) for i, k in enumerate(order)}


def _meta_title(pdf):
    """Название из свойств PDF, если это похоже на название (а не «Microsoft Word - doc1.docx»)."""
    try:
        t = clean((pdf.get_metadata_dict() or {}).get('Title') or '')
    except Exception:                            # noqa: BLE001
        return ''
    if len(t) < 3 or not LETTER_RX.search(t) or JUNK_TITLE_RX.search(t):
        return ''
    return t


def _norm(s):
    return re.sub(r'[\W_]+', ' ', str(s).lower()).strip()


def _find_title(pars, keys, meta, body, first_page):
    """Абзац-название на первой странице: совпадает с названием из свойств PDF или набран самым
    крупным кеглем документа. Заголовок, вид которого повторяется в документе, названием не считается."""
    kcount = Counter(k for k in keys if k)
    head = [i for i, p in enumerate(pars[:12]) if isinstance(p, _Par) and p.page == first_page and p.kind == 'para']
    if meta:
        b = _norm(meta)
        for i in head[:8]:
            a = _norm(pars[i].text.replace('\xad', ''))
            if a and (a == b or (min(len(a), len(b)) >= 0.7 * max(len(a), len(b)) and (a in b or b in a))):
                return i if not keys[i] or kcount[keys[i]] == 1 else None
    if head:
        i = max(head, key=lambda i: pars[i].size)
        big = pars[i]
        if big.size >= max(body + 2, body * 1.25) and len(big.text) <= 200 and \
                all(p.size < big.size for p in pars if isinstance(p, _Par) and p is not big):
            return i
    return None


# ---------------------------------------------------------------- PDF из презентации: чтение по слайдам
#
# PDF, сохранённый из PowerPoint или Impress, устроен не как документ Word: альбомные листы, на каждом —
# крупный заголовок слайда вверху и много небольших надписей в произвольных местах (карточки в несколько
# колонок, подписи вокруг схемы, таблицы без линий, колонтитул «Раздел N» и номер слайда внизу). Чтение
# «строка во всю ширину» перемешивает соседние надписи, поэтому такой PDF читается по слайдам:
#   * каждый слайд — раздел 1-го уровня; его заголовок — самый крупный текст вверху слайда, крупная строка
#     сразу под ним — подзаголовок (первый абзац раздела). Первый слайд-титул даёт название и подзаголовок
#     документа; «Содержание» и «Спасибо за внимание» пропускаются;
#   * строки собираются в надписи: строка прямо под строкой, перекрываются по x, интервал не больше высоты
#     строки, тот же кегль, жирность и цвет. Абзацы внутри надписи — по увеличенному интервалу, маркерам
#     и «столбику» коротких подписей с заглавной буквы;
#   * короткая надпись крупнее (жирнее, другого цвета) прямо над другой — её заголовок: карточка
#     «Заголовок: текст» → пункт списка с жирным началом; несколько абзацев в одной надписи — пункты;
#   * порядок — рядами сверху вниз, в ряду слева направо (разрезы по просветам между надписями); два ряда
#     «ёлочкой» (этапы над и под линией времени) — по x; ряды с одинаковыми колонками (≥ 3 колонки,
#     шапка и ≥ 2 строки) — таблица без линий; надписи «01 …», «02 …» — по номерам;
#   * числа без слов (проценты диаграмм, номера шагов) отбрасываются; плитка «крупное число / единица /
#     подпись» — пункт «Глубина залегания — 1 780–1 820 м»; значение справа от подписи (легенда «Объект
#     исследования … 15%») и число-плитка слева от карточки приписываются к ним; короткие подписи одного
#     ряда объединяются в одну строку («Этапы: Сбор данных, Анализ и оценка, Результат»);
#   * рисунки — как в документе, кроме значков (меньше 1,5 % слайда), узких полос-украшений и подложек
#     под текстом.

DECK_RATIO = (1.25, 1.9)                 # альбомный лист: 4:3 — 1,33; 16:10 — 1,6; 16:9 — 1,78
DECK_END_RX = re.compile(r'(?i)^\W*(спасибо|благодар\w*\s+за\s+внимание|thank\s+you|вопросы\W*$|questions\W*$)')
DECK_TOC_RX = re.compile(r'(?i)^\W*(содержание|оглавление|план\s+(доклада|презентации)|повестка(\s+дня)?|agenda|'
                         r'contents)\W*$')
NUM_ONLY_RX = re.compile(r'^[\s\d.,:;%‰°+±×*/=<>≈~−–—-]*\d[\s\d.,:;%‰°+±×*/=<>≈~−–—-]*$')
_UW = (r'(?:тыс|млн|млрд|трлн|руб|долл|барр|шт|чел|ед|п|д|лет|год|года|мес|сут|ч|мин|сек|т|кг|г|м[²³]?|км|см|мм|'
       r'га|л|бар|атм|[кМмГ]?Па(?:·с)?|мД|ppm|[кМГ]?Вт(?:·ч)?|раз)\.?')
_UNIT = (r'(?:%|‰|°\s?[CС]|' + _UW + r'(?:\s?' + _UW + r'){0,2}(?:/' + _UW + r')?)'
         r'(?:\s(?:в|за)\s(?:год|сутки|месяц|час|период))?')   # «м», «мПа·с», «тыс. т», «т/сут», «млн руб. в год»
UNIT_RX = re.compile(r'^\s*' + _UNIT + r'\s*$')
VALUE_RX = re.compile(r'%|‰|\d\s*[–—-]\s*\d|\d[.,]\d|[1-9]\d')    # показатель, а не номер шага «2» или «01»
YEAR_RX = re.compile(r'^\s*(19|20)\d\d(\s*[–—-]\s*((19|20)\d\d|\d\d))?\s*(гг?\.)?\s*$')     # «2031», «2028–2030»
LEAD_NUM_RX = re.compile(r'^0?(\d{1,2})(?:[.)]\s*(?=\S)|\s+(?=[«"]?[А-ЯЁA-Z]))')    # «01 Мониторить», «3. Оценка»
DECK_CONCL_RX = re.compile(r'(?i)^\W*(вывод|итог|таким образом|в результате|в итоге|резюме|главное\b|ключев\w*\s+'
                           r'(вывод|эффект|результат|мысль|идея)|ожидаем\w*\s+(результат|эффект))')
GOAL_RX = re.compile(r'(?i)^\W*цел[ьи]\b')
WORD_RX = re.compile(r'[A-Za-zА-Яа-яЁё]{2,}')
LINK_K = 1.0                             # просвет между строками одной надписи — до высоты строки


class _Box:
    """Надпись слайда — строки одна под другой. head — надпись-заголовок над ней (карточка), extra — число
    рядом («96–100», «40% — вес блока»), num/cut — номер «01 …» в начале (для порядка) и его длина."""

    def __init__(self, lines):
        self.lines = sorted(lines, key=lambda l: (l.t, l.x0))
        self.kind, self.head, self.is_head = 'box', None, False
        self.extra, self.num, self.cut, self.fixed = '', None, 0, ''
        self.breaks = set()                      # строки, с которых точно начинается новый абзац
        self.nest = False                        # пункты — вложенные в карточку слева (легенда «… — 15%»)
        self.value = ''                          # число с единицей из двух надписей («1 780–1 820» + «м»)
        self.sib = False                         # соседка карточек в ряду, только без заголовка — тоже пункт
        self.ox0, self.ox1 = min(l.x0 for l in self.lines), max(l.x1 for l in self.lines)
        self.ot, self.ob = min(l.t for l in self.lines), max(l.b for l in self.lines)
        self.fit()

    def fit(self):
        """Границы вместе с заголовком — для порядка чтения."""
        parts = [self] + ([self.head] if self.head else [])
        self.x0, self.x1 = min(p.ox0 for p in parts), max(p.ox1 for p in parts)
        self.t, self.b = min(p.ot for p in parts), max(p.ob for p in parts)

    @property
    def size(self):
        if self.value:                           # кегль значения — кегль числа, а не единицы
            return self.lines[0].size
        cnt = Counter()
        for ln in self.lines:
            cnt[ln.size] += len(ln.text)
        return cnt.most_common(1)[0][0]

    @property
    def bold(self):
        return sum(ln.bold * len(ln.text) for ln in self.lines) / max(1, sum(len(ln.text) for ln in self.lines))

    @property
    def color(self):
        return _tone(self.lines[0].color)

    @property
    def text(self):
        return self.value or clean(' '.join(ln.text for ln in self.lines).replace('\xad', ''))

    @property
    def numeric(self):
        """Число без слов: «15%», «0–100», «2», или значение из числа и единицы под ним («7,4» / «м»)."""
        return bool(self.value) or all(NUM_ONLY_RX.match(ln.text) for ln in self.lines)


class _Unit:
    """Элемент слайда, кроме надписи: таблица ('table' — по линиям, 'grid' — без линий) или подписи
    ('labels' — одной строкой или пунктами)."""

    def __init__(self, kind, data, x0, x1, t, b):
        self.kind, self.data, self.x0, self.x1, self.t, self.b = kind, data, x0, x1, t, b
        self.head, self.extra, self.num = None, '', None


def _slide_lines(pg):
    """Строки слайда: каждый сегмент строки страницы — отдельная строка _Line со своим кеглем и местом, чтобы
    надписи соседних карточек на одной высоте не склеивались. Сегмент ещё делится по просвету шире кегля:
    на слайде это уже соседняя надпись (цифра-плитка, колонка таблицы), а не пробел между словами."""
    out = []
    for _, _, _, segs in pg.lines:
        for s in segs:
            cur, reach = [], 0.0
            for c in sorted(s.chars, key=lambda c: c.x0):
                small, gap = min(cur[-1].size, c.size) if cur else 0, c.x0 - reach
                big = max(cur[-1].size, c.size) if cur else 0
                # «1.» перед текстом — маркер списка, если просвет обычный, а не через пол-слайда
                if cur and (gap > max(small, 6) or (gap > 0.3 * small and big >= 1.8 * small)) \
                        and not (gap <= 3 * big and LIST_RX.match(''.join(x.c for x in cur) + ' x')):
                    out.append(_Line(cur, pg.no, ''))
                    cur = []
                reach = max(reach, c.x1) if cur else c.x1
                cur.append(c)
            if cur:
                out.append(_Line(cur, pg.no, ''))
    return [ln for ln in out if ln.text.replace('\xad', '').strip()]


def _body_size(lines):
    """Кегль основного текста — по числу символов."""
    cnt = Counter()
    for ln in lines:
        cnt[ln.size] += len(ln.text)
    return cnt.most_common(1)[0][0] if cnt else 12.0


def _deck_like(pages):
    """PDF сохранён из презентации? Большинство листов альбомные (4:3 … 16:9), на большинстве слайдов с
    текстом вверху крупный заголовок, а длинных строк сплошного текста почти нет (у документа Word в
    альбомной ориентации строки длинные)."""
    if not pages or sum(1 for p in pages if DECK_RATIO[0] <= p.ratio <= DECK_RATIO[1]) < 0.7 * len(pages):
        return False
    with_text = titled = long_chars = chars = 0
    for p in pages:
        p.slines = _slide_lines(p)
        if not p.slines:
            continue
        with_text += 1
        body = _body_size(p.slines)
        top = [ln.size for ln in p.slines if ln.t < 0.3 * p.h and LETTER_RX.search(ln.text)]
        if top and max(top) >= max(1.3 * body, body + 4):
            titled += 1
        for ln in p.slines:
            chars += len(ln.text)
            long_chars += len(ln.text) if len(ln.text) >= 100 else 0
    return with_text > 0 and titled >= 0.5 * with_text and long_chars <= 0.35 * chars


def _drop_deck_running(pages):
    """Колонтитулы слайдов: номер слайда; мелкая подпись внизу на одном и том же месте почти на всех слайдах
    («Раздел 2», «Актуальность»); надписи у верхнего/нижнего края, повторяющиеся на большинстве слайдов
    (название компании, «Конфиденциально»). Крупный текст (заголовки слайдов) не трогается."""
    n = len(pages)
    body = _body_size([ln for p in pages for ln in p.slines])

    def key(p, ln):
        edge = 'b' if ln.t >= 0.88 * p.h else ('t' if ln.b <= 0.12 * p.h else '')
        return (edge, re.sub(r'\d+', '#', ln.text.lower()).strip()) if edge else None
    count, foot = Counter(), []
    for p in pages:
        count.update({key(p, ln) for ln in p.slines if key(p, ln)})
        foot.extend((p.no, ln.b) for ln in p.slines if ln.t >= 0.9 * p.h and ln.size <= 1.15 * body)
    need, need_foot = max(2, math.ceil(0.5 * n)), max(2, math.ceil(0.4 * n))
    for p in pages:
        keep = []
        for ln in p.slines:
            k = key(p, ln)
            if k and ln.size < 1.3 * body and (PAGE_RX.match(ln.text) or (n >= 2 and count[k] >= need)):
                continue
            if ln.t >= 0.9 * p.h and ln.size <= 1.15 * body and len(ln.text) <= 80 and \
                    len({no for no, b in foot if abs(b - ln.b) <= 3}) >= need_foot:
                continue
            keep.append(ln)
        p.slines = keep


def _overlap(a, b):
    """Перекрытие по x (у надписей — по их собственным строкам)."""
    return min(getattr(a, 'ox1', a.x1), getattr(b, 'ox1', b.x1)) - max(getattr(a, 'ox0', a.x0), getattr(b, 'ox0', b.x0))


def _tone_eq(ca, cb):
    return 'mixed' in (ca, cb) or ca == cb or (isinstance(ca, tuple) and isinstance(cb, tuple) and
                                               all(abs(x - y) <= 40 for x, y in zip(ca, cb)))


def _same_style(a, b):
    """Строки одной надписи: кегль почти тот же, жирность и цвет те же."""
    if abs(a.size - b.size) > max(1.0, 0.1 * max(a.size, b.size)) or (a.bold >= 0.85) != (b.bold >= 0.85):
        return False
    return _tone_eq(_tone(a.color), _tone(b.color))


def _title_lines(lines, pg, anywhere=False):
    """Строки заголовка слайда: самый крупный текст в верхней трети слайда (на титуле — где угодно), заметно
    крупнее остального; строки того же кегля прямо под ним — продолжение заголовка."""
    cand = [ln for ln in lines if LETTER_RX.search(ln.text) and (anywhere or ln.t < 0.3 * pg.h)]
    if not cand:
        return []
    big = max(ln.size for ln in cand)
    others = [ln for ln in lines if ln.size < big - 0.6]
    body = _body_size(others) if others else big / 1.5
    if big < max(1.2 * body, body + 3):
        return []
    group = [min((ln for ln in cand if ln.size >= big - 0.6), key=lambda l: (l.t, l.x0))]
    for ln in sorted(lines, key=lambda l: (l.t, l.x0)):
        last = group[-1]
        h = last.b - last.t
        if all(ln is not g for g in group) and abs(ln.size - group[0].size) <= max(1.0, 0.06 * group[0].size) and \
                -0.3 * h <= ln.t - last.b <= 0.6 * h and _overlap(ln, last) > 0:
            group.append(ln)
    return group


def _pair_values(lines):
    """Значение справа от подписи в той же строке («Объект исследования … 15%») приписывается к подписи:
    «Объект исследования — 15%». Только если таких пар в столбик хотя бы две (легенда, «показатель — вес»):
    одиночное число рядом с текстом — скорее подпись схемы."""
    pairs = []
    for n in lines:
        if not NUM_ONLY_RX.match(n.text) or not VALUE_RX.search(n.text):    # «2» у этапа — номер, не значение
            continue
        best = None
        for t in lines:
            if t is n or not LETTER_RX.search(t.text) or t.x1 > n.x0 + 1 or not 0.6 <= n.size / t.size <= 1.6 or \
                    min(t.b, n.b) - max(t.t, n.t) < 0.6 * min(t.b - t.t, n.b - n.t):
                continue
            if best is None or t.x1 > best.x1:
                best = t
        if best is not None and not any(o is not best and o is not n and o.x0 >= best.x1 - 1 and o.x1 <= n.x0 + 1 and
                                        min(o.b, n.b) - max(o.t, n.t) > 0 for o in lines) and \
                not any(o.x0 >= n.x1 - 1 and min(o.b, n.b) - max(o.t, n.t) > 0.5 * (n.b - n.t) for o in lines):
            pairs.append((best, n))              # справа от числа ещё ячейка («тыс. т») — это столбец таблицы
    used = set()
    for t, n in pairs:
        if any(t2 is not t and abs(t2.x0 - t.x0) <= 3 and (abs(n2.x1 - n.x1) <= 3 or abs(n2.x0 - n.x0) <= 3)
               for t2, n2 in pairs):
            add = ' — ' + n.text.strip()
            t.text += add
            t.bo += [False] * len(add)
            t.mk += [False] * len(add)
            t.xs += [t.x1] * len(add)
            used.add(id(n))
    return [ln for ln in lines if id(ln) not in used]


def _make_boxes(lines):
    """Строки слайда → надписи. Строка b продолжает надпись строки a, если она прямо под ней (перекрываются
    по x, просвет не больше высоты строки), того же вида, и у обеих это единственный такой сосед: широкая
    строка над двумя колонками колонки не склеивает."""
    lines = sorted(lines, key=lambda l: (l.t, l.x0))
    n = len(lines)
    down, up = [[] for _ in range(n)], [[] for _ in range(n)]
    for i, a in enumerate(lines):
        ha = a.b - a.t
        for j in range(i + 1, n):
            b = lines[j]
            if b.t - a.b > 3 * max(ha, 10):
                break
            if b.t < a.t + 0.5 * ha or b.t - a.b > LINK_K * max(ha, b.b - b.t):
                continue
            if _overlap(a, b) <= 0.3 * min(a.x1 - a.x0, b.x1 - b.x0) or not _same_style(a, b):
                continue
            down[i].append(j)
        if down[i]:                              # соседи — только из ближайшего ряда снизу
            top = min(lines[j].t for j in down[i])
            down[i] = [j for j in down[i] if lines[j].t < top + 0.5 * (lines[j].b - lines[j].t)]
            for j in down[i]:
                up[j].append(i)
    for j in range(n):                           # и из ближайшего ряда сверху
        if up[j]:
            bot = max(lines[i].b for i in up[j])
            up[j] = [i for i in up[j] if lines[i].b > bot - 0.5 * (lines[i].b - lines[i].t)]
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for i in range(n):
        if len(down[i]) == 1 and up[down[i][0]] == [i]:
            parent[find(i)] = find(down[i][0])
    groups = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(lines[i])
    return [_Box(g) for g in groups.values()]


def _head_like(t, b):
    """Надпись t (над b) — заголовок карточки b: короткая и заметнее текста b (крупнее, жирнее или другого
    цвета), а b — текст (2+ строки или 3+ слова), а не такая же подпись («Очень высокое» над «Высокое»);
    короткий текст — только под заметно более крупной надписью («Пласт АС10» / «Перспективный объект»).
    Из чисел заголовком бывает только год или период («2028–2030» над этапом плана)."""
    text = t.text
    year = len(t.lines) == 1 and bool(YEAR_RX.match(text))
    if (t.numeric and not year) or b.numeric or len(t.lines) > 3 or len(text) > 100 or \
            not (year or LETTER_RX.search(text)):
        return False
    if text.endswith((',', ';')) or (text.endswith('.') and len(text) > 40) or t.size < b.size - 0.5:
        return False
    if len(b.lines) < 2 and len(WORD_RX.findall(b.text)) < 3 and t.size < 1.15 * b.size:
        return False
    return (t.size >= b.size + max(0.8, 0.08 * b.size) or (t.bold >= 0.85 > b.bold) or
            (len(t.lines) <= 2 and not _tone_eq(t.color, b.color)))


def _attach_heads(boxes):
    """Заголовки карточек: ближайшая надпись прямо над надписью (выровнена с ней, просвет до ~1,3 строки),
    если под заголовком нет других надписей (иначе это подпись группы). Пары назначаются от самых явных
    (заголовок намного крупнее) к менее явным (только другой цвет); надпись — только в одной паре.
    Строчная буква в начале нижней надписи — продолжение того же абзаца другим шрифтом, а не карточка.
    → надписи без надписей-заголовков."""
    pairs = []
    for b in boxes:
        best = None
        for t in boxes:
            h = t.lines[-1].b - t.lines[-1].t
            gap = b.ot - t.ob
            if t is not b and -0.3 * h <= gap <= 1.35 * h and not (t.numeric and not YEAR_RX.match(t.text)) and \
                    _overlap(t, b) >= 0.5 * min(t.ox1 - t.ox0, b.ox1 - b.ox0) and (best is None or gap < best[0]):
                best = (gap, t, h)
        if best is None:
            continue
        _, t, h = best
        if not _head_like(t, b) or any(c is not b and c is not t and not c.numeric and _overlap(t, c) > 0 and
                                       -0.3 * h <= c.ot - t.ob <= 1.35 * h for c in boxes):
            continue
        pairs.append(((t.size / b.size, t.bold >= 0.85 > b.bold), t, b))
    used, gone = set(), set()
    for _, t, b in sorted(pairs, key=lambda p: p[0], reverse=True):
        if id(t) in used or id(b) in used:
            continue
        used.update((id(t), id(b)))
        gone.add(id(t))
        if b.lines[0].text[:1].islower() and t.text[-1:] not in '.:!?' and abs(t.size - b.size) <= 1:
            b.lines = t.lines + b.lines          # продолжение абзаца другим начертанием
            b.ox0, b.ox1, b.ot = min(b.ox0, t.ox0), max(b.ox1, t.ox1), t.ot
        else:
            b.head, t.is_head = t, True
        b.fit()
    return [b for b in boxes if id(b) not in gone]


def _extend_cards(boxes):
    """Пункты карточки, разнесённые шире высоты строки: надписи того же вида прямо под текстом карточки
    (тот же левый край, просвет до 2,5 строки, между ними ничего) — ещё абзацы этой карточки."""
    gone = set()
    for b in sorted((b for b in boxes if b.head is not None), key=lambda x: x.ot):
        while True:
            last = b.lines[-1]
            h = last.b - last.t
            nxt = [c for c in boxes if c is not b and id(c) not in gone and c.head is None and not c.numeric and
                   0 <= c.ot - b.ob <= 2.5 * h and abs(c.ox0 - b.ox0) <= 2 and _same_style(c.lines[0], last)]
            if len(nxt) != 1 or any(o is not b and o is not nxt[0] and id(o) not in gone and o.ot < nxt[0].ot and
                                    o.ob > b.ob and _overlap(o, nxt[0]) > 0 for o in boxes):
                break
            c = nxt[0]
            b.breaks.add(id(c.lines[0]))
            b.lines += c.lines
            b.ox0, b.ox1, b.ob = min(b.ox0, c.ox0), max(b.ox1, c.ox1), c.ob
            b.fit()
            gone.add(id(c))
    return [b for b in boxes if id(b) not in gone]


def _join_units(boxes):
    """Единица измерения отдельной надписью под крупным числом или справа от него («1 780–1 820» / «м»,
    «84–86» / «%») — часть значения: число и единица становятся одной надписью-значением."""
    gone = set()
    for n in boxes:
        if len(n.lines) != 1 or not NUM_ONLY_RX.match(n.text):
            continue
        h = n.ob - n.ot
        for u in boxes:
            if u is n or id(u) in gone or len(u.lines) != 1 or not UNIT_RX.match(u.text) or u.size >= n.size:
                continue
            below = abs(u.ox0 - n.ox0) <= 2 and -0.2 * h <= u.ot - n.ob <= 0.5 * h
            right = 0 <= u.ox0 - n.ox1 <= max(u.size, 6) and u.ob <= n.ob + 0.2 * h and u.ob >= n.ot + 0.5 * h
            if below or right:
                n.value = f'{n.text} {u.text.strip()}'
                n.lines = n.lines + u.lines
                n.ox1, n.ob = max(n.ox1, u.ox1), max(n.ob, u.ob)
                n.fit()
                gone.add(id(u))
                break
    return [b for b in boxes if id(b) not in gone]


def _attach_numbers(boxes):
    """Числа без слов. Число над короткой подписью («40%» / «вес блока») — плитка-показатель («Глубина
    залегания — 1 780–1 820 м»), над карточкой — значение в её заголовке; плитка или значение («96–100»)
    слева от карточки в том же ряду приписывается к ней. Остальные числа — подписи диаграмм и номера
    шагов — отбрасываются."""
    nums = [b for b in boxes if b.numeric]
    rest = [b for b in boxes if not b.numeric]
    tiles = []
    for n in nums:
        if not (n.value or VALUE_RX.search(n.text)):
            continue

        def under(c):                            # c — прямо под числом и выровнена с ним
            return 0 <= c.ot - n.ob <= n.ob - n.ot and _overlap(n, c) > 0.5 * min(n.ox1 - n.ox0, c.ox1 - c.ox0)
        def caption(c):                          # до 4 слов; под крупным числом — до 8
            k = len(WORD_RX.findall(c.text))
            return len(c.lines) <= 3 and (k <= 4 or (k <= 8 and n.size >= 1.5 * c.size)) and under(c)
        cap_ = next((u for u in rest if not u.fixed and not u.extra and caption(u.head or u)), None)
        if cap_ is not None and cap_.head is not None:      # карточка «подпись + пояснение» под числом
            cap_.extra = n.text
        elif cap_ is not None:                   # плитка: число + подпись под ним
            tile = _Box(n.lines + cap_.lines)
            tile.fixed = f'{cap_.text} — {n.text}'
            rest = [tile if u is cap_ else u for u in rest]
            tiles.append((tile, f'{n.text} — {cap_.text}'))
        else:
            tiles.append((n, n.text))
    for tile, label in tiles:
        cy, best = (tile.ot + tile.ob) / 2, None
        for u in rest:
            gap = u.x0 - tile.ox1
            if u is tile or u.fixed or u.extra or not (u.t - 1 <= cy <= u.b + 1 and 0 <= gap <= 4 * tile.size):
                continue
            if best is None or gap < best[0]:
                best = (gap, u)
        if best is None or any(o is not tile and o is not best[1] and o.x0 >= tile.ox1 - 1 and o.x1 <= best[1].x0 + 1
                               and min(o.b, tile.ob) - max(o.t, tile.ot) > 0 for o in rest):
            continue
        best[1].extra = label
        rest = [u for u in rest if u is not tile]
    # плитка без карточки рядом остаётся, если её подпись — не одно слово со строчной буквы («0–100 / баллов» —
    # шкала схемы, а «Пористость — 21 %» — показатель)
    return [u for u in rest if not u.fixed or len(WORD_RX.findall(u.fixed)) >= 2 or u.fixed[:1].isupper()]


def _cut(items, lo, hi, tol):
    """Разрез по просветам: группы элементов, проекции которых на ось (t–b или x0–x1) не перекрываются
    (tol > 0 — допустимое перекрытие, tol < 0 — наименьший просвет между группами)."""
    groups, end = [], 0.0
    for e in sorted(items, key=lambda e: getattr(e, lo)):
        if groups and getattr(e, lo) < end - tol:
            groups[-1].append(e)
            end = max(end, getattr(e, hi))
        else:
            groups.append([e])
            end = getattr(e, hi)
    return groups


def _zigzag(r1, r2):
    """Два ряда карточек «ёлочкой» (этапы над и под линией времени): колонки нижнего ряда сдвинуты на
    полшага относительно верхнего — такие ряды читаются по x, а не ряд за рядом."""
    c1, c2 = _cut(r1, 'x0', 'x1', 1.0), _cut(r2, 'x0', 'x1', 1.0)
    if len(c1) < 2 or len(c2) < 2 or abs(len(c1) - len(c2)) > 1 or any(len(c) > 1 for c in c1 + c2) or \
            any(c[0].kind != 'box' for c in c1 + c2):
        return False
    m1 = [(c[0].x0 + c[0].x1) / 2 for c in c1]
    m2 = [(c[0].x0 + c[0].x1) / 2 for c in c2]
    step = min(b - a for a, b in zip(m1, m1[1:]))
    if any(min(abs(x - y) for y in m1) < 0.3 * step for x in m2):
        return False
    seq = [k for _, k in sorted([(x, 1) for x in m1] + [(x, 2) for x in m2])]
    return all(a != b for a, b in zip(seq, seq[1:]))


def _cells(row):
    """Ячейки ряда таблицы без линий: каждая колонка ряда — одна короткая надпись без заголовка."""
    cols = _cut(row, 'x0', 'x1', 1.0)
    if all(len(c) == 1 and c[0].kind == 'box' and c[0].head is None and not c[0].extra and not c[0].fixed and
           len(c[0].lines) <= 3 and len(c[0].text) <= 150 for c in cols):
        return [c[0] for c in cols]
    return None


def _grid(rows):
    """Таблица без линий с начала rows: шапка и ≥ 2 строки, в строках ≥ 3 колонки, колонки рядов совпадают
    по x, ряды идут плотно (просвет до трёх строк — не сетка подписей под картинками); в шапке может не быть
    левой ячейки. → (сколько рядов заняла, _Unit('grid')) или None."""
    if len(rows) < 3:
        return None
    head, ref = _cells(rows[0]), _cells(rows[1])
    if not head or not ref or len(ref) < 3 or len(head) not in (len(ref), len(ref) - 1):
        return None
    hs = sorted(ln.b - ln.t for c in head + ref for ln in c.lines)
    near = 3 * hs[len(hs) // 2]

    def tight(r1, r2):
        return min(e.t for e in r2) - max(e.b for e in r1) <= near
    if not tight(head, ref):
        return None
    hmap = list(range(len(ref))) if len(head) == len(ref) else list(range(1, len(ref)))
    for c, j in zip(head, hmap):
        if _overlap(c, ref[j]) <= 0 or any(_overlap(c, ref[i]) > 0 for i in range(len(ref)) if i != j):
            return None
    body = [ref]
    for r in rows[2:]:                           # строки — те же колонки того же кегля (не плитки «число / подпись»)
        cs = _cells(r)
        if not cs or len(cs) != len(ref) or not tight(body[-1], cs) or \
                any(_overlap(c, ref[j]) <= 0 or abs(c.size - ref[j].size) > max(1.0, 0.1 * ref[j].size)
                    for j, c in enumerate(cs)):
            break
        body.append(cs)
    if len(body) < 2:
        return None
    header = [None] * len(ref)
    for c, j in zip(head, hmap):
        header[j] = c
    items = [e for r in rows[:1 + len(body)] for e in r]
    return 1 + len(body), _Unit('grid', (header, body), min(e.x0 for e in items), max(e.x1 for e in items),
                                min(e.t for e in items), max(e.b for e in items))


def _find_grids(boxes):
    """Таблицы без линий среди надписей слайда — до поиска заголовков карточек, иначе жирная шапка
    («Показатель», «Значение», «Ед. изм.») стала бы заголовком первой строки. → (таблицы, остальные надписи)."""
    hs = sorted(ln.b - ln.t for b in boxes for ln in b.lines)
    rows = _cut(boxes, 't', 'b', -0.5 * hs[len(hs) // 2]) if hs else []
    grids, rest, k = [], [], 0
    while k < len(rows):
        g = _grid(rows[k:])
        if g:
            grids.append(g[1])
            k += g[0]
        else:
            rest.extend(rows[k])
            k += 1
    return grids, rest


def _xy_order(items):
    """Порядок чтения элементов слайда: разрезы по просветам — сначала по горизонтали (ряды сверху вниз; просвет
    не меньше половины строки, иначе это не ряды, а соседние колонки разной высоты), затем по вертикали
    (колонки слева направо), и так рекурсивно. Таблица без линий и ряды «ёлочкой» распознаются среди рядов.
    Высокая левая колонка рядом с несколькими надписями справа, которые начинаются выше неё, — по колонкам,
    а не ряд «только справа» первым.
    Если просветов нет — сверху вниз, слева направо."""
    if len(items) <= 1:
        return list(items)
    hs = sorted(ln.b - ln.t for e in items if e.kind == 'box' for ln in e.lines)
    rows = _cut(items, 't', 'b', -0.5 * hs[len(hs) // 2] if hs else 0.0)
    cols = _cut(items, 'x0', 'x1', 1.0)
    if len(rows) > 1 and len(cols) > 1 and not any(e in cols[0] for e in rows[0]) and not _grid(rows):
        t0, b0 = min(e.t for e in cols[0]), max(e.b for e in cols[0])
        if sum(1 for c in cols[1:] for e in c if min(e.b, b0) - max(e.t, t0) >= 0.5 * (e.b - e.t)) >= 2:
            return [e for c in cols for e in _xy_order(c)]
    if len(rows) > 1:
        out, k = [], 0
        while k < len(rows):
            g = _grid(rows[k:])
            if g:
                out.append(g[1])
                k += g[0]
            elif k + 1 < len(rows) and _zigzag(rows[k], rows[k + 1]):
                out.extend(sorted(rows[k] + rows[k + 1], key=lambda e: e.x0 + e.x1))
                k += 2
            else:
                out.extend(_xy_order(rows[k]))
                k += 1
        return out
    if len(cols) > 1:
        return [e for c in cols for e in _xy_order(c)]
    return sorted(items, key=lambda e: (e.t, e.x0))


def _by_numbers(units):
    """Надписи «01 …», «02 …» (≥ 3, номера 1…n без пропусков) идут по номерам с места первой из них
    (цель в центре и задачи вокруг неё); номер из текста убирается, список — нумерованный."""
    found = []
    for k, u in enumerate(units):
        if u.kind == 'box' and not u.fixed:
            m = LEAD_NUM_RX.match((u.head or u).lines[0].text)
            if m:
                found.append((int(m.group(1)), k, m.end()))
    nums = sorted(f[0] for f in found)
    if len(found) < 3 or nums[0] not in (0, 1) or nums != list(range(nums[0], nums[0] + len(nums))):
        return units
    for num, k, cut in found:
        units[k].num, units[k].cut = num, cut
    first, ks = min(f[1] for f in found), {f[1] for f in found}
    return ([u for k, u in enumerate(units) if k < first] + [units[f[1]] for f in sorted(found)] +
            [u for k, u in enumerate(units) if k > first and k not in ks])


def _is_label(u):
    """Короткая подпись схемы: одна строка, до 4 слов, без точки в конце (кроме сокращения «I кв.»), не
    карточка."""
    if u.kind != 'box' or u.head is not None or u.extra or u.fixed or u.num is not None or len(u.lines) > 1:
        return False
    t = u.text
    return bool(LETTER_RX.search(t)) and len(t) <= 40 and len(WORD_RX.findall(t)) <= 4 and \
        not t.endswith(('!', '?')) and not (t.endswith('.') and not re.search(r'(^|\s)\w{1,4}\.$', t)) and \
        not re.search(r'\w:\s+\w', t)                                     # «Решение: робот…» — не подпись


def _merge_labels(units):
    """Подряд идущие короткие подписи одного вида → одна строка: в ряду через запятую («Этапы: Сбор данных,
    Анализ и оценка, Результат»), ряды — через точку с запятой. Ряд из ≥ 3 подписей по 2+ слова — пункты
    списка. Одиночная подпись из одного-двух слов («баллов», «вес блока») — подпись схемы, пропускается,
    если на слайде нет надписей-абзацев того же вида (тогда это пункт столбика: «Эксплуатация с УЭЦН»)."""
    texts_ = [u for u in units if u.kind == 'box' and not _is_label(u)]

    def listed(u):
        return any(abs(o.size - u.size) <= 0.5 and (o.bold >= 0.85) == (u.bold >= 0.85) and
                   _tone_eq(o.color, u.color) for o in texts_)
    out, k = [], 0
    while k < len(units):
        if not _is_label(units[k]):
            out.append(units[k])
            k += 1
            continue
        j = k + 1                                # подписи одного ряда — всегда вместе, следующий ряд — того же
        while j < len(units) and _is_label(units[j]) and (  # кегля и не дальше двух строк
                min(units[j].ob, units[j - 1].ob) - max(units[j].ot, units[j - 1].ot) > 0 or
                abs(units[j].size - max(u.size for u in units[k:j])) <= 1 and
                units[j].ot - units[j - 1].ob <= 2 * (units[j].ob - units[j].ot)):
            j += 1
        group, k = units[k:j], j
        if len(group) == 1:
            if len(WORD_RX.findall(group[0].text)) >= 3 or listed(group[0]):
                out.append(group[0])
            continue
        rows = []
        for u in group:
            if rows and min(rows[-1][-1].ob, u.ob) - max(rows[-1][-1].ot, u.ot) > 0.3 * (u.ob - u.ot):
                rows[-1].append(u)
            else:
                rows.append([u])
        box = (min(u.x0 for u in group), max(u.x1 for u in group), min(u.t for u in group), max(u.b for u in group))
        texts = [[u.text for u in sorted(r, key=lambda u: u.x0)] for r in rows]
        if len(rows) == 1 and len(group) >= 3 and all(len(WORD_RX.findall(t)) >= 2 and not t.endswith(':')
                                                      for t in texts[0]):
            out.append(_Unit('labels', ('', texts[0]), *box))
            continue
        parts = [ts[0] + ' ' + ', '.join(ts[1:]) if ts[0].endswith(':') and len(ts) > 1 else ', '.join(ts)
                 for ts in texts]
        out.append(_Unit('labels', ('; '.join(parts), []), *box))
    return out


def _soft_hyphen(par, ln, words):
    """Дефис в конце строки, который PDF отдаёт как мягкий перенос: «Научно-|технологический» — дефис
    остаётся, если слово так написано в другом месте презентации."""
    left = par.text.rstrip()
    m, r = re.search(r'(\w+)\xad$', left), re.match(r'\w+', ln.text)
    if m and r and f'{m.group(1)}-{r.group(0)}'.lower() in words:
        k = len(left) - 1
        par.text = par.text[:k] + '-' + par.text[k + 1:]


def _box_pars(box, words):
    """Абзацы надписи (_Par): новый абзац — по увеличенному интервалу, по маркеру списка, после строки со
    значением («Научное направление — 15%»), в «столбике» коротких подписей с заглавной буквы («Объект
    исследования / Область применения / …») или определений («wi — вес показателя / si — …»)."""
    lines = box.lines
    gaps = [b.t - a.b for a, b in zip(lines, lines[1:])]
    gmin = min(gaps) if gaps else 0.0
    column = len(lines) >= 3 and (
        all(re.match(r'[«"(]?[А-ЯЁA-Z0-9]', ln.text) for ln in lines) and
        all(len(ln.text.split()) <= 6 and ln.text.rstrip()[-1:] not in ',;:-–—(' + HYPHENS for ln in lines[:-1]) or
        all(re.match(r'\S{1,12}\s[—–]\s', ln.text) for ln in lines))
    pars = []
    for k, ln in enumerate(lines):
        m, mk = LIST_RX.match(ln.text), None
        if m and m.end() < len(ln.text) and (m.group(1) or k == 0 or lines[k - 1].text.rstrip()[-1:] in '.!?:;'):
            mk = (m.group(0), bool(m.group(3) or m.group(4)), ln.x0, ln.xs[m.end()])
        if k == 0 or column or mk or id(ln) in box.breaks or gaps[k - 1] > gmin + max(0.3 * ln.size, 2.0) or \
                re.search(r'\s—\s[\d\s.,%‰+−–-]+$', lines[k - 1].text):
            pars.append(_Par(ln, 'item', mk) if mk else _Par(ln))
        else:
            _soft_hyphen(pars[-1], ln, words)
            pars[-1].add(ln, words, False)
    return pars


def _par_parts(p, cut=0):
    """Абзац → (текст, жирное начало, выделен целиком, выделенная часть) — как абзацы документа. Длинный
    абзац, набранный жирным целиком (основной шрифт слайда — полужирный), жирного начала не имеет."""
    start = len(p.marker[0]) if p.kind == 'item' else cut
    pm = MARK_PREFIX_RX.match(p.text[start:])
    if pm:
        start += pm.end()
    whole, part = _mark_part(p.text, p.mk, start)
    text, bold = clean(p.text[start:].replace('\xad', '')), _bold_prefix(p.text, p.bo, start)
    if bold and len(bold) >= len(text) - 1 and len(WORD_RX.findall(text)) > 10:
        bold = ''
    return text, bold, whole or bool(pm), part


def _join_head(head, text):
    """Заголовок карточки + текст: «Объём и динамика: десятки конкурсов в год…»."""
    if not text:
        return head
    if head[-1:] in '.:!?…':
        return f'{head} {text}'
    return f'{head}. {text[:1].upper() + text[1:]}' if ':' in head else f'{head}: {text}'


def _add_item(sec, item, ordered):
    if sec.blocks and sec.blocks[-1].kind == 'list':
        sec.blocks[-1].items.append(item)
        sec.blocks[-1].ordered = sec.blocks[-1].ordered or ordered
    else:
        sec.blocks.append(Block('list', items=[item], ordered=ordered))


def _box_plain(box, words):
    """Весь текст надписи одной строкой (ячейка таблицы без линий)."""
    return clean(' '.join(_par_parts(p)[0] for p in _box_pars(box, words))) if box is not None else ''


def _emit(model, sec, u, words, grid_xs, name):
    """Элемент слайда → блоки раздела: карточка — пункт с жирным началом (несколько абзацев — вложенными
    пунктами), надпись из нескольких абзацев — пункты, из одного — абзац; «Вывод: …» и «Цель» — абзацы."""
    if u.kind == 'table':
        _add_table(model, sec, u.data, None, None, grid_xs, name)
        return
    if u.kind == 'grid':
        header, body = u.data
        tb = model.add_table([_box_plain(c, words) for c in header],
                             [[_box_plain(c, words) for c in r] for r in body], source=name)
        sec.blocks.append(Block('table', table_id=tb.id))
        return
    if u.kind == 'labels':
        text, items = u.data
        for t in items:
            _add_item(sec, ListItem(t), False)
        if text:
            sec.blocks.append(Block('para', text=text))
        return
    if u.fixed:                                  # плитка «подпись — число» без карточки рядом
        _add_item(sec, ListItem(u.fixed), False)
        return
    ordered = u.num is not None
    parts = [x for k, p in enumerate(_box_pars(u, words))
             for x in [_par_parts(p, u.cut if k == 0 and u.head is None else 0)] if x[0]]
    if u.head is not None:
        hp = [_par_parts(p, u.cut if k == 0 else 0) for k, p in enumerate(_box_pars(u.head, words))]
        head = clean(' '.join(x[0] for x in hp))
        hmark = any(x[2] or x[3] for x in hp)
        if u.extra:
            head = f'{head} ({u.extra})'
        if DECK_CONCL_RX.match(head) or GOAL_RX.match(head):
            sec.blocks.append(Block('para', text=_join_head(head, ' '.join(x[0] for x in parts)), bold=head,
                                    mark=hmark or any(x[2] for x in parts)))
        elif len(parts) <= 1:
            _add_item(sec, ListItem(_join_head(head, parts[0][0] if parts else ''), head, 0,
                                    hmark or any(x[2] or x[3] for x in parts)), ordered)
        else:
            _add_item(sec, ListItem(head, head, 0, hmark), ordered)
            for t, b, whole, part in parts:
                _add_item(sec, ListItem(t, b, 1, whole or bool(part)), ordered)
        return
    if not parts:
        return
    if u.extra:                                  # число-плитка слева от надписи: «Подпись — 40%»
        t, b, whole, part = parts[0]
        parts[0] = (f'{t} — {u.extra}', b, whole, part)
    if ordered or u.nest or u.sib or (len(parts) >= 2 and not all(len(x[0]) > 200 for x in parts)):
        for t, b, whole, part in parts:
            _add_item(sec, ListItem(t, b, 1 if u.nest else 0, whole or bool(part)), ordered)
    else:
        for t, b, whole, part in parts:
            sec.blocks.append(Block('para', text=t, bold=b, mark=whole, mark_text=part))


def _deck_images(pg, lines):
    """Рисунки слайда без значков (меньше 1,5 % площади слайда), узких полос (логотип в строку, цветная
    полоса внизу слайда — длина больше ширины в 5 раз) и подложек, на которых лежит текст."""
    out = []
    for im in pg.images:
        w, h = im.x1 - im.x0, im.b - im.t
        if w * h < 0.015 * pg.w * pg.h or max(w, h) >= 5 * max(min(w, h), 1.0):
            continue
        if any(im.x0 <= (ln.x0 + ln.x1) / 2 <= im.x1 and im.t <= (ln.t + ln.b) / 2 <= im.b and
               LETTER_RX.search(ln.text) for ln in lines):
            continue
        out.append(im)
    return sorted(out, key=lambda e: (e.t, e.x0))


def _deck_slide(pg, words, title_page=False, last=False):
    """Слайд → (заголовок, подзаголовок, элементы по порядку чтения, рисунки). На титуле и последнем слайде
    («Спасибо за внимание!») заголовок может стоять не вверху."""
    lines = _pair_values(list(pg.slines))
    tl = _title_lines(lines, pg, anywhere=True) if title_page else \
        _title_lines(lines, pg) or (_title_lines(lines, pg, anywhere=True) if last else [])
    title = ''
    if tl:
        par = _Par(tl[0])
        for ln in tl[1:]:
            _soft_hyphen(par, ln, words)
            par.add(ln, words, False)
        title = clean(par.text.replace('\xad', ''))
    rest = [ln for ln in lines if all(ln is not t for t in tl)]
    boxes = [b for b in _make_boxes(rest) if re.search(r'[\w%‰]', b.text)] if rest else []   # без «"», «→»
    subtitle = ''
    if tl and boxes:                             # подзаголовок — крупная строка сразу под заголовком
        tb, th = max(l.b for l in tl), tl[-1].b - tl[-1].t
        tx0, tx1 = min(l.x0 for l in tl), max(l.x1 for l in tl)
        body = _body_size(rest)
        cands = [b for b in boxes if not b.numeric and LETTER_RX.search(b.text) and len(b.lines) <= 3 and
                 len(b.text) <= 220 and tb - 0.3 * th <= b.ot <= tb + (3 if title_page else 1.5) * th and
                 (abs(b.ox0 - tx0) <= 2 * b.size or abs(b.ox0 + b.ox1 - tx0 - tx1) <= 4 * b.size) and   # под ним
                 (title_page or b.size >= max(1.15 * body, body + 1.5)) and b.size < tl[0].size]
        if cands:
            sb = min(cands, key=lambda b: b.ot)
            subtitle = _box_plain(sb, words)
            boxes = [b for b in boxes if b is not sb]
    grids, boxes = _find_grids(_join_units(boxes))
    boxes = _attach_numbers(_extend_cards(_attach_heads(boxes)))
    items = boxes + grids + [_Unit('table', t, t.x0, t.x1, t.t, t.b) for t in pg.tables]
    units = _by_numbers(_xy_order(items))
    if not title and units and units[0].kind == 'box' and units[0].head is None and not units[0].fixed and \
            len(units[0].lines) <= 3:
        text = _box_plain(units[0], words)       # заголовок не выделен кеглем — первая короткая надпись
        if 3 <= len(text) <= 90:
            title, units = text, units[1:]
    units = _merge_labels(units)
    for a, b in zip(units, units[1:]):           # легенда «подпись — значение» справа от карточки — её пункты
        if a.kind == b.kind == 'box' and a.head is not None and b.head is None and b.x0 >= a.x1 - 2 and \
                min(a.b, b.b) - max(a.t, b.t) > 0.5 * min(a.b - a.t, b.b - b.t) and \
                all(re.search(r'\s—\s[\d\s.,%‰+−–-]+$', ln.text) for ln in b.lines):
            b.nest = True
    for u in units:                              # ряд одинаковых карточек, у части нет заголовка — все пункты
        h = u.lines[0].b - u.lines[0].t if u.kind == 'box' else 0
        if u.kind == 'box' and u.head is None and not u.fixed and any(
                c.kind == 'box' and c.head is not None and abs(c.size - u.size) <= 1 and abs(c.ot - u.ot) <= h and
                abs((c.ox1 - c.ox0) - (u.ox1 - u.ox0)) <= 0.15 * max(c.ox1 - c.ox0, u.ox1 - u.ox0) for c in units):
            u.sib = True
    return title, subtitle, units, _deck_images(pg, pg.slines)


def _title_slide(pg):
    """Первый слайд — титул: название ниже обычного места заголовка (ближе к середине) или, кроме него,
    не больше пяти надписей (подзаголовок, докладчик, дата). Первый слайд каталога с заголовком вверху и
    десятком подписей — обычный слайд."""
    tl = _title_lines(pg.slines, pg, anywhere=True)
    if not tl:
        return False
    rest = [ln for ln in pg.slines if all(ln is not t for t in tl)]
    return tl[0].t >= 0.15 * pg.h or len(_make_boxes(rest) if rest else []) <= 5


def _read_deck(model, pages, cache, meta, name):
    """Страницы PDF-презентации → разделы «один слайд — один раздел» (см. описание режима выше)."""
    _drop_deck_running(pages)
    words = {w.lower() for p in pages for ln in p.slines for w in re.findall(r'\w+(?:-\w+)*', ln.text)}
    title = subtitle = ''
    secs, grid_xs = [], {}
    filled = [p for p in pages if p.slines or p.tables]
    for pg in pages:
        chars = sum(len(ln.text) for ln in pg.slines)
        is_title = bool(filled) and pg is filled[0] and chars <= 400 and not pg.tables and _title_slide(pg)
        name_, sub_, units, images = _deck_slide(pg, words, is_title, len(filled) > 1 and pg is filled[-1])
        if is_title and name_:                   # титульный слайд: название и подзаголовок документа
            title, subtitle = name_, sub_
            continue
        if DECK_TOC_RX.match(name_) or (DECK_END_RX.match(name_) and chars <= 300 and not pg.tables):
            continue                             # «Содержание», «Спасибо за внимание»
        blocks = [b for b in (_image_block(model, cache, im, name) for im in images) if b is not None]
        if not name_ and not units:              # слайд-картинка без текста — к предыдущему слайду
            if secs:
                secs[-1].blocks.extend(blocks)
            continue
        sec = Section(title=name_ or f'Слайд {pg.no + 1}', level=1, source=name)
        divider = not pg.tables and not blocks and len(units) <= 1 and \
            all(u.kind == 'box' and len(WORD_RX.findall(u.text)) <= 6 for u in units)
        if not divider:                          # слайд-разделитель («Раздел 2. …») — только заголовок
            if sub_:
                sec.blocks.append(Block('para', text=sub_))
            for u in units:
                _emit(model, sec, u, words, grid_xs, name)
            sec.blocks.extend(blocks)
            # «Цель: …» (цель в центре схемы) — первым абзацем: это главная мысль слайда
            goal = next((b for b in sec.blocks if b.kind == 'para' and GOAL_RX.match(b.bold or '')), None)
            if goal is not None:
                sec.blocks.remove(goal)
                sec.blocks.insert(0, goal)
        secs.append(sec)
    title = title or meta or (secs[0].title if secs else '')
    if not model.title:
        model.title = title
    if subtitle and not model.subtitle:
        model.subtitle = subtitle
    model.sections.extend(secs)


def _image_block(model, cache, im, name):
    """Рисунок → блок 'image' (как в документе) или None, если сохранить не удалось."""
    blob = cache.get(im.data[0])
    img = _save_image(blob[0], blob[1], model.warnings, name) if blob else None
    return Block('image', image_id=model.add_image(img, im.data[1], im.data[2])) if img is not None else None


# ---------------------------------------------------------------- главная функция

def read_pdf(path, doc_model=None, name=None):
    """Читает .pdf и добавляет его содержимое в модель Document (или создаёт новую)."""
    model = doc_model or Document()
    name = name or str(path)
    model.sources.append(name)
    if pdfium is None:
        model.warnings.append(f'{name}: для чтения PDF нужна библиотека pypdfium2 (запустите setup_windows.bat).')
        return model
    try:
        pdf = pdfium.PdfDocument(Path(path).read_bytes())    # байтами: кириллица в пути Windows не мешает
    except pdfium.PdfiumError as e:
        if getattr(e, 'err_code', None) == pdfium_c.FPDF_ERR_PASSWORD or 'password' in str(e).lower():
            model.warnings.append(f'{name}: PDF защищён паролем — откройте его, сохраните копию без пароля '
                                  f'и загрузите снова (или загрузите исходный Word).')
        else:
            model.warnings.append(f'{name}: не удалось открыть PDF — файл повреждён или это не PDF.')
        return model
    cache = {}
    try:
        pages = [_read_page(pdf, i, cache) for i in range(len(pdf))]
        meta = _meta_title(pdf)
    finally:
        pdf.close()

    # Скан или текст без таблицы символов
    if not any(p.lines or p.tables for p in pages):
        if any(p.bad for p in pages):
            model.warnings.append(f'{name}: текст в PDF записан без таблицы символов — извлечь его нельзя. '
                                  f'Нужен исходный Word или другой PDF.')
        else:
            model.warnings.append(f'{name}: в PDF нет текстового слоя (скан) — текст не распознан. '
                                  f'Нужен PDF с текстом или исходный Word.')
        return model
    scans = [p.no + 1 for p in pages if not p.lines and not p.tables and (p.scan or p.bad)]
    if scans:
        model.warnings.append(f'{name}: страницы {", ".join(map(str, scans[:12]))}{" …" if len(scans) > 12 else ""} '
                              f'без текстового слоя (скан) — их текст не распознан.')

    _drop_logos(pages)
    if _deck_like(pages):                        # PDF из PowerPoint — читается по слайдам
        _read_deck(model, pages, cache, meta, name)
        return model
    _drop_running(pages)

    flow = [x for p in pages for x in _page_flow(p)]
    # оглавление («Глава 1 ........ 5») и заголовок «Содержание» перед ним пропускаются (как стили TOC в Word)
    toc = [isinstance(x, _Line) and bool(TOC_RX.search(x.text)) for x in flow]
    flow = [x for i, x in enumerate(flow) if not toc[i] and not (
        isinstance(x, _Line) and TOC_HEAD_RX.match(x.text) and any(toc[i + 1:i + 3]))]
    lines = [x for x in flow if isinstance(x, _Line)]
    sizes = Counter()
    for ln in lines:
        sizes[ln.size] += len(ln.text)
    body = sizes.most_common(1)[0][0] if sizes else 11.0
    # обычный межстрочный интервал (в долях кегля) — по соседним строкам
    pitches = sorted((b.b - a.b) / b.size for a, b in zip(lines, lines[1:])
                     if a.page == b.page and a.col == b.col and abs(a.size - b.size) <= 0.6 and
                     0.8 * b.size < b.b - a.b < 2.5 * b.size)
    pitch_k = pitches[int(0.3 * (len(pitches) - 1))] if pitches else 1.2
    # слова документа и частота переносов — чтобы отличить перенос от настоящего дефиса
    words = {w.lower() for ln in lines for w in re.findall(r'\w+(?:-\w+)*', ln.text)}
    hy = sum(1 for a, b in zip(lines, lines[1:]) if re.search(r'\w[-‐\xad]$', a.text) and b.text[:1].islower())
    hyphenates = hy >= 5 and hy >= 0.05 * len(lines)

    pars = _paragraphs(flow, words, hyphenates, pitch_k)
    keys = [_heading_key(p, pars[i + 1] if i + 1 < len(pars) else None, body) for i, p in enumerate(pars)]

    # Название (и подзаголовок) — с первой страницы, в тексте не повторяются
    title, subtitle = '', ''
    ti = _find_title(pars, keys, meta, body, pages[0].no)
    if ti is not None:
        tp_, nxt = pars[ti], pars[ti + 1] if ti + 1 < len(pars) else None
        title = clean(tp_.text.replace('\xad', ''))
        drop = {ti}
        if isinstance(nxt, _Par) and nxt.kind == 'para' and nxt.page == tp_.page and len(nxt.text) <= 150 and \
                body + 1 <= nxt.size < tp_.size and sum(1 for p in pars if isinstance(p, _Par) and
                                                        p.size == nxt.size) == 1:
            subtitle = clean(nxt.text.replace('\xad', ''))
            drop.add(ti + 1)
        pars = [p for i, p in enumerate(pars) if i not in drop]
        keys = [k for i, k in enumerate(keys) if i not in drop]
    elif meta:
        title = meta
    # подряд идущие нумерованные строки одного вида — это нумерованный список, а не заголовки
    demote = [i for i, k in enumerate(keys) if k and pars[i].kind == 'item' and any(
        0 <= j < len(pars) and keys[j] == k and pars[j].kind == 'item' for j in (i - 1, i + 1))]
    for i in demote:
        keys[i] = None
    levels = _heading_levels(keys)

    # Сборка разделов (как в docx_reader)
    root = Section(title='', level=0, source=name)
    stack = [root]
    caption = None                               # подпись «Таблица N…» перед таблицей
    last_image = last_table = None
    grid_xs = {}                                 # таблица → x линий сетки (для продолжения на след. странице)
    list_base = 0.0
    for i, (p, key) in enumerate(zip(pars, keys)):
        sec = stack[-1]
        if isinstance(p, _El) and p.kind == 'table':
            _add_table(model, sec, p, caption, last_table, grid_xs, name)
            last_table = sec.blocks[-1] if sec.blocks and sec.blocks[-1].kind == 'table' else None
            caption = None
            continue
        last_table = None
        if isinstance(p, _El):                   # рисунок
            blob = cache.get(p.data[0])
            img = _save_image(blob[0], blob[1], model.warnings, name) if blob else None
            if img is not None:
                last_image = Block('image', image_id=model.add_image(img, p.data[1], p.data[2]))
                sec.blocks.append(last_image)
            continue
        start = len(p.marker[0]) if p.kind == 'item' else 0
        pm = MARK_PREFIX_RX.match(p.text[start:])               # «!» в начале — выделено автором
        if pm:
            start += pm.end()
        whole, part = _mark_part(p.text, p.mk, start)
        whole = whole or bool(pm)
        text = clean(p.text[start:].replace('\xad', ''))
        if not text:
            continue
        if last_image is not None and CAPTION_RX.match(text) and len(text) < 200:
            last_image.text = FIG_CAP_CUT.sub('', text)
            last_image.mark = last_image.mark or whole
            last_image = None
            continue
        last_image = None
        if key:
            level = levels[key]
            new = Section(title=text, level=level, source=name, mark=whole or bool(part))
            while len(stack) > 1 and stack[-1].level >= level:
                stack.pop()
            stack[-1].children.append(new)
            stack.append(new)
            continue
        nxt = pars[i + 1] if i + 1 < len(pars) else None
        if p.kind == 'para' and TABLE_CAP_RX.match(text) and len(text) < 160 and \
                isinstance(nxt, _El) and nxt.kind == 'table':
            caption = (TABLE_CAP_CUT.sub('', text) or text, whole)
            continue
        bold = _bold_prefix(p.text, p.bo, start)
        if p.kind == 'item':
            x = p.marker[2]
            if not (sec.blocks and sec.blocks[-1].kind == 'list'):
                list_base = x
            list_base = min(list_base, x)
            item = ListItem(text, bold, 0 if x - list_base < 12 else (1 if x - list_base < 30 else 2),
                            whole or bool(part))
            if sec.blocks and sec.blocks[-1].kind == 'list':
                sec.blocks[-1].items.append(item)
            else:
                sec.blocks.append(Block('list', items=[item], ordered=p.marker[1]))
            continue
        sec.blocks.append(Block('para', text=text, bold=bold, mark=whole, mark_text=part))

    # Текст до первого заголовка — вводный раздел; одна «обёртка» верхнего уровня — это название
    secs = []
    if root.blocks:
        secs.append(Section(title='Введение' if root.children else (title or 'Основное'), level=1,
                            blocks=root.blocks, source=name))
    secs.extend(root.children)
    if len([s for s in secs if s.level == 1]) == 1 and len(secs) == 1 and secs[0].children:
        if not title:
            title = secs[0].title
        intro = secs[0]
        secs = ([Section('Введение', 1, intro.blocks, source=name)] if intro.blocks else []) + intro.children
        for s in secs:
            _promote(s)
    if not title and secs:
        title = secs[0].title
    if not model.title:
        model.title = title
    if subtitle and not model.subtitle:
        model.subtitle = subtitle
    model.sections.extend(secs)
    return model


def _add_table(model, sec, el, caption, last_table, grid_xs, name):
    """Таблица → model.tables и блок раздела (как в docx_reader). Таблица, продолжающая предыдущую
    (следующая страница, те же столбцы), дописывается к ней; повтор шапки пропускается."""
    rows, copies, marked, xs = el.data
    nz = [i for i, r in enumerate(rows) if any(c.strip() for c in r)]
    rows, copies = [rows[i] for i in nz], [copies[i] for i in nz]
    if last_table is not None and caption is None:
        tb = model.tables.get(last_table.table_id)
        prev_xs = grid_xs.get(last_table.table_id)
        if tb is not None and prev_xs and len(prev_xs) == len(xs) and all(abs(a - b) <= 3 for a, b in zip(xs, prev_xs)):
            extra = [r for r in rows if len(r) == len(tb.columns)]
            if extra and [clean(x) for x in extra[0]] == [clean(x) for x in tb.columns]:
                extra = extra[1:]
            if extra:
                tb.rows.extend(extra)
                tb.analyze()
                return
    distinct = max((sum(1 for x, f in zip(r, c) if x.strip() and not f) for r, c in zip(rows, copies)), default=0)
    if len(rows) >= 2 and distinct >= 2:
        cap, header, body = _split_table(rows, copies)
        if body and len(header) >= 2:
            cap = TABLE_CAP_CUT.sub('', cap)
            tb = model.add_table(header, body, title=(caption[0] if caption else '') or cap, source=name)
            blk = Block('table', table_id=tb.id, mark=bool(caption and caption[1]) or marked)
            if len(header) == len(xs) - 1:
                grid_xs[tb.id] = xs
            sec.blocks.append(blk)
            return
    if caption:
        sec.blocks.append(Block('para', text=caption[0], mark=caption[1]))
    for r, cf in zip(rows, copies):              # таблица-«рамка» из одной колонки — это просто текст
        for c, f in zip(r, cf):
            if c.strip() and not f:
                sec.blocks.append(Block('para', text=c))
