# -*- coding: utf-8 -*-
"""
pictures.py — КАРТИНКИ К СЛАЙДАМ: БИБЛИОТЕКА, КАРТЫ СТРАН И СВОИ КАРТИНКИ ПОЛЬЗОВАТЕЛЯ
====================================================================================

Библиотека — assets/pictures/*.svg и каталог assets/pictures/catalog.json (название, раздел, основы
слов для подбора, источник). Все рисунки векторные, в фирменной палитре; при сборке svgdraw
переводит их в обычные фигуры PowerPoint (их можно перекрасить и подвинуть).

Карта страны — та же карта мира (engine/geo.py), выбранная страна выделена: код «map_VNM».

Свои картинки пользователя (PNG, JPEG, GIF, BMP, WEBP, TIFF, SVG) сохраняются в output/uploads/ под
именем-хэшем; растровые приводятся к PNG/JPEG и уменьшаются до 2400 точек по большей стороне,
SVG очищается (svgdraw.sanitize), хранится файлом .svg и при сборке становится фигурами, как рисунки
библиотеки. Исходное имя файла и время загрузки — в output/uploads/index.json (для окна «Мои картинки»
и подбора по словам из имени файла).

В плане рисунок слайда «image» — элемент images: {'picture': код} (библиотека или карта),
{'upload': имя файла} (своя картинка), {'svg': текст} (рисунок модели ИИ), {'path': путь}
(рисунок из документа). resolve() превращает ссылку в то, что умеет рисовать макет.

  catalog(), get(id), svg(id), countries_list()
  suggest(slide, n)      — картинки, подходящие к слайду по словам заголовка и текста;
  deck_suggest(slides)   — картинки, подходящие к презентации в целом (окно «Картинки к слайдам»);
  picture_alt(slide, im, full=False, label=…) — вариант слайда с картинкой (im — одна или список до 3);
  distribute(slides, images, mode) — раскладка выбранных картинок по слайдам (по смыслу или по порядку);
  save_upload(data, filename) → элемент images для своей картинки;
  list_uploads(), delete_upload(name) — свои картинки: список и удаление;
  auto_pictures(slides)  — при анализе: картинка-вариант к подходящим слайдам.

Фотографии (1.7). Встроенные — assets/photos/catalog.json и снимки рядом (id «ph_…», поля name, cat, tags,
source {site, author, license, url, credit}); в плане — {'picture': 'ph_…'}, в окне выбора — вкладка «📷 Фото».
Строка credit (автор и лицензия) при сборке попадает в заметки слайда (image_credits).

Свои фотографии в библиотеке (1.7). Свою картинку (растр) можно добавить в библиотеку фотографий: в индексе
output/uploads/index.json у неё отметка lib, раздел cat (по умолчанию «Мои фото») и автор. В каталоге она —
фотография с id «ph_my_<хэш>» и теми же полями (name, cat, tags, source, credit), поэтому её находят поиск, подбор
к слайдам по словам и по смыслу и окно «📷 Фото», как встроенные снимки. set_library(имя, on, cat, author).

Название по содержанию у каждой картинки: у библиотеки и фотографий — из каталога; у своих картинок — по порядку
из описания внутри файла (XMP, IPTC, EXIF — так подписывают снимки фотобанки), из осмысленного имени файла или
папки архива; если их нет — название даёт локальная модель, которая распознаёт изображения (autoname, кнопка
«Назвать по содержанию»); любое название можно поправить (set_title). Название — подпись в окнах, подбор к слайдам
по словам и замещающий текст картинки в .pptx.
"""
import hashlib
import html
import io
import json
import re
import threading
import time
from functools import lru_cache
from pathlib import Path

from .nts import config as C

PIC_DIR = C.ASSETS / 'pictures'
CATALOG_FILE = PIC_DIR / 'catalog.json'
PHOTO_DIR = C.ASSETS / 'photos'                             # встроенные фотографии (1.7)
PHOTO_CATALOG = PHOTO_DIR / 'catalog.json'
PHOTO_RX = re.compile(r'ph_[a-z0-9_]{1,60}')
THUMB_DIR = C.OUTPUT_DIR / 'cache' / 'thumbs'               # уменьшенные копии для окон выбора
UPLOAD_DIR = C.OUTPUT_DIR / 'uploads'
CATEGORIES = ['Зарубежнефть', 'Нефть и газ', 'Разведка и добыча', 'Шельф', 'Переработка и сбыт', 'Наука и технологии',
              'Энергетика', 'Низкоуглеродное развитие', 'Экология и безопасность', 'Логистика и строительство',
              'Финансы', 'Управление и стратегия', 'Цифровизация', 'Люди и коммуникации', 'Документы и контроль',
              'Элементы оформления', 'Карты']
DECOR = 'el_'                # элементы оформления (номера, выноски, ленты, рамки) — не иллюстрации: сами к слайдам
                             # не предлагаются, их выбирают в окне картинок (категория или поиск)
RASTER = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp', '.tif', '.tiff'}
MAX_UPLOAD = 25 * 1024 * 1024
MAX_SIDE = 2400
# слайды, к которым картинка подходит как вариант (тезисы рядом с рисунком)
PICTURE_LAYOUTS = ('text', 'list', 'cards', 'conclusions', 'process', 'target', 'honeycomb', 'pillars', 'hub',
                   'petals', 'puzzle', 'converge', 'checklist')
# слайды, на которые картинку не ставим даже вручную: титул, разделы, содержание, финал, таблица, диаграмма
NO_PICTURE = ('title', 'section', 'end', 'agenda', 'table', 'chart')
MAX_PER_SLIDE = 3                                           # столько картинок помещается на слайд (макет image)
UPLOAD_RX = re.compile(r'[0-9a-f]{20}\.(png|jpg|svg)')
MY_CAT = 'Мои фото'                                         # раздел своих фотографий в библиотеке (1.7)
MY_PREFIX = 'ph_my_'


class PictureError(Exception):
    pass


# --------------------------------------------------------------------------------------
# Каталог
# --------------------------------------------------------------------------------------
@lru_cache(maxsize=1)
def _builtin():
    """Рисунки библиотеки и встроенные фотографии (только те, у которых есть файл), в порядке разделов."""
    try:
        raw = json.loads(CATALOG_FILE.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        raw = []
    out = []
    for e in raw:
        if isinstance(e, dict) and re.fullmatch(r'[a-z0-9_]+', str(e.get('id') or '')) \
                and (PIC_DIR / f'{e["id"]}.svg').exists():
            out.append({'id': e['id'], 'name': e.get('name') or e['id'], 'cat': e.get('cat') or 'Разное',
                        'tags': [t.lower() for t in e.get('tags') or [] if isinstance(t, str) and len(t) >= 3],
                        'source': e.get('source') or {}})
    out += photos()
    order = {c: i for i, c in enumerate(CATEGORIES)}
    out.sort(key=lambda e: (order.get(e['cat'], 99), not e.get('photo'), e['id'].startswith('fe_')))
    return out


def _stems(words):
    """Основы слов для подбора по смыслу: «платформы» и «платформа» → «платфо»."""
    from .phrases import stems
    return list(dict.fromkeys(stems(' '.join(words))))


def photos():
    """Встроенные фотографии из assets/photos/catalog.json (только с файлом рядом)."""
    try:
        raw = json.loads(PHOTO_CATALOG.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return []
    out = []
    for e in raw if isinstance(raw, list) else []:
        if not isinstance(e, dict) or not PHOTO_RX.fullmatch(str(e.get('id') or '')):
            continue
        f = PHOTO_DIR / str(e.get('file') or f'photos/{e["id"]}.jpg')
        try:
            ok = f.resolve().is_relative_to(PHOTO_DIR.resolve()) and f.is_file()
        except (OSError, ValueError):
            ok = False
        if not ok:
            continue
        src = e.get('source') if isinstance(e.get('source'), dict) else {}
        tags = [str(t) for t in e.get('tags') or [] if isinstance(t, str)]
        out.append({'id': e['id'], 'name': str(e.get('name') or e['id'])[:90], 'cat': e.get('cat') or 'Нефть и газ',
                    'tags': _stems([str(e.get('name') or '')] + tags), 'source': src, 'photo': True,
                    'path': str(f), 'credit': str(src.get('credit') or _credit(src))[:300]})
    return out


def _credit(src):
    """Строка авторства по полям источника: «Фото: Иван Петров, CC BY-SA 4.0, Викисклад»."""
    parts = [str(src.get(k) or '').strip() for k in ('author', 'license', 'site')]
    return ('Фото: ' + ', '.join(p for p in parts if p)) if any(parts) else ''


_CAT = {'key': None, 'list': [], 'by_id': {}}


def catalog():
    """Каталог: рисунки библиотеки, встроенные фотографии и свои фотографии, добавленные в библиотеку (1.7) —
    «Мои фото» первыми; свои снимки в другом разделе — первыми в своём разделе."""
    try:
        st = _index_file().stat()
        key = (str(UPLOAD_DIR), st.st_mtime_ns, st.st_size)
    except OSError:
        key = (str(UPLOAD_DIR), None)
    if _CAT['key'] != key:
        mine = my_photos() if key[1] is not None else []
        out = list(_builtin())
        if mine:
            order = {c: i for i, c in enumerate(CATEGORIES)}
            out = sorted(mine + out, key=lambda e: (-1 if e['cat'] == MY_CAT else order.get(e['cat'], 99),
                                                    not e.get('mine'), not e.get('photo')))
        _CAT.update(key=key, list=out, by_id={e['id']: e for e in out})
    return _CAT['list']


def _by_id():
    catalog()
    return _CAT['by_id']


def my_photos():
    """Свои фотографии в библиотеке: свои растровые картинки с отметкой lib, новые первыми."""
    idx = _load_index()
    out = []
    for name, e in idx.items():
        if not isinstance(e, dict) or not e.get('lib') or not UPLOAD_RX.fullmatch(str(name)) or name.endswith('.svg'):
            continue
        p = UPLOAD_DIR / name
        if not p.is_file():
            continue
        title = upload_title(name, idx) or 'Моё фото'
        author = str(e.get('author') or '').strip()[:80]
        cat = e.get('cat') if e.get('cat') in CATEGORIES and e.get('cat') not in ('Элементы оформления', 'Карты') else MY_CAT
        out.append({'id': MY_PREFIX + name[:20], 'name': title[:90], 'cat': cat,
                    'tags': _stems([title] + [str(t) for t in e.get('tags') or []]),
                    'source': {'author': author, 'license': 'своё фото'}, 'photo': True, 'mine': True, 'upload': name,
                    'path': str(p), 'credit': f'Фото: {author}' if author else '', 'added': str(e.get('added') or '')})
    out.sort(key=lambda x: x['added'], reverse=True)
    return out


def set_library(name, on=True, cat=None, author=None):
    """Своя картинка — в библиотеку фотографий (on=True) или из неё; раздел и автор (для подписи в заметках).
    Векторный рисунок (SVG) — не фотография. True — сохранено."""
    if not upload_path(name) or str(name).endswith('.svg'):
        return False
    with _INDEX_LOCK:
        idx = _load_index()
        e = dict(idx.get(name) or {})
        if on:
            e['lib'] = True
        else:
            e.pop('lib', None)
        if cat is not None:
            e['cat'] = cat if cat in CATEGORIES and cat not in ('Элементы оформления', 'Карты') else MY_CAT
        if author is not None:
            a = re.sub(r'\s+', ' ', str(author)).strip()[:80]
            e['author'] = a
            e['credit'] = f'Фото: {a}' if a else ''
        idx[name] = e
        try:
            _save_index(idx)
        except OSError:
            return False
    return True


def countries_list():
    """[{'id': 'map_VNM', 'name': 'Вьетнам'}] — для выбора карты страны."""
    from .geo import countries
    return sorted(({'id': f'map_{c["id"]}', 'name': c['name']} for c in countries().values() if c['name']),
                  key=lambda c: c['name'])


COUNTRY_RX = re.compile(r'map_[A-Z0-9]{3}')                 # карта страны: map_ + код ISO (заглавными); id библиотеки — строчными


def get(pid):
    pid = str(pid or '')
    if COUNTRY_RX.fullmatch(pid):
        from .geo import countries
        c = countries().get(pid[4:])
        return {'id': pid, 'name': f'Карта: {c["name"]}', 'cat': 'Карты', 'tags': [], 'source': {}} if c else None
    return _by_id().get(pid)


@lru_cache(maxsize=256)
def svg(pid):
    """Текст SVG рисунка (очищенный). Нет такого — PictureError."""
    from .svgdraw import SvgError, sanitize
    pid = str(pid or '')
    if COUNTRY_RX.fullmatch(pid):
        if not get(pid):
            raise PictureError(f'нет страны {pid[4:]}')
        from .geo import picture_svg
        return picture_svg([pid[4:]])
    if PHOTO_RX.fullmatch(pid):
        raise PictureError(f'«{pid}» — фотография, а не рисунок')
    if not re.fullmatch(r'[a-z0-9_]+', pid) or not (PIC_DIR / f'{pid}.svg').exists():
        raise PictureError(f'нет картинки «{pid}» в библиотеке')
    try:
        return sanitize((PIC_DIR / f'{pid}.svg').read_text(encoding='utf-8'))
    except (OSError, SvgError) as e:
        raise PictureError(f'картинка «{pid}» повреждена: {e}')


# --------------------------------------------------------------------------------------
# Подбор по смыслу
# --------------------------------------------------------------------------------------
_TOK = re.compile(r'[а-яёa-z0-9]+')


def _tokens(text):
    return _TOK.findall((text or '').lower().replace('ё', 'е'))


def _hits(tags, toks):
    """Совпавшие основы. Основа из нескольких слов («ремонт скважин») совпадает, только если есть все её слова."""
    out = set()
    for t in tags:
        if all(any(w.startswith(p) for w in toks) for p in t.replace('ё', 'е').split()):
            out.add(t)
    return out


def _matched_tokens(tags, toks):
    parts = {p for t in tags for p in t.replace('ё', 'е').split()}
    return {w for w in toks if any(w.startswith(p) for p in parts)}


def _slide_texts(s):
    from .illustrate import slide_subject
    return s.get('title') or '', slide_subject(s)


def suggest(s, n=8, query=None):
    """[(запись каталога, баллы)] по убыванию: совпадение основы в заголовке — 3 балла, в тексте — 1;
    у пиктограмм (fe_…) баллы ×0,6, поэтому сами по себе они добавляются, только если совпали два слова заголовка;
    элементы оформления (el_…) — только по явному запросу."""
    title, body = (query, '') if query else _slide_texts(s)
    tt, bt = _tokens(title), _tokens(body)
    res, df = [], {}
    for e in catalog():
        if not query and e['id'].startswith(DECOR):
            continue
        th = _hits(e['tags'], tt)
        bh = _hits(e['tags'], bt) - th
        sc = 3 * len(th) + len(bh) + (2 if query and _tokens(e['name']) and
                                      all(any(w.startswith(x[:5]) for w in tt) for x in _tokens(e['name'])) else 0)
        if sc and e['id'].startswith('fe_'):                 # пиктограммы — запасной вариант после сюжетных картинок
            sc = round(sc * 0.6, 1)
        elif sc and e.get('photo'):                          # настоящая фотография — первой при равном совпадении
            sc = round(sc * 1.2, 1)
        if sc:
            mt = _matched_tokens(th, tt)
            for w in mt:
                df[w] = df.get(w, 0) + 1
            res.append((e, sc, len(th), mt))
    # при равных баллах выше своё фото (его добавили в библиотеку, чтобы оно подбиралось), затем картинка, совпавшая
    # по более редкому слову заголовка («двойник» точнее, чем «месторождение»)
    res.sort(key=lambda r: (-r[1], not r[0].get('mine'), -r[2], -sum(1 / df[w] for w in r[3]), r[0]['id'].startswith('fe_')))
    return [(e, sc) for e, sc, _, _ in res[:n]]


# ---- подбор по смыслу моделью поиска (1.7) ---------------------------------------------
# Названия картинок (их дают авторы снимков, файл или модель, которая видит изображения) и текст слайда
# сравниваются по смыслу той же локальной моделью поиска, что подбирает фразы (bge-m3). Векторы названий —
# в кэше output/search; первый раз они считаются в фоне (пока — подбор по словам).
_SEM = {'key': None, 'searcher': None, 'entries': [], 'thread': None, 'error': ''}
_SEM_LOCK = threading.Lock()


def _sem_text(e):
    """Текст картинки для модели поиска: название, раздел; у фотографий — ещё ключевые слова (целыми словами)."""
    words = [t for t in (e.get('tags') or []) if len(t) > 3][:8] if e.get('photo') else []
    return '. '.join(x for x in (e['name'], e.get('cat') or '', ', '.join(words)) if x)


def sem_searcher(cfg, wait=False):
    """Поиск по смыслу в каталоге картинок (phrases.Searcher) или None: модель поиска не настроена / не на связи /
    названия ещё готовятся (wait=False — тогда векторы считаются в фоне, а подбор пока по словам)."""
    from .llm_client import LLMError, side_cfg
    from .phrases import Searcher, cached_vectors, embed_texts
    if not cfg:
        return None
    try:
        model = side_cfg(cfg, 'embed')['model']
    except LLMError:
        return None
    entries = [e for e in catalog() if not COUNTRY_RX.fullmatch(e['id'])]
    texts = [_sem_text(e) for e in entries]
    key = (model, cfg.get('embed_url'), hashlib.sha1('\n'.join(texts).encode('utf-8')).hexdigest())
    with _SEM_LOCK:
        if _SEM['key'] == key and _SEM['searcher'] is not None:
            return _SEM['searcher']
    if not wait and len(set(texts) - set(cached_vectors(model, texts))) > 0:
        with _SEM_LOCK:
            t = _SEM['thread']
            if not (t and t.is_alive()):
                def run():
                    try:
                        embed_texts(cfg, texts)
                        _SEM['error'] = ''
                    except Exception as e:                   # noqa: BLE001 — фон не роняет сервер
                        _SEM['error'] = str(e)
                _SEM['thread'] = threading.Thread(target=run, daemon=True, name='pictures-embed')
                _SEM['thread'].start()
        return None
    sr = Searcher([{'t': t} for t in texts], cfg)
    if not sr.prepare():
        _SEM['error'] = sr.reason
        return None
    with _SEM_LOCK:
        _SEM.update(key=key, searcher=sr, entries=entries, error='')
    return sr


def _query(s):
    title, body = _slide_texts(s)
    return re.sub(r'\s+', ' ', f'{title}. {body}').strip()[:600]


def sem_hits(slides, cfg, k=8, wait=False, queries=None):
    """Картинки по смыслу к каждому слайду: [[(запись каталога, уверенность 0…1)], …] (пустые — если модели нет)."""
    from .llm_client import LLMError
    from .phrases import embed_texts
    sr = sem_searcher(cfg, wait)
    qs = queries or [_query(s) if isinstance(s, dict) else '' for s in slides]
    if not sr:
        return [[] for _ in qs]
    try:
        vec = embed_texts(cfg, [q for q in qs if q])
    except LLMError:
        return [[] for _ in qs]
    entries = _SEM['entries']
    return [[(entries[i], c) for i, c in sr.hits(q, vec.get(q), k)] if q in vec else [] for q in qs]


def smart_suggest(s, n=8, query=None, sem=None):
    """Слова + смысл: [(запись, балл 0…1, 'смысл'|'слова')]. sem — готовые попадания модели поиска (sem_hits)."""
    score = {}
    for e, sc in suggest(s, n * 2, query=query):
        score[e['id']] = [e, min(1.0, sc / 6.0), 'слова']
    for e, c in sem or []:
        if not query and e['id'].startswith(DECOR):
            continue
        cur = score.get(e['id'])
        if cur is None or c > cur[1]:
            score[e['id']] = [e, c if cur is None else min(1.0, c + 0.1), 'смысл']
        else:
            cur[1] = min(1.0, cur[1] + 0.1)                  # совпали и слова, и смысл
    out = []
    for e, sc, how in score.values():
        if e.get('photo'):
            sc = min(1.0, sc * 1.1)                          # настоящая фотография — первой при равном совпадении
        elif e['id'].startswith('fe_'):
            sc *= 0.7
        out.append((e, round(sc, 3), how))
    out.sort(key=lambda r: (-r[1], not r[0].get('photo')))
    return out[:n]


def search(query, cat=None, limit=200):
    """Поиск по названию и основам слов (для окна выбора)."""
    q = _tokens(query)
    out = []
    for e in catalog():
        if cat and e['cat'] != cat:
            continue
        if q:
            name = _tokens(e['name'])
            if not all(any(w.startswith(x) or x.startswith(w[:4]) for w in name + e['tags']) for x in q):
                continue
        out.append(e)
    return out[:limit]


# --------------------------------------------------------------------------------------
# Свои картинки
# --------------------------------------------------------------------------------------
def save_upload(data, filename, folder=''):
    """Байты файла → элемент images: {'upload': имя} (растр или SVG). Ошибка → PictureError.
    Название по содержанию — из описания внутри файла, имени файла или папки архива (folder); его нет — пусто
    (тогда картинку назовёт модель, которая распознаёт изображения, или автор)."""
    ext = Path(filename or '').suffix.lower()
    if not data:
        raise PictureError('файл пустой')
    if len(data) > MAX_UPLOAD:
        raise PictureError('файл больше 25 МБ')
    if ext == '.svg' or data.lstrip()[:5] in (b'<?xml', b'<svg ') and b'<svg' in data[:2000]:
        from .svgdraw import SvgError, sanitize
        try:
            text = sanitize(data.decode('utf-8', errors='replace'))
        except SvgError as e:
            raise PictureError(f'SVG не подходит: {e}')
        m = re.search(r'(?is)<title[^>]*>(.*?)</title>', text)
        meta = _clean_title(html.unescape(re.sub(r'<[^>]+>', '', m.group(1)))) if m else ''
        return {'upload': _store(text.encode('utf-8'), '.svg', filename, _naming(meta, [], filename, folder)),
                'caption': ''}
    from PIL import Image, ImageOps
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
    except Exception:                                        # noqa: BLE001
        raise PictureError('это не картинка (поддерживаются PNG, JPEG, GIF, BMP, WEBP, TIFF и SVG)')
    meta, keywords = embedded_title(im, data)
    im = ImageOps.exif_transpose(im)
    if max(im.size) > MAX_SIDE:
        im.thumbnail((MAX_SIDE, MAX_SIDE), Image.LANCZOS)
    alpha = im.mode in ('RGBA', 'LA', 'P') and ('transparency' in im.info or im.mode != 'P')
    out = io.BytesIO()
    if alpha:
        im.convert('RGBA').save(out, 'PNG', optimize=True)
        ext2 = '.png'
    else:
        im.convert('RGB').save(out, 'JPEG', quality=90, optimize=True)
        ext2 = '.jpg'
    return {'upload': _store(out.getvalue(), ext2, filename, _naming(meta, keywords, filename, folder)), 'caption': ''}


# ---- название по содержанию ----------------------------------------------------------
_JUNK_TITLE = re.compile(r'(?i)^(olympus digital camera|sony dsc|nikon|canon|samsung|huawei|xiaomi|apple|default|'
                         r'untitled|no title|без названия|безымянный|image|picture|photo|img|dsc\w*|dcim|scan|'
                         r'screenshot|снимок экрана|изображение|рисунок|фото|картинка|copyright|©)\b')
_CAMERA_FILE = re.compile(r'(?i)^(img|dsc[nf]?|pxl|mvimg|vid|gopr|dji|wp|p|photo|image|pic|scan|screenshot|'
                          r'снимок экрана|фото|whatsapp image|telegram|photo_|изображение|рисунок|безымянный)'
                          r'[\s_\-]*\(?\d')


def _clean_title(t, limit=80):
    """Описание из файла → название: первое предложение, без мусора камер, не длиннее limit."""
    t = re.sub(r'\s+', ' ', str(t or '').replace('\x00', '')).strip(' .;,:-–—«»"\'')
    if not t or _JUNK_TITLE.match(t) or len(re.findall(r'[A-Za-zА-Яа-яЁё]', t)) < 3:
        return ''
    t = re.split(r'(?<=[.!?])\s+(?=[А-ЯЁA-Z])', t)[0].rstrip('.')
    if len(t) > limit:
        t = t[:limit].rsplit(' ', 1)[0].rstrip(' ,;:—–-')
    return t[:1].upper() + t[1:]


def _decode(b):
    if isinstance(b, str):
        return b
    if not isinstance(b, (bytes, bytearray)):
        return str(b or '')
    for enc in ('utf-8', 'cp1251'):
        try:
            return bytes(b).decode(enc)
        except UnicodeDecodeError:
            pass
    return bytes(b).decode('latin-1', 'replace')


def embedded_title(im, data=b''):
    """Описание, записанное внутри снимка: XMP (dc:title, dc:description), IPTC (Object Name, Caption),
    EXIF (ImageDescription, XPTitle, XPSubject). → (название или '', [ключевые слова])."""
    titles, descs, keys = [], [], []                         # короткие названия важнее длинных описаний
    raw = bytes(data[:4_000_000]) if data else b''
    i = raw.find(b'<x:xmpmeta')
    if i >= 0:
        xmp = raw[i:raw.find(b'</x:xmpmeta>', i) + 12].decode('utf-8', 'replace')
        for tag in ('dc:title', 'photoshop:Headline', 'dc:description'):
            dst = descs if tag == 'dc:description' else titles
            m = re.search(rf'(?s)<{tag}[^>]*>(.*?)</{tag}>', xmp)
            if m:
                li = re.findall(r'(?s)<rdf:li[^>]*>(.*?)</rdf:li>', m.group(1)) or [m.group(1)]
                dst += [html.unescape(re.sub(r'<[^>]+>', '', x)) for x in li[:1]]
            m = re.search(rf'{tag}="([^"]+)"', xmp)
            if m:
                dst.append(html.unescape(m.group(1)))
        m = re.search(r'(?s)<dc:subject[^>]*>(.*?)</dc:subject>', xmp)
        if m:
            keys += [html.unescape(x) for x in re.findall(r'(?s)<rdf:li[^>]*>(.*?)</rdf:li>', m.group(1))]
    try:
        from PIL import IptcImagePlugin
        iptc = IptcImagePlugin.getiptcinfo(im) or {}
    except Exception:                                        # noqa: BLE001 — повреждённый блок IPTC
        iptc = {}
    for k in ((2, 5), (2, 105), (2, 120)):
        if iptc.get(k):
            v = iptc[k]
            (descs if k == (2, 120) else titles).append(_decode(v[0] if isinstance(v, list) else v))
    kw = iptc.get((2, 25))
    if kw:
        keys += [_decode(x) for x in (kw if isinstance(kw, list) else [kw])]
    try:
        ex = im.getexif()
    except Exception:                                        # noqa: BLE001
        ex = {}
    for tag in (0x9C9B, 0x010E, 0x9C9F, 0x9C9C):
        v = ex.get(tag) if ex else None
        if v is None:
            continue
        if tag >= 0x9C00:                                    # теги Windows (свойства файла): UTF-16LE
            try:
                v = bytes(v).decode('utf-16-le', 'ignore') if isinstance(v, (bytes, tuple, list)) else str(v)
            except (TypeError, ValueError):
                continue
        (titles if tag == 0x9C9B else descs).append(_decode(v))
    v = ex.get(0x9C9E) if ex else None
    if v:
        try:
            keys += re.split(r'[;,]', bytes(v).decode('utf-16-le', 'ignore'))
        except (TypeError, ValueError):
            pass
    title = next((t for t in (_clean_title(c) for c in titles + descs) if t), '')
    keys = [k for k in (_clean_title(k, 40).lower() for k in keys) if k]
    return title, list(dict.fromkeys(keys))[:12]


def file_title(filename):
    """Осмысленное имя файла → название («Буровая_установка-2024.jpg» → «Буровая установка 2024»);
    имя камеры или телефона («IMG_20240512_1010.jpg», «DSC01234») → ''."""
    stem = Path(str(filename or '').replace('\\', '/')).stem.strip()
    if not stem or _CAMERA_FILE.match(stem) or not _file_stems(stem + '.x'):
        return ''
    t = re.sub(r'([a-zа-яё])([A-ZА-ЯЁ])', r'\1 \2', stem)
    t = re.sub(r'_+|(?<=[A-Za-zА-Яа-яЁё])-(?=\d)|(?<=\d)-(?=[A-Za-zА-Яа-яЁё])', ' ', t)
    t = ' '.join(w for w in t.split() if not re.fullmatch(r'\d{5,}|\(?\d{1,2}\)|copy|копия', w, re.I))
    return _clean_title(t)


def _naming(meta, keywords, filename, folder=''):
    """Название новой картинки и откуда оно: описание в файле, имя файла, папка архива."""
    tags = list(keywords or [])
    parts = [x for x in re.split(r'[\\/]+', str(folder or '')) if x and x not in ('.', '__MACOSX')]
    tags += [file_title(x + '.x').lower() for x in parts if file_title(x + '.x')]
    if meta:
        return {'title': meta, 'how': 'meta', 'tags': tags}
    ft = file_title(filename)
    if ft:
        return {'title': ft, 'how': 'file', 'tags': tags}
    for x in reversed(parts):                                # «Харьяга/IMG_0012.jpg» → «Харьяга»
        t = file_title(x + '.x')
        if t:
            return {'title': t, 'how': 'folder', 'tags': tags}
    return {'title': '', 'how': '', 'tags': tags}


def set_title(name, title, how='user', tags=None):
    """Название своей картинки (правка автором или ответ модели). True — сохранено."""
    if not upload_path(name):
        return False
    t = _clean_title(title, 90) if how != 'user' else re.sub(r'\s+', ' ', str(title or '')).strip()[:90]
    with _INDEX_LOCK:
        idx = _load_index()
        e = dict(idx.get(name) or {})
        e.update(title=t, how=how if t else '')
        if tags is not None:
            e['tags'] = [str(x)[:40] for x in tags][:12]
        idx[name] = e
        try:
            _save_index(idx)
        except OSError:
            return False
    return True


def vision_jpeg(path, side=896):
    """Картинка → уменьшенный JPEG в Base64 для модели, которая распознаёт изображения."""
    import base64
    from PIL import Image
    p = Path(path)
    if p.suffix.lower() == '.svg':
        raise PictureError('векторный рисунок (SVG) модель не смотрит — назовите его сами')
    with Image.open(p) as im:
        im = im.convert('RGBA') if im.mode in ('P', 'LA') else im
        if im.mode == 'RGBA':                                # прозрачный фон — белым
            bg = Image.new('RGB', im.size, (255, 255, 255))
            bg.paste(im, mask=im.split()[3])
            im = bg
        im = im.convert('RGB')
        im.thumbnail((side, side), Image.LANCZOS)
        out = io.BytesIO()
        im.save(out, 'JPEG', quality=85)
    return base64.b64encode(out.getvalue()).decode('ascii')


def autoname(name, cfg):
    """Название своей картинки по содержанию — локальной моделью, которая распознаёт изображения.
    → {'title', 'tags'}; ошибка модели → LLMError, нет картинки → PictureError."""
    from .llm_client import vision_name
    p = upload_path(name)
    if not p:
        raise PictureError('картинка не найдена')
    r = vision_name(cfg, vision_jpeg(p))
    old = (_load_index().get(name) or {}).get('tags') or []
    set_title(name, r['name'], 'model', list(dict.fromkeys(list(old) + r['tags'])))
    return {'title': upload_title(name), 'tags': r['tags']}


def thumb(path, width=360):
    """Уменьшенная копия картинки для окна выбора (кэш output/cache/thumbs). SVG и мелкие — как есть."""
    from PIL import Image
    p = Path(path)
    if p.suffix.lower() == '.svg':
        return p
    st = p.stat()
    key = hashlib.sha1(f'{p}|{st.st_mtime_ns}|{st.st_size}|{width}'.encode('utf-8')).hexdigest()[:20]
    dst = THUMB_DIR / f'{key}.jpg'
    if dst.exists():
        return dst
    with Image.open(p) as im:
        if max(im.size) <= width * 1.3:
            return p
        im = im.convert('RGBA') if im.mode in ('P', 'LA') else im
        if im.mode == 'RGBA':
            bg = Image.new('RGB', im.size, (255, 255, 255))
            bg.paste(im, mask=im.split()[3])
            im = bg
        im = im.convert('RGB')
        im.thumbnail((width, width * 2), Image.LANCZOS)
        THUMB_DIR.mkdir(parents=True, exist_ok=True)
        tmp = dst.with_suffix('.tmp')
        im.save(tmp, 'JPEG', quality=82)
        tmp.replace(dst)
    return dst


def photo_path(pid):
    e = _by_id().get(str(pid or ''))
    return Path(e['path']) if e and e.get('photo') else None


_INDEX_LOCK = threading.Lock()


def _index_file():
    return UPLOAD_DIR / 'index.json'


def _load_index():
    try:
        d = json.loads(_index_file().read_text(encoding='utf-8'))
        return d if isinstance(d, dict) else {}
    except Exception:                                        # noqa: BLE001 — нет файла или он испорчен: начинаем заново
        return {}


def _save_index(d):
    tmp = _index_file().with_suffix('.tmp')
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding='utf-8')
    tmp.replace(_index_file())


def _store(b, ext, filename, naming=None):
    """Сохраняет файл под именем-хэшем и записывает в индекс исходное имя и название по содержанию.
    Название, которое уже дал автор или модель, при повторной загрузке того же файла не теряется."""
    name = hashlib.sha1(b).hexdigest()[:20] + ext
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    dst = UPLOAD_DIR / name
    if not dst.exists():
        dst.write_bytes(b)
    orig = Path(str(filename or '').replace('\\', '/')).name[:120]
    with _INDEX_LOCK:
        idx = _load_index()
        old = idx.get(name) or {}
        if orig or name not in idx:
            e = {'name': orig or old.get('name', ''), 'added': time.strftime('%Y-%m-%dT%H:%M:%S')}
            keep = old.get('how') in ('user', 'model', 'meta') and old.get('title')
            nm = naming or {}
            e['title'] = old['title'] if keep else nm.get('title') or old.get('title', '')
            e['how'] = old['how'] if keep else (nm.get('how') if nm.get('title') else old.get('how', ''))
            e['tags'] = list(dict.fromkeys(list(old.get('tags') or []) + list(nm.get('tags') or [])))[:12]
            idx[name] = e
            try:
                _save_index(idx)
            except OSError:                                  # индекс — только для удобства; без него картинка работает
                pass
    return name


def upload_path(name):
    """Путь к своей картинке по имени (только файлы output/uploads/ с именем-хэшем) или None."""
    if not UPLOAD_RX.fullmatch(str(name or '')):
        return None
    p = UPLOAD_DIR / name
    return p if p.exists() else None


def list_uploads(names=None):
    """Свои картинки, новые первыми: [{'upload', 'name' (исходное имя файла), 'added', 'size'}].
    names — только эти файлы (для пользователя с другого компьютера: он видит лишь свои загрузки)."""
    idx = _load_index()
    if names is None:
        paths = sorted(UPLOAD_DIR.iterdir()) if UPLOAD_DIR.exists() else []
    else:
        paths = [UPLOAD_DIR / n for n in dict.fromkeys(str(n) for n in names) if UPLOAD_RX.fullmatch(n)]
    out = []
    for p in paths:
        if not UPLOAD_RX.fullmatch(p.name) or not p.is_file():
            continue
        st = p.stat()
        info = idx.get(p.name) or {}
        out.append({'upload': p.name, 'name': str(info.get('name') or ''), 'size': st.st_size,
                    'title': str(info.get('title') or ''), 'how': str(info.get('how') or ''),
                    'lib': bool(info.get('lib')), 'cat': str(info.get('cat') or ''), 'author': str(info.get('author') or ''),
                    'tags': [str(t) for t in info.get('tags') or []][:12],
                    'added': str(info.get('added') or time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(st.st_mtime)))})
    out.sort(key=lambda e: e['added'], reverse=True)
    return out


def delete_upload(name):
    """Удаляет свою картинку из output/uploads/. True — удалена, False — такой нет."""
    p = upload_path(name)
    if not p:
        return False
    p.unlink()
    with _INDEX_LOCK:
        idx = _load_index()
        if idx.pop(name, None) is not None:
            try:
                _save_index(idx)
            except OSError:
                pass
    return True


def upload_name(name):
    """Исходное имя файла своей картинки (из индекса) или ''."""
    return str((_load_index().get(str(name or '')) or {}).get('name') or '')


def upload_title(name, idx=None):
    """Название своей картинки: по содержанию (если есть), иначе имя файла без расширения, иначе ''."""
    e = (idx if idx is not None else _load_index()).get(str(name or '')) or {}
    return str(e.get('title') or '') or Path(str(e.get('name') or '')).stem.replace('_', ' ').strip()


def display_name(im):
    """Название картинки слайда — для замещающего текста в .pptx и подписей в окнах."""
    if not isinstance(im, dict):
        return ''
    if im.get('name'):
        return str(im['name'])[:120]
    if im.get('picture'):
        e = get(im['picture'])
        return e['name'].replace('Карта: ', 'Карта: ') if e else ''
    if im.get('upload'):
        return upload_title(im['upload'])
    return str(im.get('caption') or '')[:120]


def image_credits(s):
    """Строки авторства фотографий слайда (для заметок): встроенные фотографии и свои с указанным автором."""
    out = []
    for im in s.get('images') or []:
        if not isinstance(im, dict):
            continue
        c = ''
        if im.get('picture'):
            e = get(im['picture'])
            c = (e or {}).get('credit') or ''
        elif im.get('upload'):
            c = str((_load_index().get(im['upload']) or {}).get('credit') or '')
        if c and c not in out:
            out.append(c)
    return out


def resolve(im):
    """Элемент images → то, что рисует макет: {'svg': …} или {'path': …}. Нет файла — None."""
    if not isinstance(im, dict):
        return None
    if im.get('svg'):
        return im
    if im.get('picture'):
        e = get(im['picture'])
        if e and e.get('photo'):                             # встроенная фотография — как есть
            return dict(im, path=e['path'], name=im.get('name') or e['name'])
        try:
            return dict(im, svg=svg(im['picture']), name=im.get('name') or (e or {}).get('name', ''))
        except PictureError:
            return None
    if im.get('upload'):
        p = upload_path(im['upload'])
        nm = im.get('name') or upload_title(im['upload'])
        if p and p.suffix == '.svg':                         # свой векторный рисунок — фигурами, как библиотека
            return dict(im, svg=p.read_text(encoding='utf-8'), name=nm)
        return dict(im, path=str(p), name=nm) if p else None
    if im.get('path') and Path(im['path']).exists():
        return im
    return None


# --------------------------------------------------------------------------------------
# Вариант слайда с картинкой
# --------------------------------------------------------------------------------------
def picture_alt(s, im, full=False, label=None):
    """Вариант слайда: картинка + тезисы слайда (full=True — только картинка крупно, с подписью).
    im — одна картинка или список (до трёх): одна стоит справа от тезисов, две-три — сеткой слева,
    тезисы — пронумерованным списком справа."""
    from .illustrate import illustrated_slide
    ims = [dict(x) for x in (im if isinstance(im, (list, tuple)) else [im]) if isinstance(x, dict)][:MAX_PER_SLIDE]
    if full:
        alt = {'layout': 'image', 'title': s.get('title') or '', 'subtitle': s.get('subtitle') or '',
               'section': s.get('section') or '', 'images': ims, 'items': [],
               'conclusion': s.get('conclusion') or ''}
    else:
        alt = illustrated_slide(s, None)
        alt['images'] = ims
        if len(ims) > 1:
            alt['illustration'] = False
    alt['pic_alt'] = True                                    # признак варианта «с картинкой» (его можно убрать в окне)
    alt['alt_label'] = label or (labels_of(ims) if len(ims) > 1 else 'С картинкой')
    return alt


def label_of(im):
    if im.get('picture'):
        e = get(im['picture'])
        return f'Картинка: {e["name"]}' if e else 'Картинка'
    if im.get('upload'):
        name = _short_name(im['upload'])
        return f'Картинка: {name}'[:60] if name else 'Своя картинка'
    if im.get('svg') and not im.get('ai'):
        return 'Своя картинка'
    return 'Иллюстрация'


def _short_name(upload):
    """Имя своей картинки для подписи варианта: название по содержанию или имя файла, не длиннее 40 знаков."""
    return upload_title(upload)[:40]


def labels_of(ims):
    """Подпись варианта с несколькими картинками: «Картинки: Буровая, Танкер» (не длиннее 60 знаков)."""
    if len(ims) == 1:
        return label_of(ims[0])
    names = []
    for im in ims:
        e = get(im['picture']) if im.get('picture') else None
        names.append(e['name'].replace('Карта: ', '') if e else (im.get('upload') and _short_name(im['upload'])) or 'своя')
    out = 'Картинки: ' + ', '.join(names)
    return out if len(out) <= 60 else out[:58].rstrip(' ,') + '…'


# --------------------------------------------------------------------------------------
# Раскладка выбранных картинок по слайдам (окно «Картинки к слайдам»)
# --------------------------------------------------------------------------------------
# слова, которые часто бывают в именах файлов, но о сюжете ничего не говорят
_FILE_NOISE = {'img', 'image', 'images', 'pic', 'picture', 'photo', 'foto', 'scan', 'dsc', 'dcim', 'screenshot', 'screen',
               'shot', 'copy', 'final', 'new', 'jpg', 'jpeg', 'png', 'svg', 'webp', 'tif', 'tiff', 'bmp', 'gif', 'фото',
               'картинка', 'изображение', 'рисунок', 'снимок', 'экрана', 'скриншот', 'копия', 'новый', 'новая', 'файл'}


def _file_stems(filename):
    """Основы слов из имени файла: «Буровая_установка-2024.jpg» → ['буров', 'устан']."""
    stem = Path(str(filename or '')).stem
    stem = re.sub(r'([a-zа-яё])([A-ZА-ЯЁ])', r'\1 \2', stem)     # ВерблюжийРегистр → два слова
    out = []
    for w in _tokens(stem.replace('_', ' ')):
        if len(w) < 3 or w.isdigit() or w in _FILE_NOISE:
            continue
        out.append(w[:5] if len(w) > 5 else w)
    return list(dict.fromkeys(out))


class _SlideWords:
    def __init__(self, s):
        title, body = _slide_texts(s)
        self.title, self.body = title, body
        self.tt, self.bt = _tokens(title), _tokens(body)
        self._countries = None

    def countries(self):
        if self._countries is None:
            from .geo import find_countries
            self._countries = (find_countries(self.title), find_countries(self.body))
        return self._countries


def _match(im, sw, names):
    """(баллы, почему) — насколько картинка подходит к слайду. Заголовок — 3 балла за слово, текст — 1."""
    if im.get('picture'):
        pid = str(im['picture'])
        if COUNTRY_RX.fullmatch(pid):
            t, b = sw.countries()
            c = get(pid)
            cname = c['name'].replace('Карта: ', '') if c else pid[4:]
            if pid[4:] in t:
                return 4, f'на слайде речь о стране: {cname}'
            if pid[4:] in b:
                return 2, f'на слайде упомянута страна: {cname}'
            return 0, ''
        e = get(pid)
        if not e:
            return 0, ''
        th = _hits(e['tags'], sw.tt)
        bh = _hits(e['tags'], sw.bt) - th
        sc = 3 * len(th) + len(bh)
        if sc and pid.startswith('fe_'):
            sc = round(sc * 0.6, 1)
        words = sorted(_matched_tokens(th, sw.tt) | _matched_tokens(bh, sw.bt))
        return sc, ('совпало: ' + ', '.join(words[:3])) if sc else ''
    if im.get('upload'):
        info = names.get(im['upload'])
        if not isinstance(info, dict):
            info = {'name': info or upload_name(im['upload'])}
        named = bool(info.get('title'))
        stems = _file_stems(info.get('name') or '')
        if named:                                            # название по содержанию и ключевые слова — точнее имени файла
            stems = list(dict.fromkeys(_stems([info['title']] + list(info.get('tags') or [])) + stems))
        th = {p for p in stems if any(w.startswith(p) for w in sw.tt)}
        bh = {p for p in stems if any(w.startswith(p) for w in sw.bt)} - th
        sc = 3 * len(th) + len(bh)
        words = sorted({w for w in sw.tt + sw.bt if any(w.startswith(p) for p in th | bh)})
        what = 'с названием' if named else 'с именем файла'
        return sc, (f'совпало {what}: ' + ', '.join(words[:3])) if sc else ''
    return 0, ''


def _key(im):
    return im.get('picture') or im.get('upload') or ''


def distribute(slides, images, mode='auto', busy=(), load=None, names=None):
    """Раскладка картинок по слайдам. slides — слайды плана (исходные тезисы, без вариантов),
    images — картинки, которые надо поставить ({'picture'} или {'upload'}), busy — номера слайдов,
    которые не трогаем (там рисунок из документа или модели ИИ), load — {номер слайда: сколько картинок
    на нём уже стоит} (такие слайды берутся, только когда свободных не осталось).
    mode='auto' — по смыслу, 'order' — по порядку. Возвращает [{'slide': номер или None, 'score', 'why'}]
    в порядке images.

    По смыслу: (1) каждой картинке — слайд с тезисами, где совпало больше слов (жадно, лучшие пары
    первыми; на слайд — одна картинка); (2) картинки без совпадений — равномерно на свободные слайды
    с тезисами; (3) свободных не осталось — вторая и третья картинка на слайд (лучше — туда, где
    есть совпадение); (4) и это занято — на прочие слайды (кроме титула, разделов, таблиц, диаграмм)."""
    names = names or {}
    busy = set(busy or ())
    n = len(images)
    res = [{'slide': None, 'score': 0, 'why': ''} for _ in range(n)]
    lay = [s.get('layout') if isinstance(s, dict) else None for s in slides]
    primary = [j for j, s in enumerate(slides) if j not in busy and (lay[j] in PICTURE_LAYOUTS or lay[j] == 'image')]
    secondary = [j for j, s in enumerate(slides) if j not in busy and j not in primary and lay[j] and lay[j] not in NO_PICTURE]
    if not n:
        return res
    if not primary and not secondary:
        for r in res:
            r['why'] = 'в плане нет слайдов, к которым можно поставить картинку'
        return res
    load = {int(k): int(v) for k, v in (load or {}).items() if str(k).lstrip('-').isdigit()}   # слайд → картинок на нём

    def put(i, j, sc, why):
        res[i].update(slide=j, score=sc, why=why)
        load[j] = load.get(j, 0) + 1

    if mode == 'order':
        pool = primary or secondary
        for i in range(n):
            free = [j for j in pool if not load.get(j)]
            cand = free or [j for j in pool if load.get(j, 0) < MAX_PER_SLIDE]
            if not cand:
                res[i]['why'] = 'не хватило слайдов (на слайд — не больше трёх картинок)'
                continue
            j = cand[0] if free else min(cand, key=lambda j: (load.get(j, 0), j))
            put(i, j, 0, 'по порядку' if free else 'по порядку, ещё одна картинка на слайде')
        return res

    words = {j: _SlideWords(slides[j]) for j in primary + secondary}
    score = {}
    for i, im in enumerate(images):
        for j in primary + secondary:
            sc, why = _match(im, words[j], names)
            if sc:
                score[i, j] = (sc, why)
    # (1) лучшие пары — первыми; при равных баллах — слайд раньше по ходу доклада
    for (i, j), (sc, why) in sorted(score.items(), key=lambda kv: (-kv[1][0], kv[0][1], kv[0][0])):
        if j in primary and res[i]['slide'] is None and not load.get(j):
            put(i, j, sc, why)
    # (2) без совпадений — равномерно по свободным слайдам с тезисами
    rest = [i for i in range(n) if res[i]['slide'] is None]
    free = [j for j in primary if not load.get(j)]
    if rest and free:
        k = min(len(rest), len(free))
        picks = [free[int((t + 0.5) * len(free) / k)] for t in range(k)]
        for i, j in zip(rest, picks):
            put(i, j, 0, 'по словам не совпала — поставил на свободный слайд с тезисами')
    # (3) вторая-третья картинка на слайд: сначала туда, где есть совпадение, затем по очереди
    for pool, why0 in ((primary, 'свободных слайдов не осталось — ещё одна картинка на слайде'),
                       (secondary, 'слайдов с тезисами не хватило — поставил на слайд-схему (её можно вернуть в «Вариантах»)')):
        rest = [i for i in range(n) if res[i]['slide'] is None]
        if not rest or not pool:
            continue
        if pool is secondary:                                # прочие слайды: сначала по одной картинке
            for i in list(rest):
                best = max((j for j in pool if not load.get(j)), key=lambda j: (score.get((i, j), (0,))[0], -j), default=None)
                if best is not None:
                    sc, why = score.get((i, best), (0, ''))
                    put(i, best, sc, why or why0)
            rest = [i for i in range(n) if res[i]['slide'] is None]
        for i in rest:
            cand = [j for j in pool if load.get(j, 0) < MAX_PER_SLIDE]
            if not cand:
                break
            best = max(cand, key=lambda j: (score.get((i, j), (0,))[0], -load.get(j, 0), -j))
            sc, why = score.get((i, best), (0, ''))
            put(i, best, sc, why or why0)
    for r in res:
        if r['slide'] is None:
            r['why'] = 'не хватило слайдов (на слайд — не больше трёх картинок)'
    return res


def deck_suggest(slides, n=36, cfg=None):
    """Картинки, подходящие к презентации: лучшие по слайдам с тезисами и карты упомянутых стран.
    [{'id', 'name', 'cat', 'slide': номер слайда, к которому подходит больше всего, 'by': 'model'|'words'}].
    cfg — модель поиска: тогда и по смыслу названий (векторы готовятся в фоне — до тех пор по словам)."""
    best = {}
    idx = [j for j, s in enumerate(slides) if isinstance(s, dict) and s.get('layout') not in NO_PICTURE]
    sems = sem_hits([slides[j] for j in idx], cfg, 6) if cfg and idx else [[] for _ in idx]
    for j, sem in zip(idx, sems):
        for e, sc, how in smart_suggest(slides[j], 4, sem=sem):
            if sc >= 0.34 and (e['id'] not in best or sc > best[e['id']][0]):
                best[e['id']] = (sc, j, e, how)
    out = [{'id': e['id'], 'name': e['name'], 'cat': e['cat'], 'slide': j, 'by': 'model' if how == 'смысл' else 'words'}
           for sc, j, e, how in sorted(best.values(), key=lambda v: (-v[0], v[1]))[:n]]
    from .geo import find_countries
    from .illustrate import slide_subject
    seen = set()
    for j, s in enumerate(slides):
        if not isinstance(s, dict) or s.get('layout') in NO_PICTURE:
            continue
        for cid in find_countries(slide_subject(s))[:3]:
            e = get(f'map_{cid}')
            if e and cid not in seen and len(seen) < 6:
                seen.add(cid)
                out.append({'id': e['id'], 'name': e['name'], 'cat': 'Карты стран', 'slide': j})
    return out


def auto_pictures(slides, main_for_text=True, cfg=None, stats=None):
    """Картинка из библиотеки к подходящим слайдам — вариантом (в alts). Слайду «одна мысль» (text)
    с явным совпадением по заголовку картинка ставится основной. Одна картинка — не больше одного
    раза на доклад. Возвращает число слайдов с картинками.
    cfg — настройки модели поиска (1.7): тогда картинки (в первую очередь фотографии) подбираются и по смыслу
    названия, а не только по совпадению слов; stats['semantic'] — сколько подобрано по смыслу."""
    from .variety import apply_alt
    used = set()
    n = 0
    cand = [s for s in slides if s.get('layout') in PICTURE_LAYOUTS and not s.get('keep_layout')
            and not any(a.get('layout') == 'image' for a in s.get('alts') or [])]
    sems = sem_hits(cand, cfg, 6, wait=True) if cfg and cand else [[] for _ in cand]
    if stats is not None:
        stats['semantic_ready'] = bool(cfg and _SEM['searcher'] is not None)
    for s, sem in zip(cand, sems):
        best = None
        for e, sc in suggest(s, 6):
            if e['id'] not in used and sc >= 3:
                best = (e, sc, 1.0 if sc >= 4 else 0.6, 'слова')
                break
        for e, c in sem:                                     # по смыслу — только уверенное совпадение
            if e['id'] in used or e['id'].startswith('fe_') or c < 0.6:
                continue
            if best is None or c > best[2] + 0.15:
                best = (e, 0, c, 'смысл')
            break
        if not best:
            continue
        e, sc, conf, how = best
        used.add(e['id'])
        if how == 'смысл' and stats is not None:
            stats['semantic'] = stats.get('semantic', 0) + 1
        alt = picture_alt(s, {'picture': e['id'], 'caption': ''}, label=f'{"Фото" if e.get("photo") else "Картинка"}: {e["name"]}'[:60])
        if how == 'смысл':
            alt['pic_by'] = 'model'                          # подобрала модель поиска по смыслу (для подсказки в окне)
        alts = s.get('alts') or [dict({k: v for k, v in s.items() if k not in ('alts', 'notes')},
                                      alt_label=s.get('alt_label') or 'Текущий')]
        alts = alts[:4] + [alt]
        s['alts'] = alts
        n += 1
        # основной картинка становится, только если совпало и слово заголовка, и что-то из текста (≥ 4 баллов):
        # одно общее слово («закачка») ещё не тема слайда
        title_hit = (sc >= 4 and _hits(e['tags'], _tokens(s.get('title') or ''))) or conf >= 0.85
        if main_for_text and s.get('layout') == 'text' and title_hit:
            new = apply_alt(s, len(alts) - 1)
            s.clear()
            s.update(new)
    return n
