# -*- coding: utf-8 -*-
"""
versions.py — ВЕРСИИ ПРЕЗЕНТАЦИИ ПОД АУДИТОРИЮ (1.7)
==================================================
Из одного плана — до трёх презентаций:
  * «для правления» — коротко: выводы, показатели результата, цель, главная диаграмма и то, о чём просят
    решения; не больше n слайдов по существу, без содержания и разделителей, длинные списки — до 4 пунктов;
  * «рабочая» — полная: все слайды, заметки докладчика и «Источники чисел»;
  * «внешняя» — для партнёров и публикаций: без внутренних цифр — денег, затрат, цен, бюджета, окупаемости,
    зарплат (и слов, которые укажет автор), без заметок докладчика и источников чисел. Слайд, где
    внутренние цифры — главное (диаграмма бюджета, таблица затрат), убирается целиком; в остальных
    убираются только пункты и фразы с такими цифрами.
Каждая версия возвращается с отчётом «что изменено» — его стоит прочитать перед отправкой наружу.
Числа не придумываются и не пересчитываются: версии только убирают.
"""
import copy
import re

from .textutil import clean

KINDS = {
    'board': ('для правления', 'Коротко: выводы, показатели, цель и решение'),
    'work': ('рабочая', 'Полная: все слайды, заметки докладчика и источники чисел'),
    'external': ('внешняя', 'Без внутренних цифр (деньги, затраты, цены) и без заметок'),
}
BOARD_N = 6                                         # слайдов по существу в версии для правления
BOARD_ITEMS = 4                                     # пунктов в списках версии для правления
SHORTEN = ('cards', 'list', 'checklist', 'conclusions', 'pillars', 'honeycomb', 'bubbles', 'petals', 'mindmap', 'hub')
META_LAYOUTS = ('title', 'end', 'agenda', 'section')

RX_NUM = re.compile(r'\d')
RX_MONEY = re.compile(r'(?i)₽|\$|€|¥|(?<![а-яё])(руб|долл|usd|eur|евро|юан|cny|rub)')
RX_COST = re.compile(r'(?i)бюджет|затрат|расход|стоимост|(?<![а-яё])цен[аыуеой]|тариф|себестоим|выручк|прибыл|ebitda|npv|irr|'
                     r'(?<![а-яё])чдд|capex|opex|капвлож|капзатрат|инвестиц|окупа|зарплат|заработн|(?<![а-яё])фот(?![а-яё])|'
                     r'преми[яий]|долг|кредит|марж|рентабельн|смет|контрактн|штраф')
RX_SENT = re.compile(r'(?<=[.!?…;])\s+(?=[А-ЯЁA-Z«"\d•–—-])')
BOARD_WORDS = re.compile(r'(?i)решени|утверд|одобр|просим|предлага|поручени|согласова|рекоменд')


# ---------------------------------------------------------------------------------------------
# Общее
# ---------------------------------------------------------------------------------------------
def _txt(v):
    if isinstance(v, dict):
        return ' '.join(_txt(x) for k, x in v.items() if k not in ('icon', 'alts', 'found', 'picture', 'image'))
    if isinstance(v, (list, tuple)):
        return ' '.join(_txt(x) for x in v)
    return str(v) if isinstance(v, (str, int, float)) else ''


def _title(s, i):
    return clean(str(s.get('title') or '')) or f'Слайд {i + 1}'


def _strip(s):
    """Служебное, что в презентацию не попадает: варианты слайда, найденные фразы."""
    for k in ('alts', 'found', 'found_n', 'ai_fix'):
        s.pop(k, None)
    return s


def _base(spec):
    sp = copy.deepcopy(spec)
    sp['slides'] = [_strip(s) for s in sp.get('slides') or [] if isinstance(s, dict)]
    sp.setdefault('meta', {})
    return sp


# ---------------------------------------------------------------------------------------------
# Для правления
# ---------------------------------------------------------------------------------------------
def board_score(s):
    lay = s.get('layout')
    score = {'conclusions': 10, 'kpi': 8, 'hero': 8, 'gauge': 7, 'target': 7, 'chart': 5, 'compare': 5, 'shift': 5,
             'balance': 5, 'swot': 4, 'risk': 4, 'roadmap': 4, 'timeline': 4, 'gantt': 3, 'process': 3, 'cards': 4,
             'text': 3, 'table': 2, 'map': 3, 'own': 3, 'image': 1}.get(lay, 3)
    if s.get('conclusion') or s.get('insights'):
        score += 2
    if BOARD_WORDS.search(_txt([s.get('title'), s.get('subtitle'), s.get('conclusion')])):     # о чём просят решения
        score += 6
    return score


def board(spec, n=BOARD_N):
    """Короткая версия для правления → (план, [что изменено])."""
    sp = _base(spec)
    slides, notes = sp['slides'], []
    content = [(i, s) for i, s in enumerate(slides) if s.get('layout') not in META_LAYOUTS]
    keep = {i for i, s in content if s.get('layout') == 'conclusions'}
    seen = {}                                        # второй слайд того же вида — ниже в очереди: правлению нужно разное
    while len(keep) < n:
        rest = [(board_score(s) - 2 * seen.get(s.get('layout'), 0), -i, i, s) for i, s in content if i not in keep]
        if not rest:
            break
        _, _, i, s = max(rest)
        keep.add(i)
        seen[s.get('layout')] = seen.get(s.get('layout'), 0) + 1
    out = []
    for i, s in enumerate(slides):
        lay = s.get('layout')
        if lay in ('title', 'end'):
            out.append(s)
        elif lay in ('agenda', 'section'):
            notes.append(f'Убран слайд «{_title(s, i)}»: в короткой версии содержание и разделители не нужны.')
        elif i in keep:
            items = s.get('items')
            if lay in SHORTEN and isinstance(items, list) and len(items) > BOARD_ITEMS:
                s['items'] = items[:BOARD_ITEMS]
                notes.append(f'«{_title(s, i)}»: оставлены первые {BOARD_ITEMS} пункта из {len(items)}.')
            if lay == 'table' and isinstance(s.get('rows'), list) and len(s['rows']) > 6:
                notes.append(f'«{_title(s, i)}»: оставлены первые 6 строк таблицы из {len(s["rows"])}.')
                s['rows'] = s['rows'][:6]
            out.append(s)
        else:
            notes.append(f'Убран слайд «{_title(s, i)}».')
    sp['slides'] = out
    sp['meta']['version'] = 'board'
    return sp, notes


# ---------------------------------------------------------------------------------------------
# Внешняя
# ---------------------------------------------------------------------------------------------
class Internal:
    """Что считается внутренним: числа рядом с деньгами и затратами; слова, которые указал автор (без чисел тоже)."""

    def __init__(self, words=()):
        ws = [w.strip() for w in words or () if str(w).strip()]
        self.words = re.compile('(?i)' + '|'.join(re.escape(w) for w in ws)) if ws else None

    def text(self, t):
        t = str(t or '')
        if self.words and self.words.search(t):
            return True
        return bool(RX_NUM.search(t) and (RX_MONEY.search(t) or RX_COST.search(t)))

    def unit(self, t):
        return bool(RX_MONEY.search(str(t or '')) or RX_COST.search(str(t or '')) or (self.words and self.words.search(str(t or ''))))


def _clean_text(t, inn):
    """Убрать из текста фразы с внутренними цифрами → (текст, сколько убрано)."""
    t = str(t or '')
    if not inn.text(t):
        return t, 0
    lines, cut = [], 0
    for line in t.split('\n'):
        parts = RX_SENT.split(line)
        kept = [p for p in parts if not inn.text(p)]
        cut += len(parts) - len(kept)
        if kept:
            lines.append(' '.join(kept))
    return '\n'.join(lines).strip(), cut


def _clean_item(it, inn):
    """Пункт: внутреннее число в значении или заголовке — пункт убирается; в тексте — только фраза."""
    if isinstance(it, str):
        return (None, 1) if inn.text(it) else (it, 0)
    if not isinstance(it, dict):
        return it, 0
    if (it.get('value') not in (None, '') and (inn.unit(it.get('unit')) or inn.unit(it.get('title')) or inn.text(it.get('value'))))\
            or inn.text(it.get('title')):
        return None, 1
    cut = 0
    for k in ('text', 'note', 'caption'):
        if isinstance(it.get(k), str):
            had = bool(it[k].strip())
            it[k], c = _clean_text(it[k], inn)
            cut += c
            if had and c and not it[k] and inn.unit(it.get('title')):   # «Окупаемость» без своего числа — пустая карточка
                return None, cut
    for k in ('items', 'children', 'points'):
        if isinstance(it.get(k), list):
            sub = [_clean_item(x, inn) for x in it[k]]
            it[k] = [x for x, _ in sub if x is not None]
            cut += sum(c for _, c in sub)
    return it, cut


def _money_chart(s, inn):
    ch = s.get('chart') or {}
    names = [ch.get('unit'), ch.get('title'), s.get('title'), s.get('subtitle')] + [x.get('name') for x in ch.get('series') or [] if isinstance(x, dict)]
    return any(inn.unit(x) for x in names if x)


def _clean_table(s, inn):
    """Столбцы с деньгами и затратами — долой; строки, где затраты в первой ячейке, — тоже; деньги в ячейке — «—»."""
    cols, rows = list(s.get('columns') or []), [list(r) for r in s.get('rows') or [] if isinstance(r, list)]
    bad = {j for j, c in enumerate(cols) if inn.unit(c)}
    cut = len(bad) * len(rows)
    cols = [c for j, c in enumerate(cols) if j not in bad]
    out = []
    for r in rows:
        r = [c for j, c in enumerate(r) if j not in bad]
        if r and inn.unit(r[0]) and any(RX_NUM.search(str(c)) for c in r[1:]):
            cut += len(r)
            continue
        new = []
        for c in r:
            if inn.text(c):
                new.append('—')
                cut += 1
            else:
                new.append(c)
        out.append(new)
    s['columns'], s['rows'] = cols, out
    return cut


def external(spec, words=()):
    """Внешняя версия → (план, [что изменено])."""
    from .spec import LAYOUTS
    sp = _base(spec)
    inn = Internal(words)
    notes, out = [], []
    for i, s in enumerate(sp['slides']):
        lay, t = s.get('layout'), _title(s, i)
        if s.get('notes'):
            s['notes'] = ''
        if lay in ('title', 'end', 'agenda', 'section'):
            for k in ('title', 'subtitle'):
                if inn.text(s.get(k)):
                    s[k], _ = _clean_text(s[k], inn)
            out.append(s)
            continue
        if lay == 'own':
            notes.append(f'⚠ «{t}» — свой слайд из файла PowerPoint: конструктор его не меняет, проверьте цифры сами.')
            out.append(s)
            continue
        if lay == 'chart' and _money_chart(s, inn):
            notes.append(f'Убран слайд «{t}»: диаграмма в деньгах или затратах.')
            continue
        cut = 0
        if lay == 'table':
            cut += _clean_table(s, inn)
            if len(s.get('columns') or []) < 2 or not s.get('rows'):
                notes.append(f'Убран слайд «{t}»: в таблице почти всё — внутренние цифры.')
                continue
        if isinstance(s.get('items'), list):
            res = [_clean_item(x, inn) for x in s['items']]
            s['items'] = [x for x, _ in res if x is not None]
            cut += sum(c for _, c in res)
            need = max(1, int((LAYOUTS.get(lay) or {}).get('min') or 1))
            if len(s['items']) < need:
                notes.append(f'Убран слайд «{t}»: почти все пункты — с внутренними цифрами.')
                continue
        for side in ('left', 'right'):
            if isinstance(s.get(side), dict):
                s[side], c = _clean_item(s[side], inn)
                cut += c
                if s[side] is None:
                    s[side] = {'title': '', 'text': ''}
        for k in ('subtitle', 'conclusion', 'text', 'caption'):
            if isinstance(s.get(k), str) and s[k]:
                s[k], c = _clean_text(s[k], inn)
                cut += c
        if isinstance(s.get('insights'), list):
            kept = [x for x in s['insights'] if not inn.text(x)]
            cut += len(s['insights']) - len(kept)
            s['insights'] = kept
        if inn.text(s.get('title')):
            new, c = _clean_text(s['title'], inn)
            if not new:
                notes.append(f'Убран слайд «{t}»: внутренняя цифра — в самом заголовке.')
                continue
            s['title'], cut = new, cut + c
        if cut:
            notes.append(f'«{t}»: убрано фраз и чисел с внутренними цифрами — {cut}.')
        out.append(s)
    kept_sections = {clean(str(s.get('section') or '')).lower() for s in out}
    for s in out:
        if s.get('layout') == 'agenda' and isinstance(s.get('items'), list):
            s['items'] = [x for x in s['items'] if clean(_txt(x)).lower() in kept_sections or not kept_sections]
    sp['slides'] = out
    sp['meta'].update(version='external', facts='', pool='')
    notes.append('Заметки докладчика и «Источники чисел» убраны на всех слайдах.')
    notes.append('Проверьте версию глазами перед отправкой: конструктор находит деньги, затраты и цены по словам и единицам, '
                 'а названия контрагентов и другие сведения — на вашей проверке (их можно вписать в «Также убрать»).')
    return sp, notes


def work(spec):
    sp = _base(spec)
    sp['meta']['version'] = 'work'
    n = sum(1 for s in sp['slides'] if s.get('layout') not in META_LAYOUTS)
    return sp, [f'Все слайды ({n} по существу), заметки докладчика и «Источники чисел».']


def make(spec, kinds=('board', 'work', 'external'), words=(), n=BOARD_N):
    """Версии плана → [{'kind', 'name', 'spec', 'notes', 'slides'}]."""
    out = []
    for k in kinds:
        if k == 'board':
            sp, notes = board(spec, n)
        elif k == 'external':
            sp, notes = external(spec, words)
        elif k == 'work':
            sp, notes = work(spec)
        else:
            continue
        out.append({'kind': k, 'name': KINDS[k][0], 'spec': sp, 'notes': notes, 'slides': len(sp['slides'])})
    return out
