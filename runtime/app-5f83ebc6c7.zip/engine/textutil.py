# -*- coding: utf-8 -*-
"""
textutil.py — РАБОТА С ТЕКСТОМ: очистка, предложения, сокращение, числа, типографика, иконки
==========================================================================================

Здесь «малая лингвистика» для планировщика по правилам:
  * clean()            — убрать лишние пробелы, маркеры списков, номера пунктов;
  * sentences()        — разбить абзац на предложения (с учётом сокращений «т. е.», «и т. д.»);
  * shorten()          — сократить текст до N символов по границе предложения/слова;
  * split_title_text() — разделить пункт «Заголовок: пояснение» на заголовок и текст;
  * typo()             — русская типографика: неразрывные пробелы после коротких
                         предлогов и между числом и единицей (чтобы «0–100», «25 %»
                         не разрывались переносом);
  * parse_number() / fmt_number() — числа в русском формате («1 234,5», «12 %»);
  * pick_icon()        — подбор иконки по ключевым словам (словарь ICON_RULES и каталог assets/icons/catalog.json:
                         у каждой из ~770 иконок — русское название и основы слов).
"""
import re

NBSP = ' '

# --------------------------------------------------------------------------------------
# Очистка и предложения
# --------------------------------------------------------------------------------------
# «а) », «б. Текст» — буква-маркер; «п. п.», «т. е.» (за точкой строчная буква) — не маркер
_BULLET = re.compile(r'^\s*(?:[•●▪■◦○\-–—*·►✓✔]+\s+|\(?\d{1,2}[.)]\s+|\(?[a-zа-яёA-ZА-ЯЁ]\)\s+|'
                     r'[a-zа-яё]\.\s+(?=[A-ZА-ЯЁ«"]))')


def clean(s):
    """Нормализует пробелы, убирает маркер списка в начале («• », «1) », «а) »).
    Неразрывные пробелы (\\u00a0) сохраняются — это осознанная типографика."""
    s = str(s or '').replace('\t', ' ')
    s = re.sub(r'[ \t\r\n\f\v\u2028\u2029]+', ' ', s).strip()
    s = _BULLET.sub('', s)
    return s.strip(' ;')


_ABBR = r'(?:т|е|д|п|г|гг|др|пр|см|рис|табл|им|ул|стр|руб|тыс|млн|млрд|ок|рр|кв|ст|н|э)'
_SENT = re.compile(r'(?<=[.!?…])\s+(?=[«"(]?[А-ЯЁA-Z0-9])')


def sentences(s):
    """Разбивает текст на предложения. Не режет после сокращений «т. е.», «млн.», «рис.»."""
    s = clean(s)
    if not s:
        return []
    parts = _SENT.split(s)
    out = []
    for p in parts:
        if out and re.search(r'(?:^|\s)' + _ABBR + r'\.$', out[-1], re.I) and not (
                re.search(r'(?i)\s(руб|млн|млрд|тыс|долл|барр)\.$', out[-1]) and re.match(r'[А-ЯЁA-Z][а-яёa-z]{2,}', p)):
            out[-1] = out[-1] + ' ' + p          # предыдущий кусок кончался сокращением — склеиваем
                                                 # («420 млн руб. Проект …» — уже новое предложение)
        else:
            out.append(p)
    return [p.strip() for p in out if p.strip()]


def shorten(s, max_chars):
    """Сокращает текст до max_chars так, чтобы он читался законченным:
      1) целыми предложениями;
      2) иначе — без второстепенного: скобок, вводных слов, придаточных «, который…», «, в том числе…»,
         пояснений после тире (условия «если», «но», «кроме» не отбрасываются — меняют смысл);
      3) иначе — по границе части фразы («;», «:», «,»), с точкой, если исходный текст — предложение;
      4) и только в крайнем случае — по словам с «…».
    Скобки и кавычки в результате всегда парные."""
    s = clean(s)
    if len(s) <= max_chars:
        return s
    acc = ''
    for sent in sentences(s):
        cand = (acc + ' ' + sent).strip()
        if len(cand) > max_chars:
            break
        acc = cand
    if acc and len(acc) >= max_chars * 0.45:
        return acc
    sents = sentences(s)
    first = sents[0] if sents else s
    is_sent = bool(re.search(r'[.!?…]["»)]?$', s))
    # 2) убираем второстепенное в первом предложении (сокращение, после которого остаётся меньше
    #    половины лимита, не берётся — лучше обрезать по границе части фразы)
    t, short, tiny = first, '', ''
    for rx in _MINOR:
        if len(t) <= max_chars:
            break
        t2 = clean(rx.sub(lambda m: _keep(m, t) if 'keep' in rx.groupindex else
                          (m.group(1) if rx.groups == 1 else ' '), t))
        t2 = re.sub(r'\s+([,.;:!?])', r'\1', t2)
        if len(t2) >= 12 and (len(t2) > max_chars or len(t2) >= max_chars * 0.5):
            t = t2
        elif len(t2) >= max(12, max_chars * 0.3) and not short:
            short = t2                           # слишком сильное сокращение — запасной вариант
        elif len(t2) >= 20 and not tiny and has_predicate(t2):
            tiny = t2                            # совсем короткая, но законченная фраза — лучше, чем «…»
    if len(t) <= max_chars:
        return _end_sentence(t, is_sent)
    # 3) по границе части фразы; затем — запасной сокращённый вариант
    cut = _clause_cut(t, max_chars) or short or _clause_cut(t, max_chars, 0.3) or tiny
    if cut:
        return _end_sentence(cut, is_sent)
    # 4) по словам
    cut = t[:max_chars - 1].rsplit(' ', 1)[0].rstrip(',;:—–-( ')
    return balance(cut) + '…'


# второстепенные части предложения — в порядке «чем раньше, тем менее важно»
_MINOR = [
    re.compile(r'\s*\((?![^()]*\d)[^()]{1,120}\)'),                       # (пояснение без чисел)
    re.compile(r'(?i)^(?:кроме того|при этом|также|вместе с тем|в свою очередь|в частности|в целом|как правило|'
               r'таким образом|следовательно|соответственно|в результате|в итоге|по сути|отметим, что|'
               r'следует отметить, что|стоит отметить, что|важно отметить, что|необходимо отметить, что)[,\s]+(?P<keep>\w)'),
    re.compile(r'(?i)^(?:по (?:данным|оценкам|расч[её]там|результатам|мнению)\s[^,;]{1,60}|как показывает \w+),\s+(?P<keep>\w)'),
    re.compile(r'(?i),\s*(?:как правило|по-видимому|по сути|в основном|в целом|как ожидается|'
               r'по (?:данным|оценкам|расч[её]там)\s[^,;]{1,50}),(?P<keep>\s)'),
    re.compile(r'(?i),\s*(?:в том числе|включая|например|в частности|то есть|т\.\s?е\.)\s[^,;]*?(?P<keep>[,;.]|$)'),
    re.compile(r'\s*\([^()]{1,160}\)'),                                    # любые скобки
    re.compile(r'(?i)(?<!\sтом)(?<!\sто)(?<!\sтех)(?<!\sтого)(?<!\sтам),\s*(?:котор\w+|чьи|чей|где|куда|откуда)\s[^;]*?(?=[;.]|$)'),
    re.compile(r'(?i),\s*(?:а также|причём|причем|при этом|так как|поскольку|чтобы|что позволя\w+|что обеспеч\w+)\s[^;]*?(?=[;.]|$)'),
    re.compile(r'\s[—–]\s[^—–;.]{3,120}?\s[—–]\s(?=\w)'),                      # «— вставка с двух сторон —»
    re.compile(r'^(?![^—–]*[—–][^—–]*[—–])(.*?\S)\s[—–]\s[^—–;]*?(?=[;.]|$)'),     # пояснение после единственного тире
]
_KEEP_AFTER = re.compile(r'(?i)^\s*(?:если|но|однако|хотя|кроме|за исключением|при условии|не\b|только|лишь)')


_PRED_WORD = re.compile(
    r'(?i)\b[а-яё]{2,}(?:ет|ёт|ют|ит|ят|ут|ат|ется|ются|ится|ятся|ал|ала|ало|али|ял|яла|яло|яли|ил|ила|ило|или|ел|ела|'
    r'ело|ели|ыл|ыла|ыло|ыли|ался|алась|алось|ались|ился|илась|илось|ились|ен|ена|ено|ены|ён|ан|ана|ано|аны|ят|'
    r'ос|осла|осло|осли)\b|\b(?:есть|нет|был[аио]?|будет|будут|является|являются|можно|нужно|необходимо|важно|'
    r'следует|надо)\b|\s[—–]\s|:\s')
_NOT_PRED = re.compile(r'(?i)\b(?:как правило|в частности|в целом|в основном|по данным|по оценкам|в среднем|'
                       r'в результате|в итоге)\b')


def has_predicate(t):
    """Есть ли в части фразы сказуемое (глагол, краткое причастие, тире): «Несмотря на небольшой масштаб» — нет."""
    return bool(_PRED_WORD.search(_NOT_PRED.sub(' ', t)))


def _clause_cut(t, max_chars, k=0.5):
    """Самая длинная начальная часть фразы до «;», «:», «,», тире (а если таких нет — до союза «и», «а», «или»),
    которая помещается в max_chars и не короче половины лимита. Условия «если…», «но…» не отбрасываются."""
    need_pred = has_predicate(t)                 # перечень без глагола («монтаж, обвязка, замена…») режем и так
    for rx in (r'\s*(?:;|:|,|\s[—–])\s', r'\s(?:и|а|или|либо)\s'):
        best = ''
        for m in re.finditer(rx, t):
            head = t[:m.start()].rstrip(' ,;:—–')
            if len(head) > max_chars - 1:
                break
            if _KEEP_AFTER.match(t[m.end():]):
                continue
            if re.search(r'(?i)\s(?:о|об|в|на|по|за|из)?\s?(?:том|то|тем|того|тех|таким|так|такой|такие|одно)$', head):
                continue                                 # «вопрос о том, где…» — без продолжения бессмысленно
            if re.search(r'(?i)[\s,](?:где|как|когда|что|чтобы|если|куда|почему|зачем|котор\w+|чем|но|или|в|на|с|со|'
                         r'по|за|из|к|о|об|от|до|для|при|не|ни)$', head):
                continue                                 # часть не может кончаться служебным словом
            if len(head) >= max_chars * k and len(head.split()) >= 2 and (not need_pred or has_predicate(head)):
                best = head
        if best:
            return balance(best)
    return ''


def _keep(m, t):
    """Остаток после выброшенной вводной части; в начале фразы — с заглавной, если фраза была с заглавной."""
    k = m.group('keep')
    return k.upper() if m.start() == 0 and t[:1].isupper() else k


def _end_sentence(t, is_sent):
    t = balance(t.strip().rstrip(',;:—– '))
    if is_sent and t and t[-1] not in '.!?…':
        t += '.'
    return t


def balance(t):
    """Парные скобки и кавычки: незакрытая скобка (кавычка) в конце — отбрасывается вместе с хвостом,
    если хвост короткий, иначе закрывается."""
    for o, c in (('(', ')'), ('«', '»')):
        while t.count(o) > t.count(c):
            i = t.rfind(o)
            if len(t) - i <= max(25, len(t) * 0.4) and i > 8:
                t = t[:i].rstrip(' ,;:—–')
            else:
                t = t.rstrip(' .') + c
        while t.count(c) > t.count(o):
            i = t.find(c)
            t = t[:i] + t[i + 1:]
    if t.count('"') % 2:
        i = t.rfind('"')
        t = t[:i] + t[i + 1:]
    return t


def first_sentence(s, max_chars=160):
    sents = sentences(s)
    return shorten(sents[0], max_chars) if sents else ''


def words(s):
    return re.findall(r'[\wЁё-]+', s)


def cap(s):
    """Первая буква — заглавная."""
    s = s.strip()
    return s[:1].upper() + s[1:] if s else s


# --------------------------------------------------------------------------------------
# Заголовок + текст из одного пункта
# --------------------------------------------------------------------------------------
_TITLE_SEP = re.compile(r'^(.{2,70}?)\s*(?::|\s[—–-]\s)\s*(.+)$')


def split_title_text(item, bold_prefix='', max_title_words=7):
    """Делит пункт на (заголовок, текст).

    Порядок попыток:
      1) жирное начало абзаца в Word («**Мониторинг.** Робот проверяет…»);
      2) «Заголовок: текст» или «Заголовок — текст» (заголовок до 7 слов);
      3) первое короткое предложение (до 7 слов) — заголовок, остальное — текст;
      4) иначе заголовка нет, весь пункт — текст.
    """
    item = clean(item)
    bp = clean(bold_prefix).rstrip('.:—–- ')
    if bp and item.startswith(bp) and 0 < len(words(bp)) <= 10:
        rest = item[len(bp):].lstrip('.:—–- ').strip()
        return cap(bp), cap(rest)
    m = _TITLE_SEP.match(item)
    if m and (m.group(1).count('(') != m.group(1).count(')') or m.group(1).count('«') != m.group(1).count('»')):
        m = None                                   # разделитель внутри скобок или кавычек
    if m and len(words(m.group(1))) <= max_title_words:
        return cap(m.group(1).strip()), cap(m.group(2).strip())
    sents = sentences(item)
    if len(sents) > 1 and len(words(sents[0])) <= max_title_words:
        return cap(sents[0].rstrip('.')), ' '.join(sents[1:])
    return '', item


def short_title(text, max_words=5, max_chars=40):
    """Короткий заголовок из начала текста (когда в пункте нет явного заголовка)."""
    t = clean(text)
    t = re.split(r'[.:;,(—–]', t)[0]
    ws = t.split()
    if len(ws) > max_words:
        t = ' '.join(ws[:max_words])
    if len(t) > max_chars:
        t = t[:max_chars].rsplit(' ', 1)[0]
    return cap(t.strip(' -—–'))


# --------------------------------------------------------------------------------------
# Типографика
# --------------------------------------------------------------------------------------
_UNITS = r'(?:%|‰|₽|\$|€|руб\.?|тыс\.?|млн\.?|млрд\.?|трлн\.?|т\b|кг|км|м\b|м2|м3|м²|м³|°C|°|шт\.?|чел\.?|ед\.?|лет|года|год|г\.|гг\.|мес\.?|дн\.?|ч\b|мин\b|сек\b|баррел\w*|барр\.?|бар\.?|МВт|кВт|ГВт|Гкал|п\.\s?п\.|п\.п\.|раз\w*)'
_SHORT = r'(?:в|во|на|до|от|по|за|из|к|ко|с|со|у|о|об|при|для|без|над|под|и|а|но|или|не|ни|же|ли|бы|№|§)'


def typo(s):
    """Русская типографика: неразрывные пробелы.

    * после коротких предлогов и союзов («в рамках», «и т. д.»);
    * между числом и единицей («25 %», «1,5 млн руб.»);
    * внутри чисел-разрядов («1 234 567»).
    Возвращает новую строку (символы NBSP вместо обычных пробелов в нужных местах).
    """
    if not s:
        return s
    s = re.sub(r'(?<=\d) (?=\d{3}\b)', NBSP, s)
    s = re.sub(r'(?<=\d) (?=' + _UNITS + r')', NBSP, s)
    s = re.sub(r'(?<=\d) (?=(?:до|—|–|-) ?\d)', NBSP, s)
    s = re.sub(r'(?i)(?<![\w-])(' + _SHORT + r') (?=\S)', lambda m: m.group(1) + NBSP, s)
    return s


# --------------------------------------------------------------------------------------
# Числа
# --------------------------------------------------------------------------------------
_NUM = re.compile(r'[-−–]?\d[\d\s  ]*(?:[.,]\d+)?')


def parse_number(v):
    """Число из значения ячейки/текста: 1 234,5 → 1234.5; «12 %» → 12.0; 0.25 (float) → 0.25.
    Возвращает float или None."""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if not s or len(s) > 40:
        return None
    s2 = s.replace(' ', '').replace(' ', '').replace(' ', '').replace('−', '-').replace('–', '-')
    s2 = re.sub(r'(?i)(%|‰|₽|руб\.?|р\.|\$|€|тыс\.?|млн\.?|млрд\.?|шт\.?|ед\.?|т)$', '', s2)
    if re.fullmatch(r'-?\d+(?:[.,]\d+)?', s2):
        return float(s2.replace(',', '.'))
    if re.fullmatch(r'-?\d{1,3}(?:,\d{3})+(?:\.\d+)?', s2):     # 1,234,567.8
        return float(s2.replace(',', ''))
    return None


def fmt_number(x, decimals=None):
    """Число в русском формате: разряды через неразрывный пробел, дробная часть через запятую."""
    if x is None:
        return ''
    if decimals is None:
        ax = abs(x)
        decimals = 0 if ax >= 100 or float(x).is_integer() else (1 if ax >= 10 else 2)
    s = f'{x:,.{decimals}f}'.replace(',', ' ').replace('.', ',').replace(' ', NBSP)
    if decimals and ',' in s:
        s = s.rstrip('0').rstrip(',')
    return s.replace('-', '−')


def find_number(text):
    """Первое число в тексте с единицей: '…составил 12,5 млн руб. в 2025 г.' →
    ('12,5', 'млн руб.', start, end) или None. Годы (1900–2100) без единицы пропускаются."""
    for m in re.finditer(r'(?<![\w.])([-−]?\d[\d  ]*(?:[.,]\d+)?)\s?(' + _UNITS + r'(?:\s?' + _UNITS + r')?)?', text):
        num = m.group(1).strip()
        unit = (m.group(2) or '').strip()
        val = parse_number(num)
        if val is None:
            continue
        if not unit and 1900 <= val <= 2100 and '.' not in num and ',' not in num:
            continue
        return num.replace(' ', NBSP), unit, m.start(), m.end()
    return None


# --------------------------------------------------------------------------------------
# Иконки по ключевым словам
# --------------------------------------------------------------------------------------
# (регулярное выражение по основам слов, иконка). Порядок важен: первое совпадение побеждает.
ICON_RULES = [
    (r'вывод|итог|заключен|резюм', 'TbCircleCheck'),
    (r'цел[ьи]|целев|мишен', 'TbTarget'),
    (r'задач', 'TbChecklist'),
    (r'риск|угроз|опасн|авари|инцидент', 'TbAlertTriangle'),
    (r'проблем|недостат|слаб', 'TbAlertCircle'),
    (r'безопас|защит|охран|конфиденц|кибер', 'TbShieldCheck'),
    (r'доступ\w* к|парол|шифрован', 'TbLock'),
    (r'грант|субсид|финансирован', 'TbCoins'),
    (r'эконом|сбережен|снижен\w* затрат|окупаем', 'TbPigMoney'),
    (r'прибыл|доход|выручк|ebitda|маржин', 'TbReportMoney'),
    (r'бюджет|затрат|расход|стоимост|цен[аы]|руб|финанс|инвест|капвлож|capex|opex|деньг|оплат', 'TbCash'),
    (r'рост|увелич|прирост|повыш|ускор', 'TbTrendingUp'),
    (r'сниж|уменьш|сокращ|паден', 'TbTrendingDown'),
    (r'процент|доля|долей|структур', 'TbChartPie'),
    (r'показател|kpi|метрик|индикатор', 'TbGauge'),
    (r'аналит|анализ|статист|отчетн|отчётн', 'TbReportAnalytics'),
    (r'оценк|оценив|рейтинг|балл|скоринг', 'TbScale'),
    (r'мониторинг|наблюден|отслежив', 'TbDeviceAnalytics'),
    (r'поиск|найти|выявлен|выявля', 'TbSearch'),
    (r'искусствен|нейросет|машинн\w* обуч|\bии\b|\bai\b|llm|модел\w* язык', 'TbBrain'),
    (r'робот|автоматиз|автоматическ', 'TbRobot'),
    (r'сервер|инфраструкт|вычислит|gpu|видеокарт|желез', 'TbServer'),
    (r'облак|cloud', 'TbCloud'),
    (r'данн|баз[аеы]|реестр|хранилищ|архив|уч[её]т', 'TbDatabase'),
    (r'цифров|информацион|программн\w* обеспеч|софт|приложен|платформ|it\b|ит\b', 'TbDeviceDesktop'),
    (r'интеграц|сеть|сетев|связ[ьи]|api', 'TbNetwork'),
    (r'код|разработк\w* по|алгоритм', 'TbCode'),
    (r'нефт|скважин|месторожд|добыч|пласт|кин\b|мун\b|трииз|триз', 'TbDroplet'),
    (r'бурен|буров', 'TbCrane'),
    (r'газ', 'TbFlame'),
    (r'геотерм|тепл|температур', 'TbTemperature'),
    (r'энерг|электр|мощност', 'TbBolt'),
    (r'солнеч|виэ|возобнов', 'TbSolarPanel'),
    (r'эколог|выброс|климат|углерод|esg', 'TbLeaf'),
    (r'логист|транспорт|достав|перевоз', 'TbTruck'),
    (r'склад|запас|хранен', 'TbBuildingWarehouse'),
    (r'производ|завод|предприят|цех|переработ', 'TbBuildingFactory2'),
    (r'оборудован|техник|инструмент|ремонт|обслужив', 'TbTool'),
    (r'исслед|лаборатор|эксперимент|испытан|опи\b', 'TbFlask'),
    (r'наук|научн|вуз|университет|академ|институт', 'TbSchool'),
    (r'обучен|образован|курс|компетенц|квалификац|навык', 'TbCertificate'),
    (r'эксперт|специалист', 'TbUserCheck'),
    (r'сотрудник|персонал|команд|кадр|люд|коллектив|работник', 'TbUsers'),
    (r'клиент|заказчик|потребител|пользовател', 'TbUserStar'),
    (r'партн[её]р|сотруднич|взаимодейств|кооперац|альянс', 'TbHeartHandshake'),
    (r'договор|контракт|соглашен', 'TbContract'),
    (r'закон|прав[оа]|норматив|регламент|требован|стандарт|гост', 'TbGavel'),
    (r'лиценз|сертифик|патент', 'TbLicense'),
    (r'документ|отчет|отчёт|справк|положен|инструкц', 'TbFileText'),
    (r'уведомл|оповещ|почт|письм|e-mail|email', 'TbBell'),
    (r'коммуникац|сообщ|обсужд|совещан', 'TbMessages'),
    (r'срок|график|календар|дат[аы]|квартал', 'TbCalendar'),
    (r'время|быстр|оператив|час', 'TbClock'),
    (r'этап|шаг|процесс|порядок|последоват', 'TbRoute'),
    (r'план|дорожн|программ[аы]', 'TbClipboardList'),
    (r'стратег|развит|перспектив', 'TbStairsUp'),
    (r'иннова|технолог|новаци', 'TbBulb'),
    (r'запуск|внедрен|старт', 'TbRocket'),
    (r'качеств|эффективн|результат|эффект', 'TbAward'),
    (r'управлен|контрол|координац|настройк|оптимиз|режим', 'TbAdjustments'),
    (r'международ|зарубеж|стран|мир|глобал|экспорт', 'TbWorld'),
    (r'регион|территор|карт[аы]|географ|локац', 'TbMapPin'),
    (r'импортозамещ|замещен|обмен', 'TbArrowsExchange'),
    (r'модел|формул|расч[её]т|вычисл', 'TbMathFunction'),
    (r'проект', 'TbPresentation'),
    (r'решени', 'TbPuzzle'),
    (r'компани|организац|общество|холдинг', 'TbBuilding'),
]
_ICON_RE = [(re.compile(p, re.I), ic) for p, ic in ICON_RULES]
FALLBACK_ICONS = ['TbBulb', 'TbTarget', 'TbStar', 'TbFlag', 'TbPuzzle', 'TbCircleCheck', 'TbSparkles', 'TbDiamond']


_CATALOG = None


def icon_catalog():
    """Каталог иконок (1.7): [{id, ru, cat, words}] из assets/icons/catalog.json; нет файла — пустой список."""
    global _CATALOG
    if _CATALOG is None:
        import json
        from pathlib import Path
        p = Path(__file__).resolve().parent.parent / 'assets' / 'icons' / 'catalog.json'
        try:
            _CATALOG = [e for e in json.loads(p.read_text(encoding='utf-8')) if isinstance(e, dict) and e.get('id')]
        except (OSError, ValueError):
            _CATALOG = []
    return _CATALOG


_CAT_RE = None


def _catalog_re():
    """(выражение по основам слов с начала слова, иконка) — для каждой иконки каталога."""
    global _CAT_RE
    if _CAT_RE is None:
        _CAT_RE = []
        for e in icon_catalog():
            stems = sorted({w.strip().lower() for w in e.get('words') or [] if len(w.strip()) >= 3}, key=len, reverse=True)
            if stems:
                _CAT_RE.append((re.compile(r'(?<![а-яёa-z])(?:' + '|'.join(map(re.escape, stems)) + ')', re.I), e['id']))
    return _CAT_RE


def pick_icon(*texts, used=None):
    """Иконка по ключевым словам заголовка/текста. used — множество уже занятых на слайде
    иконок (стараемся не повторять). Сначала проверяется заголовок, затем текст. Правила ICON_RULES проверены
    на докладах и при равенстве важнее; каталог (1.7) добавляет сотни узких тем: компрессор, танкер, ГРП…"""
    used = used if used is not None else set()
    for t in texts:
        if not t:
            continue
        # побеждает правило, чьё слово встречается РАНЬШЕ в тексте (обычно это предмет фразы)
        best = None
        for k, (rx, ic) in enumerate(_ICON_RE):
            if ic in used:
                continue
            m = rx.search(t)
            if m and (best is None or (m.start(), k) < best[:2]):
                best = (m.start(), k, ic)
        for k, (rx, ic) in enumerate(_catalog_re()):
            if ic in used:
                continue
            m = rx.search(t)
            if m and (best is None or (m.start(), 10000 + k) < best[:2]):
                best = (m.start(), 10000 + k, ic)
        if best:
            used.add(best[2])
            return best[2]
    for ic in FALLBACK_ICONS:
        if ic not in used:
            used.add(ic)
            return ic
    return 'TbPoint'


_ALT_JUNK = re.compile(r'(?i)^(рисунок|рис\.?|изображение|картинка|фото(графия)?|снимок|picture|image|graphic|графический '
                       r'объект|объект|группа|group|фигура|shape|диаграмма|chart|логотип|logo|content placeholder|'
                       r'заполнитель|объект \d+|место для [а-я ]+)\s*№?\s*\d*$')


def alt_text(t, limit=120):
    """Замещающий текст рисунка из документа (Word, PowerPoint) → название, если оно осмысленное: без «Рисунок 3»,
    имён файлов и автоматических описаний Office («Изображение выглядит как…»)."""
    t = clean(t)
    if not t or len(t) > limit or 'автоматически созданное описание' in t.lower() or \
            re.match(r'(?i)^изображение выглядит как', t) or re.search(r'(?i)\.(png|jpe?g|emf|wmf|gif|bmp|tiff?|svg)$', t):
        return ''
    if _ALT_JUNK.match(t) or len(re.findall(r'[A-Za-zА-Яа-яЁё]', t)) < 3:
        return ''
    return cap(t.rstrip('.'))
