# -*- coding: utf-8 -*-
"""
variety.py — РАЗНООБРАЗИЕ СХЕМ В ПРЕЗЕНТАЦИИ
===========================================

Структура слайда выбирается по смыслу материала (planner_rules.py, smart.py). Этот модуль
проходит по готовому плану и снимает монотонность, НЕ ломая логику:

  * если два соседних слайда получились в одном макете (или один макет встречается
    слишком часто), второй переводится в РАВНОЗНАЧНУЮ форму того же содержания:
    карточки ↔ соты ↔ список; процесс ↔ таймлайн ↔ дорожная карта (при сроках);
    показатели ↔ полосы/пузыри (одна единица) ↔ спидометры (проценты);
  * схема выбирается только если для неё хватает данных (число элементов, числа, центр);
  * у макетов без родственной схемы меняется вариант оформления (variant) — например,
    карточки на градиентной подложке вместо белых.

Авторские решения не трогаются: слайды, у которых в плане явно задан variant или
keep_layout, остаются как есть.
"""
from .convert import NUMERIC, convert_slide
from .layouts.extra import checklist_ok, gantt_ok, hero_ok, risk_ok, swot_ok
from .layouts.mapslide import map_ok
from .layouts.oilgas import oilgas_ok
from .spec import LAYOUTS
from .textutil import parse_number

# схемы, которым нужны особые данные: сроки (Гант), уровни рисков, статусы, ключевое число, S/W/O/T
EXTRA_OK = {'gantt': gantt_ok, 'risk': risk_ok, 'checklist': checklist_ok, 'hero': hero_ok, 'swot': swot_ok,
            'map': map_ok}

# РАВНОЗНАЧНЫЕ формы одного и того же содержания (замена не меняет смысла):
#   набор равноправных элементов: карточки ↔ соты ↔ список;
#   шаги со сроками: процесс ↔ таймлайн ↔ дорожная карта (только если у всех шагов есть срок);
#   числа одной единицы: показатели ↔ полосы ↔ пузыри; проценты — спидометры.
# Схемы со смыслом (пирамида, воронка, мишень, сеть связей, слои, опоры…) выбираются только по
# содержанию — для «разнообразия» они не подставляются.
ALTERNATIVES = {
    'cards':     ['honeycomb', 'list'],
    'honeycomb': ['cards'],
    'list':      ['cards'],
    'process':   ['timeline', 'roadmap'],
    'timeline':  ['roadmap', 'process'],
    'roadmap':   ['timeline'],
    'kpi':       ['bars', 'gauge', 'bubbles'],
    'bars':      ['kpi'],
}
FAMILY = {}
for _fam, _lays in {'numbers': ('kpi', 'bars', 'gauge', 'bubbles', 'funnel', 'hero'),
                    'set': ('cards', 'honeycomb', 'list', 'pillars', 'hub', 'puzzle', 'petals', 'field'),
                    'steps': ('process', 'timeline', 'roadmap', 'stairs', 'path', 'gantt', 'value_chain'),
                    'levels': ('pyramid', 'layers', 'well'),
                    'pair': ('compare', 'shift', 'balance')}.items():
    for _l in _lays:
        FAMILY[_l] = _fam

VARIANTS = {'cards': ['', 'solid'], 'kpi': ['', 'ring'], 'text': ['', 'quote'], 'list': ['', 'tiles']}
MAX_SAME = 2                     # один макет (кроме диаграмм и таблиц) — не больше двух раз подряд по докладу


def _ok(s, lay, explicit=False):
    """Хватает ли слайду данных для макета lay. explicit — макет явно попросил пользователь (замечание к слайду):
    тогда нефтегазовые схемы не требуют нефтегазовых слов в тексте."""
    info = LAYOUTS.get(lay) or {}
    items = s.get('items') or []
    n = len(items)
    if info.get('kind') == 'items':
        if not (info.get('min') or 1) <= n <= (info.get('max') or 99):
            return False
    if lay in NUMERIC:
        vals = [parse_number(str(it.get('value') or '').replace('до ', '')) for it in items]
        if not items or any(v is None for v in vals):
            return False
        units = {str(it.get('unit') or '') for it in items}
        if lay in ('bars', 'bubbles') and len(units) > 1:
            return False
        if lay == 'gauge' and units != {'%'}:
            return False
    if lay == 'roadmap' and not all(it.get('label') for it in items):
        return False
    if lay in EXTRA_OK and not EXTRA_OK[lay](items):
        return False
    if not explicit and not oilgas_ok(s, lay):       # нефтегазовые схемы — только для нефтегазового содержания
        return False
    if lay in ('petals', 'puzzle', 'mindmap', 'fishbone') and not all(it.get('title') for it in items):
        return False
    if lay in ('honeycomb',) and any(len(it.get('title') or it.get('text') or '') > 40 for it in items) \
            and not all(it.get('title') for it in items):
        return False
    if lay in ('hub', 'pillars', 'layers', 'stairs', 'honeycomb') and not all(it.get('title') for it in items):
        return False
    return True


def volume(s):
    """Объём видимого текста слайда (знаков): варианты для разнообразия не должны терять содержание."""
    n = 0
    for k in ('subtitle', 'lead', 'conclusion', 'center'):
        n += len(str(s.get(k) or ''))
    n += sum(len(str(p)) for p in s.get('paragraphs') or [])
    for it in s.get('items') or []:
        if isinstance(it, dict):
            n += sum(len(str(it.get(k) or '')) for k in ('title', 'text', 'value', 'unit', 'label'))
        else:
            n += len(str(it))
    for side in ('left', 'right'):
        if isinstance(s.get(side), dict):
            n += sum(len(str(x)) for x in s[side].get('items') or [])
    n += sum(len(str(x)) for x in s.get('aside') or [])
    n += sum(len(' '.join(map(str, r))) for r in s.get('rows') or [])
    return n


def apply_alt(s, i):
    """Подставляет i-й вариант слайда (заметки, подпись раздела и список вариантов сохраняются)."""
    import copy
    alts = s.get('alts') or []
    if not 0 <= i < len(alts):
        return s
    new = copy.deepcopy(alts[i])
    for k in ('notes', 'section', 'title'):
        if s.get(k):
            new[k] = s[k]
    new['alts'] = alts
    new['alt_index'] = i
    return new


def diversify(slides):
    """Меняет макеты повторяющихся подряд слайдов на родственные схемы. Возвращает новый список."""
    out = []
    count = {}
    prev = None
    prev_variant = ''
    for s in slides:
        lay = s.get('layout')
        if lay in ('title', 'end', 'section', 'agenda', 'chart', 'table', 'image') or s.get('keep_layout'):
            out.append(s)
            if lay not in ('section',):
                prev = lay if lay not in ('title', 'end', 'agenda') else prev
            continue
        repeat = lay == prev
        if repeat and s.get('alts'):
            # среди готовых вариантов слайда — только та же «семья» содержания
            # (числа остаются числами, шаги — шагами), иначе слайд не меняется
            fam = FAMILY.get(lay)
            for i, a in enumerate(s['alts'][1:], start=1):
                al, av = a.get('layout'), a.get('variant') or ''
                other_form = al != prev and fam and FAMILY.get(al) == fam
                other_look = al == prev and av != prev_variant          # тот же макет в другом оформлении
                if volume(a) < 0.8 * volume(s):
                    continue                              # вариант беднее по содержанию — не подставляем
                if (other_form or other_look) and not (al == 'table' and lay != 'table'):
                    s = apply_alt(s, i)
                    lay = al
                    repeat = False
                    break
        if repeat:
            for alt in ALTERNATIVES.get(lay, []):
                if alt == prev or count.get(alt, 0) >= MAX_SAME:
                    continue
                if not _ok(s, alt):
                    continue
                s2 = convert_slide(dict(s), alt)
                if s2.get('layout') == alt:
                    s = s2
                    lay = alt
                    break
        # вариант оформления: чередуем внутри одного макета
        vs = VARIANTS.get(lay)
        if lay == 'text' and (len(s.get('paragraphs') or []) > 3
                              or sum(len(p) for p in s.get('paragraphs') or []) > 650):
            vs = None                                  # длинные пояснения в «цитате» мельчат — оставляем колонку
        if repeat and vs and not s.get('variant') and not s.get('aside') and not s.get('alt_index'):
            v = next((x for x in vs if x != prev_variant), '')      # соседи одного макета — в разном оформлении
            if v:
                s = dict(s, variant=v)
        count[lay] = count.get(lay, 0) + 1
        prev = lay
        prev_variant = s.get('variant') or ''
        out.append(s)
    return out
