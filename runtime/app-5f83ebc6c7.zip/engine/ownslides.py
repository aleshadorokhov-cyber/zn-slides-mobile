# -*- coding: utf-8 -*-
"""
ownslides.py — СВОИ СЛАЙДЫ ИЗ ФАЙЛА POWERPOINT (1.7)
===================================================

Автор вставляет в план готовые слайды из своей презентации. В плане такой слайд —
  {'layout': 'own', 'own': {'file': id файла, 'n': номер слайда, 'title_ph': заголовок — заполнитель,
   'title0': заголовок в файле, 'name': имя файла, 'dark': тёмный фон}, 'title', 'notes', 'bg'},
а при сборке (render_own) его содержимое переносится в презентацию с выбранным фоном (bg):

  * 'corporate' — фирменный фон: слайд по контентному макету шаблона (как остальные), заголовок — в заголовке
    шаблона, его шрифтом и цветом, остальное — в рабочей области (уменьшается, если не помещается); цвета и
    шрифты темы исходника становятся цветами и шрифтами шаблона;
  * 'white'     — белый фон без графики шаблона, слайд — как в файле;
  * 'source'    — как в файле: фон, графика макета и мастера исходника, цвета и шрифты его темы.
  При фирменном и белом фоне светлый текст, который в файле стоял прямо на тёмном фоне, становится тёмным
  (текст на своих плашках не трогается).

Переносится всё содержимое слайда: текст, картинки, диаграммы с данными, таблицы, SmartArt, видео, ссылки.
Заполнители исходника становятся обычными фигурами: положение и оформление текста (кегль, цвет, маркеры) берутся
из макета и мастера исходника. Слайд другого размера (4:3) ставится по центру, при другом масштабе — пропорционально
(вместе с кеглями). Заметки докладчика — из исходника (в плане их можно поправить); изменённый в плане заголовок
заменяет заголовок слайда.

Файлы хранятся в output/own_slides: <хэш>.pptx, <хэш>.json (список слайдов) и index.json (имена файлов).
"""
import copy
import hashlib
import io
import json
import re
import threading
from datetime import datetime
from pathlib import Path

from lxml import etree
from pptx import Presentation
from pptx.opc.constants import RELATIONSHIP_TARGET_MODE as RTM
from pptx.opc.constants import RELATIONSHIP_TYPE as RT
from pptx.opc.package import PartFactory, _Relationship
from pptx.oxml.ns import qn
from pptx.util import Inches

from .nts import config as C

OWN_DIR = C.OUTPUT_DIR / 'own_slides'
ID_RX = re.compile(r'[0-9a-f]{20}')
BG = ('corporate', 'white', 'source')
BG_NAMES = {'corporate': 'фирменный фон', 'white': 'белый фон', 'source': 'фон как в файле'}
INFO_VERSION = 2
R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
DSP_NS = 'http://schemas.microsoft.com/office/drawing/2008/diagram'
CT_DGM_DATA = 'application/vnd.openxmlformats-officedocument.drawingml.diagramData+xml'
CT_DGM_DRAWING = 'application/vnd.ms-office.drawingml.diagramDrawing+xml'
TEXT_DARK, TEXT_HEAD = '5A5A5A', '00326E'           # тёмный текст шаблона: обычный и крупный (заголовки)
# связи, которые не переносятся: слайд со своим макетом и заметками, переходы на другие слайды, примечания
SKIP_RELS = {RT.SLIDE_LAYOUT, RT.SLIDE_MASTER, RT.NOTES_SLIDE, RT.NOTES_MASTER, RT.HANDOUT_MASTER, RT.SLIDE,
             RT.COMMENTS, RT.COMMENT_AUTHORS}
_LOCK = threading.Lock()


class OwnError(ValueError):
    """Файл не подходит или не найден — текст показывается пользователю."""


# --------------------------------------------------------------------------------------
# Файлы
# --------------------------------------------------------------------------------------
def _index_file():
    return OWN_DIR / 'index.json'


def _load_index():
    try:
        d = json.loads(_index_file().read_text(encoding='utf-8'))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_index(d):
    OWN_DIR.mkdir(parents=True, exist_ok=True)
    tmp = _index_file().with_suffix('.tmp')
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding='utf-8')
    tmp.replace(_index_file())


def path_of(fid):
    """Путь к сохранённому файлу или None."""
    if not isinstance(fid, str) or not ID_RX.fullmatch(fid):
        return None
    p = OWN_DIR / f'{fid}.pptx'
    return p if p.is_file() else None


def save(data, filename):
    """Байты .pptx (.potx, .ppsx) → сохранённый файл; возвращает inspect(). Ошибка — OwnError."""
    from .templates import TemplateError, normalize_package
    try:
        data = normalize_package(data)
    except TemplateError as e:
        raise OwnError(str(e).replace('шаблон в PowerPoint как .pptx или .potx', 'файл в PowerPoint как .pptx')
                       .replace('(.pptx или .potx)', '(.pptx)'))
    try:
        prs = Presentation(io.BytesIO(data))
        n = len(prs.slides)
    except Exception:                                    # noqa: BLE001 — любой сбой разбора — понятный отказ
        raise OwnError('Файл PowerPoint не читается. Откройте его в PowerPoint и сохраните заново как .pptx.')
    if not n:
        raise OwnError('В файле нет слайдов.')
    fid = hashlib.sha1(data).hexdigest()[:20]
    OWN_DIR.mkdir(parents=True, exist_ok=True)
    p = OWN_DIR / f'{fid}.pptx'
    if not p.exists():
        p.write_bytes(data)
    with _LOCK:
        idx = _load_index()
        idx[fid] = {'name': Path(str(filename or 'слайды.pptx')).name[:200], 'n': n,
                    'added': datetime.now().isoformat(timespec='seconds')}
        _save_index(idx)
    return inspect(fid)


def listing():
    """Загруженные файлы, новые первыми: [{'id', 'name', 'n', 'added'}]."""
    idx = _load_index()
    out = [dict(v, id=k) for k, v in idx.items() if isinstance(v, dict) and path_of(k)]
    return sorted(out, key=lambda x: x.get('added') or '', reverse=True)


def delete(fid):
    p = path_of(fid)
    if not p:
        return False
    with _LOCK:
        idx = _load_index()
        idx.pop(fid, None)
        _save_index(idx)
    for f in (p, p.with_suffix('.json')):
        try:
            f.unlink()
        except OSError:
            pass
    return True


def inspect(fid):
    """Слайды файла: {'id', 'name', 'n', 'wide', 'slides': [{'n', 'title', 'title_ph', 'text', 'notes', 'hidden',
    'dark'}]} (кэш — <хэш>.json рядом с файлом)."""
    p = path_of(fid)
    if not p:
        raise OwnError('Файл со своими слайдами не найден — загрузите его снова.')
    name = (_load_index().get(fid) or {}).get('name') or 'слайды.pptx'
    cache = p.with_suffix('.json')
    try:
        info = json.loads(cache.read_text(encoding='utf-8'))
        if info.get('v') == INFO_VERSION:
            return dict(info, name=name)
    except (OSError, ValueError):
        pass
    prs = Presentation(str(p))
    slides = []
    for i, sl in enumerate(prs.slides, 1):
        title, is_ph, tid = slide_title(sl)
        texts = [re.sub(r'\s+', ' ', t).strip() for t in _texts(sl.shapes._spTree)]
        body = ' · '.join(t for t in texts if t and t != title)
        notes = ''
        if sl.has_notes_slide:
            notes = (sl.notes_slide.notes_text_frame.text if sl.notes_slide.notes_text_frame is not None else '').strip()
        try:
            dark = is_dark(sl)
        except Exception:                                # noqa: BLE001 — оценка фона не мешает списку
            dark = False
        slides.append({'n': i, 'title': title[:200], 'title_ph': is_ph, 'title_id': tid, 'text': body[:300], 'notes': notes[:4000],
                       'hidden': sl._element.get('show') == '0', 'dark': dark})
    info = {'v': INFO_VERSION, 'id': fid, 'n': len(slides), 'wide': prs.slide_width / prs.slide_height > 1.5,
            'slides': slides}
    try:
        cache.write_text(json.dumps(info, ensure_ascii=False), encoding='utf-8')
    except OSError:
        pass
    return dict(info, name=name)


def plan_slide(info, n, bg='corporate'):
    """Слайд плана для слайда n файла (inspect)."""
    s = info['slides'][n - 1]
    return {'layout': 'own', 'title': s['title'], 'notes': s['notes'], 'bg': bg if bg in BG else 'corporate',
            'own': {'file': info['id'], 'n': n, 'title_ph': s['title_ph'], 'title_id': s.get('title_id'), 'title0': s['title'],
                    'name': info.get('name') or '', 'dark': s['dark']}}


def _texts(root):
    out = []
    for tx in root.iter(qn('p:txBody'), qn('a:txBody')):
        t = '\n'.join(''.join(r.text or '' for r in p.iter(qn('a:t'))) for p in tx.iter(qn('a:p')))
        if t.strip():
            out.append(t)
    return out


def _ph(el):
    """Элемент p:ph фигуры верхнего уровня или None."""
    return el.find('./*/' + qn('p:nvPr') + '/' + qn('p:ph'))


def _title_el(sl):
    for el in sl.shapes._spTree.iterchildren():
        ph = _ph(el)
        if ph is not None and ph.get('type') in ('title', 'ctrTitle'):
            return el
    return None


def _one_line(el):
    return re.sub(r'\s+', ' ', ' '.join(_texts(el))).strip()


def _slide_size(sl):
    sz = sl.part.package.presentation_part._element.find(qn('p:sldSz'))
    return (int(sz.get('cx')), int(sz.get('cy'))) if sz is not None else (Inches(10), Inches(7.5))


def _title_guess(sl):
    """Надпись-заголовок без заполнителя: короткая крупная или жирная надпись в верхней пятой части слайда → элемент."""
    _, H = _slide_size(sl)
    best = None
    for el in sl.shapes._spTree.iterchildren():
        if _local(el) != 'sp' or _ph(el) is not None:
            continue
        t = _one_line(el)
        x = el.find(qn('p:spPr') + '/' + qn('a:xfrm'))
        off = x.find(qn('a:off')) if x is not None else None
        if not t or len(t) > 120 or off is None or int(off.get('y', 0)) > 0.2 * H:
            continue
        if len([p for p in el.iter(qn('a:p')) if ''.join(r.text or '' for r in p.iter(qn('a:t'))).strip()]) > 3:
            continue
        rprs = list(el.iter(qn('a:rPr'), qn('a:defRPr')))
        if not any(int(r.get('sz') or 0) >= 2000 or r.get('b') == '1' for r in rprs):
            continue
        y = int(off.get('y', 0))
        if best is None or y < best[0]:
            best = (y, el)
    return best[1] if best else None


def _shape_id(el):
    c = el.find('./*/' + qn('p:cNvPr'))
    return c.get('id') if c is not None else None


def _by_id(sl, sid):
    for el in sl.shapes._spTree.iterchildren():
        if sid and _shape_id(el) == str(sid):
            return el
    return None


def slide_title(sl):
    """Заголовок слайда → (текст, это заполнитель заголовка, id надписи-заголовка без заполнителя или None).
    Без заполнителя и без явной надписи-заголовка — самая верхняя короткая надпись (только для плана)."""
    el = _title_el(sl)
    if el is not None:
        t = _one_line(el)
        if t:
            return t, True, None
    g = _title_guess(sl)
    if g is not None:
        return _one_line(g), False, _shape_id(g)
    best = None
    for el in sl.shapes._spTree.iterchildren():
        if etree.QName(el).localname not in ('sp', 'grpSp'):
            continue
        t = _one_line(el)
        off = el.find('.//' + qn('a:off'))
        if not t or len(t) > 120 or off is None:
            continue
        y = int(off.get('y', 0))
        if best is None or y < best[0]:
            best = (y, t)
    return (best[1] if best else ''), False, None


def _eff_xfrm(el, sl):
    """Положение фигуры (x, y, cx, cy) с учётом заполнителя макета и мастера исходника или None."""
    for x in _xfrms(el)[:1]:
        off, ext = x.find(qn('a:off')), x.find(qn('a:ext'))
        if off is not None and ext is not None:
            return int(off.get('x', 0)), int(off.get('y', 0)), int(ext.get('cx', 0)), int(ext.get('cy', 0))
    ph = _ph(el)
    if ph is None:
        return None
    types, mtypes = _ph_types(ph.get('type', 'obj'))
    for x, tt, idx in ((sl.slide_layout, types, ph.get('idx')), (sl.slide_layout.slide_master, mtypes, None)):
        b = _find_ph(x, tt, idx)
        r = _eff_xfrm_plain(b) if b is not None else None
        if r:
            return r
    return None


def _ph_types(t):
    """Типы заполнителя для поиска в макете и в мастере (как наследует PowerPoint)."""
    if t in ('title', 'ctrTitle'):
        return ('title', 'ctrTitle'), ('title', 'ctrTitle')
    if t in ('dt', 'ftr', 'sldNum', 'hdr'):
        return (t,), (t,)
    return ('body', 'obj', 'subTitle', t), ('body',)


def _eff_xfrm_plain(el):
    for x in _xfrms(el)[:1]:
        off, ext = x.find(qn('a:off')), x.find(qn('a:ext'))
        if off is not None and ext is not None:
            return int(off.get('x', 0)), int(off.get('y', 0)), int(ext.get('cx', 0)), int(ext.get('cy', 0))
    return None


def _subtitle_el(sl, title_el):
    """Подзаголовок: заполнитель-подзаголовок или короткий текстовый заполнитель сразу под заголовком."""
    if title_el is None:
        return None
    tb = _eff_xfrm(title_el, sl)
    for el in sl.shapes._spTree.iterchildren():
        ph = _ph(el)
        if ph is None or el is title_el or _local(el) != 'sp' or ph.get('type', 'obj') not in ('subTitle', 'body', 'obj'):
            continue
        t = _one_line(el)
        if not t or len(t) > 160 or len([p for p in el.iter(qn('a:p')) if ''.join(_texts(p)).strip()]) > 1:
            continue
        if ph.get('type') == 'subTitle':
            return el
        b = _eff_xfrm(el, sl)
        if tb and b and tb[1] + tb[3] - Inches(0.15) <= b[1] <= tb[1] + tb[3] + Inches(0.5) and b[3] <= Inches(0.9):
            return el
    return None


def _footer_zone(el, sl):
    """Надпись-заполнитель в самом низу слайда (подвал исходника: раздел, номер, дата) — не переносится на другой фон."""
    if _ph(el) is None:
        return False
    _, H = _slide_size(sl)
    b = _eff_xfrm(el, sl)
    return bool(b) and b[1] >= 0.9 * H and len(_one_line(el)) <= 80


# --------------------------------------------------------------------------------------
# Цвета и шрифты темы исходника
# --------------------------------------------------------------------------------------
def _local(el):
    return etree.QName(el).localname if isinstance(el.tag, str) else ''


class _Theme:
    """Тема слайда исходника: цвета схемы с учётом сопоставления (clrMap), шрифты, стили фона."""

    def __init__(self, sl):
        layout = sl.slide_layout
        master = layout.slide_master
        self.master, self.layout = master, layout
        self.part = master.part.part_related_by(RT.THEME)
        th = etree.fromstring(self.part.blob)
        self.scheme = {}
        cs = th.find('.//' + qn('a:clrScheme'))
        for c in (cs if cs is not None else []):
            if not isinstance(c.tag, str) or not len(c):
                continue
            v = c[0]
            self.scheme[_local(c)] = (v.get('val') if _local(v) == 'srgbClr' else v.get('lastClr') or '000000').upper()
        self.cmap = dict(master._element.find(qn('p:clrMap')).attrib) if master._element.find(qn('p:clrMap')) is not None else {}
        for x in (layout, sl):
            o = x._element.find(qn('p:clrMapOvr') + '/' + qn('a:overrideClrMapping'))
            if o is not None:
                self.cmap.update(o.attrib)
        self.fonts = {}
        for kind, key in (('majorFont', 'mj'), ('minorFont', 'mn')):
            f = th.find('.//' + qn('a:' + kind))
            for script in ('latin', 'ea', 'cs'):
                e = f.find(qn('a:' + script)) if f is not None else None
                if e is not None and e.get('typeface'):
                    self.fonts[f'+{key}-{script[:2] if script != "latin" else "lt"}'] = e.get('typeface')
        fmt = th.find('.//' + qn('a:fmtScheme'))
        self.fills = list(fmt.find(qn('a:fillStyleLst'))) if fmt is not None and fmt.find(qn('a:fillStyleLst')) is not None else []
        self.bgfills = list(fmt.find(qn('a:bgFillStyleLst'))) if fmt is not None and fmt.find(qn('a:bgFillStyleLst')) is not None else []

    def hex(self, val):
        return self.scheme.get(self.cmap.get(val, val)) or self.scheme.get(val)

    def rgb(self, c):
        """Элемент цвета (srgbClr, schemeClr, sysClr, prstClr…) → (r, g, b) 0…1 с учётом lumMod/lumOff/tint/shade."""
        if c is None or not isinstance(c.tag, str):
            return None
        tag = _local(c)
        h = None
        if tag == 'srgbClr':
            h = c.get('val')
        elif tag == 'schemeClr':
            h = self.hex(c.get('val'))
        elif tag == 'sysClr':
            h = c.get('lastClr') or ('FFFFFF' if c.get('val') == 'window' else '000000')
        elif tag == 'prstClr':
            h = {'white': 'FFFFFF', 'black': '000000'}.get(c.get('val'), '808080')
        elif tag == 'scrgbClr':
            return tuple(max(0.0, min(1.0, int(c.get(k, 0)) / 100000)) for k in ('r', 'g', 'b'))
        if not h or len(h) != 6:
            return None
        try:
            rgb = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
        except ValueError:
            return None
        for m in c:
            if not isinstance(m.tag, str):
                continue
            k, v = _local(m), int(m.get('val', 0)) / 100000
            if k == 'lumMod':
                rgb = [x * v for x in rgb]
            elif k == 'lumOff':
                rgb = [min(1.0, x + v) for x in rgb]
            elif k == 'tint':
                rgb = [x + (1 - x) * (1 - v) for x in rgb]
            elif k == 'shade':
                rgb = [x * v for x in rgb]
        return tuple(rgb)

    def bg_fill(self, ref):
        """bgRef (стиль фона темы) → элемент заливки с цветом из ссылки вместо phClr."""
        idx = int(ref.get('idx', '0') or 0)
        lst, i = (self.bgfills, idx - 1001) if idx >= 1001 else (self.fills, idx - 1)
        if not (0 <= i < len(lst)):
            return None
        fill = copy.deepcopy(lst[i])
        color = next((c for c in ref if isinstance(c.tag, str)), None)
        if color is not None:
            for ph in list(fill.iter(qn('a:schemeClr'))):
                if ph.get('val') != 'phClr':
                    continue
                new = copy.deepcopy(color)
                for m in ph:
                    new.append(copy.deepcopy(m))
                ph.getparent().replace(ph, new)
        return fill

    def freeze(self, root):
        """Цвета схемы → явные цвета, шрифты темы → имена шрифтов (фон «как в файле»)."""
        for c in list(root.iter(qn('a:schemeClr'))):
            h = self.hex(c.get('val'))
            if not h:
                continue
            new = etree.Element(qn('a:srgbClr'), val=h)
            for m in c:
                new.append(m)
            c.getparent().replace(c, new)
        for tag in ('a:latin', 'a:ea', 'a:cs'):
            for f in root.iter(qn(tag)):
                t = f.get('typeface') or ''
                if t.startswith('+') and self.fonts.get(t):
                    f.set('typeface', self.fonts[t])


def _luma(rgb):
    return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2] if rgb else None


def _fill_luma(fill, owner, theme):
    """Средняя яркость заливки (0 — чёрный, 1 — белый) или None."""
    if fill is None:
        return None
    tag = _local(fill)
    if tag == 'solidFill':
        return _luma(theme.rgb(next((c for c in fill if isinstance(c.tag, str)), None)))
    if tag == 'gradFill':
        ls = [_luma(theme.rgb(next((c for c in gs if isinstance(c.tag, str)), None))) for gs in fill.iter(qn('a:gs'))]
        ls = [x for x in ls if x is not None]
        return sum(ls) / len(ls) if ls else None
    if tag == 'pattFill':
        ls = [_luma(theme.rgb(next((c for c in x if isinstance(c.tag, str)), None)))
              for x in (fill.find(qn('a:fgClr')), fill.find(qn('a:bgClr'))) if x is not None]
        ls = [x for x in ls if x is not None]
        return sum(ls) / len(ls) if ls else None
    if tag == 'blipFill':
        blip = fill.find(qn('a:blip'))
        rid = blip.get(qn('r:embed')) if blip is not None else None
        if not rid or owner is None or rid not in owner.rels:
            return None
        return _image_luma(owner.related_part(rid).blob)
    return None


def _image_luma(blob):
    try:
        from PIL import Image, ImageStat
        with Image.open(io.BytesIO(blob)) as im:
            im = im.convert('L')
            im.thumbnail((48, 48))
            return ImageStat.Stat(im).mean[0] / 255
    except Exception:                                    # noqa: BLE001 — EMF/WMF и пр. не оцениваются
        return None


def _background(sl):
    """Действующий фон слайда: (элемент p:bg, часть-владелец) — со слайда, макета или мастера."""
    for x in (sl, sl.slide_layout, sl.slide_layout.slide_master):
        bg = x._element.find(qn('p:cSld') + '/' + qn('p:bg'))
        if bg is not None:
            return bg, x.part
    return None, None


def _bg_fill(bg, owner, theme):
    """Заливка фона и её часть-владелец (для картинки): (элемент заливки, часть) или (None, None)."""
    if bg is None:
        return None, None
    pr = bg.find(qn('p:bgPr'))
    if pr is not None:
        return next((c for c in pr if isinstance(c.tag, str) and _local(c).endswith('Fill')), None), owner
    ref = bg.find(qn('p:bgRef'))
    return (theme.bg_fill(ref), theme.part) if ref is not None else (None, None)


def is_dark(sl, theme=None):
    """Тёмный ли фон слайда: по заливке фона или по картинке во весь слайд."""
    theme = theme or _Theme(sl)
    W, H = _slide_size(sl)
    for el in sl.shapes._spTree.iterchildren():           # картинка во весь слайд — это и есть фон
        if _local(el) != 'pic':
            continue
        off, ext = el.find('.//' + qn('a:off')), el.find('.//' + qn('a:ext'))
        if off is None or ext is None or int(ext.get('cx', 0)) * int(ext.get('cy', 0)) < 0.85 * W * H:
            continue
        blip = el.find('.//' + qn('a:blip'))
        rid = blip.get(qn('r:embed')) if blip is not None else None
        if rid and rid in sl.part.rels:
            lu = _image_luma(sl.part.related_part(rid).blob)
            if lu is not None:
                return lu < 0.45
    bg, owner = _background(sl)
    fill, fowner = _bg_fill(bg, owner, theme)
    lu = _fill_luma(fill, fowner, theme)
    return lu is not None and lu < 0.45


# --------------------------------------------------------------------------------------
# Перенос частей пакета (картинки, диаграммы с данными, SmartArt, видео)
# --------------------------------------------------------------------------------------
def _tmpl(partname):
    s = str(partname).replace('%', '%%')
    m = re.match(r'^(.*?)(\d+)(\.[^./]+)$', s)
    if m:
        return m.group(1) + '%d' + m.group(3)
    base, dot, ext = s.rpartition('.')
    return (base + '%d.' + ext) if dot else s + '%d'


def _skip(reltype):
    return reltype in SKIP_RELS or reltype.endswith('/comments') or reltype.endswith('/commentAuthors')


def _new_part(src, pkg, memo, key):
    new = PartFactory(pkg.next_partname(_tmpl(src.partname)), src.content_type, pkg, src.blob)
    memo[key] = new
    return new


def _key(part, memo):
    """Картинки и видео переносятся один раз на сборку, остальные части (диаграммы, SmartArt) — для каждого слайда
    свои: один слайд можно вставить дважды с разным фоном, а общая диаграмма у двух слайдов PowerPoint не нравится."""
    media = str(part.content_type).split('/')[0] in ('image', 'video', 'audio')
    return (id(part.package), str(part.partname)) + (() if media else (memo.get('_slide'),))


def _link_children(src, new, memo):
    """Связи перенесённой части — с теми же rId (на них ссылается её XML), части — копиями."""
    base = new.rels._base_uri
    for rid, rel in list(src.rels.items()):
        if rel.is_external:
            new.rels._rels[rid] = _Relationship(base, rid, rel.reltype, RTM.EXTERNAL, rel.target_ref)
            continue
        if _skip(rel.reltype):
            continue
        t = rel.target_part
        child = memo.get(_key(t, memo))
        fresh = child is None
        if fresh:
            child = _new_part(t, new.package, memo, _key(t, memo))
        new.rels._rels[rid] = _Relationship(base, rid, rel.reltype, RTM.INTERNAL, child)
        if fresh:
            _link_children(t, child, memo)


def _import_rel(src_part, rid, dst_part, memo):
    """Связь rid части src_part → связь в dst_part (часть копируется один раз за сборку). None — не переносится."""
    if rid not in src_part.rels:
        return None
    rel = src_part.rels[rid]
    if rel.is_external:
        return dst_part.rels.get_or_add_ext_rel(rel.reltype, rel.target_ref)
    if _skip(rel.reltype):
        return None
    t = rel.target_part
    new = memo.get(_key(t, memo))
    if new is None:
        new = _new_part(t, dst_part.package, memo, _key(t, memo))
        rid2 = dst_part.rels.get_or_add(rel.reltype, new)     # сначала связь: тогда новая часть видна пакету
        _link_children(t, new, memo)
        return rid2
    return dst_part.rels.get_or_add(rel.reltype, new)


def _import_rels(root, src_part, dst_part, memo):
    """Все ссылки r:… в XML (картинки, диаграммы, ссылки) — на связи нового слайда."""
    for e in list(root.iter()):
        if not isinstance(e.tag, str):
            continue
        for k, v in list(e.attrib.items()):
            if not k.startswith('{' + R_NS + '}') or not v:
                continue
            new = _import_rel(src_part, v, dst_part, memo)
            if new:
                e.set(k, new)
            elif _local(e) in ('hlinkClick', 'hlinkMouseOver', 'custData', 'tags'):
                if e.getparent() is not None:
                    e.getparent().remove(e)
            else:
                del e.attrib[k]


# --------------------------------------------------------------------------------------
# Заполнители исходника → обычные фигуры с их положением и оформлением
# --------------------------------------------------------------------------------------
PPR_ORDER = ['lnSpc', 'spcBef', 'spcAft', 'buClrTx', 'buClr', 'buSzTx', 'buSzPct', 'buSzPts', 'buFontTx', 'buFont',
             'buNone', 'buAutoNum', 'buChar', 'buBlip', 'tabLst', 'defRPr', 'extLst']
PPR_GROUP = {'buClrTx': 'buClr', 'buSzTx': 'buSz', 'buSzPct': 'buSz', 'buSzPts': 'buSz', 'buFontTx': 'buFont',
             'buNone': 'bu', 'buAutoNum': 'bu', 'buChar': 'bu', 'buBlip': 'bu'}
RPR_ORDER = ['ln', 'noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill', 'grpFill', 'effectLst', 'effectDag',
             'highlight', 'uLnTx', 'uLn', 'uFillTx', 'uFill', 'latin', 'ea', 'cs', 'sym', 'hlinkClick', 'hlinkMouseOver',
             'rtl', 'extLst']
FILLS = ('noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill', 'grpFill')
RPR_GROUP = dict({f: 'fill' for f in FILLS}, effectDag='effect', effectLst='effect', uLnTx='uLn', uFillTx='uFill')
SPPR_ORDER = ['xfrm', 'custGeom', 'prstGeom'] + list(FILLS) + ['ln', 'effectLst', 'effectDag', 'scene3d', 'sp3d', 'extLst']
SPPR_GROUP = dict({f: 'fill' for f in FILLS}, custGeom='geom', prstGeom='geom', effectDag='effect', effectLst='effect')
BODY_ORDER = ['prstTxWarp', 'noAutofit', 'normAutofit', 'spAutoFit', 'scene3d', 'sp3d', 'flatTx', 'extLst']
BODY_GROUP = {'noAutofit': 'fit', 'normAutofit': 'fit', 'spAutoFit': 'fit', 'sp3d': '3d', 'flatTx': '3d'}


def _insert(parent, child, order):
    """Вставить child в parent на место по порядку схемы."""
    name = _local(child)
    pos = order.index(name) if name in order else len(order)
    for i, c in enumerate(parent):
        n2 = _local(c)
        if n2 in order and order.index(n2) > pos:
            parent.insert(i, child)
            return
    parent.append(child)


def _overlay(base, top, order, groups, deep=None):
    """Свойства top поверх base (атрибуты и дочерние элементы по группам), результат — в base."""
    base.attrib.update(top.attrib)
    for c in top:
        if not isinstance(c.tag, str):
            continue
        name = _local(c)
        g = groups.get(name, name)
        old = [x for x in base if isinstance(x.tag, str) and groups.get(_local(x), _local(x)) == g]
        if deep and name in deep and old and _local(old[0]) == name:
            o, gr = deep[name]
            _overlay(old[0], c, o, gr)
            continue
        for x in old:
            base.remove(x)
        _insert(base, copy.deepcopy(c), order)
    return base


def _merge_levels(styles):
    """Несколько стилей списков (снизу вверх) → один a:lstStyle с уровнями 1…9."""
    out = etree.Element(qn('a:lstStyle'))
    for lvl in range(1, 10):
        tag = qn(f'a:lvl{lvl}pPr')
        acc = None
        for st in styles:
            if st is None:
                continue
            p = st.find(tag)
            if p is None:
                continue
            if acc is None:
                acc = etree.Element(tag)
            _overlay(acc, p, PPR_ORDER, PPR_GROUP, deep={'defRPr': (RPR_ORDER, RPR_GROUP)})
        if acc is not None:
            out.append(acc)
    return out


def _find_ph(x, types, idx):
    """Заполнитель макета или мастера: по номеру, иначе по типу."""
    tree = x._element.find(qn('p:cSld') + '/' + qn('p:spTree'))
    cands = [(el, _ph(el)) for el in tree.iterchildren()]
    cands = [(el, ph) for el, ph in cands if ph is not None]
    if idx is not None:
        for el, ph in cands:
            if ph.get('idx', '0') == idx and (ph.get('type', 'obj') in types or idx != '0'):
                return el
    for el, ph in cands:
        if ph.get('type', 'obj') in types:
            return el
    return None


def _master_style(master, t):
    tx = master._element.find(qn('p:txStyles'))
    if tx is None:
        return None
    name = 'titleStyle' if t in ('title', 'ctrTitle') else ('otherStyle' if t in ('dt', 'ftr', 'sldNum', 'hdr') else 'bodyStyle')
    return tx.find(qn('p:' + name))


def _unplaceholder(e, ph, sl, dst_part, memo):
    """Заполнитель → обычная фигура: геометрия, заливка и стиль текста — из макета и мастера исходника."""
    t, idx = ph.get('type', 'obj'), ph.get('idx')
    types, mtypes = _ph_types(t)
    layout = sl.slide_layout
    master = layout.slide_master
    lph = _find_ph(layout, types, idx)
    mph = _find_ph(master, mtypes, None)
    bases = [(b, o) for b, o in ((lph, layout.part), (mph, master.part)) if b is not None]
    tag = _local(e)
    if tag in ('sp', 'pic', 'cxnSp'):
        sp_pr = e.find(qn('p:spPr'))
        if sp_pr is None:
            sp_pr = etree.SubElement(e, qn('p:spPr'))
        for b, owner in bases:
            bpr = b.find(qn('p:spPr'))
            for c in (bpr if bpr is not None else []):
                if not isinstance(c.tag, str):
                    continue
                g = SPPR_GROUP.get(_local(c), _local(c))
                if any(SPPR_GROUP.get(_local(x), _local(x)) == g for x in sp_pr if isinstance(x.tag, str)):
                    continue
                c2 = copy.deepcopy(c)
                _import_rels(c2, owner, dst_part, memo)
                _insert(sp_pr, c2, SPPR_ORDER)
    elif tag == 'graphicFrame' and e.find(qn('p:xfrm')) is None:
        for b, _ in bases:
            x = b.find(qn('p:spPr') + '/' + qn('a:xfrm'))
            if x is None:
                x = b.find(qn('p:xfrm'))
            if x is not None:
                px = etree.Element(qn('p:xfrm'))
                for c in x:
                    px.append(copy.deepcopy(c))
                e.insert(1, px)
                break
    tx = e.find(qn('p:txBody'))
    if tx is not None:
        own_lst = tx.find(qn('a:lstStyle'))
        styles = [(_master_style(master, t), master.part)] + \
            [(b.find(qn('p:txBody') + '/' + qn('a:lstStyle')), o) for b, o in reversed(bases)]
        lst = _merge_levels([_owned(st, o, dst_part, memo) for st, o in styles] + [own_lst])
        body = tx.find(qn('a:bodyPr'))
        if body is None:
            body = etree.Element(qn('a:bodyPr'))
            tx.insert(0, body)
        merged = etree.Element(qn('a:bodyPr'))
        for b, _ in reversed(bases):
            bb = b.find(qn('p:txBody') + '/' + qn('a:bodyPr'))
            if bb is not None:
                _overlay(merged, bb, BODY_ORDER, BODY_GROUP)
        _overlay(merged, body, BODY_ORDER, BODY_GROUP)
        tx.replace(body, merged)
        if own_lst is not None:
            tx.replace(own_lst, lst)
        else:
            merged.addnext(lst)
    ph.getparent().remove(ph)


def _owned(st, owner, dst_part, memo):
    """Копия стиля из макета, мастера или презентации со связями нового слайда (маркеры-картинки)."""
    if st is None:
        return None
    st = copy.deepcopy(st)
    _import_rels(st, owner, dst_part, memo)
    return st


def _freeze_defaults(root, prs_part, dst_part, memo):
    """Фон «как в файле»: текст обычных надписей получает стиль по умолчанию исходника (кегль, цвет, шрифт)."""
    dts = _owned(prs_part._element.find(qn('p:defaultTextStyle')), prs_part, dst_part, memo)
    if dts is None:
        return
    for sp in root.iter(qn('p:sp')):
        tx = sp.find(qn('p:txBody'))
        if tx is None or _ph(sp) is not None:
            continue
        own = tx.find(qn('a:lstStyle'))
        lst = _merge_levels([dts, own])
        if own is not None:
            tx.replace(own, lst)
        else:
            body = tx.find(qn('a:bodyPr'))
            if body is not None:
                body.addnext(lst)
            else:
                tx.insert(0, lst)


def _empty_ph(el):
    """Пустой заполнитель (в показе его не видно) — не переносится."""
    if _local(el) != 'sp':
        return False
    return not ''.join(_texts(el)).strip()


def _has_fill(sp, theme):
    pr = sp.find(qn('p:spPr'))
    if pr is not None:
        for c in pr:
            n = _local(c)
            if n == 'noFill':
                return False
            if n in ('solidFill', 'gradFill', 'blipFill', 'pattFill'):
                return True
            if n == 'grpFill':
                g = sp.getparent()
                gp = g.find(qn('p:grpSpPr')) if g is not None else None
                return gp is not None and any(_local(x) in ('solidFill', 'gradFill', 'blipFill', 'pattFill') for x in gp)
    st = sp.find(qn('p:style'))
    ref = st.find(qn('a:fillRef')) if st is not None else None
    return ref is not None and int(ref.get('idx', '0') or 0) > 0


def _darken_light_text(root, theme):
    """Светлый текст, стоявший прямо на тёмном фоне исходника, — тёмным (на светлом фоне его не было бы видно)."""
    for sp in root.iter(qn('p:sp')):
        if _has_fill(sp, theme):
            continue
        tx = sp.find(qn('p:txBody'))
        if tx is None:
            continue
        for rpr in tx.iter(qn('a:rPr'), qn('a:defRPr'), qn('a:endParaRPr')):
            f = rpr.find(qn('a:solidFill'))
            col = next((c for c in f if isinstance(c.tag, str)), None) if f is not None else None
            lu = _luma(theme.rgb(col))
            if lu is not None and lu > 0.6:
                big = int(rpr.get('sz') or 0) >= 2000
                f.replace(col, etree.Element(qn('a:srgbClr'), val=TEXT_HEAD if big else TEXT_DARK))
        st = sp.find(qn('p:style'))
        ref = st.find(qn('a:fontRef')) if st is not None else None
        col = next((c for c in ref if isinstance(c.tag, str)), None) if ref is not None else None
        lu = _luma(theme.rgb(col))
        if lu is not None and lu > 0.6:
            ref.replace(col, etree.Element(qn('a:srgbClr'), val=TEXT_DARK))


def _darken_chart_text(root, theme):
    """То же для подписей диаграммы."""
    for tx in root.iter('{http://schemas.openxmlformats.org/drawingml/2006/chart}txPr',
                        '{http://schemas.openxmlformats.org/drawingml/2006/chart}rich'):
        for rpr in tx.iter(qn('a:defRPr'), qn('a:rPr')):
            f = rpr.find(qn('a:solidFill'))
            col = next((c for c in f if isinstance(c.tag, str)), None) if f is not None else None
            lu = _luma(theme.rgb(col))
            if lu is not None and lu > 0.6:
                f.replace(col, etree.Element(qn('a:srgbClr'), val=TEXT_DARK))


def _set_text(sp, text):
    """Новый текст фигуры с оформлением её первого фрагмента (изменённый в плане заголовок)."""
    tx = sp.find(qn('p:txBody'))
    ps = tx.findall(qn('a:p')) if tx is not None else []
    if not ps:
        return
    p = ps[0]
    for x in ps[1:]:
        tx.remove(x)
    runs = p.findall(qn('a:r'))
    rpr = copy.deepcopy(runs[0].find(qn('a:rPr'))) if runs and runs[0].find(qn('a:rPr')) is not None else None
    for x in list(p):
        if _local(x) in ('r', 'br', 'fld'):
            p.remove(x)
    r = etree.Element(qn('a:r'))
    if rpr is not None:
        r.append(rpr)
    etree.SubElement(r, qn('a:t')).text = text
    end = p.find(qn('a:endParaRPr'))
    if end is not None:
        end.addprevious(r)
    else:
        p.append(r)


# --------------------------------------------------------------------------------------
# Геометрия: размер слайда исходника, рабочая область шаблона
# --------------------------------------------------------------------------------------
def _xfrms(el):
    """Элементы a:xfrm/p:xfrm фигуры верхнего уровня (у mc:AlternateContent — у каждого варианта)."""
    tag = _local(el)
    if tag == 'AlternateContent':
        return [x for ch in el for sh in ch for x in _xfrms(sh)]
    if tag == 'graphicFrame':
        x = el.find(qn('p:xfrm'))
    elif tag == 'grpSp':
        x = el.find(qn('p:grpSpPr') + '/' + qn('a:xfrm'))
    else:
        x = el.find(qn('p:spPr') + '/' + qn('a:xfrm'))
    return [x] if x is not None else []


def _bbox(els):
    box = None
    for el in els:
        for x in _xfrms(el)[:1]:
            off, ext = x.find(qn('a:off')), x.find(qn('a:ext'))
            if off is None or ext is None:
                continue
            l, t = int(off.get('x', 0)), int(off.get('y', 0))
            r, b = l + int(ext.get('cx', 0)), t + int(ext.get('cy', 0))
            box = (l, t, r, b) if box is None else (min(box[0], l), min(box[1], t), max(box[2], r), max(box[3], b))
    return box


def _transform(els, s, dx, dy):
    for el in els:
        for x in _xfrms(el):
            off, ext = x.find(qn('a:off')), x.find(qn('a:ext'))
            if off is not None:
                off.set('x', str(int(round(int(off.get('x', 0)) * s + dx))))
                off.set('y', str(int(round(int(off.get('y', 0)) * s + dy))))
            if ext is not None and abs(s - 1) > 1e-6:
                ext.set('cx', str(int(round(int(ext.get('cx', 0)) * s))))
                ext.set('cy', str(int(round(int(ext.get('cy', 0)) * s))))


def _renumber(els, start):
    """Новые id фигур (без повторов на слайде); связи соединителей — по тем же id."""
    mp, nid = {}, start
    for el in els:
        for c in el.iter(qn('p:cNvPr')):
            nid += 1
            mp[c.get('id')] = str(nid)
            c.set('id', str(nid))
    for el in els:
        for c in el.iter(qn('a:stCxn'), qn('a:endCxn')):
            if c.get('id') in mp:
                c.set('id', mp[c.get('id')])
    return nid


def _max_id(tree):
    ids = [int(c.get('id')) for c in tree.iter(qn('p:cNvPr')) if (c.get('id') or '').isdigit()]
    return max(ids or [1])


# --------------------------------------------------------------------------------------
# Сборка
# --------------------------------------------------------------------------------------
class _Src:
    """Исходник, открытый на время сборки, и уже перенесённые из него части."""

    def __init__(self, path):
        self.prs = Presentation(str(path))
        self.memo = {}


def _source(ctx, fid):
    cache = ctx.__dict__.setdefault('_own_src', {})
    if fid not in cache:
        p = path_of(fid)
        if not p:
            raise OwnError('файл не найден')
        cache[fid] = _Src(p)
    return cache[fid]


def _content(ss, src, dst_part, mode, drop=(), keep=None):
    """Фигуры слайда исходника (копии со связями нового слайда); drop — фигуры исходника, которые не переносятся
    (заголовок и подзаголовок уходят в заполнители шаблона); keep — фигура исходника, копию которой вернуть."""
    out, kept = [], None
    for el in ss.shapes._spTree.iterchildren():
        tag = _local(el)
        if tag in ('nvGrpSpPr', 'grpSpPr', 'extLst', '') or any(el is d for d in drop):
            continue
        ph = _ph(el)
        if ph is not None:
            t = ph.get('type', 'obj')
            if mode != 'source' and (t in ('dt', 'ftr', 'sldNum', 'hdr') or _footer_zone(el, ss)):
                continue
            if _empty_ph(el):
                continue
        e = copy.deepcopy(el)
        _import_rels(e, ss.part, dst_part, src.memo)
        if ph is not None:
            _unplaceholder(e, _ph(e), ss, dst_part, src.memo)
        if keep is not None and el is keep:
            kept = e
        out.append(e)
    return out, kept


def _decor(ss, dst_part, memo):
    """Графика макета и мастера исходника (не заполнители) — для фона «как в файле»."""
    if ss._element.get('showMasterSp') == '0':
        return []
    layout = ss.slide_layout
    parts = ([layout.slide_master] if layout._element.get('showMasterSp') != '0' else []) + [layout]
    out = []
    for x in parts:
        tree = x._element.find(qn('p:cSld') + '/' + qn('p:spTree'))
        for el in tree.iterchildren():
            if _local(el) in ('nvGrpSpPr', 'grpSpPr', 'extLst', '') or _ph(el) is not None:
                continue
            e = copy.deepcopy(el)
            _import_rels(e, x.part, dst_part, memo)
            out.append(e)
    return out


def _parts_of(els, slide_part):
    """Перенесённые части диаграмм и SmartArt, на которые ссылаются фигуры."""
    out = []
    for el in els:
        for e in el.iter():
            if not isinstance(e.tag, str):
                continue
            for k, v in e.attrib.items():
                if k.startswith('{' + R_NS + '}') and v and v in slide_part.rels and not slide_part.rels[v].is_external:
                    p = slide_part.rels[v].target_part
                    if p not in out:
                        out.append(p)
    return out


def _xml_of(part):
    """XML части для правки и функция записи обратно (у неопознанных python-pptx частей — через blob)."""
    if hasattr(part, '_element'):
        return part._element, (lambda el: None)
    if not str(part.content_type).endswith('+xml'):
        return None, None
    el = etree.fromstring(part.blob)

    def put(e):
        part._blob = etree.tostring(e, xml_declaration=True, encoding='UTF-8', standalone=True)
    return el, put


def render_own(ctx, s):
    """Свой слайд из файла PowerPoint (см. описание модуля)."""
    from .layouts.base import content_slide
    from .nts.theme import _scale_tree
    o = s.get('own') or {}
    bg = s.get('bg') if s.get('bg') in BG else 'corporate'
    try:
        src = _source(ctx, o.get('file'))
        n = int(o.get('n') or 0)
        if not 1 <= n <= len(src.prs.slides):
            raise OwnError(f'в файле нет слайда {n}')
    except (OwnError, OSError, ValueError, KeyError) as e:
        return _missing(ctx, s, e)
    ss = src.prs.slides[n - 1]
    theme = _Theme(ss)
    dark = is_dark(ss, theme)
    deck = ctx.d
    W0, H0 = src.prs.slide_width, src.prs.slide_height
    t_src = _title_el(ss)
    if t_src is None or _empty_ph(t_src):
        t_src = _by_id(ss, o.get('title_id')) if o.get('title_id') else None
    if bg == 'corporate':
        sub_src = _subtitle_el(ss, t_src)
        title = (s.get('title') or '') if t_src is not None else ''
        sub = _one_line(sub_src) if sub_src is not None else ''
        sl, top, bottom = content_slide(ctx, {'title': title or '\u2060', 'subtitle': sub, 'section': s.get('section') or '',
                                              'notes': s.get('notes') or ''})
        if not title:                                        # без заголовка: заполнитель-пустышка убирается
            for ph in list(sl.placeholders):
                if ph.has_text_frame and ph.text_frame.text == '\u2060':
                    ph._element.getparent().remove(ph._element)
        drop = [x for x in (t_src, sub_src) if x is not None]
    else:
        sl = deck.prs.slides.add_slide(_blank_layout(deck))
        for ph in list(sl.placeholders):
            ph._element.getparent().remove(ph._element)
        sl._element.set('showMasterSp', '0')                  # без графики шаблона
        if s.get('notes'):
            sl.notes_slide.notes_text_frame.text = s['notes']
        drop = []
    src.memo['_slide'] = id(sl)
    els, title_el = _content(ss, src, sl.part, bg, drop=drop, keep=t_src if bg != 'corporate' else None)
    if title_el is not None and s.get('title') and o.get('title0') is not None and s['title'] != o.get('title0'):
        _set_text(title_el, s['title'])                     # заголовок, изменённый в плане
    for p in _parts_of(els, sl.part):                       # SmartArt: рисунок связан со слайдом, а ссылка — в данных
        if p.content_type == CT_DGM_DATA:
            el, put = _xml_of(p)
            if el is not None:
                for ext in el.iter('{%s}dataModelExt' % DSP_NS):
                    new = _import_rel(ss.part, ext.get('relId') or '', sl.part, src.memo)
                    if new:
                        ext.set('relId', new)
                put(el)
    decor, bg_el = [], None
    if bg == 'source':
        for e in els:
            _freeze_defaults(e, src.prs.part, sl.part, src.memo)
        decor = _decor(ss, sl.part, src.memo)
        b, owner = _background(ss)
        if b is not None:
            fill, fowner = _bg_fill(b, owner, theme)
            if fill is not None:
                fill = copy.deepcopy(fill)
                _import_rels(fill, fowner, sl.part, src.memo)
                bg_el = etree.Element(qn('p:bg'))
                pr = etree.SubElement(bg_el, qn('p:bgPr'))
                pr.append(fill)
                etree.SubElement(pr, qn('a:effectLst'))
        for e in els + decor + ([bg_el] if bg_el is not None else []):
            theme.freeze(e)
    elif bg == 'white':
        bg_el = etree.fromstring('<p:bg xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" '
                                 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><p:bgPr><a:solidFill>'
                                 '<a:srgbClr val="FFFFFF"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>')
    if dark and bg != 'source':
        for e in els:
            _darken_light_text(e, theme)
    # геометрия
    if bg == 'corporate':
        box = _bbox(els)
        if box:
            tx, ty, tw, th = Inches(C.L), Inches(top), Inches(C.CW), Inches(bottom - top)
            bw, bh = max(1, box[2] - box[0]), max(1, box[3] - box[1])
            k = min(1.0, tw / bw, th / bh)
            if k < 1.0:
                nx, ny = tx + (tw - bw * k) / 2, ty
            else:                                            # помещается — на прежнем месте, но в рабочей области
                cx = box[0] + (Inches(C.SLIDE_W) - W0) / 2
                nx = min(max(cx, tx), tx + tw - bw)
                ny = min(max(box[1], ty), ty + th - bh)
            _transform(els, k, nx - box[0] * k, ny - box[1] * k)
            scale = k
        else:
            scale = 1.0
    else:
        Wd, Hd = deck.prs.slide_width, deck.prs.slide_height
        scale = min(Wd / W0, Hd / H0)
        dx, dy = (Wd - W0 * scale) / 2, (Hd - H0 * scale) / 2
        _transform(els + decor, scale, dx, dy)
    if abs(scale - 1) > 1e-3:
        for e in els + decor:
            _scale_tree(e, scale)
    for p in _parts_of(els, sl.part):                       # диаграммы и SmartArt: кегли, цвета
        el, put = _xml_of(p)
        if el is None:
            continue
        if abs(scale - 1) > 1e-3 and 'chart' in p.content_type:
            _scale_tree(el, scale)
        if bg == 'source':
            theme.freeze(el)
        elif dark and 'chart' in p.content_type:
            _darken_chart_text(el, theme)
        put(el)
    tree = sl.shapes._spTree
    nid = _max_id(tree)
    nid = _renumber(decor, nid)
    _renumber(els, nid)
    ext = tree.find(qn('p:extLst'))
    for e in decor + els:
        if ext is not None:
            ext.addprevious(e)
        else:
            tree.append(e)
    if bg_el is not None:
        csld = sl._element.find(qn('p:cSld'))
        old = csld.find(qn('p:bg'))
        if old is not None:
            csld.remove(old)
        csld.insert(0, bg_el)
    return sl


def _blank_layout(deck):
    """Макет без графики шаблона (копия контентного макета без фигур) — для белого фона и фона «как в файле».
    Одного «скрыть графику» у слайда мало: LibreOffice (картинки слайдов в окне) всё равно рисует фигуры макета."""
    lay = getattr(deck, '_own_blank', None)
    if lay is not None:
        return lay
    from pptx.opc.constants import CONTENT_TYPE as CT
    from pptx.parts.slide import SlideLayoutPart
    src = deck.L_WHITE
    el = copy.deepcopy(src._element)
    tree = el.find(qn('p:cSld') + '/' + qn('p:spTree'))
    for c in list(tree):
        if _local(c) not in ('nvGrpSpPr', 'grpSpPr'):
            tree.remove(c)
    el.find(qn('p:cSld')).set('name', 'Пустой (свои слайды)')
    el.set('showMasterSp', '0')
    for k in ('matchingName', 'type'):
        el.attrib.pop(k, None)
    pkg = deck.prs.part.package
    master_part = src.slide_master.part
    part = SlideLayoutPart.load(pkg.next_partname('/ppt/slideLayouts/slideLayout%d.xml'), CT.PML_SLIDE_LAYOUT, pkg,
                                etree.tostring(el, xml_declaration=True, encoding='UTF-8', standalone=True))
    rid = master_part.relate_to(part, RT.SLIDE_LAYOUT)
    base = part.rels._base_uri
    for r, rel in src.part.rels.items():                    # связи макета (картинка фона) — те же rId
        if rel.reltype == RT.SLIDE_MASTER:
            part.rels._rels[r] = _Relationship(base, r, rel.reltype, RTM.INTERNAL, master_part)
        elif rel.is_external:
            part.rels._rels[r] = _Relationship(base, r, rel.reltype, RTM.EXTERNAL, rel.target_ref)
        else:
            part.rels._rels[r] = _Relationship(base, r, rel.reltype, RTM.INTERNAL, rel.target_part)
    prs_el = deck.prs.part._element
    ids = [int(x.get('id')) for x in prs_el.iter(qn('p:sldMasterId'))]
    for m in deck.prs.slide_masters:
        ids += [int(x.get('id')) for x in m._element.iter(qn('p:sldLayoutId'))]
    lst = master_part._element.find(qn('p:sldLayoutIdLst'))
    if lst is None:
        lst = etree.Element(qn('p:sldLayoutIdLst'))
        master_part._element.find(qn('p:cSld')).addnext(lst)
        if lst.getnext() is not None and _local(lst.getnext()) == 'clrMap':     # порядок: cSld, clrMap, sldLayoutIdLst
            lst.getnext().addnext(lst)
    item = etree.SubElement(lst, qn('p:sldLayoutId'))
    item.set('id', str(max(ids + [2147483648]) + 1))
    item.set(qn('r:id'), rid)
    deck._own_blank = part.slide_layout
    return deck._own_blank


def _missing(ctx, s, err):
    """Файл не найден (план с другого компьютера) — слайд-заглушка с понятной причиной."""
    from .layouts.base import content_slide
    from .nts.shapes import text
    o = s.get('own') or {}
    sl, top, _ = content_slide(ctx, {'title': s.get('title') or 'Свой слайд', 'notes': s.get('notes') or ''})
    name = o.get('name') or 'файл PowerPoint'
    text(sl, C.L, top + 0.2, C.CW, 1.2,
         f'Здесь должен быть слайд {o.get("n") or "?"} из файла «{name}», но {err}. '
         f'Загрузите файл снова кнопкой «＋ Свои слайды» и вставьте слайд.', size=16, color=C.GRAY)
    return sl
