# -*- coding: utf-8 -*-
"""
factcheck.py — СВЕРКА ЧИСЕЛ С ИСТОЧНИКОМ (1.7)
=============================================

У каждого числа на слайдах ищется место в материалах доклада: файл, раздел, предложение или ячейка таблицы
(строка × столбец). Итог по числу:

  ok       — найдено в материалах как есть (с той же или явной единицей: «640 млн руб.» = ячейка 640 в столбце
             «млн руб.» = «640 000 000 руб.»);
  rounded  — найдено, на слайде округлено (12,46 → 12,5; 1 234 567 руб. → 1,2 млн руб.);
  derived  — посчитано из чисел материалов: изменение в %, доля в итоге, разница, сумма строки или столбца
             таблицы; расчёт показывается;
  library  — есть только в библиотеке материалов, а не в материалах доклада (числа на слайдах — только из
             материалов доклада, поэтому такое число тоже нужно проверить);
  missing  — в материалах нет — число нужно проверить; рядом ближайшие похожие числа из материалов.

Годы, даты, время, номера, коды оборудования («ЭЦН-5») и малые счётные числа («3 этапа») не сверяются.

Числа материалов собираются при анализе документа и хранятся в output/cache/facts/<id>.json (meta.facts) —
как фразы для поиска (meta.pool). Числа библиотеки материалов источником не считаются, но ненайденное число
ищется и там — чтобы сказать, откуда оно могло попасть на слайд.

  facts_from_doc(doc)   → данные о числах материалов;   save_facts(данные) → id;   load_facts(id)
  verify(spec)          → {'slides': [...], 'counts': {...}} или {'error': ...}
  notes_block(slide)    → текст «Источники чисел» для заметок (сборка дописывает его, если meta.number_notes
                          не выключено)
"""
import bisect
import hashlib
import json
import math
import re

from .nts import config as C
from .textutil import clean, sentences

FACTS_DIR = C.OUTPUT_DIR / 'cache' / 'facts'
FACTS_RX = re.compile(r'[0-9a-f]{16}')
MAX_FACTS = 60000
MAX_DERIVED = 200000
SMALL = 12                      # целые до 12 без единиц — счётные слова («3 этапа»), не сверяются

_NUM = re.compile(
    r'(?<![\w.,/:№#\-])'                            # не часть слова, кода, даты, времени или номера
    r'([+\-−–]\s?)?'
    r'(\d{1,3}(?:[ \u00a0\u202f]\d{3})+|\d+)'       # 1 234 567 — с пробелами между разрядами
    r'(?:[.,](\d+))?'
    r'(?![\w/:]|[.,]\d)'
    r'(\s?%|\s?(?:тыс\w*|млн|млрд|трлн|миллион\w*|миллиард\w*)\.?)?', re.I)
_MULT = (('трлн', 1e12), ('млрд', 1e9), ('миллиард', 1e9), ('млн', 1e6), ('миллион', 1e6), ('тыс', 1e3))
_WORD = re.compile(r'[а-яёa-z]{4,}', re.I)
_TOTAL = re.compile(r'(?i)^\s*(итог|всего|итого|сумма|total)')
_CODE = re.compile(r'(?i)(?:№|#|\bN|\bNo\.?|\bГОСТ(?:\s?Р)?|\bТУ|\bСТО|\bОСТ|\bISO|\bСНиП|\bСП|\bст\.|\bп\.|\bпп\.|\bрис\.|\bтабл\.|\bстр\.)\s*$')


def mult_of(text):
    """Множитель из единицы измерения: «млн руб.» → 1e6, «тыс. т» → 1e3, иначе 1."""
    t = str(text or '').lower()
    for k, m in _MULT:
        if re.search(r'(?<![а-яё])' + k, t):
            return m
    return 1.0


def numbers(text, unit=''):
    """Числа в тексте → [{'raw', 'v', 'd', 'm', 'p', 'a', 'b', 'skip'}]. unit — единица поля (столбца, диаграммы),
    если в самом тексте её нет. skip: 'year' | 'small' | 'code' | '' (сверять)."""
    s = str(text or '')
    out = []
    um, up = mult_of(unit), '%' in str(unit or '')
    for mo in _NUM.finditer(s):
        sign, ip, dp, suf = mo.group(1) or '', mo.group(2), mo.group(3) or '', (mo.group(4) or '').strip().lower()
        try:
            v = float(re.sub(r'\D', '', ip) + ('.' + dp if dp else ''))
        except ValueError:
            continue
        if not math.isfinite(v):
            continue
        if sign.strip() in ('-', '−', '–'):
            v = -v
        p = suf.startswith('%') or (not suf and up)
        m = mult_of(suf) if suf and not suf.startswith('%') else (um if not suf else 1.0)
        skip = ''
        if not sign and not suf and _CODE.search(s[max(0, mo.start() - 12):mo.start()]):
            skip = 'code'                       # № 725, ГОСТ Р 51858, рис. 3, п. 4.2
        elif not dp and not suf and not re.search(r'\s', ip):
            if 1900 <= abs(v) <= 2100 and not up and um == 1:
                skip = 'year'
            elif abs(v) <= SMALL and not up and um == 1:
                skip = 'small'
        out.append({'raw': mo.group(0).strip(), 'v': v, 'd': len(dp), 'm': m, 'p': bool(p),
                    'a': mo.start(), 'b': mo.end(), 'skip': skip})
    return out


# --------------------------------------------------------------------------------------
# Числа материалов
# --------------------------------------------------------------------------------------
def facts_from_doc(doc, limit=MAX_FACTS):
    """Все числа документа с местом: {'sources': [...], 'facts': [{'v','d','m','p','s','sec','x','t','r','c','lb'}]}.
    x — где: предложение или «Таблица «…»: строка × столбец»; t, r, c — таблица и ячейка (для расчётов)."""
    sources, facts, seen_tables = [], [], set()

    def sid(src):
        src = str(src or '')
        if src not in sources:
            sources.append(src)
        return sources.index(src)

    def add_text(text, src, sec):
        for sent in sentences(text):
            for n in numbers(sent):
                if n['skip'] or len(facts) >= limit:
                    continue
                facts.append({'v': n['v'], 'd': n['d'], 'm': n['m'], 'p': int(n['p']), 's': sid(src), 'sec': sec,
                              'x': sent[:240], 't': '', 'r': -1, 'c': -1, 'raw': n['raw']})

    def add_table(t, src, sec):
        if t is None or t.id in seen_tables:
            return
        seen_tables.add(t.id)
        title = clean(t.title)[:80] or 'таблица'
        for i, row in enumerate(t.rows):
            label = clean(row[t.label_col]) if t.label_col < len(row) else ''
            for j, cell in enumerate(row):
                if j == t.label_col:
                    continue
                col = clean(t.columns[j]) if j < len(t.columns) else f'столбец {j + 1}'
                unit = t.units[j] if j < len(t.units or []) else ''
                for n in numbers(cell, unit or col)[:1]:
                    if n['skip'] == 'year' or len(facts) >= limit:
                        continue
                    facts.append({'v': n['v'], 'd': n['d'], 'm': n['m'], 'p': int(n['p']), 's': sid(t.source or src),
                                  'sec': sec, 'x': f'таблица «{title}»: {label[:60]} × {col[:60]}', 't': t.id, 'r': i,
                                  'c': j, 'lb': label[:60], 'col': col[:60], 'tot': int(bool(_TOTAL.match(label))),
                                  'raw': n['raw']})

    default = (getattr(doc, 'sources', None) or [''])[0]
    for sec in doc.walk():
        src = getattr(sec, 'source', '') or default
        label = clean(sec.title)[:80]
        for b in sec.blocks:
            if b.kind == 'para':
                add_text(b.text, src, label)
            elif b.kind == 'list':
                for it in b.items:
                    add_text(it.text, src, label)
            elif b.kind == 'table':
                add_table(doc.tables.get(b.table_id), src, label)
    for t in (getattr(doc, 'tables', None) or {}).values():         # таблицы вне разделов (листы Excel)
        add_table(t, t.source or default, clean(t.title)[:80])
    return {'v': 1, 'sources': sources, 'facts': facts}


def save_facts(data):
    """Числа материалов → output/cache/facts/<id>.json. Возвращает id (или '' — нечего хранить или ошибка)."""
    if not data or not data.get('facts'):
        return ''
    raw = json.dumps(data, ensure_ascii=False, separators=(',', ':'))
    fid = hashlib.sha1(raw.encode('utf-8')).hexdigest()[:16]
    try:
        FACTS_DIR.mkdir(parents=True, exist_ok=True)
        p = FACTS_DIR / f'{fid}.json'
        if not p.exists():
            tmp = p.with_suffix('.tmp')
            tmp.write_text(raw, encoding='utf-8')
            tmp.replace(p)
        else:
            p.touch()
    except OSError:
        return ''
    return fid


def load_facts(fid):
    if not FACTS_RX.fullmatch(str(fid or '')):
        return None
    try:
        d = json.loads((FACTS_DIR / f'{fid}.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None
    return d if isinstance(d, dict) and isinstance(d.get('facts'), list) else None


def _library_facts():
    """Числа из фраз библиотеки материалов (кэш до её изменения)."""
    try:
        from .library import pool, rev
        r = rev()
    except Exception:                                       # noqa: BLE001 — без библиотеки сверка по материалам
        return []
    if _LIB['rev'] == r:
        return _LIB['facts']
    out = []
    for ph in pool():
        if not ph.get('num'):
            continue
        for n in numbers(ph['t']):
            if not n['skip'] and len(out) < MAX_FACTS:
                out.append({'v': n['v'], 'd': n['d'], 'm': n['m'], 'p': int(n['p']), 'src': ph.get('src') or '',
                            'sec': 'библиотека материалов', 'x': ph['t'][:240], 't': '', 'r': -1, 'c': -1,
                            'raw': n['raw']})
    _LIB.update(rev=r, facts=out)
    return out


_LIB = {'rev': None, 'facts': []}
_INDEX = {}


# --------------------------------------------------------------------------------------
# Поиск числа
# --------------------------------------------------------------------------------------
def _round(x, d):
    k = 10 ** d
    return math.floor(abs(x) * k + 0.5 + 1e-9) / k


def _same(a, b):
    return abs(a - b) <= 1e-9 * max(1.0, abs(a), abs(b))


def _words(text):
    return {w.lower()[:6] for w in _WORD.findall(str(text or ''))}


class Index:
    """Числа материалов, отсортированные для быстрого поиска (как написаны и в базовых единицах) + расчёты."""

    def __init__(self, data, extra=()):
        srcs = data.get('sources') or []
        self.f = []
        for f in data.get('facts') or []:
            if isinstance(f, dict) and isinstance(f.get('v'), (int, float)):
                s = f.get('s')
                self.f.append(dict(f, src=srcs[s] if isinstance(s, int) and 0 <= s < len(srcs) else ''))
        self.f += list(extra)
        self.raw = sorted((abs(f['v']), k) for k, f in enumerate(self.f))
        self.sc = sorted((abs(f['v']) * f['m'], k) for k, f in enumerate(self.f))
        self._der = None

    @staticmethod
    def _near(arr, lo, hi):
        i = bisect.bisect_left(arr, (lo, -1))
        out = []
        while i < len(arr) and arr[i][0] <= hi:
            out.append(arr[i][1])
            i += 1
        return out

    def _pick(self, ks, tok, words):
        """Лучший из подходящих фактов: тот же знак «%», раздел или контекст ближе к слайду."""
        def score(k):
            f = self.f[k]
            return (int(bool(f['p']) == tok['p']) * 2 + len(words & _words(f['x'] + ' ' + f.get('sec', ''))), -k)
        return self.f[max(ks, key=score)] if ks else None

    def match(self, tok, words=frozenset(), derived=True):
        """Число слайда → (статус, факт или None, пояснение). derived=False — без расчётов (данные диаграммы)."""
        v, d, m = abs(tok['v']), tok['d'], tok['m']
        half, eps = 0.5 * 10 ** -d, 1e-9 * max(1.0, v)
        f_ = self.f

        def pct_ok(k, loose=False):
            # «40 %» на слайде — только проценты материалов; как есть допускается и число из диапазона «8–10 %»
            return bool(f_[k]['p']) == tok['p'] or (loose and tok['p'] and '%' in f_[k]['x'])
        same_m = [k for k in self._near(self.raw, v - eps, v + eps)
                  if (m == 1 or f_[k]['m'] in (1, m)) and pct_ok(k, True)]
        if same_m:
            return 'ok', self._pick(same_m, tok, words), ''
        tv = v * m
        scaled = [k for k in self._near(self.sc, tv - eps * m, tv + eps * m) if pct_ok(k)]
        if scaled:
            return 'ok', self._pick(scaled, tok, words), ''
        rnd = [k for k in self._near(self.raw, v - half - eps, v + half + eps)
               if f_[k]['d'] > d and _same(_round(f_[k]['v'], d), v) and (m == 1 or f_[k]['m'] in (1, m)) and pct_ok(k)]
        if rnd:
            return 'rounded', self._pick(rnd, tok, words), ''
        rs = [k for k in self._near(self.sc, (v - half) * m - eps * m, (v + half) * m + eps * m)
              if f_[k]['m'] != m and _same(_round(abs(f_[k]['v']) * f_[k]['m'] / m, d), v) and pct_ok(k)]
        if rs:
            return 'rounded', self._pick(rs, tok, words), ''
        der = self._derived_match(tok, words) if derived else None
        if der:
            return 'derived', der[0], der[1]
        return 'missing', None, ''

    def similar(self, tok, words=frozenset(), n=2):
        """Похожие числа материалов (±15 %, та же единица) — подсказка к ненайденному числу.
        → [(факт, то же число в записи слайда — для кнопки «Заменить»)]."""
        v, m = abs(tok['v']), tok['m']
        if v == 0:
            return []
        cand = {}
        for k in self._near(self.raw, v * 0.85, v * 1.15):          # как написано, единица та же или не указана
            f = self.f[k]
            if (m == 1 or f['m'] in (1, m)) and bool(f['p']) == tok['p']:
                cand[k] = (abs(f['v']), f['d'])
        for k in self._near(self.sc, v * m * 0.85, v * m * 1.15):   # в базовых единицах (руб. ↔ млн руб.)
            f = self.f[k]
            if k not in cand and bool(f['p']) == tok['p']:
                cand[k] = (abs(f['v']) * f['m'] / m, max(tok['d'], 1 if f['m'] != m else f['d']))

        def key(k):
            f = self.f[k]
            return (-len(words & _words(f['x'] + ' ' + f.get('sec', ''))), abs(cand[k][0] - v))
        out, seen = [], set()
        for k in sorted(cand, key=key):
            val, d = cand[k]
            fix = f'{-val if tok["v"] < 0 else val:,.{d}f}'.replace(',', '\u00a0').replace('.', ',')
            if fix not in seen:
                seen.add(fix)
                out.append((self.f[k], fix))
            if len(out) >= n:
                break
        return out

    # расчёты из чисел материалов: изменение, доля, разница, суммы — для чисел, которых нет как есть
    def _derived(self):
        if self._der is not None:
            return self._der
        pct, absl = [], []

        def add(lst, x, how, f):
            if math.isfinite(x) and len(lst) < MAX_DERIVED:
                lst.append((abs(x), how, f))

        def pairs(a, b, la, lb, f):
            va, vb = a['v'], b['v']
            if va:
                add(pct, (vb - va) / abs(va) * 100, f'изменение {lb} к {la}: ({_fmt(vb)} − {_fmt(va)}) / {_fmt(va)}', f)
                add(pct, vb / va * 100, f'{lb} к {la}: {_fmt(vb)} / {_fmt(va)}', f)
            add(absl, vb - va, f'разница {lb} и {la}: {_fmt(vb)} − {_fmt(va)}', f)

        tables = {}
        for f in self.f:
            if f.get('t'):
                tables.setdefault((f.get('src'), f['t']), {})[(f['r'], f['c'])] = f
        for grid in tables.values():
            rows = sorted({r for r, _ in grid})
            cols = sorted({c for _, c in grid})
            for r in rows:
                cells = [grid[(r, c)] for c in cols if (r, c) in grid]
                for a, b in zip(cells, cells[1:]):
                    pairs(a, b, a.get('col', ''), b.get('col', ''), b)
                if len(cells) > 1:
                    add(absl, sum(c['v'] for c in cells), f'сумма по строке «{cells[0].get("lb", "")}»', cells[0])
            for c in cols:
                cells = [grid[(r, c)] for r in rows if (r, c) in grid]
                body = [x for x in cells if not x.get('tot')]
                for a, b in zip(body, body[1:]):
                    pairs(a, b, a.get('lb', ''), b.get('lb', ''), b)
                tot = next((x for x in cells if x.get('tot')), None)
                total = tot['v'] if tot else sum(x['v'] for x in body)
                if len(body) > 1:
                    add(absl, sum(x['v'] for x in body), f'сумма по столбцу «{body[0].get("col", "")}»', body[0])
                    if total:
                        for x in body:
                            add(pct, x['v'] / total * 100, f'доля «{x.get("lb", "")}» в итоге: {_fmt(x["v"])} / {_fmt(total)}', x)
        by_sent = {}
        for f in self.f:
            if not f.get('t'):
                by_sent.setdefault((f.get('src'), f['x']), []).append(f)
        for fs in by_sent.values():
            fs = fs[:6]
            for i, a in enumerate(fs):
                for b in fs[i + 1:]:
                    if a['m'] == b['m'] and a['p'] == b['p']:
                        pairs(a, b, _fmt(a['v']), _fmt(b['v']), a)
        self._der = (sorted((x, i) for i, (x, _, _) in enumerate(pct)), pct,
                     sorted((x, i) for i, (x, _, _) in enumerate(absl)), absl)
        return self._der

    def _derived_match(self, tok, words):
        sp, pct, sa, absl = self._derived()
        v, d = abs(tok['v']), tok['d']
        half, eps = 0.5 * 10 ** -d, 1e-9 * max(1.0, v)
        arr, lst = (sp, pct) if tok['p'] else (sa, absl)
        cands = [lst[i] for i in self._near(arr, v - half - eps, v + half + eps) if _same(_round(lst[i][0], d), v)]
        if not cands:
            return None
        best = max(cands, key=lambda c: len(words & _words(c[2]['x'] + ' ' + c[1] + ' ' + c[2].get('sec', ''))))
        overlap = len(words & _words(best[2]['x'] + ' ' + best[1] + ' ' + best[2].get('sec', '')))
        if overlap == 0 and len(cands) > 1:                 # случайное совпадение с одним из многих расчётов — не засчитывать
            return None
        return best[2], best[1]


def _fmt(v):
    s = f'{v:,.4f}'.rstrip('0').rstrip('.').replace(',', ' ').replace('.', ',')
    return s.replace(' ', '\u00a0')


def index_for(meta):
    """Index для презентации (meta.facts) или None — материалы не сохранены (план без анализа, кэш очищен)."""
    fid = str((meta or {}).get('facts') or '')
    if fid not in _INDEX:
        data = load_facts(fid)
        if not data:
            return None
        if len(_INDEX) > 6:
            _INDEX.clear()
        _INDEX[fid] = Index(data)
    return _INDEX[fid]


def library_index():
    """Index чисел библиотеки материалов (для подсказки «есть только в библиотеке») или None."""
    lib = _library_facts()
    if not lib:
        return None
    if _LIB.get('index_rev') != _LIB['rev']:
        _LIB.update(index=Index({'facts': []}, lib), index_rev=_LIB['rev'])
    return _LIB['index']


# --------------------------------------------------------------------------------------
# Числа слайда
# --------------------------------------------------------------------------------------
SKIP_KEYS = {'layout', 'notes', 'alts', 'alt_index', 'alt_label', 'images', 'icon', 'found', 'found_n', 'pic_base',
             'example', 'section', 'illustration', 'categories', 'number_format', 'type', 'unit', 'pool', 'facts',
             'color', 'id', 'icon_shape', 'effect', 'tone', 'svg', 'upload', 'picture', 'caption_by', 'check'}
FIELD = {'title': 'заголовок', 'subtitle': 'подзаголовок', 'conclusion': 'вывод', 'center': 'центр', 'items': 'пункт',
         'rows': 'таблица, строка', 'insights': 'подпись диаграммы', 'left': 'слева', 'right': 'справа',
         'text': 'текст', 'value': 'число', 'columns': 'заголовок таблицы'}


def _label(path):
    parts = []
    for i, p in enumerate(path):
        if isinstance(p, int):
            if parts:
                parts[-1] += f' {p + 1}'
        elif p in FIELD and (i == 0 or p not in ('text', 'title')):
            parts.append(FIELD[p])
    return ', '.join(parts) or 'слайд'


def slide_numbers(s):
    """Числа слайда → [{'path', 'field', 'tok', 'ctx'}]: path — где лежит текст в слайде (для замены)."""
    out = []

    def text_tokens(text, path, unit=''):
        for t in numbers(text, unit):
            if t['skip']:
                continue
            a, b = max(0, t['a'] - 40), min(len(text), t['b'] + 40)
            out.append({'path': path, 'field': _label(path), 'tok': t,
                        'ctx': ('…' if a else '') + text[a:b].strip() + ('…' if b < len(text) else '')})

    def walk(x, path):
        if isinstance(x, str):
            text_tokens(x, path)
        elif isinstance(x, list):
            for i, y in enumerate(x):
                walk(y, path + [i])
        elif isinstance(x, dict):
            if 'value' in x and isinstance(x.get('value'), (str, int, float)) and 'unit' in x:   # показатель: 640 + «млн руб.»
                text_tokens(str(x['value']), path + ['value'], str(x.get('unit') or ''))
            for k, y in x.items():
                if k in SKIP_KEYS or k == 'value' and 'unit' in x:
                    continue
                if k == 'chart' and isinstance(y, dict):
                    chart(y, path + ['chart'])
                    continue
                walk(y, path + [k])

    def chart(ch, path):
        unit = str(ch.get('unit') or '')
        cats = ch.get('categories') or []
        for si, sr in enumerate(ch.get('series') or []):
            if not isinstance(sr, dict):
                continue
            for vi, val in enumerate(sr.get('values') or []):
                if not isinstance(val, (int, float)) or isinstance(val, bool) or not math.isfinite(val):
                    continue
                txt = f'{val:.6f}'.rstrip('0').rstrip('.')
                d = len(txt.split('.')[1]) if '.' in txt else 0
                tok = {'raw': _fmt(val) + (f' {unit}' if unit else ''), 'v': float(val), 'd': d, 'm': mult_of(unit),
                       'p': '%' in unit, 'a': 0, 'b': 0, 'skip': ''}
                cat = str(cats[vi]) if vi < len(cats) else ''
                out.append({'path': path + ['series', si, 'values', vi], 'tok': tok,
                            'field': f'диаграмма: «{sr.get("name") or ""}»' + (f', {cat}' if cat else ''),
                            'ctx': f'{sr.get("name") or ""} — {cat}: {_fmt(val)} {unit}'.strip()})
        for k in ('title', 'insights'):
            if ch.get(k):
                walk(ch[k], path + [k])

    for k, y in s.items():
        if k in SKIP_KEYS:
            continue
        if k == 'chart' and isinstance(y, dict):
            chart(y, ['chart'])
        else:
            walk(y, [k])
    return out


def _plain(t):
    """Текст без типографики (неразрывные пробелы расставляются позже) — для сравнения подписей."""
    return re.sub(r'[\s\u00a0\u202f]+', ' ', str(t or '')).strip()


def _own_insights(s):
    """Подписи, которые конструктор посчитал бы по данным диаграммы слайда (итоги, рост, доли)."""
    ch = s.get('chart')
    if not isinstance(ch, dict) or not s.get('insights'):
        return set()
    try:
        from .insights import make_insights
        return {_plain(t) for t in make_insights(ch) + make_insights(ch, 12)}
    except Exception:                                       # noqa: BLE001
        return set()


def _where(f):
    if not f:
        return {}
    return {'src': f.get('src') or '', 'sec': f.get('sec') or '', 'where': f.get('x') or '', 'found': f.get('raw') or ''}


def check_slide(s, idx, lib=None):
    """Сверка чисел одного слайда → [{'raw', 'field', 'ctx', 'path', 'status', 'src', 'sec', 'where', 'how', 'similar'}].
    lib — Index библиотеки материалов: где искать ненайденное число."""
    words = _words(' '.join(str(s.get(k) or '') for k in ('title', 'subtitle', 'section', 'conclusion')))
    res, seen = [], set()
    own = _own_insights(s)
    for n in slide_numbers(s):
        tok = n['tok']
        w = words | _words(n['ctx'])
        p = n['path']
        if len(p) >= 2 and p[0] == 'insights' and isinstance(p[1], int) and p[1] < len(s['insights']) \
                and _plain(s['insights'][p[1]]) in own:  # подпись, которую конструктор посчитал по данным диаграммы
            status, f, how = 'derived', None, 'посчитано по данным диаграммы этого слайда'
        else:
            status, f, how = idx.match(tok, w, derived='series' not in p)   # данные диаграммы — только как есть
            if status == 'missing' and lib is not None:
                st2, f2, _ = lib.match(tok, w, derived=False)
                if st2 in ('ok', 'rounded'):
                    status, f = 'library', f2
        key = (tok['raw'], status, n['field'])
        if key in seen:
            continue
        seen.add(key)
        r = dict({'raw': tok['raw'], 'field': n['field'], 'ctx': n['ctx'], 'path': n['path'], 'status': status,
                  'how': how}, **_where(f))
        if status == 'missing':
            r['similar'] = [dict(_where(x), fix=fix) for x, fix in idx.similar(tok, w)]
        res.append(r)
    return res


def verify(spec):
    """Сверка всех слайдов презентации. → {'slides': [{'i', 'title', 'numbers': [...], 'counts'}], 'counts', 'facts'}
    или {'error': …}, если материалы доклада не сохранены."""
    meta = (spec or {}).get('meta') or {}
    idx = index_for(meta)
    if idx is None:
        return {'error': 'Материалы доклада для сверки не найдены: план загружен из файла или прошло больше недели. '
                         'Загрузите документы заново — числа сверятся с ними.'}
    out, total = [], {'ok': 0, 'rounded': 0, 'derived': 0, 'library': 0, 'missing': 0}
    lib = library_index()
    for i, s in enumerate((spec or {}).get('slides') or []):
        if not isinstance(s, dict) or s.get('layout') in ('title', 'end', 'agenda', 'own'):   # свой слайд — как в файле
            continue
        nums = check_slide(s, idx, lib)
        if not nums:
            continue
        cnt = {k: sum(1 for n in nums if n['status'] == k) for k in total}
        for k in total:
            total[k] += cnt[k]
        out.append({'i': i, 'title': str(s.get('title') or ''), 'numbers': nums, 'counts': cnt})
    return {'slides': out, 'counts': total, 'facts': len(idx.f)}


def notes_block(s, idx, limit=10):
    """«Источники чисел» для заметок слайда (найденные и посчитанные числа; ненайденные — с просьбой проверить)."""
    lines, seen = [], set()
    for n in check_slide(s, idx, library_index()):
        if n['raw'] in seen:
            continue
        seen.add(n['raw'])
        src = ', '.join(x for x in (f'«{n["sec"]}»' if n.get('sec') else '', n.get('src') or '') if x)
        if n['status'] == 'ok':
            lines.append(f'• {n["raw"]} — {src}: {n["where"][:160]}')
        elif n['status'] == 'rounded':
            lines.append(f'• {n["raw"]} — округлено из {n["found"]}; {src}: {n["where"][:140]}')
        elif n['status'] == 'derived':
            lines.append(f'• {n["raw"]} — посчитано: {n["how"]}' + (f'; {src}' if src else ''))
        elif n['status'] == 'library':
            lines.append(f'• {n["raw"]} — есть только в библиотеке материалов ({n.get("src") or ""}), проверьте')
        else:
            lines.append(f'• {n["raw"]} — в материалах не найдено, проверьте')
        if len(lines) >= limit:
            break
    return ('Источники чисел:\n' + '\n'.join(lines)) if lines else ''
