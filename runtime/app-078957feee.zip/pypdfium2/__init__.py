# -*- coding: utf-8 -*-
"""
pypdfium2 для телефона — облегчённая замена библиотеки pypdfium2 в мобильной версии конструктора.

В браузере телефона нет «настоящего» pypdfium2 (он вызывает PDFium из Windows/Linux через ctypes).
Здесь тот же PDFium работает в WebAssembly (пакет @embedpdf/pdfium, файл vendor/pdfium.wasm), а этот
модуль даёт движку конструктора ту часть интерфейса pypdfium2, которую использует чтение PDF
(engine/readers/pdf_reader.py): документ, страницы, символы текста, линии, выделения и рисунки.

Чтобы не вызывать JavaScript на каждый символ, данные страницы забираются одним вызовом
(js.znPdf.*, runtime/pdf-bridge.js), а функции pypdfium2.raw читают их уже в Python.
"""
import json
import types

from . import raw as _raw

__all__ = ['PdfDocument', 'PdfPage', 'PdfTextPage', 'PdfObject', 'PdfImage', 'PdfiumError', 'raw']
raw = _raw


class PdfiumError(RuntimeError):
    def __init__(self, msg, err_code=None):
        super().__init__(msg)
        self.err_code = err_code


class PdfiumUnavailable(RuntimeError):
    """Модуль PDFium не загрузился (первый запуск без интернета) — это не «повреждённый PDF»."""


def _bridge():
    try:
        import js
        b = js.znPdf
    except Exception:                                   # noqa: BLE001
        b = None
    if b is None or not b.ready():
        raise PdfiumUnavailable('модуль чтения PDF не загрузился — подключитесь к интернету и добавьте файл ещё раз')
    return b


def _bytes(proxy):
    """Uint8Array из JavaScript → bytes."""
    try:
        return proxy.to_bytes()
    finally:
        try:
            proxy.destroy()
        except Exception:                               # noqa: BLE001
            pass


ERRORS = {1: 'неизвестная ошибка', 2: 'файл не найден или не открывается', 3: 'это не PDF или файл повреждён',
          4: 'нужен пароль', 5: 'неподдерживаемая защита', 6: 'ошибка страницы'}


class PdfDocument:
    def __init__(self, input, password=None, autoclose=False):   # noqa: A002 — как в pypdfium2
        if isinstance(input, (bytes, bytearray, memoryview)):
            data = bytes(input)
        elif hasattr(input, 'read'):
            data = input.read()
        else:
            with open(str(input), 'rb') as f:
                data = f.read()
        from pyodide.ffi import to_js
        b = _bridge()
        r = b.open(to_js(data), password or None)
        if r <= 0:
            code = -int(r) or 1
            raise PdfiumError(f'Failed to load document (PDFium: {ERRORS.get(code, code)}).', err_code=code)
        self._id = int(r)
        self._n = int(b.pageCount(self._id))
        self._b = b

    def __len__(self):
        return self._n

    def __iter__(self):
        for i in range(self._n):
            yield self[i]

    def __getitem__(self, i):
        if i < 0:
            i += self._n
        if not 0 <= i < self._n:
            raise IndexError(i)
        return PdfPage(self, i)

    get_page = __getitem__

    def get_metadata_dict(self, skip_empty=False):
        d = json.loads(str(self._b.meta(self._id)))
        return {k: v for k, v in d.items() if v} if skip_empty else d

    def close(self):
        if self._id:
            self._b.close(self._id)
            self._id = 0

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:                               # noqa: BLE001
            pass


class PdfPage:
    def __init__(self, pdf, index):
        self.pdf, self.index = pdf, index
        self._b, self._doc = pdf._b, pdf._id
        w, h = json.loads(str(self._b.pageSize(self._doc, index)))
        self._size = (float(w), float(h))
        self._paths = self._annots = self._images = None
        self.raw = self                                 # функции raw получают страницу целиком

    def get_size(self):
        return self._size

    def get_width(self):
        return self._size[0]

    def get_height(self):
        return self._size[1]

    def get_textpage(self):
        return PdfTextPage(self)

    def _load(self, what):
        return json.loads(str(getattr(self._b, what)(self._doc, self.index)))

    def get_objects(self, filter=None, max_depth=2):    # noqa: A002 — как в pypdfium2
        want = set(filter or (_raw.FPDF_PAGEOBJ_PATH, _raw.FPDF_PAGEOBJ_IMAGE))
        if _raw.FPDF_PAGEOBJ_PATH in want:
            if self._paths is None:
                self._paths = self._load('pagePaths')
            for p in self._paths:
                yield PdfObject(self, _raw.FPDF_PAGEOBJ_PATH, p)
        if _raw.FPDF_PAGEOBJ_IMAGE in want:
            if self._images is None:
                self._images = self._load('pageImages')
            for p in self._images:
                yield PdfImage(self, _raw.FPDF_PAGEOBJ_IMAGE, p)

    def annots(self):
        if self._annots is None:
            self._annots = self._load('pageAnnots')
        return self._annots

    def close(self):
        if self._b is not None:
            self._b.closePage(self._doc, self.index)
            self._b = None


class PdfTextPage:
    """Символы страницы: по 18 чисел на символ (см. pdf-bridge.js) и список шрифтов."""
    STRIDE = 18

    def __init__(self, page):
        res = page._b.pageText(page._doc, page.index)
        try:
            arr = res.data
            self.data = arr.to_py().tolist() if hasattr(arr, 'to_py') else list(arr)
            try:
                arr.destroy()
            except Exception:                           # noqa: BLE001
                pass
            self.fonts = [(n.encode('utf-8'), int(f)) for n, f in json.loads(str(res.fonts))]
            self.n = int(res.n)
        finally:
            try:
                res.destroy()
            except Exception:                           # noqa: BLE001
                pass
        self.raw = self

    def count_chars(self):
        return self.n

    def get_text_range(self, index=0, count=-1):
        end = self.n if count < 0 else min(self.n, index + count)
        return ''.join(chr(int(self.data[i * self.STRIDE])) for i in range(index, end)
                       if 0 < int(self.data[i * self.STRIDE]) < 0x110000)

    def close(self):
        self.data = []


class PdfObject:
    def __init__(self, page, type_, info):
        self.page, self.type, self._info = page, type_, info
        self.raw = info
        self.level = 0


class PdfImage(PdfObject):
    def get_metadata(self):
        md = self._info.get('md') or [0, 0, 0, 0, 0, 0, 0, -1]
        return types.SimpleNamespace(width=md[1], height=md[2], horizontal_dpi=md[3], vertical_dpi=md[4],
                                     bits_per_pixel=md[5], colorspace=md[6], marked_content_id=md[7])

    def get_filters(self, skip_simple=False):
        f = list(self._info.get('f') or [])
        if skip_simple:
            f = [x for x in f if x not in ('ASCIIHexDecode', 'ASCII85Decode', 'RunLengthDecode', 'FlateDecode', 'LZWDecode')]
        return f

    def get_data(self, decode_simple=False):
        p = self.page
        return _bytes(p._b.imageData(p._doc, p.index, self._info['k'], bool(decode_simple)))

    def get_bitmap(self, render=False, scale_to_original=True):
        p = self.page
        r = p._b.imageBitmap(p._doc, p.index, self._info['k'])
        if r is None:
            raise PdfiumError('Не удалось получить рисунок из PDF.')
        try:
            return _Bitmap(int(r.w), int(r.h), int(r.stride), int(r.fmt), _bytes(r.data))
        finally:
            try:
                r.destroy()
            except Exception:                           # noqa: BLE001
                pass


class _Bitmap:
    MODES = {1: ('L', 'L'), 2: ('RGB', 'BGR'), 3: ('RGB', 'BGRX'), 4: ('RGBA', 'BGRA')}

    def __init__(self, w, h, stride, fmt, data):
        self.width, self.height, self.stride, self.format, self.buffer = w, h, stride, fmt, data

    def to_pil(self):
        from PIL import Image
        mode, rawmode = self.MODES.get(self.format, ('RGBA', 'BGRA'))
        return Image.frombuffer(mode, (self.width, self.height), self.buffer, 'raw', rawmode, self.stride, 1).copy()

    def close(self):
        self.buffer = b''
